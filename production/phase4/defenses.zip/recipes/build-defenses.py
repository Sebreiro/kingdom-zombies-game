import io,json,hashlib,math
from PIL import Image

def sha(b):return hashlib.sha256(b).hexdigest()
def dump(o):return (json.dumps(o,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()
def png(im):
 out=io.BytesIO();im.save(out,format='PNG',compress_level=9);return out.getvalue()
def clean(im):
 im=im.convert('RGBA');im.putalpha(im.getchannel('A').point(lambda a:255 if a>=128 else 0));im.putdata([(r,g,b,a) if a else (0,0,0,0) for r,g,b,a in im.get_flattened_data()]);return im
def image(d,n):return Image.open(io.BytesIO(d[n])).convert('RGBA')
def damage(im,level,fragment):
 im=im.copy();w,h=im.size;cuts=[]
 for cx,cy in [(w//3,h//2)]+([(2*w//3,2*h//3)] if level==2 else []):
  radius=max(2,min(w,h)//(9 if level==1 else 6));cuts.append([cx,cy,radius])
  for yy in range(max(0,cy-radius),min(h,cy+radius+1)):
   for xx in range(max(0,cx-radius),min(w,cx+radius+1)):
    if abs(xx-cx)+abs(yy-cy)<=radius and ((xx+yy)%3!=0 or level==2):im.putpixel((xx,yy),(0,0,0,0))
  patch=fragment.crop(fragment.getbbox());patch=patch.resize((max(2,radius),max(2,radius)),Image.Resampling.NEAREST)
  im.alpha_composite(patch,(min(w-patch.width,cx+1),min(h-patch.height,cy+1)))
 return clean(im),cuts
def rubble(im):
 w,h=im.size;out=Image.new('RGBA',(w,h));pieces=[]
 for i,(x,y) in enumerate([(0,h//2),(w//3,h//3),(2*w//3,h//2)]):
  box=[x,y,min(w,x+max(5,w//3)),min(h,y+max(6,h//4))];part=im.crop(box);part=part.transpose(Image.Transpose.ROTATE_90 if i%2 else Image.Transpose.FLIP_TOP_BOTTOM)
  at=[min(w-part.width,i*w//3),h-part.height];out.alpha_composite(part,at);pieces.append({'box':box,'at':at,'transform':'rotate90' if i%2 else 'flip-y'})
 return out,pieces
def build(data):
 parts=[];images={};derived={}
 def add(key,im,origin,operations):
  im=clean(im);b=png(im);member='parts/'+key+'.png';derived[member]=b;images[key]=im
  parts.append({'key':key,'member':member,'origin':origin,'operations':operations,'sha256':sha(b),'worldSize':list(im.size),'density':1,'rgbaSha256':sha(im.tobytes()),'visiblePixels':sum(bool(a) for a in im.getchannel('A').tobytes())})
  return im
 selected=json.loads(data['sources/selected.json']);lookup={r['name']:r for r in selected}
 def donor(name):return image(data,'sources/common/'+lookup[name]['member'])
 fragment=clean(donor('wall_wreck_1_s028_040'));metal=image(data,'sources/main/parts/metal-fragment.png')
 add('wood-fragment',fragment,'sources/common/'+lookup['wall_wreck_1_s028_040']['member'],[{'op':'binary-alpha','threshold':128}])
 add('metal-fragment',metal,'sources/main/parts/metal-fragment.png',[{'op':'binary-alpha','threshold':128}])
 bases=[('wall-1','wall_1'),('wall-2','wall_2'),('tower-1','tower_2')]
 for key,name in bases:add(key,donor(name),'sources/common/'+lookup[name]['member'],[{'op':'binary-alpha','threshold':128}])
 for key,size in [('wall-3',[48,48]),('tower-2',[72,64]),('tower-3',[96,80])]:
  member='masters/'+key+'.png';im=clean(image(data,member));box=list(im.getbbox());im=im.crop(box).resize(size,Image.Resampling.NEAREST)
  add(key,im,member,[{'op':'binary-alpha','threshold':128},{'op':'crop','box':box},{'op':'nearest','size':size}])
 tiers=[]
 for index,key in enumerate(['wall-1','wall-2','wall-3','tower-1','tower-2','tower-3']):
  material=['wood','reinforced-wood','metal-reinforced'][index%3];base=images[key];fragmentKey='metal-fragment' if index%3==2 else 'wood-fragment';frag=images[fragmentKey]
  states={'intact':key}
  for level,state in [(1,'damage-light'),(2,'damage-heavy')]:
   im,cuts=damage(base,level,frag);k=key+'-'+state;add(k,im,'parts/'+key+'.png',[{'op':'localized-damage','level':level,'diamondCuts':cuts,'fragment':fragmentKey}]);states[state]=k
  im,pieces=rubble(base);add(key+'-ruin',im,'parts/'+key+'.png',[{'op':'matched-rubble','pieces':pieces}]);states['destroyed']=key+'-ruin'
  tiers.append({'id':'BL-'+str(index+4).zfill(2),'kind':'wall' if index<3 else 'tower','tier':index%3+1,'material':material,'states':states,'frame':key+'-frame','damagedFrame':key+'-frame-damaged','bakedGuardCount':0,'fragments':[fragmentKey],'footprint':list(base.size),'previousTierRuin':True})
 scaffold=clean(donor('scaffolds_03'));fill=scaffold;frames=[]
 footprints=[('main-'+str(i),[160,88]) for i in range(1,4)]+[(r['kind']+'-'+str(r['tier']),r['footprint']) for r in tiers]
 for key,size in footprints:
  frame=Image.new('RGBA',size);placements=[]
  for x in range(0,size[0],32):
   for y in range(max(0,size[1]-32),-32,-32):
    source=scaffold;box=[0,max(0,-y),min(32,size[0]-x),min(32,size[1]-y)];at=[x,max(0,y)];frame.alpha_composite(source.crop(box),at);placements.append({'source':'scaffolds_03','box':box,'at':at})
  add(key+'-frame',frame,'sources/selected.json',[{'op':'scaffold-tiles','placements':placements,'size':size}]);damaged,cuts=damage(frame,2,fragment);add(key+'-frame-damaged',damaged,'parts/'+key+'-frame.png',[{'op':'localized-damage','level':2,'diamondCuts':cuts,'fragment':'wood-fragment'}]);frames.append({'structure':key,'footprint':size,'frame':key+'-frame','damagedFrame':key+'-frame-damaged','tileScale':1})
 for key,name in [('site-wall','wall_0'),('site-tower','tower_0b')]:add(key,donor(name),'sources/common/'+lookup[name]['member'],[{'op':'binary-alpha','threshold':128}])
 atlas=Image.new('RGBA',(1024,512));x=y=1;rowHeight=0
 for p in parts:
  im=images[p['key']]
  if x+im.width+1>atlas.width:x=1;y+=rowHeight+1;rowHeight=0
  assert y+im.height+1<atlas.height
  atlas.alpha_composite(im,(x,y));p['atlasRect']=[x,y,im.width,im.height];x+=im.width+1;rowHeight=max(rowHeight,im.height)
 atlasBytes=png(atlas);derived['defenses.png']=atlasBytes
 pack={'schemaVersion':1,'id':'defenses','version':1,'logicalPixelsPerWorldPixel':1,'stylePrecedence':'D-13 LOW-RESOLUTION OVERRIDES older richer sprite skill','atlas':{'path':'res://assets/buildings/defenses.png','size':list(atlas.size),'sha256':sha(atlasBytes),'rgbaSha256':sha(atlas.tobytes()),'alphaValues':[0,255]},'tiers':tiers,'parts':parts,'frames':frames,'siteStates':['unbuilt','available','tree-blocked','portal-blocked','main-tier-blocked','unaffordable','new-frame','damaged-unfinished','intact','damage-light','damage-heavy','upgrade-paid','upgrade-complete','repair-paid','repair-complete','unsafe-waiting','no-worker-waiting','destroyed','rebuild-paid','rebuild-complete','restore-destroyed','restore-upgrade'],'visibility':{'intactAbove':0.75,'lightDamageAbove':0.4,'heavyDamageAbove':0,'newFrameMaxHealthFraction':0.25,'workOverlayMaxCoverage':0.48,'oldFunctionalTierUntilProgress':1,'rubblePreservesCompletedTier':True,'noGuardLoot':True,'frameTileScale':1},'sources':json.loads(data['sources/lineage.json']),'recipe':{'member':'recipes/build-defenses.py','sha256':sha(data['recipes/build-defenses.py'])},'acceptance':{'visual':'pending','owner':'04-32/04-33','humanApproval':None,'completedObligations':[]}}
 return pack,derived
