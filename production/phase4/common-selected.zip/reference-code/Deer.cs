using System;
using System.Collections;
using Coatsink.Common;
using UnityEngine;

public class Deer : MonoBehaviour, IAuthorityReq, IAnimReceiver, IRPCable, IPushable, IPetrifiable
{
	private class State
	{
		public const int Wander = 0;

		public const int Look = 1;

		public const int Eat = 2;

		public const int WalkAway = 3;

		public const int RunAway = 4;

		public const int FollowPlayer = 5;

		public const int Petrified = 6;

		public static string[] StateToName = new string[7] { "Wander", "Look", "Eat", "WalkAway", "RunAway", "FollowPlayer", "Petrified" };
	}

	private static readonly int APEat = Animator.StringToHash("Eating");

	[SerializeField]
	private int numCoinsDropped = 2;

	[SerializeField]
	private CurrencyType _yieldCurrencyType;

	[SerializeField]
	private Vector2 _coinDropForce;

	[Header("Movement")]
	[SerializeField]
	private float walkSpeed = 0.5f;

	[SerializeField]
	private float runSpeed = 2.75f;

	[SerializeField]
	private float _playerFollowOffset = 3f;

	[Header("Threat")]
	[SerializeField]
	private float alertRange = 6f;

	[SerializeField]
	private float threatRange = 4f;

	[SerializeField]
	private float chaseDistance = 2.5f;

	[SerializeField]
	private AudioEmitter attractedToPlayerSound;

	[SerializeField]
	private GameObject heartsParticles;

	private Mover _mover;

	private Animator _animator;

	private AnimationSync _animSync;

	private Damageable _damageable;

	private Petrifiable _petrifiable;

	private Scanner _alertScanner;

	private Scanner _threatScanner;

	private GameObject _threat;

	private FloatRange _habitat;

	private bool _habitatSet;

	private StateMachine _fsm;

	private SpriteRendererFX _renderFX;

	private SpriteRenderer _spriteRenderer;

	protected CRPCHeader parentHeaderRef;

	private int _spawnHeartsIndex = -1;

	public GameObject GetGO => base.gameObject;

	public bool isRunningAway { get; private set; }

	public void Awake()
	{
		_mover = Require.Component<Mover>(this);
		_animator = Require.Component<Animator>(this);
		_damageable = Require.Component<Damageable>(this);
		_spriteRenderer = GetComponent<SpriteRenderer>();
		_renderFX = GetComponent<SpriteRendererFX>();
		_animSync = GetComponent<AnimationSync>();
		_petrifiable = Require.Component<Petrifiable>(this);
		_petrifiable.Init(this, _damageable);
		_alertScanner = new Scanner(base.transform, LayerMask.GetMask("Player", "Citizens"), alertRange, 2f);
		_threatScanner = new Scanner(base.transform, LayerMask.GetMask("Player", "Citizens"), threatRange, 3f);
		_threatScanner.SetTags("Player", "Archer");
		_fsm = new StateMachine(0, this);
		_fsm.AddState(0, null, Wander(), 1);
		_fsm.AddState(1, null, Look(), 0);
		_fsm.AddState(2, null, Eat(), 1);
		_fsm.AddState(3, null, WalkAway(), 1);
		_fsm.AddState(4, null, RunAway(), 3);
		_fsm.AddState(5, null, FollowPlayer(), 1);
		_fsm.AddState(6, null, PetrifiedRoutine(), 1, interruptable: false);
		_fsm.AddTransition(0, ShouldRunAway, 4, canInterrupt: true);
		_fsm.AddTransition(1, ShouldRunAway, 4, canInterrupt: true);
		_fsm.AddTransition(2, ShouldRunAway, 4, canInterrupt: true);
		_fsm.AddTransition(3, ShouldRunAway, 4, canInterrupt: true);
		_fsm.AddTransition(0, ShouldFollowPlayer, 5, canInterrupt: true);
		_fsm.AddTransition(2, ShouldFollowPlayer, 5);
		_fsm.AddTransition(1, ShouldFollowPlayer, 5, canInterrupt: true);
		_fsm.AddTransition(1, ShouldEat, 2);
		_fsm.AddTransition(1, ShouldWalkAway, 3);
		_fsm.AddTransition(null, IsPetrified, 6, canInterrupt: true);
		Gradient deerColorsA = BiomeData.Current.DeerColorsA;
		Gradient deerColorsB = BiomeData.Current.DeerColorsB;
		Color recolorA = deerColorsA.Evaluate(UnityEngine.Random.Range(0f, deerColorsA.colorKeys[^1].time));
		Color recolorB = deerColorsB.Evaluate(UnityEngine.Random.Range(0f, deerColorsA.colorKeys[^1].time));
		_renderFX.recolorA = recolorA;
		_renderFX.recolorB = recolorB;
	}

	public void Start()
	{
		RegisterWithNetworkBoss();
		HandleAuthorityChange(NetworkBigBoss.HasWorldAuth);
	}

	private void OnEnable()
	{
		_fsm.GoToState(0);
		_damageable.OnReceiveDamage += HandleOnReceiveDamage;
		_damageable.OnDeath += HandleOnDeath;
		_habitatSet = false;
	}

	private void OnDisable()
	{
		_damageable.OnReceiveDamage -= HandleOnReceiveDamage;
		_damageable.OnDeath -= HandleOnDeath;
	}

	private void OnDestroy()
	{
		DeregisterWithNetworkBoss();
	}

	private void Update()
	{
		if (!_damageable.isDead)
		{
			_fsm.Update();
		}
		_fsm.StepCoroutine();
	}

	private IEnumerator Wander()
	{
		int num = (int)base.transform.localScale.x;
		if (UnityEngine.Random.value < 0.3f)
		{
			num *= -1;
		}
		_mover.SetSpeed(walkSpeed, num);
		yield return StateMachine.WaitForSeconds(UnityEngine.Random.Range(3f, 6f));
	}

	private IEnumerator Look()
	{
		_mover.Stop();
		yield return StateMachine.WaitForSeconds(3.2f);
	}

	private bool ShouldEat()
	{
		return UnityEngine.Random.value < 0.5f;
	}

	private IEnumerator Eat()
	{
		_mover.Stop();
		_animator.SetBool(APEat, value: true);
		if (NetworkBigBoss.HasWorldAuth)
		{
			ByteBuffer.PrepWriteBuffer();
			ByteBuffer.Write(value: true);
			_animSync.SendAnimation(APEat);
		}
		yield return StateMachine.WaitForSeconds(UnityEngine.Random.Range(3f, 4f));
		_animator.SetBool(APEat, value: false);
		if (NetworkBigBoss.HasWorldAuth)
		{
			ByteBuffer.PrepWriteBuffer();
			ByteBuffer.Write(value: false);
			_animSync.SendAnimation(APEat);
		}
	}

	private bool ShouldWalkAway()
	{
		_threat = _alertScanner.GetClosest();
		return IsThreat(_threat);
	}

	private IEnumerator WalkAway()
	{
		if (_threat != null)
		{
			int direction = ((_threat.transform.localPosition.x < base.transform.localPosition.x) ? 1 : (-1));
			_mover.SetSpeed(walkSpeed, direction);
		}
		else
		{
			_mover.SetSpeed(walkSpeed);
		}
		yield return StateMachine.WaitForSeconds(UnityEngine.Random.Range(5f, 8f));
	}

	private bool ShouldRunAway()
	{
		foreach (SidedCaveData sidedCaveDatum in SingletonMonoBehaviour<Managers>.Inst.caveHelper.sidedCaveData)
		{
			float num = (sidedCaveDatum.bombablePortal ? sidedCaveDatum.bombablePortal.WaitPosition : 10000f);
			float num2 = base.transform.position.x - num;
			if ((num < 0f) ? (num2 < 5f) : (num2 > -5f))
			{
				return true;
			}
		}
		float num3 = ((base.transform.position.x < 0f) ? SingletonMonoBehaviour<Managers>.Inst.world.worldBounds.left : SingletonMonoBehaviour<Managers>.Inst.world.worldBounds.right);
		if (Mathf.Abs(base.transform.position.x - num3) < 5f)
		{
			return true;
		}
		_threat = _threatScanner.GetClosest();
		return IsThreat(_threat);
	}

	private IEnumerator RunAway()
	{
		isRunningAway = true;
		_animator.SetBool(APEat, value: false);
		if (NetworkBigBoss.HasWorldAuth)
		{
			ByteBuffer.PrepWriteBuffer();
			ByteBuffer.Write(value: false);
			_animSync.SendAnimation(APEat);
		}
		float x = base.transform.position.x;
		SetHabitatIfEmpty();
		float num = Mathf.Max(x - _habitat.max, _habitat.min - x);
		if (_threat == null || (num > 5f && UnityEngine.Random.value < 0.2f))
		{
			_mover.SetGoal(UnityEngine.Random.Range(_habitat.min, _habitat.max), runSpeed);
			while (_mover.movingToGoal)
			{
				yield return null;
			}
		}
		else
		{
			float x2 = _threat.transform.position.x;
			int num2 = (int)Mathf.Sign(x - x2);
			if (Mathf.Abs(x2 - x) < chaseDistance)
			{
				num2 *= -1;
			}
			foreach (SidedCaveData sidedCaveDatum in SingletonMonoBehaviour<Managers>.Inst.caveHelper.sidedCaveData)
			{
				float num3 = (sidedCaveDatum.bombablePortal ? sidedCaveDatum.bombablePortal.WaitPosition : 10000f);
				float num4 = base.transform.position.x - num3;
				if (!((num3 < 0f) ? (num4 < 5f) : (num4 > -5f)))
				{
				}
			}
			float num5 = ((base.transform.position.x < 0f) ? SingletonMonoBehaviour<Managers>.Inst.world.worldBounds.left : SingletonMonoBehaviour<Managers>.Inst.world.worldBounds.right);
			if (Mathf.Abs(base.transform.position.x - num5) < 5f)
			{
				num2 = ((base.transform.position.x < 0f) ? 1 : (-1));
			}
			_mover.SetSpeed(runSpeed, num2);
			yield return StateMachine.WaitForSeconds(UnityEngine.Random.Range(3f, 4f));
		}
		isRunningAway = false;
	}

	private bool ShouldFollowPlayer()
	{
		Player nearestPlayer = SingletonMonoBehaviour<Managers>.Inst.kingdom.GetNearestPlayer(base.transform.position.x);
		CloneRulerAbilityBehaviour clone = nearestPlayer.steed.Clone;
		if (nearestPlayer != null && nearestPlayer.steed.attractsDeer && nearestPlayer.CanInteractWithWorld && (Mathf.Abs(nearestPlayer.transform.position.x - base.transform.position.x) < 4f || (clone != null && Math.Abs(clone.transform.position.x - base.transform.position.x) < 4f)))
		{
			return true;
		}
		return false;
	}

	private IEnumerator FollowPlayer()
	{
		Player player = SingletonMonoBehaviour<Managers>.Inst.kingdom.GetNearestPlayer(base.transform.position.x);
		attractedToPlayerSound.Play(base.transform.position);
		Pool.SpawnGO(heartsParticles, new Vector3(19f / 32f, 0.625f, -0.001f), Quaternion.identity, base.transform);
		if (NetworkBigBoss.HasWorldAuth && NetworkBigBoss.HasClientCaughtUp)
		{
			SendHeartSpawn();
		}
		_mover.SetGoal(player.gameObject, walkSpeed, 0.5f);
		while (player.gameObject.activeInHierarchy && player.steed.attractsDeer && player.actionState != Player.ActionState.Transformed)
		{
			yield return StateMachine.WaitForSeconds(UnityEngine.Random.Range(1.5f, 4f));
			float playerDist = Mathf.Abs(player.transform.position.x - base.transform.position.x);
			while (playerDist > _playerFollowOffset)
			{
				playerDist = Mathf.Abs(player.transform.position.x - base.transform.position.x);
				_mover.SetGoal(player.transform.position.x + UnityEngine.Random.Range(0f - _playerFollowOffset, _playerFollowOffset), (playerDist < _playerFollowOffset) ? walkSpeed : runSpeed);
				yield return StateMachine.WaitForSeconds(UnityEngine.Random.Range(0.5f, 1.5f));
			}
		}
	}

	private bool IsPetrified()
	{
		return _petrifiable.IsPetrified;
	}

	private IEnumerator PetrifiedRoutine()
	{
		yield return null;
		while (IsPetrified())
		{
			yield return null;
		}
	}

	private void HandleOnReceiveDamage(int damageMultiplier, GameObject hitter, DamageSource source)
	{
		if (!IsPetrified())
		{
			RunAwayFrom(hitter);
		}
	}

	private void HandleOnDeath(GameObject other)
	{
		if (!base.isActiveAndEnabled)
		{
			return;
		}
		_mover.Stop();
		if (!_petrifiable.HasCrumbled)
		{
			Vector2 offset = new Vector2(0f, 0.4f);
			for (int i = 0; i < numCoinsDropped; i++)
			{
				Vector3 position = base.transform.position + new Vector3(offset.x, offset.y, 0f);
				_yieldCurrencyType.SpawnCurrency(position, Quaternion.identity).Drop(base.gameObject, new Vector2(UnityEngine.Random.Range(0f - _coinDropForce.x, _coinDropForce.x), _coinDropForce.y), offset, PickUpPolicy.Nobody);
			}
			SingletonMonoBehaviour<Managers>.Inst.stats.Increment(Stat.HuntedDeers);
		}
		_fsm.StopCurrentStateCoroutine();
	}

	private void SetHabitatIfEmpty()
	{
		if (_habitatSet)
		{
			return;
		}
		float x = base.transform.position.x;
		_habitat.min = x - 10f;
		_habitat.max = x + 10f;
		float num = float.MaxValue;
		foreach (Forest forest in SingletonMonoBehaviour<Managers>.Inst.world.forests)
		{
			Rect region = forest.GetRegion();
			float num2 = Mathf.Max(x - region.xMax, region.xMin - x);
			if (num2 < num)
			{
				num = num2;
				_habitat.min = region.xMin;
				_habitat.max = region.xMax;
			}
		}
		_habitatSet = true;
	}

	public void RunAwayFrom(GameObject threat)
	{
		_threat = threat;
		_fsm.GoToState(4);
	}

	private bool IsThreat(GameObject scannedObject)
	{
		if (scannedObject == null)
		{
			return false;
		}
		if (scannedObject.TryGetComponent<Player>(out var component) && component.actionState != Player.ActionState.Transformed)
		{
			if (!component.isMoving)
			{
				return false;
			}
			if (component.steed.attractsDeer)
			{
				return false;
			}
		}
		return true;
	}

	public void HandleAuthorityChange(bool newAuthorityState)
	{
		base.enabled = newAuthorityState;
	}

	public void RegisterWithNetworkBoss()
	{
		NetworkPostbox.AddAuthDependentObject(this);
	}

	public void DeregisterWithNetworkBoss()
	{
		NetworkPostbox.RemoveAuthDependentObject(this);
	}

	public void SetAnimation(int animCode)
	{
		bool value = ByteBuffer.ReadBool();
		_animator.SetBool(animCode, value);
		if (animCode == Damageable.APDie)
		{
			_damageable.FadeRecvDeath();
		}
	}

	public void PassthroughAnimationSend(int animCode)
	{
		_animSync.SendAnimation(animCode);
	}

	private void SendHeartSpawn()
	{
		ByteBuffer.PrepWriteBuffer();
		parentHeaderRef.CallMethodRemotely(_spawnHeartsIndex);
	}

	private void RecvHeartSpawn()
	{
		attractedToPlayerSound.Play(base.transform.position);
		Pool.SpawnGO(heartsParticles, new Vector3(19f / 32f, 0.625f, -0.001f), Quaternion.identity, base.transform);
	}

	public bool BeginRegisteringRPCs(CRPCHeader headerRef)
	{
		if (_spawnHeartsIndex != -1 || parentHeaderRef != null)
		{
			Debug.LogError("Attempted to re-register already registered RPC component 'Deer'!");
			return false;
		}
		parentHeaderRef = headerRef;
		_spawnHeartsIndex = headerRef.RegisterRPC(RecvHeartSpawn);
		return true;
	}

	public void GetSerializationData(out Type compType)
	{
		compType = typeof(Deer);
	}

	public void DeserializeFromData()
	{
	}

	public void OnPush(Vector2 _velocity)
	{
	}

	public void StartPetrifyInternal()
	{
		_mover.Pause(float.MaxValue);
		_animator.enabled = false;
		_petrifiable.StartPetrifyEffect(_spriteRenderer);
	}

	public void EndPetrifyInternal(bool skipVisuals = false)
	{
		if (skipVisuals)
		{
			CleanupEndPetrifyInternal();
		}
		else
		{
			_petrifiable.StartDePetrifyEffect(_spriteRenderer);
		}
	}

	private void CleanupEndPetrifyInternal()
	{
		_animator.enabled = true;
		_mover.UnPause();
	}

	public void CrumbleInternal()
	{
		_animator.SetBool(Damageable.APDie, value: true);
		_damageable.FadeRecvDeath();
		_petrifiable.StartCrumbleEffect(_spriteRenderer);
		if (NetworkBigBoss.HasWorldAuth)
		{
			Pool.DespawnOrDestroy(base.gameObject, 4f);
		}
	}
}
