using System.Collections;
using UnityEngine;

public abstract class BaseSpriteFX : MonoBehaviour
{
	public enum EndAction
	{
		None,
		Deactivate,
		Destroy
	}

	protected static int SPRecolorA;

	protected static int SPRecolorB;

	protected static int SPRecolorC;

	protected static int SPOverlay;

	protected static int SPAmbientResponse;

	protected static int SPOutlineColor;

	protected Color _recolorA = new Color(1f, 1f, 0f, 1f);

	protected Color _recolorB = new Color(0.9f, 0.7f, 0.5f, 0f);

	protected Color _recolorC = new Color(0.9f, 0.7f, 0.5f, 0f);

	protected Color _overlay = new Color(0f, 0f, 0f, 0f);

	protected Color _outline = new Color(0f, 0f, 0f, 0f);

	protected float _originalAlpha = 1f;

	protected EndAction _endAction;

	protected Color _startColorA;

	protected Color _startColorB;

	protected Color _targetColorA;

	protected Color _targetColorB;

	protected float _timeRemaining;

	protected float _timeRemainingA;

	protected float _timeRemainingB;

	protected float _targetAlpha;

	protected bool _indefiniteGlow;

	protected Coroutine _lerpColorARoutine;

	protected Coroutine _lerpColorBRoutine;

	protected Coroutine _fadeRoutine;

	protected Coroutine _overlayRoutine;

	protected Material _sharedMaterial;

	protected Material _instancedMaterial;

	protected bool _deviatesFromSharedMaterial;

	private bool _hasInitialised;

	public abstract float alpha { get; set; }

	public abstract Color recolorA { get; set; }

	public abstract Color recolorB { get; set; }

	public abstract Color recolorC { get; set; }

	public abstract float ambientResponse { get; set; }

	public abstract Color overlay { get; set; }

	public abstract Color outline { get; set; }

	public abstract float overlayAlpha { get; set; }

	public void Awake()
	{
		if (!_hasInitialised)
		{
			_hasInitialised = true;
			SPRecolorA = Shader.PropertyToID("_RecolorA");
			SPRecolorB = Shader.PropertyToID("_RecolorB");
			SPRecolorC = Shader.PropertyToID("_RecolorC");
			SPOverlay = Shader.PropertyToID("_Overlay");
			SPAmbientResponse = Shader.PropertyToID("_AmbientResponse");
			SPOutlineColor = Shader.PropertyToID("_OutlineColor");
			PseudoAwake();
			_originalAlpha = alpha;
		}
	}

	protected abstract void PseudoAwake();

	protected virtual void OnDisable()
	{
		_fadeRoutine = null;
		_overlayRoutine = null;
		alpha = _originalAlpha;
		overlayAlpha = 0f;
		_indefiniteGlow = false;
	}

	public void ClearOverlayRoutines()
	{
		this.ClearCoroutine(ref _fadeRoutine);
		this.ClearCoroutine(ref _overlayRoutine);
		this.ClearCoroutine(ref _lerpColorARoutine);
		this.ClearCoroutine(ref _lerpColorBRoutine);
		_indefiniteGlow = false;
		overlayAlpha = 0f;
		alpha = _originalAlpha;
	}

	protected abstract IEnumerator LerpColorARoutine();

	protected abstract IEnumerator LerpColorBRoutine();

	public void LerpColorATo(Color targetColor, float duration)
	{
		_endAction = EndAction.None;
		_startColorA = _recolorA;
		_targetColorA = targetColor;
		_timeRemainingA = duration;
		if (_lerpColorARoutine != null)
		{
			StopCoroutine(_lerpColorARoutine);
		}
		_lerpColorARoutine = StartCoroutine(LerpColorARoutine());
	}

	public void LerpColorBTo(Color targetColor, float duration)
	{
		_endAction = EndAction.None;
		_startColorB = _recolorB;
		_targetColorB = targetColor;
		_timeRemainingB = duration;
		if (_lerpColorBRoutine != null)
		{
			StopCoroutine(_lerpColorBRoutine);
		}
		_lerpColorBRoutine = StartCoroutine(LerpColorBRoutine());
	}

	protected abstract IEnumerator FadeRoutine();

	public void FadeInFromTransparent(float duration)
	{
		alpha = 0f;
		_endAction = EndAction.None;
		_targetAlpha = _originalAlpha;
		_timeRemaining = duration;
		ClearFadeRoutine();
		_fadeRoutine = StartCoroutine(FadeRoutine());
	}

	public void FadeIn(float duration)
	{
		FadeTo(duration, _originalAlpha);
	}

	public void FadeTo(float duration, float targetAlpha)
	{
		_endAction = EndAction.None;
		_targetAlpha = targetAlpha;
		_timeRemaining = duration;
		base.gameObject.SetActive(value: true);
		ClearFadeRoutine();
		_fadeRoutine = StartCoroutine(FadeRoutine());
	}

	public void FadeOut(float duration, EndAction endAction = EndAction.None)
	{
		_targetAlpha = 0f;
		_timeRemaining = duration;
		_endAction = endAction;
		ClearFadeRoutine();
		_fadeRoutine = StartCoroutine(FadeRoutine());
	}

	public void ClearFadeRoutine()
	{
		this.ClearCoroutine(ref _fadeRoutine);
	}

	protected abstract IEnumerator FlashRoutine(float duration, Color color, bool unscaledTime);

	public void FlashOverlay(float maxAlpha, float duration, Color color)
	{
		if (_overlayRoutine != null)
		{
			StopCoroutine(_overlayRoutine);
		}
		if (base.isActiveAndEnabled)
		{
			color.a = maxAlpha;
			_overlayRoutine = StartCoroutine(FlashRoutine(duration, color, unscaledTime: false));
		}
	}

	public void FlashOverlay(Color color, float duration, bool unscaledTime = false)
	{
		if (_overlayRoutine != null)
		{
			StopCoroutine(_overlayRoutine);
		}
		if (base.isActiveAndEnabled)
		{
			_overlayRoutine = StartCoroutine(FlashRoutine(duration, color, unscaledTime));
		}
	}

	protected abstract IEnumerator FadeOverlayRoutine(float duration, Color color);

	public void FadeOverlay(Color color, float duration)
	{
		if (_overlayRoutine != null)
		{
			StopCoroutine(_overlayRoutine);
		}
		_overlayRoutine = StartCoroutine(FadeOverlayRoutine(duration, color));
	}

	protected abstract IEnumerator BlinkRoutine(Color overlayColor);

	public void BlinkOverlay(Color overlayColor)
	{
		if (_overlayRoutine != null)
		{
			StopCoroutine(_overlayRoutine);
		}
		_overlayRoutine = StartCoroutine(BlinkRoutine(overlayColor));
	}

	protected abstract IEnumerator GlowRoutine(Color overlayColor, float duration);

	public void GlowOverlay(Color overlayColor, float duration)
	{
		if (_overlayRoutine != null)
		{
			StopCoroutine(_overlayRoutine);
		}
		_overlayRoutine = StartCoroutine(GlowRoutine(overlayColor, duration));
	}

	protected abstract IEnumerator GlowRoutine(Gradient overlayGradient, float duration);

	public void GlowOverlay(Gradient overlayGradient, float duration)
	{
		if (_overlayRoutine != null)
		{
			StopCoroutine(_overlayRoutine);
		}
		_overlayRoutine = StartCoroutine(GlowRoutine(overlayGradient, duration));
	}

	protected abstract IEnumerator GlowIndefiniteRoutine(Gradient overlayGradient);

	public void StartIndefiniteGlowOverlay(Gradient overlayGradient)
	{
		if (_overlayRoutine != null)
		{
			StopCoroutine(_overlayRoutine);
		}
		_indefiniteGlow = true;
		_overlayRoutine = StartCoroutine(GlowIndefiniteRoutine(overlayGradient));
	}

	public void StopIndefiniteGlowOverlay()
	{
		_indefiniteGlow = false;
	}
}
