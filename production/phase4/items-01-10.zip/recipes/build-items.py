"""Reproducible item authoring: selected immutable donors and built-in masters only."""
import pathlib,sys,json,hashlib,io,zipfile,math,os
from PIL import Image,ImageDraw
ROOT=pathlib.Path('D:/Work/Games/KingdomZombies');WORK=ROOT/'.phase4/04-05'
def sha(b):return hashlib.sha256(b).hexdigest()
def js(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def png(im):
 b=io.BytesIO();im.save(b,format='PNG',compress_level=9);return b.getvalue()
def info(im):return {'width':im.width,'height':im.height,'rgbaSha256':sha(im.tobytes()),'visiblePixels':sum(a>0 for a in im.getchannel('A').tobytes()),'alphaBBox':list(im.getbbox()),'alphaValues':sorted(set(im.getchannel('A').tobytes()))}
def clean(im):
 im=im.convert('RGBA');im.putalpha(im.getchannel('A').point(lambda a:255 if a>=128 else 0));im.putdata([(r,g,b,a) if a else (0,0,0,0) for r,g,b,a in im.get_flattened_data()]);return im
NAMES=['Money','Arrows','Knife','Wooden club','Machete','Metal bat','Bow','Berries','Fruit','Meat']
FOOT=[[1,1],[1,2],[1,2],[1,3],[1,3],[1,4],[2,4],[1,1],[1,1],[1,2]]
SIZES={'knife':[4,12],'club':[5,18],'machete':[5,20],'bat':[4,24],'fruit':[6,7],'meat':[7,5]}
SOURCES={1:'common.s0.7856',2:'common.s0.6885',7:'common.s0.7008',8:'common.r.11340'}
GEN={3:'knife',4:'club',5:'machete',6:'bat',9:'fruit',10:'meat'}
def quoted(v):return json.dumps(v,ensure_ascii=False)
def track(index,target,value):
 return f'tracks/{index}/type = "value"\ntracks/{index}/path = NodePath({quoted(target)})\ntracks/{index}/interp = 0\ntracks/{index}/enabled = true\ntracks/{index}/keys = {{"times": PackedFloat32Array(0), "transitions": PackedFloat32Array(1), "update": 1, "values": [{value}]}}\n'
def scene(pack):
 parts=pack['parts'];items=pack['items'];s=['[gd_scene load_steps='+str(1+1+len(parts)+len(items)*2+4+4)+' format=3]','[ext_resource type="Texture2D" path="res://'+pack['atlas']['path']+'" id="1_items"]']
 for part in parts:
  x,y,w,h=part['atlasRect'];s.append(f'[sub_resource type="AtlasTexture" id="A_{part["key"]}"]\natlas = ExtResource("1_items")\nregion = Rect2({x}, {y}, {w}, {h})\nfilter_clip = true')
 for item in items:
  lines=[f'[sub_resource type="Animation" id="Select_{item["node"]}"]','length = 0.001']
  for j,other in enumerate(items):lines.append(track(j,'Groups/'+other['node']+':visible','true' if other==item else 'false'))
  # Selection always retires broken/ammo test states, without changing item identity.
  ti=len(items)
  for other in items:
   for mode in other['modes']:
    lines.append(track(ti,f'Groups/{other["node"]}/Art/{mode["node"]}:visible','false'));ti+=1
  s.append('\n'.join(lines))
  for mode in item['modes']:
   lines=[f'[sub_resource type="Animation" id="State_{item["node"]}_{mode["node"]}"]','length = 0.001'];ti=0
   for other in items:
    for candidate in other['modes']:
     lines.append(track(ti,f'Groups/{other["node"]}/Art/{candidate["node"]}:visible','true' if other==item and candidate==mode else 'false'));ti+=1
   s.append('\n'.join(lines))
 for z in [1,2,4,8]:
  lines=[f'[sub_resource type="Animation" id="Zoom_{z}"]','length = 0.001']
  for j,item in enumerate(items):lines.append(track(j,'Groups/'+item['node']+'/Art:scale',f'Vector2({z}, {z})'))
  s.append('\n'.join(lines))
 def library(id,rows):return f'[sub_resource type="AnimationLibrary" id="{id}"]\n_data = {{\n'+',\n'.join('&'+quoted(k)+': SubResource('+quoted(v)+')' for k,v in rows)+'\n}'
 s.append(library('Selections',[(x['id'],'Select_'+x['node']) for x in items]));s.append(library('States',[(x['id']+'.'+m['node'],'State_'+x['node']+'_'+m['node']) for x in items for m in x['modes']]));s.append(library('Zooms',[(f'zoom{z}',f'Zoom_{z}') for z in [1,2,4,8]]))
 def node(name,type,parent=None,props=''):
  s.append('[node name='+quoted(name)+' type='+quoted(type)+((' parent='+quoted(parent)) if parent is not None else '')+']\n'+props)
 node(pack['preview']['root'],'Control',props='layout_mode = 3\nanchors_preset = 15\nanchor_right = 1.0\nanchor_bottom = 1.0\ngrow_horizontal = 2\ngrow_vertical = 2\ntexture_filter = 1')
 node('Title','Label','.', 'offset_left = 12.0\noffset_top = 8.0\ntext = "Items - reusable masters; resource inspection"')
 node('Browse','ScrollContainer','.', 'offset_left = 12.0\noffset_top = 44.0\noffset_right = 222.0\noffset_bottom = 470.0')
 node('List','VBoxContainer','Browse','layout_mode = 2')
 for item in items:node('Select_'+item['node'],'Button','Browse/List','layout_mode = 2\ntext = '+quoted(item['id']+' '+item['name']))
 node('Zoom','HBoxContainer','.', 'offset_left = 250.0\noffset_top = 55.0\noffset_right = 540.0\noffset_bottom = 87.0')
 for z in [1,2,4,8]:node('Zoom'+str(z),'Button','Zoom','layout_mode = 2\ntext = '+quoted(str(z)+'x'))
 node('Modes','HBoxContainer','.', 'offset_left = 250.0\noffset_top = 95.0\noffset_right = 770.0\noffset_bottom = 127.0')
 node('Groups','Control','.', 'offset_left = 250.0\noffset_top = 145.0')
 for item in items:
  group='Groups/'+item['node'];node(item['node'],'Control','Groups','visible = '+('true' if item==items[0] else 'false'))
  node('Identity','Label',group,'text = '+quoted(item['id']+' | '+item['name']+' | '+item['status']))
  node('Use','Label',group,'offset_top = 25.0\ntext = '+quoted(item['usageLabel']))
  node('Art','Node2D',group,'position = Vector2(0, 115)\nscale = Vector2(4, 4)\ntexture_filter = 1')
  for j,comp in enumerate(item['components']):
   node(comp['node'],'Sprite2D',group+'/Art',f'position = Vector2({j*27}, 0)\ntexture = SubResource("A_{comp["part"]}")\ncentered = false\nrotation = {comp["rotation"]}\ntexture_filter = 1')
   node('Caption_'+str(j),'Label',group,f'offset_left = {j*108}.0\noffset_top = 240.0\ntext = '+quoted(comp['name']))
  for mode in item['modes']:
   node(mode['node'],'Sprite2D',group+'/Art',f'visible = false\nposition = Vector2(27, 0)\ntexture = SubResource("A_{mode["part"]}")\ncentered = false\ntexture_filter = 1')
  for j,mode in enumerate(item['modes']):node('State_'+mode['node'],'Button',group,f'offset_left = {j*140}.0\noffset_top = 50.0\noffset_right = {(j+1)*140-8}.0\noffset_bottom = 80.0\ntext = '+quoted(mode['node']+' example'))
  if item.get('storage'):
   w,h=item['storage'];node('Storage','Label',group,'offset_top = 280.0\ntext = '+quoted('Storage '+str(w)+'x'+str(h)+'\n'+('\n'.join(' '.join('[ ]' for _ in range(w)) for _ in range(h)))))
 for name,lib in [('Selection','Selections'),('State','States'),('ZoomPlayer','Zooms')]:node(name,'AnimationPlayer','.', 'libraries = {&"": SubResource("'+lib+'")}')
 for item in items:
  s.append('[connection signal="pressed" from="Browse/List/Select_'+item['node']+'" to="Selection" method="play" binds= [&'+quoted(item['id'])+']]')
  for mode in item['modes']:s.append('[connection signal="pressed" from="Groups/'+item['node']+'/State_'+mode['node']+'" to="State" method="play" binds= [&'+quoted(item['id']+'.'+mode['node'])+']]')
 for z in [1,2,4,8]:s.append('[connection signal="pressed" from="Zoom/Zoom'+str(z)+'" to="ZoomPlayer" method="play" binds= [&"zoom'+str(z)+'"]]')
 return ('\n\n'.join(s)+'\n').encode()
def build(which):
 assert which=='items-01-10'
 out=WORK/(which+'-stage-'+str(__import__('time').time_ns()));assert not out.exists(),'FRESH_STAGE_REQUIRED';out.mkdir()
 members={};generated=json.loads((WORK/'generated.json').read_text());common=json.loads((ROOT/'src/godot-game/content/packs/common.json').read_text());donors={x['id']:x for x in common['resources']}
 with zipfile.ZipFile(ROOT/'production/phase4/common-selected.zip') as archive:
  for id in list(SOURCES.values())+['common.r.8203','common.s0.7848']:
   row=donors[id];members['donors/'+id+'.json']=js(row);members['donors/'+id+'.png']=archive.read(row['member'])
 for name in ['references.png','survivor.png','donor-survivor.png','donor-wall.png']:members['references/'+name]=(WORK/name).read_bytes()
 parts=[];images={};items=[];atlas=Image.new('RGBA',(512,256));x=2;y=2;rowh=0
 def part(key,im,origin,ops):
  nonlocal x,y,rowh
  assert im.getbbox() and im.width<=128 and im.height<=128
  if x+im.width+2>512:x=2;y+=rowh+2;rowh=0
  assert y+im.height<256
  atlas.paste(im,(x,y));images[key]=im;member='parts/'+key+'.png';raw=png(im);members[member]=raw
  p={'key':key,'member':member,'sha256':sha(raw),'image':info(im),'atlasRect':[x,y,im.width,im.height],'origin':origin,'operations':ops,'worldSize':list(im.size),'density':1};parts.append(p);x+=im.width+2;rowh=max(rowh,im.height);return key
 for n in range(1,11):
  id=f'IT-{n:02}';node=id.replace('-','_');route='adapt-donor';origin=None
  if n in GEN:
   name=GEN[n];g=generated[name];raw=pathlib.Path(g['path']).read_bytes();master=Image.open(io.BytesIO(raw)).convert('RGBA');cl=clean(master);bbox=cl.getbbox();size=SIZES[name];im=cl.crop(bbox).resize(size,Image.Resampling.NEAREST);origin='masters/'+name+'.png';members[origin]=raw;members['prompts/'+name+'.txt']=(g['prompt']+'\n').encode();members['cleaned/'+name+'.png']=png(cl)
   source={'tool':'built-in image_gen','outputIdentity':g['path'].split('/')[-1],'session':g['path'].split('/')[-2],'master':origin,'masterSha256':sha(raw),'prompt':'prompts/'+name+'.txt','promptSha256':sha(members['prompts/'+name+'.txt']),'original':info(master),'originalCanvas':list(master.size),'crop':list(bbox),'nativeExport':size,'maskThreshold':128,'resampling':'nearest','referenceMembers':['references/references.png','references/survivor.png','references/donor-wall.png']};route='generate' if n!=9 else 'generated-adaptation'
   ops=[{'op':'alpha-threshold','value':128},{'op':'crop','box':list(bbox)},{'op':'nearest','size':size}]
  else:
   d=SOURCES[n];origin='donors/'+d+'.png';master=Image.open(io.BytesIO(members[origin])).convert('RGBA');im=clean(master);source={'resource':d,'record':'donors/'+d+'.json','master':origin,'masterSha256':sha(members[origin]),'original':info(master),'nativeExport':list(im.size),'retainsOriginalRegistration':True};ops=[{'op':'alpha-threshold','value':128}]
   if n==8:
    # Exact purple berry clusters from K04; arrange into a compact bunch without repainting pixels.
    berry=im.crop((5,0,7,2));im=Image.new('RGBA',(6,5));
    for at in [(0,0),(3,0),(1,3)]:im.alpha_composite(berry,at)
    ops.append({'op':'crop-compose','box':[5,0,7,2],'size':[6,5],'placements':[[0,0],[3,0],[1,3]]})
  masterkey=part(node+'_master',im,origin,ops)
  canonical=masterkey
  if n==2:
   single=im;im=Image.new('RGBA',(10,7))
   for at in [(0,0),(1,2),(2,3)]:im.alpha_composite(single,at)
   canonical=part(node+'_bundle',im,origin,[{'op':'alpha-threshold','value':128},{'op':'crop-compose','box':[0,0,8,4],'size':[10,7],'placements':[[0,0],[1,2],[2,3]]}])
  item={'id':id,'version':1,'node':node,'name':NAMES[n-1],'nameKey':'item.'+id+'.name','descriptionKey':'item.'+id+'.description','inventoryFootprint':FOOT[n-1],'canonicalIcon':canonical,'iconVariants':[canonical],'master':masterkey,'route':route,'source':source,'status':'Source produced; appearance review pending04-32','storage':None,'slot':None,'components':[],'modes':[],'bodyFitOwner':'04-06/04-07','balanceOwner':'DT-04','inspection':{'category':'Items','scene':'inspection/ItemsWeaponsPreview.tscn','selection':'Selection','animation':id,'button':'Browse/List/Select_'+node,'group':'Groups/'+node,'zoom':'ZoomPlayer','zoomAnimations':['zoom1','zoom2','zoom4','zoom8']}}
  def component(name,key=masterkey,rotation=0,attachment=None,pivot=None):item['components'].append({'name':name,'node':name.replace('-','_'),'part':key,'rotation':rotation,'scale':[1,1],'pivot':pivot or [0,0],'attachment':attachment,'nativeSize':list(images[key].size)})
  component('icon',canonical)
  if n in [2,3,4,5,6,7]:
   item['slot']='either-logical-hand';item['usageLabel']='Logical left/right hand attachments; natural scale1; body fits owned04-06/07'
   grip=[images[masterkey].width//2,max(0,images[masterkey].height-3)] if n not in [2,7] else ([2,2] if n==2 else [7,9])
   for hand in ['left','right']:
    component('held-'+hand,attachment='hand.'+hand,pivot=grip);component('corpse-'+hand,rotation=math.pi/2,attachment='corpse.hand.'+hand,pivot=grip)
   if n==2:
    component('nocked-arrow',attachment='bow.nock',pivot=[0,2]);component('flying-arrow',attachment='projectile.origin',pivot=[0,2]);item['ammoVisibleWhen']='opposite-hand stack count>0';item['recoverableProjectile']=False
   else:
    w,h=images[masterkey].size;mask=Image.new('RGBA',(w,h));draw=ImageDraw.Draw(mask);draw.line([(max(0,w//2-1),h//2),(w//2,h//2+1),(max(0,w//2-1),min(h-1,h//2+2))],fill=(33,33,46,255));k=part(node+'_broken',mask,'procedural-condition-overlay',[{'op':'broken-crack','size':[w,h]}]);item['modes'].append({'node':'Broken','part':k,'visibleWhen':'condition==0','identity':id})
   if n==7:
    # Reuse the exact bow master; string/limb transforms belong to the later bow action rig.
    for name in ['drawn-bow','released-bow']:component(name,attachment='bow.grip',pivot=grip)
    arrow=images['IT_02_master'];k=part(node+'_nocked',arrow,'donors/common.s0.6885.png',[{'op':'alpha-threshold','value':128}]);item['modes'].append({'node':'Nocked','part':k,'visibleWhen':'opposite-hand arrows>0 and bow usable','identity':'IT-02'});item['emptyArrowHand']='no nocked layer';item['actionRigOwner']='04-09'
  elif n in [8,9,10]:
   item['usageLabel']='Food-use component from the canonical master; no cooked/raw mechanic';component('food-use',attachment='hand.food');component('corpse-storage',rotation=math.pi/2,attachment='inventory.hidden')
  else:item['usageLabel']='Physical currency icon; count is a UI overlay, no global wallet';component('stored',attachment='inventory.hidden')
  items.append(item)
 sceneName='ItemsWeaponsPreview.tscn';pack={'schemaVersion':1,'id':which,'version':1,'stylePrecedence':'Current D-13 SIMPLE LOW-RESOLUTION OVERRIDES older rich sprite skill examples','commonBundleSha256':sha((ROOT/'production/phase4/common-selected.zip').read_bytes()),'scaleDecision':'D-13-pilot-1','logicalPixelsPerWorldPixel':1,'atlas':{'path':'assets/equipment/'+which+'.png',**info(atlas),'sha256':sha(png(atlas))},'items':items,'parts':parts,'preview':{'scene':'inspection/'+sceneName,'root':'ItemsWeaponsPreview','selectionPlayer':'Selection','statePlayer':'State','zoomPlayer':'ZoomPlayer','zooms':[1,2,4,8],'integrationOwner':'04-23','currentHubReachability':'pending-04-23'},'donorSuitability':[{'family':'K20','decision':'Reuse coin7856/bow7008/arrow6885 exact selected art; adaptations explicitly identified'},{'family':'K04','decision':'Compose three exact2x2 purple berry crops from11340; do not confuse with orchard apples'},{'family':'K05','decision':'8203 has13x3/13x4 flattened orchard fragments, not a legible complete apple; generated full apple retains source reference'},{'family':'K14','decision':'Humanoid clothing is baked into tiny bodies; later wearable generation/reuse retains source palette/ingredients'}],'acceptance':{'visual':'pending','humanApproval':None,'owner':'04-32/04-33','completedObligations':[]},'publication':{'kind':'validated-standalone','indexAdoptionOwner':'04-23','manifestPublishedLast':True},'recipe':{'member':'recipes/build-items.py','sha256':sha(pathlib.Path(__file__).read_bytes()),'toolPins':{'Python':'3.12.14','Pillow':'13.0.0'}}}
 sceneBytes=scene(pack);pack['preview']['sha256']=sha(sceneBytes);members[sceneName]=sceneBytes;members[which+'.png']=png(atlas);members['recipes/build-items.py']=pathlib.Path(__file__).read_bytes();members[which+'.json']=js(pack)
 # Self-contained source proofs are artwork assemblies, not rendered game screenshots.
 board=Image.new('RGBA',(480,100),(24,37,43,255))
 for i,item in enumerate(items):
  im=images[item['canonicalIcon']];board.alpha_composite(im.resize((im.width*3,im.height*3),Image.Resampling.NEAREST),(i*46+3,5))
 members['proofs/icons-nearest3x.png']=png(board)
 members['members.json']=js([{'path':k,'bytes':len(v),'sha256':sha(v)} for k,v in sorted(members.items())])
 with zipfile.ZipFile(out/(which+'.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,raw in sorted(members.items()):z.writestr(name,raw)
 for name in [which+'.json',which+'.png',sceneName]:(out/name).write_bytes(members[name])
 print(json.dumps({'stage':str(out),'items':len(items),'parts':len(parts),'members':len(members),'atlas':info(atlas)}))
if __name__=='__main__':build(sys.argv[1])
