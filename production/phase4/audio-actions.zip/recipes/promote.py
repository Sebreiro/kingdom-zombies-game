import hashlib,json,pathlib,sys,zipfile
root=pathlib.Path(sys.argv[1]).resolve()
assert root.is_relative_to(pathlib.Path('D:/Work/Games/KingdomZombies/.phase4').resolve())
sha=lambda b:hashlib.sha256(b).hexdigest()
approval=json.loads((root/'approval.json').read_text())
original=(root/'presented-manifest.json').read_bytes()
assert sha(original)==approval['presentedManifestSha256']
assert sha((root/'presented.zip').read_bytes())==approval['presentedPacketSha256']
pack=json.loads(original)
with zipfile.ZipFile(root/'presented.zip') as z:members={n:z.read(n) for n in z.namelist()}
pack['status']='approved-production-source'
pack['scope']='AU01-15 creator-approved exact production sources; final native mix/04-32/33 acceptance pending'
pack['approval']=approval
pack['listening']={'status':'Approved by creator attestation','listener':'creator/user','verdict':'accepted','approvalId':approval['id']}
for sample in pack['samples']:sample['listening']=pack['listening'].copy()
for category in pack['categories']:
    category['status']='Selected by creator attestation'
    category['suitability']='Approved for the presented source/category use'
pack['donorPolicy']['remaining']='Final native mix/04-32/33 judgment pending; no new audio approved by this attestation'
members['approval/presented-manifest.json']=original
members['approval/creator-attestation.json']=(json.dumps(approval,indent=2)+'\n').encode()
members['approval/coordinator-record.md']=(root/'coordinator-record.md').read_bytes()
members['recipes/promote.py']=pathlib.Path(__file__).read_bytes()
pack['recipes']['promotionMember']='recipes/promote.py'
pack['recipes']['promotionSha256']=sha(members['recipes/promote.py'])
pack['retainedManifestMember']='production/manifest.json'
pack['bundleMembers']=[{'path':k,'bytes':len(v),'sha256':sha(v)} for k,v in sorted(members.items())]
del pack['bundleSha256']
members['production/manifest.json']=(json.dumps(pack,indent=2,allow_nan=False)+'\n').encode()
with zipfile.ZipFile(root/'audio-actions.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,payload in sorted(members.items()):
        info=zipfile.ZipInfo(name,(2026,11,18,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,payload)
pack['bundleSha256']=sha((root/'audio-actions.zip').read_bytes())
(root/'audio-actions.json').write_text(json.dumps(pack,indent=2,allow_nan=False)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'samples':len(pack['samples']),'members':len(members),'sourceApproval':approval['id']}))
