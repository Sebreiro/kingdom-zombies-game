import array, hashlib, io, json, math, pathlib, sys, wave, zipfile
root=pathlib.Path(sys.argv[1]).resolve()
assert root.is_relative_to(pathlib.Path('D:/Work/Games/KingdomZombies/.phase4').resolve())
sha=lambda b:hashlib.sha256(b).hexdigest()
config=json.loads((root/'selection.json').read_text())
samples=[]
members={}
bank=array.array('h')
def wav(pcm):
    out=io.BytesIO()
    with wave.open(out,'wb') as f:
        f.setnchannels(2);f.setsampwidth(2);f.setframerate(44100);f.writeframes(pcm)
    return out.getvalue()
for object_id,name in config['candidates']:
    folder=root/('candidate.'+str(object_id))
    original=(folder/(name+'.wav')).read_bytes()
    record=json.loads((folder/'sample.json').read_text())
    import base64
    prefix='sources/'+str(object_id)
    members[prefix+'/original.wav']=original
    members[prefix+'/stream.fsb']=base64.b64decode(record['bundle']['originalPayloadBase64'])
    members[prefix+'/audioclip.bin']=base64.b64decode(record['bundle']['rawAudioClipBase64'])
    del record['bundle']
    members[prefix+'/provenance.json']=(json.dumps(record,indent=2)+'\n').encode()
    with wave.open(io.BytesIO(original),'rb') as f:
        raw=f.readframes(f.getnframes())
    data=array.array('h');data.frombytes(raw)
    assert sys.byteorder=='little'
    source_channels=record['output']['channels']
    if source_channels==1:data=array.array('h',(v for value in data for v in (value,value)))
    peak=max(abs(v) for v in data)
    assert peak>0
    # Candidate headroom normalization is a technical transform, not audible approval.
    gain=min(1.0,24575/peak)
    variants=[('full',0,len(data)//2)]
    if object_id in [3294,4949]:variants.append(('jump-trim',0,min(5292,len(data)//2)))
    if object_id in [4523,3574]:variants.append(('break-trim',0,min(6174,len(data)//2)))
    for role,start,end in variants:
        adapted=array.array('h',(round(v*gain) for v in data[start*2:end*2]))
        payload=adapted.tobytes();output=wav(payload)
        identity='action.'+str(object_id)+'.'+role
        variant='variants/'+identity+'.wav';members[variant]=output
        first=len(bank)//2;bank.extend(adapted)
        samples.append({'id':identity,'version':1,'candidateId':object_id,'candidateName':name,
          'source':record['source'],'preservation':record['preservation'],'tools':record['tools'],
          'original':record['output'],'sourceMember':prefix+'/original.wav','variantMember':variant,
          'sha256':sha(output),'pcmSha256':sha(payload),'frames':end-start,'channels':2,'rate':44100,'sampleWidth':2,
          'durationSeconds':(end-start)/44100,'trimFrames':[start,end],'gainLinear':gain,'gainDb':20*math.log10(gain),
          'channelTransform':'duplicate-mono-to-stereo' if source_channels==1 else 'preserve-stereo',
          'regionFrames':[first,len(bank)//2],'loop':None,'listening':{'status':'Not auditioned','listener':None,'verdict':None},
          'technical':{'peak':max(abs(v) for v in adapted),'rms':math.sqrt(sum(v*v for v in adapted)/len(adapted)),
             'nonzeroSamples':sum(v!=0 for v in adapted),'sourceFullScaleSamples':sum(abs(v)>=32767 for v in data),
             'fullScaleSamples':sum(abs(v)>=32767 for v in adapted)}})
    bank.extend([0]*4410) # 50ms indexed separator, excluded from every region
bankbytes=wav(bank.tobytes())
pack={'schemaVersion':1,'id':'audio-actions','version':1,'status':'candidate-review-blocked',
 'scope':'AU01-15 source-only candidate review; no completion, suitability, native mix or final acceptance credit',
 'bank':{'path':'assets/audio/actions.wav','sha256':sha(bankbytes),'frames':len(bank)//2,'channels':2,'rate':44100,'sampleWidth':2},
 'categories':[],'samples':samples,'listening':{'status':'Not auditioned','listener':None,'verdicts':[],
 'blockedBy':'Actual capable listener must hear exact candidate and adapted sample versions before Task1 completion'},
 'donorPolicy':{'authority':'specs/0.1/assets-and-resources.md section10',
 'selection':'All forty exact relevant donor anchors exported independently before any replacement synthesis',
 'synthesisPerformed':False,'unsuitabilityClaims':[],
 'remaining':'Auditory suitability/material classification/wet-versus-fire/speech/music/source identity/punch remain unknown'},
 'recipes':{'decoderMember':'recipes/decode.py','decoderSha256':sha((root/'decode.py').read_bytes()),
 'assemblerMember':'recipes/assemble.py','assemblerSha256':sha(pathlib.Path(__file__).read_bytes()),
 'selectionMember':'recipes/selection.json'}}
for identity,title,anchors,question in config['coverage']:
    wanted='jump-trim' if identity=='AU-02' else 'break-trim' if identity=='AU-05' else 'full'
    selected=[s['id'] for s in samples if s['candidateId'] in anchors and s['id'].endswith('.'+wanted)]
    pack['categories'].append({'id':identity,'title':title,'candidateIds':anchors,'sampleIds':selected,
      'status':'Not auditioned','suitability':'Unknown until actual hearing','question':question})
members['recipes/decode.py']=(root/'decode.py').read_bytes()
members['recipes/assemble.py']=pathlib.Path(__file__).read_bytes()
members['recipes/selection.json']=(root/'selection.json').read_bytes()
members['review/README.txt']=('Extract this ZIP to a new folder; open review/index.html locally. Each Play is deliberate. '
 'Listen to the full source and adapted variant. Nothing autoplays. All samples are Not auditioned. '
 'Report name, actual device/player, UTC date, sample ID/version/hash, entire-sample hearing, '
 'music/speech/identity/silence/clipping/onset-tail/punch and accepted/changes-required/blocked verdict. '
 'Use exact seconds for suggested edits. No game window or mix review is performed here.').encode()
import html
rows=[]
for category in pack['categories']:
    rows.append('<h2>'+category['id']+' '+html.escape(category['title'])+'</h2><p>'+html.escape(category['question'])+'</p>')
    for identity in category['sampleIds']:
        sample=next(s for s in samples if s['id']==identity)
        rows.append('<details><summary>'+identity+' v1 | '+str(sample['frames'])+' frames | '+str(round(sample['durationSeconds'],3))+'s | Not auditioned</summary>'
        +'<p>Source: resources.assets AudioClip '+str(sample['candidateId'])+' '+html.escape(sample['candidateName'])+'</p>'
        +'<p>Full source</p><audio controls preload="none" src="../'+sample['sourceMember']+'"></audio>'
        +'<p>Adapted variant: trim '+str(sample['trimFrames'])+'; gain '+str(sample['gainDb'])+'dB; bank '+str(sample['regionFrames'])+'</p>'
        +'<audio controls preload="none" src="../'+sample['variantMember']+'"></audio><p>WAV SHA256 '+sample['sha256']+'</p></details>')
members['review/index.html']=('<!doctype html><html lang="en"><meta charset="utf-8"><title>AU01-15 candidate review</title>'
 '<style>body{max-width:950px;margin:2rem auto;font:16px sans-serif;background:#181b1e;color:#eee}details{padding:12px;border:1px solid #777;margin:8px}audio{width:100%}p{overflow-wrap:anywhere}</style>'
 '<h1>AU01-15 source-only candidate review</h1><p>All candidates: Not auditioned. Start each playback deliberately. '
 'Confirm an audible device at comfortable volume. Assess source and adapted version; no game/mix approval is requested. '
 'Some source clips may include unwanted voice, music or source identity: these are unapproved candidates.</p>'+''.join(rows)+'</html>').encode()
pack['bundleMembers']=[{'path':key,'bytes':len(value),'sha256':sha(value)} for key,value in sorted(members.items())]
members['review/manifest.json']=(json.dumps(pack,indent=2,allow_nan=False)+'\n').encode()
with zipfile.ZipFile(root/'audio-actions.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for key,value in sorted(members.items()):
        info=zipfile.ZipInfo(key,(2026,11,18,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,value)
pack['bundleSha256']=sha((root/'audio-actions.zip').read_bytes())
(root/'actions.wav').write_bytes(bankbytes)
(root/'audio-actions.json').write_text(json.dumps(pack,indent=2,allow_nan=False)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'candidates':len(config['candidates']),'variants':len(samples),'frames':len(bank)//2,'zipBytes':(root/'audio-actions.zip').stat().st_size}))
