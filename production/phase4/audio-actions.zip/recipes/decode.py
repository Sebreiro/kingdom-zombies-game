"""Read-only exact Unity AudioClip selection; one native decoder owner per child."""
import base64
import hashlib
import importlib.metadata
import io
import json
import pathlib
import sys
import wave

sys.dont_write_bytecode = True
ROOT = pathlib.Path('D:/Work/Games/KingdomZombies')
DONOR = pathlib.Path('D:/Work/Games/KindomCrown/recovered/resources')
DEPENDENCIES = pathlib.Path('D:/Work/Games/KindomCrown/.tools/resource-python')
PYTHON_VERSION = '3.12.14'
SELECTIONS = {"candidate.3294":["resources.assets",3294,"citizen_run01",0],"candidate.4949":["resources.assets",4949,"citizen_run02",0],"candidate.3369":["resources.assets",3369,"knight_newattack1",0],"candidate.4872":["resources.assets",4872,"knight_newattack2",0],"candidate.5123":["resources.assets",5123,"troll_hits_player",0],"candidate.2880":["resources.assets",2880,"Greed_Archer_Take_Damage_Blunt_02",0],"candidate.3700":["resources.assets",3700,"Greed_Archer_Take_Damage_Arrow_05",0],"candidate.4523":["resources.assets",4523,"wall_wood_wreck",0],"candidate.3574":["resources.assets",3574,"wall_iron_wreck01",0],"candidate.3288":["resources.assets",3288,"arrow_shoot",0],"candidate.5476":["resources.assets",5476,"arrow_generic_hit",0],"candidate.3640":["resources.assets",3640,"arrow_hit_ground",0],"candidate.4434":["resources.assets",4434,"arrow_hit_wall1",0],"candidate.5020":["resources.assets",5020,"arrow_hit_wall2",0],"candidate.3357":["resources.assets",3357,"arrow_hit_bunny",0],"candidate.4692":["resources.assets",4692,"arrow_hits_portal01",0],"candidate.2790":["resources.assets",2790,"lizard_spitexplosion_altv",0],"candidate.2864":["resources.assets",2864,"troll_movement14",0],"candidate.3150":["resources.assets",3150,"troll_charge01",0],"candidate.3131":["resources.assets",3131,"Greed_Archer_Die_01",0],"candidate.2804":["resources.assets",2804,"Greed_Knight_Death_02",0],"candidate.3554":["resources.assets",3554,"sfx_greed_crusher_die_01",0],"candidate.5736":["resources.assets",5736,"player_loses_crown01",0],"candidate.3944":["resources.assets",3944,"deer_jump_v2",0],"candidate.4247":["resources.assets",4247,"deer_is_killed",0],"candidate.3811":["resources.assets",3811,"sfx_critter_hare_die_01",0],"candidate.5272":["resources.assets",5272,"worker_hammer_wood01",0],"candidate.3945":["resources.assets",3945,"worker_hammer_wood02",0],"candidate.3804":["resources.assets",3804,"worker_hammer_iron01",0],"candidate.5176":["resources.assets",5176,"worker_hammer_iron02",0],"candidate.4611":["resources.assets",4611,"payment_choptree01",0],"candidate.3741":["resources.assets",3741,"worker_chops_tree01",0],"candidate.3672":["resources.assets",3672,"worker_chops_tree02",0],"candidate.2862":["resources.assets",2862,"payment_build",0],"candidate.4543":["resources.assets",4543,"wall_completed",0],"candidate.4245":["resources.assets",4245,"ironbuilding_complete",0],"candidate.4169":["resources.assets",4169,"troll_hitwallwood01",0],"candidate.4041":["resources.assets",4041,"troll_hitwalliron01",0],"candidate.5654":["resources.assets",5654,"wall_wood_wreck2",0],"candidate.5154":["resources.assets",5154,"wall_iron_wreck02",0]}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_hash(file):
    with file.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def owned(value):
    target = pathlib.Path(value).resolve()
    assert target.is_relative_to((ROOT / '.phase4').resolve()), 'AUDIO_OUTPUT_ROOT'
    assert not target.exists(), 'AUDIO_OUTPUT_EXISTS'
    for parent in target.parents:
        assert not parent.is_symlink(), 'AUDIO_OUTPUT_REPARSE'
    target.mkdir(parents=True)
    return target


def decode(identity, destination):
    assert sys.version.split()[0] == PYTHON_VERSION, 'PYTHON_PIN'
    assert identity in SELECTIONS, 'AUDIO_SELECTION'
    sys.path.insert(0, str(DEPENDENCIES))
    import UnityPy
    from PIL import Image
    from UnityPy.helpers.ResourceReader import get_resource_data
    assert UnityPy.__version__ == '1.23.0' and Image.__version__ == '13.0.0', 'DECODER_PIN'
    assert importlib.metadata.version('pyfmodex') == '0.7.2', 'PYFMODEX_PIN'
    owner_name, object_id, expected_name, expected_frames = SELECTIONS[identity]
    data_root = DONOR / 'KingdomTwoCrowns_Data'
    manifest_bytes = (DONOR / 'manifest.json').read_bytes()
    manifest = json.loads(manifest_bytes)
    original_rows = []

    def preserved(name):
        assert pathlib.PurePath(name).name == name, 'AUDIO_SOURCE_PATH'
        expected = next(row for row in manifest['files'] if row['path'] == name)
        file = data_root / name
        assert file.stat().st_size == expected['bytes'], 'ORIGINAL_SIZE'
        assert file_hash(file) == expected['sha256'], 'ORIGINAL_HASH'
        original_rows.append(expected)

    preserved(owner_name)
    environment = UnityPy.load(str(data_root / owner_name))
    owner = next(file for file in environment.files.values() if pathlib.Path(file.name).name == owner_name)
    obj = owner.objects[object_id]
    assert obj.type.name == 'AudioClip', 'AUDIO_TYPE'
    clip = obj.read()
    assert clip.m_Name == expected_name, 'AUDIO_NAME'
    stream = clip.m_Resource
    resource_name = pathlib.PurePosixPath(stream.m_Source.replace('\\', '/')).name
    preserved(resource_name)
    assert 0 <= stream.m_Offset and 0 < stream.m_Size <= 32 * 1024 * 1024, 'AUDIO_STREAM_BOUNDS'
    raw = get_resource_data(stream.m_Source, obj.assets_file, stream.m_Offset, stream.m_Size)
    assert len(raw) == stream.m_Size, 'AUDIO_STREAM_TRUNCATED'
    samples = clip.samples
    assert len(samples) == 1 and expected_name + '.wav' in samples, 'AUDIO_SAMPLE_COUNT'
    wav_bytes = samples[expected_name + '.wav']
    with wave.open(io.BytesIO(wav_bytes), 'rb') as wav:
        frames, channels, rate, width = wav.getnframes(), wav.getnchannels(), wav.getframerate(), wav.getsampwidth()
        pcm = wav.readframes(frames + 1)
        assert 0 < frames <= 44100 * 120 and abs(frames - round(clip.m_Length * rate)) <= 1 and channels == clip.m_Channels and channels == (1 if object_id in [2880,3700,3131,3554,3811] else 2) and rate == 44100 and width == 2, 'AUDIO_FORMAT'
        assert len(pcm) == frames * channels * width and wav.getcomptype() == 'NONE', 'AUDIO_PCM_TRUNCATED'
    for expected in original_rows:
        assert file_hash(data_root / expected['path']) == expected['sha256'], 'ORIGINAL_MUTATION'
    from UnityPy.export import AudioClipConverter
    AudioClipConverter.import_pyfmodex()
    fmod = pathlib.Path(AudioClipConverter.pyfmodex.__file__)
    native = DEPENDENCIES / 'UnityPy/lib/FMOD/Windows/x64/fmod.dll'
    result = {
        'id': identity, 'version': 1, 'role': identity.split('.')[-1],
        'source': {'owner': owner_name, 'type': 'AudioClip', 'objectId': object_id, 'name': expected_name,
                   'stream': {'path': resource_name, 'offset': stream.m_Offset, 'bytes': stream.m_Size,
                              'sha256': sha(raw)}, 'rawObjectSha256': sha(obj.get_raw_data())},
        'preservation': {'manifestSha256': sha(manifest_bytes), 'originalsBefore': original_rows,
                         'originalsAfter': original_rows, 'verifiedAfter': True},
        'tools': {'python': PYTHON_VERSION, 'pythonExeSha256': file_hash(pathlib.Path(sys.executable)),
                  'UnityPy': UnityPy.__version__, 'Pillow': Image.__version__,
                  'pyfmodex': importlib.metadata.version('pyfmodex'),
                  'converterSha256': file_hash(pathlib.Path(AudioClipConverter.__file__)),
                  'pyfmodexEntrySha256': file_hash(fmod), 'fmodDllSha256': file_hash(native)},
        'output': {'name': expected_name + '.wav', 'bytes': len(wav_bytes), 'sha256': sha(wav_bytes),
                   'pcmSha256': sha(pcm), 'pcmBytes': len(pcm), 'frames': frames, 'channels': channels,
                   'rate': rate, 'sampleWidth': width, 'seconds': frames / rate, 'trimFrames': [0, frames],
                   'loop': 'not-selected-or-auditioned', 'gainDb': 0},
        'bundle': {'originalPayloadBase64': base64.b64encode(raw).decode('ascii'),
                   'decodedWavBase64': base64.b64encode(wav_bytes).decode('ascii'),
                   'rawAudioClipBase64': base64.b64encode(obj.get_raw_data()).decode('ascii')},
        'status': {'decode': 'verified', 'listening': 'blocked-needs-capable-human',
                   'productionSelection': 'candidate-only', 'acceptanceOwner': '04-32'},
    }
    (destination / result['output']['name']).write_bytes(wav_bytes)
    (destination / 'sample.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({'id': identity, 'version': 1, 'sha256': sha(wav_bytes), 'frames': frames, 'complete': True}))


if __name__ == '__main__':
    assert len(sys.argv) == 4 and sys.argv[1] == '--child', 'USAGE --child ID OWNED_NEW_DIRECTORY'
    decode(sys.argv[2], owned(sys.argv[3]))
