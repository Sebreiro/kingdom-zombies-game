import pathlib,sys,json,io,hashlib,zipfile,math
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).resolve().parents[2]
spec=__import__('importlib.util',fromlist=['']).spec_from_file_location('media',ROOT/'tools/phase4/extract-media.py')
m=__import__('importlib.util',fromlist=['']).module_from_spec(spec);spec.loader.exec_module(m);Image=m.image_module()
def js(v):return (json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()
def png(im):
 b=io.BytesIO();im.save(b,format='PNG',compress_level=9);return b.getvalue()
def sha(b):return hashlib.sha256(b).hexdigest()
def build(inputs):
 common=json.loads(inputs['sources/common.json']);records={r['id']:r for r in common['resources']};retained=dict(inputs);parts=[];images={}
 def part(key,source,crop=None,size=None):
  record=records.get(source);member=record['member'] if record else 'masters/environment.png'
  im=Image.open(io.BytesIO(inputs[member])).convert('RGBA')
  if crop:im=im.crop(tuple(crop))
  im.putalpha(im.getchannel('A').point(lambda a:255 if a>=128 else 0))
  if size:
   im.putalpha(im.getchannel('A').point(lambda a:255 if a>=128 else 0));im=im.crop(im.getbbox());im=im.resize(tuple(size),Image.Resampling.NEAREST)
  data=bytearray(im.tobytes())
  for j in range(0,len(data),4):
   if not data[j+3]:data[j:j+3]=b'\x00\x00\x00'
  im=Image.frombytes('RGBA',im.size,bytes(data));images[key]=im;memberout='parts/'+key+'.png';retained[memberout]=png(im)
  parts.append({'key':key,'source':source,'sourceMember':member,'sourceSha256':sha(inputs[member]),'crop':crop,'nearestSize':size,'member':memberout,'sha256':sha(retained[memberout]),'rgbaSha256':sha(im.tobytes()),'size':list(im.size),'visiblePixels':sum(bool(a) for a in im.getchannel('A').tobytes())})
 selected=[('trunk-oak','common.r.10674'),('leaves-oak','common.r.9896'),('trunk-birch','common.r.11055'),('leaves-birch','common.r.9118'),('stump','common.r.10716'),('stump-birch','common.r.10719'),('hill','common.r.7982'),('hill-middle','common.r.10121'),('cliff-edge','common.r.11002'),('grass','common.r.11491'),('rocks','common.r.8949'),('cloud','common.r.8604'),('moon','common.r.10266'),('banner-pole','common.r.10173'),('banner-0','common.s0.18126'),('banner-1','common.s0.17383'),('banner-2','common.s0.5802'),('banner-3','common.s0.4447'),('banner-4','common.s0.6298'),('banner-5','common.s0.3167'),('tree-mark','common.s0.7705'),('portal-map','common.s0.6949'),('portal-map-ruin','common.s0.7692'),('camp-map','common.s0.7907'),('pointer-map','common.s0.7540'),('rabbit','common.r.9243'),('deer','common.r.8557'),('portal-back','common.s0.7865'),('portal-front','common.s0.8291')]
 for key,source in selected:part(key,source)
 part('berry-base','common.r.9480',[0,0,30,20]);part('fruit-base','common.r.11222',[0,0,96,104]);part('fruit-front','common.r.9468',[0,0,76,11]);part('fruit-stock','common.r.9204',[0,0,90,74]);part('fruit-front-stock','common.r.8203',[0,0,41,8])
 for i,source in enumerate(['common.r.10311','common.r.11340','common.r.10475','common.r.7827']):part('berry-stock-'+str(i),source)
 for key,crop,size in [('ground',[0,0,640,640],[128,48]),('log',[640,0,1280,640],[48,20]),('roots',[0,640,640,1280],[36,14]),('contact-shadow',[640,640,1280,1280],[20,4])]:part(key,'generated.environment',crop,size)
 atlas=Image.new('RGBA',(2048,1024));x=y=row=0
 for p in parts:
  w,h=p['size']
  if x+w+2>2048:x=0;y+=row+2;row=0
  assert y+h<=1024
  atlas.alpha_composite(images[p['key']],(x,y));p['atlasRect']=[x,y,w,h];x+=w+2;row=max(row,h)
 atlasbytes=png(atlas)
 pack={'schemaVersion':1,'id':'world','version':1,'obligations':['BL-15']+['EN-'+str(i).zfill(2) for i in range(1,12)],'logicalPixelsPerWorldPixel':1,'designUnitPixels':8,'stylePrecedence':'D-13 LOW-RESOLUTION OVERRIDES older detailed references; nearest native pixels','atlas':{'path':'res://assets/world/environment.png','size':[2048,1024],'sha256':sha(atlasbytes),'rgbaSha256':sha(atlas.tobytes())},'parts':parts,'sourceBindings':[{'file':'content/packs/common.json','sha256':sha(inputs['sources/common.json'])}],'sources':{'commonBundleSha256':inputs['sources/common-bundle.sha256'].decode().strip(),'generated':{'tool':'built-in image_gen','master':'masters/environment.png','sha256':sha(inputs['masters/environment.png']),'prompt':'prompts/environment.txt','promptSha256':sha(inputs['prompts/environment.txt']),'reference':'references/donor-board.png','reason':'K02 cliff art has no continuous walking surface; recovered kit has no selected fallen log or exposed root composition'}},'recipe':{'member':'recipes/build-world.py','sha256':sha(inputs['recipes/build-world.py'])},'acceptance':{'visual':'pending','owner':'04-32/04-33','completedObligations':[]}}
 world={'schemaVersion':1,'id':'world-map','version':1,'units':'u','pixelsPerUnit':8,'edges':[-320,320],'groundY':0,'terrain':[{'id':'ground','from':-320,'to':320,'height':0,'collisionPolygon':[[-320,0],[320,0],[320,6],[-320,6]],'navigation':[[-320,0],[320,0]],'art':'ground','artTileWidth':16}],'layers':[{'id':'sky','parallax':0,'z':-100},{'id':'hills','parallax':0.12,'z':-80},{'id':'middle-forest','parallax':0.35,'z':-60},{'id':'near-forest','parallax':0.7,'z':-30},{'id':'ground','parallax':1,'z':0},{'id':'actors','parallax':1,'z':5},{'id':'foreground','parallax':1,'z':12}],'lighting':[{'id':'dawn','time':0,'sky':[0.52,0.57,0.55,1],'tint':[0.85,0.84,0.77,1]},{'id':'day','time':0.25,'sky':[0.56,0.65,0.68,1],'tint':[1,1,1,1]},{'id':'dusk','time':0.65,'sky':[0.34,0.35,0.43,1],'tint':[0.74,0.70,0.73,1]},{'id':'night','time':0.8,'sky':[0.07,0.11,0.19,1],'tint':[0.48,0.56,0.72,1]},{'id':'next-dawn','time':1,'sky':[0.52,0.57,0.55,1],'tint':[0.85,0.84,0.77,1]}],'firelight':{'color':[1,0.65,0.28,1],'energy':0.7,'radiusPixels':70,'cosmeticOnly':True},'portals':[],'walls':[],'towers':[],'clearings':[],'plants':[],'wildlifeZones':[],'rallies':[],'dressing':[]}
 for side,sign in [('left',-1),('right',1)]:
  for i,xpos in enumerate([100,190,280]):world['portals'].append({'id':side+'.portal.'+str(i+1),'side':side,'sourceIndex':i+1,'x':sign*xpos,'art':['portal-back','portal-front'],'blocker':{'rect':[-1,-64,2,70],'blocks':['survivor'],'passes':['zombie'],'extendsAllJumpHeights':True},'projectileRect':[-1,-9,2,9],'interactionRadius':3,'revealRadius':24,'spawnOffset':[sign*2,0]})
  for kind,distances in [('walls',[25,75,155,245]),('towers',[21,71,151,241])]:
   for i,xpos in enumerate(distances):world[kind].append({'id':side+'.'+kind[:-1]+'.'+str(i+1),'side':side,'x':sign*xpos,'clearing':None if i==0 else side+'.clearing.'+str(i),'requiresDestroyedPortals':[side+'.portal.'+str(j+1) for j,p in enumerate([100,190,280]) if p<xpos],'interactionRadius':3,'collisionRect':[-2,-5,4,5] if kind=='walls' else [-1,-6,2,6],'factionBlocker':'zombie' if kind=='walls' else None,'artBoundsDoNotCollide':True})
  for i,xpos in enumerate([50,125,215]):world['clearings'].append({'id':side+'.clearing.'+str(i+1),'side':side,'x':sign*xpos,'extent':6,'trees':[{'offset':[-3,0],'species':'oak'},{'offset':[2,0],'species':'birch'}],'blocksWalking':False,'unlocks':[side+'.wall.'+str(i+2),side+'.tower.'+str(i+2)],'foodIndependent':True})
  for kind,distances,stock in [('berry',[10,50],8),('fruit',[16],6)]:
   for i,xpos in enumerate(distances):world['plants'].append({'id':side+'.'+kind+'.'+str(i+1),'side':side,'kind':kind,'x':sign*xpos,'capacity':stock,'refill':'daily-dawn-once','interactionRadius':3,'clearingRemoves':False,'base':kind+'-base','stockLayers':['berry-stock-'+str(j) for j in range(4)] if kind=='berry' else ['fruit-stock','fruit-front-stock'],'foodUnit':'one-item-per-stock'})
  for i,xpos in enumerate([45,130,230]):world['wildlifeZones'].append({'id':side+'.wildlife.'+str(i+1),'side':side,'center':sign*xpos,'width':15,'dailyBatch':[{'id':side+'.rabbit.'+str(i+1),'kind':'rabbit','x':sign*(xpos-3),'art':'rabbit'},{'id':side+'.deer.'+str(i+1),'kind':'deer','x':sign*(xpos+3),'art':'deer'},{'id':side+'.rabbit.'+str(i+1)+'.second','kind':'rabbit','x':sign*xpos,'art':'rabbit'}],'retainExisting':True,'visibleBorder':False})
  world['rallies'].append({'id':side+'.rally','side':side,'borderSource':'outermost-completed-living-wall','fallbackBorder':sign*12,'offsetInward':sign*-5,'states':['idle','ready','launching','assault-active','recalling','returning','no-target','insufficient-squad'],'pole':'banner-pole','cloth':['banner-'+str(i) for i in range(6)],'label':side.upper(),'interactionRadius':3})
  for i in range(16):world['dressing'].append({'id':side+'.prop.'+str(i),'x':sign*(6+i*19),'part':['rocks','grass','log','roots','stump'][i%5],'layer':'foreground' if i%3==0 else 'near-forest','blocksWalking':False})
 world['clearingStates']=[{'id':'intact','stump':False,'mark':False,'rotation':0,'duration':0},{'id':'marked-paid','stump':False,'mark':True,'rotation':0,'duration':0},{'id':'chopping','stump':False,'mark':True,'rotation':0,'duration':0.8},{'id':'falling-left','stump':False,'mark':False,'rotation':-1.5707963267948966,'duration':0.65},{'id':'falling-right','stump':False,'mark':False,'rotation':1.5707963267948966,'duration':0.65},{'id':'cleared-stump','stump':True,'mark':False,'rotation':0,'duration':0}]
 world['stockStates']=[{'id':'full','fraction':1},{'id':'partial','fraction':0.5},{'id':'empty','fraction':0},{'id':'refilled','fraction':1}]
 world['reveal']={'radius':24,'shared':True,'preserveExplored':True,'liveEnemies':False,'samples':[{'id':'unknown-portals','explored':[[-24,24]],'players':[{'id':'P1','number':1,'name':'Ada','x':0,'shape':'diamond','color':[0.3,0.65,0.95,1]},{'id':'P2','number':2,'name':'Bo','x':0,'shape':'square','color':[0.9,0.57,0.25,1]},{'id':'P3','number':3,'name':'Cai','x':0,'shape':'triangle','color':[0.55,0.8,0.4,1]},{'id':'P4','number':4,'name':'Dee','x':0,'shape':'circle','color':[0.75,0.45,0.85,1]}],'knownDefenses':['left.wall.1','right.wall.1'],'destroyedPortals':[],'borders':[-25,25]},{'id':'shared-exploration','explored':[[-214,124]],'players':[{'id':'P1','number':1,'name':'Ada','x':100,'shape':'diamond','color':[0.3,0.65,0.95,1]},{'id':'P2','number':2,'name':'Bo','x':-190,'shape':'square','color':[0.9,0.57,0.25,1]}],'knownDefenses':['left.wall.1','right.wall.1','right.wall.2'],'destroyedPortals':['left.portal.1'],'borders':[-25,75]}]}
 world['rallySamples']=[{'id':'refuge','livingWalls':[],'borders':[-12,12],'rallies':[-9,9]},{'id':'expanded','livingWalls':['left.wall.2','right.wall.3'],'borders':[-75,155],'rallies':[-70,150]},{'id':'wall-lost','livingWalls':['left.wall.1','right.wall.1'],'borders':[-25,25],'rallies':[-20,20]}]
 world['interaction']={'targetKinds':['character','corpse','site','plant','stash','rally'],'selection':{'steady':True,'outlinePixels':1,'markerPixels':3,'color':[0.95,0.94,0.85,1]},'overlapSample':[{'id':'corpse.same-x','kind':'corpse','x':0,'label':'Corpse'},{'id':'stash.same-x','kind':'stash','x':0,'label':'Stash'}],'selectorUsesStableId':True,'panelOcclusion':'outside-clipped-world-viewport'}
 # Native resource specification, consumed by source proof and production WorldPreview.
 nodes=[]
 def sprite(ident,partkey,pos,z=0,parent='.',rotation=0,color=None):
  nodes.append({'id':ident,'type':'Sprite2D','parent':parent,'part':partkey,'position':pos,'z':z,'rotation':rotation,'color':color or [1,1,1,1]})
 for i in range(40):sprite('ground_'+str(i),'ground',[-2560+i*128,-4],0)
 for i in range(7):sprite('hill_'+str(i),'hill',[-2560+i*896,-114],-80,color=[0.65,0.70,0.66,1])
 for i in range(34):
  xpos=-2520+i*150;species='oak' if i%2 else 'birch'
  sprite('middle_trunk_'+str(i),'trunk-'+species,[xpos,-120],-60,color=[0.42,0.49,0.47,1]);sprite('middle_leaves_'+str(i),'leaves-'+species,[xpos-18,-160],-59,color=[0.47,0.54,0.49,1])
 for item in world['clearings']:
  for i,tree in enumerate(item['trees']):
   xpos=item['x']*8+tree['offset'][0]*8;species=tree['species'];h=images['trunk-'+species].height
   sprite(item['id']+'.trunk.'+str(i),'trunk-'+species,[xpos,-h],-20);sprite(item['id']+'.leaves.'+str(i),'leaves-'+species,[xpos-18,-h-28],-19)
 for item in world['plants']:
  w,h=images[item['base']].size;sprite(item['id']+'.base',item['base'],[item['x']*8-w//2,-h],2)
  for i,partkey in enumerate(item['stockLayers']):sprite(item['id']+'.stock.'+str(i),partkey,[item['x']*8-w//2+(2 if item['kind']=='berry' else 0),-h+(2 if item['kind']=='berry' else 20)],3)
 for item in world['portals']:
  for i,partkey in enumerate(item['art']):w,h=images[partkey].size;sprite(item['id']+'.'+str(i),partkey,[item['x']*8-w//2,-h],1+i*4)
 for item in world['walls']+world['towers']:sprite(item['id'],'tree-mark',[item['x']*8-5,-12],5)
 for zone in world['wildlifeZones']:
  for animal in zone['dailyBatch']:
   w,h=images[animal['art']].size;sprite(animal['id'],animal['art'],[animal['x']*8-w//2,-h],5);sprite(animal['id']+'.shadow','contact-shadow',[animal['x']*8-10,-2],4,color=[1,1,1,0.3])
 for plant in world['plants']:sprite(plant['id']+'.shadow','contact-shadow',[plant['x']*8-10,-2],1,color=[1,1,1,0.3])
 for rally in world['rallies']:
  xpos=(rally['fallbackBorder']+(3 if rally['side']=='left' else -3))*8;sprite(rally['id']+'.pole','banner-pole',[xpos,-70],5);sprite(rally['id']+'.cloth','banner-0',[xpos,-68],6)
 for item in world['dressing']:w,h=images[item['part']].size;sprite(item['id'],item['part'],[item['x']*8-w//2,-h],12 if item['layer']=='foreground' else -10)
 for i in range(16):sprite('cloud_'+str(i),'cloud',[-2500+i*320,-220-(i%3)*10],-90,color=[0.8,0.85,0.85,1])
 world['native']={'root':'AuthoredWorld','filter':'nearest','atlas':'res://assets/world/environment.png','nodes':nodes,'geometrySource':'terrain/portals/walls/towers; never sprite alpha or padded texture bounds','origin':[0,0]}
 outputs={'environment.png':atlasbytes,'world.json':js(pack),'map.json':js(world)}
 retained.update(outputs)
 return pack,world,retained
def main():
 here=pathlib.Path(__file__).parent;common=(ROOT/'src/godot-game/content/packs/common.json').read_bytes();p=json.loads(common)
 ids={10674,9896,11055,9118,10716,10719,7982,10121,11002,11491,8949,8604,10266,10173,18126,17383,5802,4447,6298,3167,7705,6949,7692,7907,7540,9243,8557,7865,8291,9480,11222,9468,9204,8203,10311,11340,10475,7827}
 inputs={'sources/common.json':common,'sources/common-bundle.sha256':sha((ROOT/'production/phase4/common-selected.zip').read_bytes()).encode(),'masters/environment.png':(here/'world-master.png').read_bytes(),'prompts/environment.txt':(here/'world-prompt.txt').read_bytes(),'references/donor-board.png':(here/'donor-board.png').read_bytes(),'recipes/build-world.py':pathlib.Path(__file__).read_bytes()}
 with zipfile.ZipFile(ROOT/'production/phase4/common-selected.zip') as z:
  for r in p['resources']:
   if r['source'].get('objectId') not in ids:continue
   if not r.get('member','').endswith('.png'):continue
   inputs[r['member']]=z.read(r['member']);inputs['records/'+r['id']+'.json']=js(r)
   for s in [r['source'],*r.get('dependencies',[])]:
    if 'rawMember' in s:inputs[s['rawMember']]=z.read(s['rawMember'])
  for n in ['palettes/73492.json','palettes/73486.json','preserved-manifest.json']:inputs[n]=z.read(n)
 pack,world,members=build(inputs);members['members.json']=js([{'path':k,'bytes':len(v),'sha256':sha(v)} for k,v in sorted(members.items())])
 destinations={'environment.png':'src/godot-game/assets/world/environment.png','world.json':'src/godot-game/content/packs/world.json','map.json':'src/godot-game/content/world/map.json'}
 for name,dest in destinations.items():target=ROOT/dest;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(members[name])
 with zipfile.ZipFile(ROOT/'production/phase4/world.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,b in sorted(members.items()):info=zipfile.ZipInfo(n,(2026,11,17,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
 print(json.dumps({'parts':len(pack['parts']),'nodes':len(world['native']['nodes']),'members':len(members),'atlasBytes':len(members['environment.png'])}))
if __name__=='__main__':main()
