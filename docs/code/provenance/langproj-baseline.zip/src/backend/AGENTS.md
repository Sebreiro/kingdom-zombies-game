# Backend — Agent Guide

The backend is one .NET 10 solution, `lang-proj-core/LangProject.Core.slnx`, with an ASP.NET Core host
and PostgreSQL through EF Core. Its code rules are strict: a violation fails the build or the
architecture tests. Open only the docs the task needs. The [root guide](../../AGENTS.md) has the
repository-wide rules.

## Projects

The solution holds exactly these 15 projects. Each project's `docs/README.md` states its
responsibility, its allowed dependencies and its rules. Product projects sit in `lang-proj-core/`,
reusable packages in `lang-proj-core/packages/`.

| Project | Responsibility |
|---------|----------------|
| [LangProject.Core.CompositionRoot](lang-proj-core/LangProject.Core.CompositionRoot/docs/README.md) | The only host: logging, telemetry, configuration and each layer's registration, in order |
| [LangProject.Core.API](lang-proj-core/LangProject.Core.API/docs/README.md) | The HTTP layer: middleware, endpoints, the JSON contract and health checks |
| [LangProject.Core.API.Abstractions](lang-proj-core/LangProject.Core.API.Abstractions/docs/README.md) | The HTTP contract: request and response DTOs, their enums and the route constants |
| [LangProject.Core.Application](lang-proj-core/LangProject.Core.Application/docs/README.md) | The use cases, which map entities to DTOs by hand |
| [LangProject.Core.Application.Abstractions](lang-proj-core/LangProject.Core.Application.Abstractions/docs/README.md) | The application interfaces and the DTOs they take and return |
| [LangProject.Core.Domain](lang-proj-core/LangProject.Core.Domain/docs/README.md) | The domain entities and the rules they keep about their own values |
| [LangProject.Core.DAL](lang-proj-core/LangProject.Core.DAL/docs/README.md) | Persistence with EF Core on PostgreSQL: the context, repositories, migrations, the database health check |
| [LangProject.Core.DAL.Abstractions](lang-proj-core/LangProject.Core.DAL.Abstractions/docs/README.md) | The repository ports that Application reads and writes data through |
| [LangProject.Core.Integration.Abstractions](lang-proj-core/LangProject.Core.Integration.Abstractions/docs/README.md) | The provider port; its contract shape is decided in Phase 2 |
| [LangProject.Core.IntegrationTests](lang-proj-core/LangProject.Core.IntegrationTests/docs/README.md) | Integration tests against PostgreSQL in a container, with recorded provider responses |
| [LangProject.Core.ArchitectureTests](lang-proj-core/LangProject.Core.ArchitectureTests/docs/README.md) | Architecture and docs tests over the working tree and the production assemblies |
| [Sebreiro.UnitOfWork.Abstractions](lang-proj-core/packages/Sebreiro.UnitOfWork.Abstractions/docs/README.md) | The reusable Unit of Work port, `IUnitOfWork` |
| [Sebreiro.UnitOfWork.EntityFrameworkCore](lang-proj-core/packages/Sebreiro.UnitOfWork.EntityFrameworkCore/docs/README.md) | The reusable Unit of Work on EF Core |
| [Sebreiro.CodeRules.Analyzers](lang-proj-core/packages/Sebreiro.CodeRules.Analyzers/docs/README.md) | The reusable Roslyn analyzer with the custom `SCR` code rules |
| [Sebreiro.CodeRules.Analyzers.Tests](lang-proj-core/packages/Sebreiro.CodeRules.Analyzers.Tests/docs/README.md) | In-memory tests of every analyzer rule |

## Dependency rules

- CompositionRoot is the only host and the only project that references every layer.
- Transitive project references are disabled: a project uses only the projects it references directly.
- Consumers reference only `.Abstractions` projects; implementation projects are referenced only by
  CompositionRoot and the test projects.
- Layers stay pure: Domain depends only on `System`, Application uses no infrastructure types, and no
  code outside CompositionRoot uses `IServiceProvider`.
- Packages under `packages/` are product-agnostic: nothing in them names `LangProject`.

The exact allowed references are the edge table in
[code-architecture.md](docs/CodeRules/code-architecture.md#allowed-project-references).

## Code rules

- [Code style](docs/CodeRules/code-style.md): build settings, formatting, naming, members, named
  arguments, banned APIs and tests.
- [Code architecture](docs/CodeRules/code-architecture.md): the project set, dependencies, layer purity,
  types, the JSON contract, enums and health checks.
- [Rule matrix](docs/rule-matrix.md): how each rule is enforced and proven, and the only place to change
  that.

## Decision records

- [0001 Layer graph](docs/decisions/0001-layer-graph.md): the host, the abstractions and the allowed
  references.
- [0002 Provider abstraction](docs/decisions/0002-provider-abstraction.md): one port, one project per
  vendor.
- [0003 Enforcement approach](docs/decisions/0003-enforcement-approach.md): how the code rules are
  enforced and proven.
