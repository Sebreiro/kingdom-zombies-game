# 0003 Enforcement approach

Status: Accepted, Phase 1 (v1)

## Context

Readability for a human developer is a top priority of the backend, and the code rules that serve it
are written in [code-style.md](../CodeRules/code-style.md) and
[code-architecture.md](../CodeRules/code-architecture.md). A written rule that nothing checks drifts:
an editor hint is easy to ignore, a review misses things, and an AI agent follows the code it sees
rather than the doc. Some rules have no built-in diagnostic at all, and a check that is never shown to
fail may be passing by accident.

## Decision

Every written rule is enforced by at least one mechanism, and every mechanism is proven:

- **The compiler, with warnings as errors.** `TreatWarningsAsErrors` and `EnforceCodeStyleInBuild` are
  on in `Directory.Build.props`, so every compiler, analyzer and code-style warning fails the build.
  The NuGet vulnerability-audit warnings NU1901 to NU1904 are the only ones that stay warnings.
- **Analyzers.** The in-box .NET analyzers at `latest-recommended`, Meziantou.Analyzer and
  Roslynator.Analyzers, configured in `.editorconfig`, plus `Microsoft.CodeAnalysis.BannedApiAnalyzers`
  with a `BannedSymbols.txt`. Every enabled rule is an error.
- **Custom analyzer rules.** `Sebreiro.CodeRules.Analyzers` holds the `SCR` rules for what no built-in
  rule enforces exactly as written: named arguments, no comments in member bodies, no primary
  constructors, no `#region`, no null-forgiving `!`, body and line length, member order, continuation
  indent, using order, no `this.` and the typed `new` form.
- **ArchitectureTests.** Rule functions over the solution, the build files, the tracked files, the docs
  and the production assemblies check the project graph, type and layer rules, the file format, the
  docs and the rule matrix itself.
- **Proofs at two levels.** Fast in-memory analyzer tests cover each rule's edge cases, and every
  ArchitectureTests rule also runs on a bad-on-purpose input. A few real `dotnet build` runs of a
  throwaway solution copy prove that the actual build breaks for each configured rule, a banned API
  and a transitive-reference leak, and that a new migration builds clean.
- **The rule matrix is the one place to change a rule's enforcement.** [rule-matrix.md](../rule-matrix.md)
  maps each rule heading to its mechanisms, scope, exemptions, proof tests and level, and each heading
  links back to its row. ArchitectureTests fail when a heading, a row or a named proof test is missing.
- **No suppressions outside the matrix.** A suppression, a weakened severity, a skipped test or a
  generated-code marker on hand-written code fails the suppression scan unless it matches an
  exemption row of the matrix. The fix is to change the code, not to silence the rule.
- **No Node or Markdown toolchain in CI.** The docs checks are .NET tests in ArchitectureTests too.

## Consequences

- A rule violation fails the build or the tests locally and in CI, so it never reaches review as a
  warning.
- A new rule is a heading, an `Enforcement:` line, a matrix row, a mechanism and its proofs, added in
  one change; a rule with no mechanism cannot be written down unnoticed.
- An exemption is visible, scoped and reasoned in one table instead of spread across files.
- The custom analyzer is pinned to the Roslyn version of the SDK band in `global.json`, and its own
  coverage is gated in CI, so it has to be maintained with the SDK.
- The real-build proofs make the architecture test run slower than pure rule functions would; they are
  kept few and target only what a rule function cannot prove.
