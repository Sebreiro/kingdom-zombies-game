# Code Architecture Guidelines

This document describes the backend's project set, the dependency rules between projects, and the
type conventions. Follow these rules when writing or changing backend code. Every rule is enforced,
and any violation fails the build or the architecture tests. The [rule matrix](../rule-matrix.md)
maps each rule to every mechanism that enforces it, its scoped exemptions and its proof tests; the
`Enforcement:` line under each rule heading links to the rule's row.

## Solution structure

The solution root is `src/backend/lang-proj-core/`. Product projects use the `LangProject.Core.*`
names and sit flat in the solution root; reusable packages use the `Sebreiro.*` names and sit under
`packages/`.

```
src/backend/
    docs/                                         # code rules, decision records, rule matrix
    lang-proj-core/
        LangProject.Core.slnx                     # the solution
        Directory.Build.props                     # shared build settings and the single version value
        Directory.Packages.props                  # central package versions
        .editorconfig                             # C# style and analyzer settings
        Dockerfile                                # backend image
        LangProject.Core.CompositionRoot/         # the only host (ASP.NET Core)
        LangProject.Core.API/                     # HTTP endpoints
        LangProject.Core.API.Abstractions/        # HTTP contracts: RequestDto / ResponseDto, route constants
        LangProject.Core.Application/             # use cases
        LangProject.Core.Application.Abstractions/ # application interfaces and DTOs
        LangProject.Core.Domain/                  # domain entities
        LangProject.Core.DAL/                     # EF Core persistence and migrations
        LangProject.Core.DAL.Abstractions/        # repository interfaces
        LangProject.Core.Integration.Abstractions/ # provider port
        LangProject.Core.IntegrationTests/        # integration tests
        LangProject.Core.ArchitectureTests/       # architecture and docs tests
        packages/
            Sebreiro.UnitOfWork.Abstractions/     # Unit of Work interfaces
            Sebreiro.UnitOfWork.EntityFrameworkCore/ # Unit of Work on EF Core
            Sebreiro.CodeRules.Analyzers/         # custom code-rule analyzers
            Sebreiro.CodeRules.Analyzers.Tests/   # analyzer tests
```

### Exactly the listed projects

Enforcement: [R-51](../rule-matrix.md#r-51)

The solution holds exactly these 15 projects. `LangProject.Core.Integration.<Vendor>` projects,
one per provider, arrive in Phase 2. Every backend csproj is in the solution, and every project a
project references is one of them.

## Project dependencies

### CompositionRoot is the only host

Enforcement: [R-52](../rule-matrix.md#r-52)

`LangProject.Core.CompositionRoot` is the only host and the only non-test executable. It is the
only project that references every layer.

### Transitive project references disabled

Enforcement: [R-53](../rule-matrix.md#r-53)

`DisableTransitiveProjectReferences` is on in every project, so a project can use only the
projects it references directly. It is set once, to `true`, in the solution's
`Directory.Build.props`, and every project imports that file and the solution's
`Directory.Build.targets`, with no nearer `Directory.Build.*` file in between.

### Allowed project references

Enforcement: [R-54](../rule-matrix.md#r-54)

Each project may reference exactly the projects in this table, and no others. Short names drop the
`LangProject.Core.` prefix. Each edge is a `ProjectReference` in the project's own csproj; the
checks read the references MSBuild evaluates, so one added by a semicolon list, a wildcard, a
`Directory.Build.*` file or an imported file counts too.

| Project | Allowed ProjectReferences |
|---|---|
| CompositionRoot | every non-test project except the analyzer (needed so all assemblies are present at runtime while transitive references are disabled) |
| API | API.Abstractions, Application.Abstractions |
| API.Abstractions | none |
| Application | Application.Abstractions, DAL.Abstractions, Integration.Abstractions, Domain, Sebreiro.UnitOfWork.Abstractions |
| Application.Abstractions | none (DTOs only, no Domain) |
| DAL | DAL.Abstractions, Domain |
| DAL.Abstractions | Domain |
| Domain | none |
| Integration.Abstractions | none |
| `Integration.<Vendor>` (Phase 2) | Integration.Abstractions |
| Sebreiro.UnitOfWork.EntityFrameworkCore | Sebreiro.UnitOfWork.Abstractions |
| Sebreiro.UnitOfWork.Abstractions | none |
| Sebreiro.CodeRules.Analyzers | none |
| *Analyzer edge* | every project → `Sebreiro.CodeRules.Analyzers` as an analyzer only (`OutputItemType=Analyzer`, `ReferenceOutputAssembly=false`), set once in `Directory.Build.targets`; the graph test treats it separately |
| IntegrationTests | CompositionRoot, plus any other non-test project except the analyzer (tests are exempt from the implementation rule) |
| ArchitectureTests | every non-test project except the analyzer |
| Sebreiro.CodeRules.Analyzers.Tests | Sebreiro.CodeRules.Analyzers |

ArchitectureTests references every non-test project except the analyzer, because a test project
is an executable and is not referenced by another test project. "Non-test project" leaves out the
three test projects. The analyzer is never a `ProjectReference` of these rows: every project
except the analyzer itself reaches it through the analyzer edge. IntegrationTests must reference
CompositionRoot and may also reference any other non-test project its tests need. The
architecture tests parse this table and compare it with their copy of it, so the two cannot
drift apart.

### Interface-only abstractions

Enforcement: [R-55](../rule-matrix.md#r-55)

- Every implementation project (API, Application, DAL, each `Integration.<Vendor>` and
  `Sebreiro.UnitOfWork.EntityFrameworkCore`) has an interface-only `.Abstractions` sibling.
- Consumers reference only the `.Abstractions` project.
- Implementation projects are referenced only by CompositionRoot and the test projects.
- An implementation project's only public type is its `AddXxx` registration class; everything else
  is `internal`.
- `.Abstractions` projects hold only interfaces, DTOs, enums and constants-only static classes,
  such as route constants.
- Domain, CompositionRoot, the analyzer and the test projects have no `.Abstractions` sibling.

### No entities in outward contracts

Enforcement: [R-56](../rule-matrix.md#r-56)

`Application.Abstractions` and `API.Abstractions` use DTOs only and never reference Domain.
`DAL.Abstractions` repository interfaces may take and return Domain entities.

### Per-layer registration

Enforcement: [R-57](../rule-matrix.md#r-57)

Each layer exposes one `AddXxx(IServiceCollection, ...)` extension, for example `AddApi`,
`AddApplication` and `AddDal`. CompositionRoot calls them in order.

## Layer purity

### Domain depends only on System

Enforcement: [R-58](../rule-matrix.md#r-58)

Domain code depends only on `System.*` types.

### Application has no infrastructure types

Enforcement: [R-59](../rule-matrix.md#r-59)

Application code does not use EF Core, ASP.NET Core or `System.Net.Http` types.

### No IServiceProvider outside CompositionRoot

Enforcement: [R-60](../rule-matrix.md#r-60)

Code outside CompositionRoot does not use `IServiceProvider` or any other service-location type:
`IKeyedServiceProvider`, `IServiceScopeFactory`, `IServiceScope` or `ActivatorUtilities`, not
even inside a lambda or an `async` method. Layers depend only on DI abstractions such as
`IServiceCollection`.

### Integration projects are isolated

Enforcement: [R-61](../rule-matrix.md#r-61)

Integration projects reference only `Integration.Abstractions`, never DAL, Application or another
Integration project.

### Reusable packages are product-agnostic

Enforcement: [R-62](../rule-matrix.md#r-62)

Projects under `packages/` have no ProjectReference or PackageReference whose path or ID contains
the product name `LangProject`, and every non-test package project is packable with `dotnet pack`.

## Architecture rules

### Domain entities

Enforcement: [R-63](../rule-matrix.md#r-63)

- Every setter is private: not public, internal, protected or `init`.
- State is changed through methods.
- Every entity has a parameterized constructor that initialises it.
- Every entity has a private parameterless constructor marked `[Obsolete]`, used only by the ORM.

### DTOs

Enforcement: [R-64](../rule-matrix.md#r-64)

- A DTO is a type whose name ends in `Dto`.
- HTTP DTOs, the DTOs of `API.Abstractions`, end in `RequestDto` or `ResponseDto`, for example
  `HealthResponseDto`. A type that is one part of a body is named for its side too, for example
  `HealthCheckEntryResponseDto`.
- No product type ends in plain `Request` or `Response`.
- DTOs are classes, not records (neither `record class` nor `record struct`).
- DTO setters are private, and values are set through the constructor.

### Options classes

Enforcement: [R-81](../rule-matrix.md#r-81)

- An options class is a non-static class whose name ends in `Options` and that is bound from configuration, for
  example `TelemetryOptions` from the `Telemetry` section.
- Every setter is private: not public, internal, protected or `init`.
- It is bound with `BindNonPublicProperties = true`, for example
  `section.Get<TelemetryOptions>(configureOptions: binder => binder.BindNonPublicProperties = true)`. The default
  binder fills only public properties with public setters, so without the flag every value stays at its default.

### Hand-written mapping

Enforcement: [R-65](../rule-matrix.md#r-65)

Mapping between entities and DTOs is hand-written, with explicit constructor-based mapping methods.
AutoMapper, Mapster and Mapperly are not used.

### Single version value

Enforcement: [R-66](../rule-matrix.md#r-66)

The version value is set only in `src/backend/lang-proj-core/Directory.Build.props`. No other
csproj or props file sets `Version`, `VersionPrefix`, `VersionSuffix`, `AssemblyVersion` or
`FileVersion`.

## Code structure

### Member body length

Enforcement: [R-37](../rule-matrix.md#r-37)

A member body of more than 60 lines fails the build; 40 lines is the advised length. Split code
into private methods where you can. The counting rules are in `code-style.md`.

## Documentation

### XML docs and comments

Enforcement: [R-35](../rule-matrix.md#r-35), [R-36](../rule-matrix.md#r-36)

All public types and members have XML documentation comments, and member bodies hold no comments.
The details are in `code-style.md`.

### Every project has its own docs

Enforcement: [R-83](../rule-matrix.md#r-83)

Every project in the solution has a `docs/` folder beside its csproj, with a `README.md` that has
these three sections:

- `## Responsibility`: what the project owns, in a few sentences.
- `## Allowed dependencies`: one top-level bullet per project its csproj references, the project name
  in a code span, or the single bullet `None` when it references none. The analyzer-only edge from
  `Directory.Build.targets` is not listed.
- `## Rules`: the rules that matter most for the project, linked to these docs and to the rule matrix.

Other sections may follow. A change that adds or removes a ProjectReference updates the project's
list in the same change, together with the edge table above.

### Decision records

Enforcement: [R-84](../rule-matrix.md#r-84)

Backend architecture decisions are recorded in `src/backend/docs/decisions/`, one Markdown file per
decision, named `NNNN-short-name.md`. Each record has a `Status:` line and the sections
`## Context`, `## Decision` and `## Consequences`, and the [backend index](../../AGENTS.md) links it.
The layer graph, the provider abstraction and the enforcement approach each have a record. A change
to a recorded decision updates its record in the same change.

## Named arguments

### Named arguments at call sites

Enforcement: [R-38](../rule-matrix.md#r-38)

When calling any method or constructor, name every argument (prefix it with its parameter name),
except for the exemptions list in `code-style.md`.

**Example - Correct:**
```csharp
return new SentenceDefinitionResponseDto(
        originalSentence: normalizedSentence,
        translation: translationResult.Translation,
        transcription: translationResult.Transcription,
        sourceLanguage: SourceLanguageCode,
        targetLanguage: TargetLanguageCode);
```

**Example - Incorrect (do not use):**
```csharp
return new SentenceDefinitionResponseDto(
        normalizedSentence,
        translationResult.Translation,
        translationResult.Transcription,
        SourceLanguageCode,
        TargetLanguageCode);
```

## JSON contract

The HTTP JSON contract is set once, in `JsonContract.Configure` in API, and applied to the HTTP JSON
options in `AddApi`. If controllers are added later, the same method is applied to their JSON
options too.

### Property names in camelCase and enums as their pinned names

Enforcement: [R-68](../rule-matrix.md#r-68)

Property names are written in camelCase. An enum goes on the wire as a string: the name pinned on
the member with `[JsonStringEnumMemberName]`, which is the C# member name when the member is
written, for example `"NotSupported"`. An enum is never written as a number.

### Exact-match enum input

Enforcement: [R-69](../rule-matrix.md#r-69)

An incoming enum value must equal a pinned name exactly. Numbers, numeric strings, other casing,
surrounding whitespace, comma-joined values and the `Unknown` name are rejected, and so is any
token that is not a string. One shared converter, `ExactStringEnumConverterFactory`, reads every
enum.

### Nulls omitted and unknown properties ignored

Enforcement: [R-70](../rule-matrix.md#r-70)

A property whose value is null is left out of a response. A request property that the DTO does not
declare is ignored.

### Missing and null required values rejected

Enforcement: [R-71](../rule-matrix.md#r-71)

A request without a value for a constructor parameter, or with a null for a non-nullable one, is
rejected before app code runs. Every constructor parameter is required, nullable ones included, so
an optional request field needs a default value in the constructor, for example `string? note = null`.

### Shared JSON settings configured once

Enforcement: [R-72](../rule-matrix.md#r-72)

The settings above live in `JsonContract.Configure` only, and the host's HTTP JSON options are
configured with it. No endpoint or DTO sets its own serializer options.

### Times and durations

Enforcement: [R-73](../rule-matrix.md#r-73)

- Times are UTC ISO 8601 values with `Z`, held as `DateTimeOffset` and stored as `timestamptz`.
- Times come from `TimeProvider.GetUtcNow()`; `DateTime.Now`, `DateTime.UtcNow`, `DateTime.Today`
  and the `DateTimeOffset` twins of the first two are banned.
- DTO and entity properties and fields never hold a `DateTime` or a `TimeSpan`, not even inside
  a nullable, an array, a list or a dictionary.
- A duration is a number whose name carries its unit, for example `durationMs`.

## Enums

### Unknown is the zero value and never valid

Enforcement: [R-74](../rule-matrix.md#r-74)

Every enum declares `Unknown = 0`. It is never valid: the JSON contract rejects it on input and
never writes it, storage never writes it and rejects it on read, and entities refuse it. It only
forces every value to be set explicitly.

### Every enum member is pinned

Enforcement: [R-75](../rule-matrix.md#r-75)

Every enum member carries `[JsonStringEnumMemberName("...")]`, and no two members share a pinned
name. The pinned name is the published value: renaming the C# member changes neither the JSON
contract nor a stored value.

### Enums stored as their pinned names

Enforcement: [R-76](../rule-matrix.md#r-76)

An enum property of an EF entity is stored as its pinned name, a string, through the shared
converter `EnumMemberNameValueConverter`. `EnumStorage.ApplyPinnedNames` sets it on every enum
property at the end of `OnModelCreating`. A stored string that is not a pinned name fails loudly
when it is read.

### Enum values only added

Enforcement: [R-77](../rule-matrix.md#r-77)

Enum values are only ever added, never removed or renamed: a member keeps its pinned name and its
number for good. Response enums are documented as extensible, so a client maps a value it does not
know to its own fallback.

### Domain enums never leave the backend

Enforcement: [R-78](../rule-matrix.md#r-78)

Enums of Domain entities are never used in a contract project. `API.Abstractions` and
`Application.Abstractions` declare their own enums, and the hand-written mappers translate between
them.

## Health checks

The health endpoint `/health` reports the service's own health from its registered health checks
(D-56, D-59).

### Every external dependency has a health check

Enforcement: [R-79](../rule-matrix.md#r-79)

Every external dependency the service needs, such as the database, a cache or a provider, gets a
health check when it is added. Each check is classified as one of two kinds:

- **Critical**: the service cannot work without the dependency. The check's failure status is
  `Unhealthy`, so `/health` answers 503. The database is critical.
- **Non-critical**: the service still works without the dependency. The check's failure status is
  `Degraded`, so `/health` answers 200 and the body shows the failing check.

### One tag per health check, matching its failure status

Enforcement: [R-80](../rule-matrix.md#r-80)

Every registered health check carries exactly one tag, `critical` or `non-critical`. A `critical`
check fails as `Unhealthy` and a `non-critical` check fails as `Degraded`.
