using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// The workflow part of the suppression scan, for workflows and composite actions: <c>continue-on-error</c>,
/// quoted or not, set to anything other than <c>false</c>, and every weakening command-line switch of
/// <see cref="CommandLineSuppressions"/>. Comment lines are skipped; the subject of a hit is its trimmed line.
/// </summary>
internal static partial class WorkflowSuppressions
{
    /// <summary>Finds every suppression in one workflow or composite action.</summary>
    /// <param name="relativePath">The repository-relative path, with forward slashes.</param>
    /// <param name="content">The file text.</param>
    /// <returns>The hits, in file order.</returns>
    internal static IReadOnlyList<SuppressionHit> Scan(string relativePath, string content)
    {
        var hits = new List<SuppressionHit>();
        string[] lines = content.Split(separator: '\n');
        for (int index = 0; index < lines.Length; index++)
        {
            string line = lines[index].Trim();
            if (line.StartsWith(value: '#'))
            {
                continue;
            }

            var patterns = new List<string>(collection: CommandLineSuppressions.Patterns(line: line));
            Match continueOnError = ContinueOnErrorPattern().Match(input: line);
            if (continueOnError.Success && !IsFalse(value: continueOnError.Groups["value"].Value))
            {
                patterns.Insert(index: 0, item: "continue-on-error");
            }

            hits.AddRange(collection: patterns.Select(selector: pattern => new SuppressionHit(
                    path: relativePath,
                    lineNumber: index + 1,
                    text: line,
                    subject: line,
                    pattern: pattern)));
        }

        return hits;
    }

    [GeneratedRegex(
            pattern: @"[""']?\bcontinue-on-error[""']?\s*:(?<value>[^#]*)",
            options: RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex ContinueOnErrorPattern();

    private static bool IsFalse(string value)
    {
        return string.Equals(
                a: value.Trim().Trim('"', '\''),
                b: "false",
                comparisonType: StringComparison.OrdinalIgnoreCase);
    }
}
