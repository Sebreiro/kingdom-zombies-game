using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Rules;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Documentation;

/// <summary>
/// Every relative link in the repository's docs resolves (SPEC R17 adjacency edge, D-12): each tracked Markdown file
/// outside <c>.claude/</c> and <c>.planning/</c> has no relative link whose target git does not track. External
/// links and <c>#anchor</c> parts are not checked. The rule runs on the repository and on synthetic docs.
/// </summary>
public sealed class DocsLinkTests
{
    /// <summary>Every relative link of every checked Markdown file points at a tracked file or folder.</summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Docs_RelativeLinks_ResolveToFiles()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        RepositoryDocs docs = await RepositoryDocs.LoadAsync(cancellationToken: cancellationToken);

        docs.Text(path: "AGENTS.md").ShouldNotBeNull();
        docs.Documents.Keys.ShouldNotContain(elementPredicate: path => path.StartsWith(
                value: ".planning/",
                comparisonType: StringComparison.Ordinal));
        IReadOnlyList<string> violations = MarkdownLinks.CheckLinks(docs: docs);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// A link to a missing file is reported with its document, line and target; a link to a missing anchor of an
    /// existing file is not.
    /// </summary>
    [Fact]
    public void LinkCheck_MissingTarget_IsReported()
    {
        RepositoryDocs docs = Repository(
                documents: new(comparer: StringComparer.Ordinal)
                {
                    [DocumentPath] = "# Guide\n\nSee [the rules](rules/missing.md#intro).\n"
                            + "Read [setup](rules/setup.md#no-such-anchor).\n",
                },
                otherTracked: ["docs/rules/setup.md"]);

        IReadOnlyList<string> violations = MarkdownLinks.CheckLinks(docs: docs);

        string violation = violations.ShouldHaveSingleItem();
        violation.ShouldStartWith(expected: DocumentPath + ":3:");
        violation.ShouldContain(expected: "docs/rules/missing.md");
    }

    /// <summary>
    /// <c>http:</c>, <c>https:</c> and <c>mailto:</c> links, links to an anchor of the same document, and links in
    /// fenced code or code spans are not read, so none of them is reported.
    /// </summary>
    [Fact]
    public void LinkCheck_ExternalAnchorAndCodeLinks_AreSkipped()
    {
        const string Markdown = """
                # Guide

                [Site](https://example.com/missing.md) [plain](http://example.com) [mail](mailto:a@example.com)
                [Here](#guide) and `[code](missing-in-span.md)`.

                ```text
                [fenced](missing-in-fence.md)
                ```

                """;

        IReadOnlyList<MarkdownLink> links = MarkdownLinks.ReadLinks(documentPath: DocumentPath, markdown: Markdown);

        links.ShouldBeEmpty();
    }

    /// <summary>
    /// Targets resolve from the document's folder: <c>..</c> goes up, a leading <c>/</c> starts at the root, a
    /// trailing slash names a folder, and a title or angle brackets around the path are dropped.
    /// </summary>
    /// <param name="target">The link target as written.</param>
    /// <param name="expected">The repository path it must resolve to.</param>
    [Theory]
    [InlineData("../src/backend/AGENTS.md", "src/backend/AGENTS.md")]
    [InlineData("./rules/setup.md", "docs/rules/setup.md")]
    [InlineData("/deploy/compose.yaml", "deploy/compose.yaml")]
    [InlineData("rules/", "docs/rules")]
    [InlineData("rules/setup.md \"Setup\"", "docs/rules/setup.md")]
    [InlineData("<rules/my%20notes.md>", "docs/rules/my notes.md")]
    public void LinkCheck_RelativeTarget_ResolvesFromDocumentFolder(string target, string expected)
    {
        IReadOnlyList<MarkdownLink> links = MarkdownLinks.ReadLinks(
                documentPath: DocumentPath,
                markdown: $"See [it]({target}#part).\n");

        MarkdownLink link = links.ShouldHaveSingleItem();
        link.Line.ShouldBe(expected: 1);
        link.Target.ShouldBe(expected: expected);
    }

    /// <summary>A link that climbs above the repository root is reported.</summary>
    [Fact]
    public void LinkCheck_TargetAboveRoot_IsReported()
    {
        RepositoryDocs docs = Repository(
                documents: new(comparer: StringComparer.Ordinal) { [DocumentPath] = "See [up](../../outside.md).\n" },
                otherTracked: []);

        IReadOnlyList<string> violations = MarkdownLinks.CheckLinks(docs: docs);

        violations.ShouldHaveSingleItem().ShouldContain(expected: "leaves the repository");
    }

    /// <summary>
    /// Links to a tracked file and to a folder that holds tracked files pass; a folder git does not know fails.
    /// </summary>
    [Fact]
    public void LinkCheck_TrackedFileAndFolder_AreAccepted()
    {
        RepositoryDocs docs = Repository(
                documents: new(comparer: StringComparer.Ordinal)
                {
                    [DocumentPath] = "[File](rules/setup.md), [folder](rules/), [root](../), [gone](empty/).\n",
                },
                otherTracked: ["docs/rules/setup.md"]);

        IReadOnlyList<string> violations = MarkdownLinks.CheckLinks(docs: docs);

        violations.ShouldHaveSingleItem().ShouldContain(expected: "'docs/empty'");
    }

    /// <summary>
    /// Reference definitions and HTML <c>href</c> and <c>src</c> attributes are links too, and a missing target is
    /// reported for each; a footnote definition and a reference definition to a tracked file are not.
    /// </summary>
    [Fact]
    public void LinkCheck_ReferenceAndHtmlLinks_AreChecked()
    {
        RepositoryDocs docs = Repository(
                documents: new(comparer: StringComparer.Ordinal)
                {
                    [DocumentPath] = "# Guide\n\n[rules]: ../missing.md\n[ok]: rules/setup.md \"Setup\"\n"
                            + "See <a href=\"gone.md#part\">gone</a> and <img src='pic.png'>.\n[^1]: A footnote.\n",
                },
                otherTracked: ["docs/rules/setup.md"]);

        IReadOnlyList<string> violations = MarkdownLinks.CheckLinks(docs: docs);

        violations.Count.ShouldBe(expected: 3, customMessage: string.Join(separator: "\n", values: violations));
        violations[0].ShouldStartWith(expected: DocumentPath + ":3:");
        violations[1].ShouldContain(expected: "'docs/gone.md'");
        violations[2].ShouldContain(expected: "'docs/pic.png'");
    }

    /// <summary>
    /// Fences follow CommonMark: a line with an inline triple-backtick code span opens no fence, a <c>~~~</c> fence
    /// hides its links, and a four-backtick fence around a three-backtick block closes only at four backticks. The
    /// links before, between and after are read, and the rule-doc headings after the stray line are found.
    /// </summary>
    [Fact]
    public void LinkCheck_StrayFenceLines_DoNotHideLinks()
    {
        const string Markdown = """
                ```dotnet build``` is the command.
                [after](missing-one.md)

                ~~~text
                [tilde](in-tilde.md)
                ~~~

                ````markdown
                ```
                [nested](in-nested.md)
                ```
                [still](in-outer.md)
                ````
                [last](missing-two.md)

                ### Heading after the fences

                """;

        IReadOnlyList<MarkdownLink> links = MarkdownLinks.ReadLinks(documentPath: DocumentPath, markdown: Markdown);

        links.Select(selector: link => link.Target).ShouldBe(expected: ["docs/missing-one.md", "docs/missing-two.md"]);
        links.Select(selector: link => link.Line).ShouldBe(expected: [2, 14]);
        RuleDocument.Headings(markdown: Markdown).ShouldHaveSingleItem().Text
                .ShouldBe(expected: "Heading after the fences");
    }

    private const string DocumentPath = "docs/guide.md";

    private static RepositoryDocs Repository(Dictionary<string, string> documents, IReadOnlyList<string> otherTracked)
    {
        return new RepositoryDocs(trackedFiles: otherTracked, documents: documents);
    }
}
