using System.Collections.Generic;

namespace LangProject.Core.ArchitectureTests.Types.Fixtures;

/// <summary>
/// Type shapes for the abstractions-content and implementation-visibility rules: the allowed kinds, and one
/// bad-on-purpose shape per violation. They compile under every house rule; only the ArchitectureTests rules reject
/// the bad ones.
/// </summary>
internal static class AbstractionFixtures
{
    /// <summary>Allowed in an abstractions project: an interface.</summary>
    internal interface ISampleContract
    {
        string Id { get; }
    }

    /// <summary>Allowed in an abstractions project: an enum.</summary>
    internal enum SampleKind
    {
        Unknown = 0,
        Sample = 1,
    }

    /// <summary>Allowed in an abstractions project: a static class holding only constants.</summary>
    internal static class SampleRoutes
    {
        public const string Sample = "/sample";
    }

    /// <summary>Allowed in an abstractions project: a DTO.</summary>
    internal sealed class SampleDto
    {
        public SampleDto(string id)
        {
            Id = id;
        }

        public string Id { get; private set; }
    }

    /// <summary>Bad in an abstractions project: a service class, which belongs in the implementation project.</summary>
    internal sealed class SampleService : ISampleContract
    {
        public string Id => "sample";
    }

    /// <summary>Bad in an abstractions project: a static class with a method, not only constants.</summary>
    internal static class SampleHelpers
    {
        public static string Normalize(string value)
        {
            return value.Trim();
        }
    }

    /// <summary>Allowed public type of an implementation project: the registration class with an Add method.</summary>
    public static class SampleRegistration
    {
        public static ICollection<string> AddSample(ICollection<string> services)
        {
            services.Add(item: "sample");
            return services;
        }
    }

    /// <summary>Bad in an implementation project: a second public type besides the registration class.</summary>
    public sealed class SamplePublicService
    {
    }

    /// <summary>Allowed in an implementation project: an internal implementation.</summary>
    internal sealed class SampleInternalService
    {
    }
}
