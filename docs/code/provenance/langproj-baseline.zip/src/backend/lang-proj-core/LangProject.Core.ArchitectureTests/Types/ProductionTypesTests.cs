using System;
using System.IO;
using System.Linq;
using LangProject.Core.ArchitectureTests.Infrastructure;
using LangProject.Core.ArchitectureTests.Projects;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Types;

/// <summary>
/// The subjects of every type and purity rule: one assembly per production project of the solution, so a new
/// production project, such as a Phase 2 <c>Integration.&lt;Vendor&gt;</c> project, is checked without any edit to
/// the rule list.
/// </summary>
public sealed class ProductionTypesTests
{
    /// <summary>
    /// The loaded assemblies are exactly the solution's non-test projects except the analyzer, each from the test
    /// output, and every assembly a test names through a type is one of them.
    /// </summary>
    [Fact]
    public void ProductionAssemblies_LoadedSet_MatchesSolutionProjects()
    {
        string solutionXml = File.ReadAllText(path: RepositoryLayout.SolutionFilePath);

        ProductionTypes.Assemblies.Select(selector: ProductionTypes.NameOf)
                .ShouldBe(expected: ProductionTypes.ProductionProjectNames(solutionXml: solutionXml));
        ProductionTypes.Assemblies.Count.ShouldBe(expected: 11);
        ProductionTypes.Anchors.Select(selector: anchor => anchor.Assembly)
                .Except(second: ProductionTypes.Assemblies)
                .ShouldBeEmpty();
        string outputFolder = Path.TrimEndingDirectorySeparator(path: AppContext.BaseDirectory);
        ProductionTypes.Assemblies
                .Select(selector: assembly => Path.GetDirectoryName(path: assembly.Location))
                .ShouldAllBe(elementPredicate: folder => folder == outputFolder);
    }

    /// <summary>
    /// A project added to the solution, such as an Integration vendor, becomes a subject, while test projects and
    /// the analyzer do not.
    /// </summary>
    [Fact]
    public void ProductionAssemblies_NewSolutionProject_IsIncluded()
    {
        const string SolutionXml = """
                <Solution>
                  <Project Path="LangProject.Core.Domain/LangProject.Core.Domain.csproj" />
                  <Project Path="LangProject.Core.Integration.Vendor/LangProject.Core.Integration.Vendor.csproj" />
                  <Project Path="LangProject.Core.IntegrationTests/LangProject.Core.IntegrationTests.csproj" />
                  <Project Path="packages/Sebreiro.CodeRules.Analyzers/Sebreiro.CodeRules.Analyzers.csproj" />
                </Solution>
                """;

        ProductionTypes.ProductionProjectNames(solutionXml: SolutionXml).ShouldBe(expected:
        [
            AllowedEdges.Domain,
            "LangProject.Core.Integration.Vendor",
        ]);
    }
}
