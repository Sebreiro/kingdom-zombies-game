using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// P5: the devcontainer never reaches the host Docker daemon. No tracked devcontainer file (every
/// <c>devcontainer.json</c> under <c>.devcontainer/</c>, the root <c>.devcontainer.json</c>, and every other file
/// under <c>.devcontainer/</c>, such as the Dockerfile and scripts) names a Docker or Podman socket, sets
/// <c>DOCKER_HOST</c>, joins the host network, uses a compose file or uses a feature that binds the host socket;
/// Docker runs inside the container through the docker-in-docker feature.
/// SPEC R10: the devcontainer installs exactly the Node version pinned in <c>src/frontend/user-app/.node-version</c>
/// from the official tarball after a checksum check, and pnpm from <c>packageManager</c> with install scripts off.
/// The check lives here because devcontainer edits do not trigger the frontend workflow.
/// </summary>
public sealed partial class DevcontainerTests
{
    /// <summary>
    /// At least one devcontainer config is tracked, the main one uses docker-in-docker, and no tracked devcontainer
    /// file reaches the host daemon.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Devcontainer_RepositoryConfig_HasNoHostDockerSocketBind()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        IReadOnlyList<string> trackedFiles = await TrackedFiles.ListAsync(cancellationToken: cancellationToken);
        var references = new List<string>();
        foreach (string path in DevcontainerFiles(trackedFiles: trackedFiles))
        {
            string text = await File.ReadAllTextAsync(
                    path: Path.Combine(path1: RepositoryLayout.RepositoryRoot, path2: path),
                    cancellationToken: cancellationToken);
            references.AddRange(collection: FindHostDaemonReferences(text: text)
                    .Select(selector: reference => $"{path}: {reference}"));
        }

        string main = await File.ReadAllTextAsync(
                path: Path.Combine(path1: RepositoryLayout.RepositoryRoot, path2: FolderPrefix + ConfigName),
                cancellationToken: cancellationToken);

        ConfigFiles(trackedFiles: trackedFiles).ShouldNotBeEmpty();
        main.ShouldContain(expected: "docker-in-docker");
        references.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: references));
    }

    /// <summary>
    /// A host socket, a TCP or SSH <c>DOCKER_HOST</c>, the host network, a Podman socket, a compose file or a
    /// socket-binding feature is reported, wherever it appears.
    /// </summary>
    /// <param name="devcontainerJson">A synthetic devcontainer file.</param>
    [Theory]
    [InlineData("{ \"mounts\": [\"source=/var/run/docker.sock,target=/var/run/docker.sock,type=bind\"] }")]
    [InlineData("{ \"runArgs\": [\"-v\", \"/var/run/docker.sock:/var/run/docker-host.sock\"] }")]
    [InlineData("{ \"containerEnv\": { \"DOCKER_HOST\": \"unix:///run/docker.sock\" } }")]
    [InlineData("{ \"containerEnv\": { \"DOCKER_HOST\": \"tcp://host.docker.internal:2375\" } }")]
    [InlineData("{ \"remoteEnv\": { \"DOCKER_HOST\": \"ssh://user@host\" } }")]
    [InlineData("{ \"mounts\": [\"source=//./pipe/docker_engine,target=/var/run/docker.sock,type=npipe\"] }")]
    [InlineData("{ \"mounts\": [\"source=/run/podman/podman.sock,target=/run/podman/podman.sock,type=bind\"] }")]
    [InlineData("{ \"runArgs\": [\"--network=host\"] }")]
    [InlineData("{ \"runArgs\": [\"--network\", \"host\"] }")]
    [InlineData("{ \"runArgs\": [\"--net=host\"] }")]
    [InlineData("{ \"dockerComposeFile\": \"compose.yaml\", \"service\": \"dev\" }")]
    [InlineData("{ \"initializeCommand\": \"export DOCKER_HOST=tcp://localhost:2375\" }")]
    [InlineData("{ \"features\": { \"ghcr.io/devcontainers/features/docker-outside-of-docker:1\": {} } }")]
    [InlineData("{ \"features\": { \"ghcr.io/devcontainers/features/docker-from-docker:1\": {} } }")]
    public void Devcontainer_HostSocketReference_IsReported(string devcontainerJson)
    {
        FindHostDaemonReferences(text: devcontainerJson).ShouldNotBeEmpty();
    }

    /// <summary>The docker-in-docker feature, ordinary volume mounts and a container name are not reported.</summary>
    [Fact]
    public void Devcontainer_DockerInDocker_IsNotReported()
    {
        const string Devcontainer = """
                {
                  "features": { "ghcr.io/devcontainers/features/docker-in-docker:4": {} },
                  "runArgs": ["--name", "dev-network-host-tools"],
                  "mounts": ["source=history-${devcontainerId},target=/commandhistory,type=volume"]
                }
                """;

        FindHostDaemonReferences(text: Devcontainer).ShouldBeEmpty();
    }

    /// <summary>
    /// Every place the devcontainer tools read a config from is found: <c>.devcontainer/devcontainer.json</c>,
    /// <c>.devcontainer/&lt;name&gt;/devcontainer.json</c> and the root <c>.devcontainer.json</c>; every tracked file
    /// under <c>.devcontainer/</c> is checked; a file elsewhere is not.
    /// </summary>
    [Fact]
    public void DevcontainerFiles_TrackedPaths_AreAllFound()
    {
        string[] trackedFiles =
        [
            ".devcontainer.json",
            ".devcontainer/devcontainer.json",
            ".devcontainer/python/devcontainer.json",
            ".devcontainer/setup.sh",
            "docs/devcontainer.json",
        ];

        ConfigFiles(trackedFiles: trackedFiles).ShouldBe(expected: trackedFiles[..3]);
        DevcontainerFiles(trackedFiles: trackedFiles).ShouldBe(expected: trackedFiles[..4]);
    }

    /// <summary>
    /// The tracked Dockerfile installs Node from the version in <c>src/frontend/user-app/.node-version</c> with a
    /// checksum check and pnpm with install scripts off, its dockerignore lets both pin files in, and the Claude Code
    /// install still comes after the Node step.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Devcontainer_NodeInstall_ReadsTheNodeVersionPin()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        string dockerfile = await File.ReadAllTextAsync(
                path: Path.Combine(path1: RepositoryLayout.RepositoryRoot, path2: FolderPrefix + DockerfileName),
                cancellationToken: cancellationToken);
        string dockerignore = await File.ReadAllTextAsync(
                path: Path.Combine(path1: RepositoryLayout.RepositoryRoot, path2: FolderPrefix + DockerignoreName),
                cancellationToken: cancellationToken);

        IReadOnlyList<string> findings = FindNodePinProblems(dockerfile: dockerfile, dockerignore: dockerignore);

        int nodeStep = dockerfile.IndexOf(value: NodePinCopy, comparisonType: StringComparison.Ordinal);
        int claudeCodeStep = dockerfile.IndexOf(value: ClaudeCodePackage, comparisonType: StringComparison.Ordinal);

        findings.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: findings));
        claudeCodeStep.ShouldBeGreaterThan(expected: nodeStep);
    }

    /// <summary>
    /// Each single change to a pinned install is reported: the NodeSource script, a literal Node version, a missing
    /// pin copy or pin read, a skipped checksum, Corepack, a pnpm install with scripts on, and a dockerignore without
    /// one of the two pin file exceptions.
    /// </summary>
    /// <param name="target">The synthetic file to change, the Dockerfile or the dockerignore.</param>
    /// <param name="original">The text of the accepted synthetic file to replace.</param>
    /// <param name="replacement">The text that replaces it.</param>
    /// <param name="expected">A fragment of the finding that must be reported.</param>
    [Theory]
    [InlineData(
            DockerfileName,
            "apt-get install -y curl jq",
            "apt-get install -y curl jq && curl -fsSL https://deb.nodesource.com/setup_24.x | bash -",
            "NodeSource")]
    [InlineData(DockerfileName, "\"$(cat /tmp/node/.node-version)\"", "24.1.0", "hard-codes a Node version")]
    [InlineData(
            DockerfileName,
            "dist/v${NODE_VERSION}/node-v${NODE_VERSION}",
            "dist/v24.1.0/node-v24.1.0",
            "hard-codes a Node version")]
    [InlineData(DockerfileName, "COPY src/", "ENV NODE_VERSION 24.1.0\nCOPY src/", "hard-codes a Node version")]
    [InlineData(DockerfileName, "FROM base:1.0.0", "FROM node:24.1.0", "hard-codes a Node version")]
    [InlineData(DockerfileName, "COPY src/frontend/user-app/.node-version ", "COPY ", "does not COPY")]
    [InlineData(DockerfileName, "/tmp/node/.node-version)", "/tmp/node/version.txt)", "does not read NODE_VERSION")]
    [InlineData(DockerfileName, " | sha256sum -c -", "", "sha256sum -c")]
    [InlineData(DockerfileName, "npm install -g --ignore-scripts ", "npm install -g ", "--ignore-scripts")]
    [InlineData(
            DockerfileName,
            "&& rm -rf /tmp/node",
            "&& npm i --global pnpm && rm -rf /tmp/node",
            "--ignore-scripts")]
    [InlineData(DockerfileName, "&& rm -rf /tmp/node", "&& corepack enable pnpm && rm -rf /tmp/node", "Corepack")]
    [InlineData(DockerignoreName, "!src/frontend/user-app/.node-version\n", "", "!src/frontend/user-app/.node-version")]
    [InlineData(DockerignoreName, "!src/frontend/user-app/package.json\n", "", "!src/frontend/user-app/package.json")]
    public void NodePinRule_LiteralVersionOrNodeSource_IsReported(
            string target,
            string original,
            string replacement,
            string expected)
    {
        bool inDockerfile = string.Equals(a: target, b: DockerfileName, comparisonType: StringComparison.Ordinal);
        string source = inDockerfile ? PinnedDockerfile : PinnedDockerignore;
        source.ShouldContain(expected: original);
        string changed = source.Replace(
                oldValue: original,
                newValue: replacement,
                comparisonType: StringComparison.Ordinal);

        IReadOnlyList<string> findings = FindNodePinProblems(
                dockerfile: inDockerfile ? changed : PinnedDockerfile,
                dockerignore: inDockerfile ? PinnedDockerignore : changed);

        findings.ShouldContain(
                elementPredicate: finding => finding.Contains(
                        value: expected,
                        comparisonType: StringComparison.Ordinal),
                customMessage: string.Join(separator: "\n", values: findings));
    }

    /// <summary>A Dockerfile and dockerignore that install the pinned Node and pnpm as required are accepted.</summary>
    [Fact]
    public void NodePinRule_PinnedInstall_IsAccepted()
    {
        IReadOnlyList<string> findings = FindNodePinProblems(
                dockerfile: PinnedDockerfile,
                dockerignore: PinnedDockerignore);

        findings.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: findings));
    }

    /// <summary>
    /// Finds the Node pin problems of a devcontainer Dockerfile and its dockerignore. Comment lines are ignored and
    /// continuation lines are joined, as Docker reads them.
    /// </summary>
    /// <param name="dockerfile">The Dockerfile text.</param>
    /// <param name="dockerignore">The text of the Dockerfile's dockerignore.</param>
    /// <returns>One message per problem.</returns>
    internal static IReadOnlyList<string> FindNodePinProblems(string dockerfile, string dockerignore)
    {
        string instructions = Instructions(dockerfile: dockerfile);
        List<string> findings = [];
        if (NodeSourcePattern().IsMatch(input: instructions))
        {
            findings.Add(item: "uses the NodeSource setup script; install Node from the official tarball");
        }

        findings.AddRange(collection: LiteralNodeVersionPattern()
                .Matches(input: instructions)
                .Select(selector: match => $"hard-codes a Node version ('{match.Value}'); read it from .node-version"));
        if (!instructions.Contains(value: NodePinCopy, comparisonType: StringComparison.Ordinal))
        {
            findings.Add(item: $"does not COPY the pin files ('{NodePinCopy}')");
        }

        if (!NodePinReadPattern().IsMatch(input: instructions))
        {
            findings.Add(item: "does not read NODE_VERSION from the copied /tmp/node/.node-version");
        }

        if (!instructions.Contains(value: "SHASUMS256.txt", comparisonType: StringComparison.Ordinal)
                || !instructions.Contains(value: "sha256sum -c", comparisonType: StringComparison.Ordinal))
        {
            findings.Add(item: "does not verify the Node tarball against SHASUMS256.txt with sha256sum -c");
        }

        if (CorepackPattern().IsMatch(input: instructions))
        {
            findings.Add(item: "uses Corepack; install pnpm with npm install -g --ignore-scripts");
        }

        findings.AddRange(collection: FindPnpmInstallProblems(instructions: instructions));
        HashSet<string> ignoreLines = [.. dockerignore.Split(separator: '\n').Select(selector: line => line.Trim())];
        findings.AddRange(collection: _nodePinExceptions
                .Where(predicate: line => !ignoreLines.Contains(item: line))
                .Select(selector: line => $"Dockerfile.dockerignore lacks '{line}'"));
        return findings;
    }

    private const string FolderPrefix = ".devcontainer/";
    private const string RootConfig = ".devcontainer.json";
    private const string ConfigName = "devcontainer.json";
    private const string DockerfileName = "Dockerfile";
    private const string DockerignoreName = "Dockerfile.dockerignore";
    private const string NodePinCopy =
            "COPY src/frontend/user-app/.node-version src/frontend/user-app/package.json /tmp/node/";
    private const string ClaudeCodePackage = "@anthropic-ai/claude-code";
    private const string PinnedDockerfile = """
            FROM base:1.0.0
            # Node 24.1.0 named in a comment is not an instruction.
            RUN apt-get update && apt-get install -y curl jq
            COPY src/frontend/user-app/.node-version src/frontend/user-app/package.json /tmp/node/
            RUN NODE_VERSION="$(cat /tmp/node/.node-version)" \
              && ARCH="$(dpkg --print-architecture | sed 's/amd64/x64/')" \
              && cd /tmp/node \
              && curl -fsSLO "https://nodejs.org/dist/v${NODE_VERSION}/node-v${NODE_VERSION}-linux-${ARCH}.tar.gz" \
              && curl -fsSLO "https://nodejs.org/dist/v${NODE_VERSION}/SHASUMS256.txt" \
              && grep " node-v${NODE_VERSION}-linux-${ARCH}.tar.gz\$" SHASUMS256.txt | sha256sum -c - \
              && tar -xzf "node-v${NODE_VERSION}-linux-${ARCH}.tar.gz" -C /usr/local \
                --strip-components=1 --no-same-owner \
              && npm install -g --ignore-scripts "$(jq -r .packageManager package.json)" \
              && rm -rf /tmp/node
            RUN npm install -g @anthropic-ai/claude-code@latest
            """;
    private const string PinnedDockerignore =
            "*\n!global.json\n!src/frontend/user-app/.node-version\n!src/frontend/user-app/package.json\n";

    private static readonly string[] _nodePinExceptions =
    [
        "!src/frontend/user-app/.node-version",
        "!src/frontend/user-app/package.json",
    ];

    private static readonly string[] _commandSeparators = ["&&", ";", "\n", "|"];

    [GeneratedRegex(
            pattern: @"docker\.sock|podman\.sock|/var/run/docker\b|docker_engine|docker-outside-of-docker"
                    + @"|docker-from-docker|DOCKER_HOST|dockerComposeFile|--net(work)?(=|""\s*,\s*""|\s+)host\b",
            options: RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex HostDaemonPattern();

    [GeneratedRegex(
            pattern: "nodesource",
            options: RegexOptions.IgnoreCase | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex NodeSourcePattern();

    [GeneratedRegex(
            pattern: @"node-v[0-9]+\.[0-9]+|nodejs\.org/dist/v[0-9]|NODE_VERSION(\s*=\s*|\s+)[""']?[0-9]"
                    + @"|\bnode:[0-9]|\bnodejs=[0-9]",
            options: RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex LiteralNodeVersionPattern();

    [GeneratedRegex(
            pattern: @"\bNODE_VERSION=""?\$\(cat\s+/tmp/node/\.node-version\)",
            options: RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex NodePinReadPattern();

    [GeneratedRegex(
            pattern: @"\bcorepack\b",
            options: RegexOptions.IgnoreCase | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex CorepackPattern();

    [GeneratedRegex(
            pattern: @"^((RUN|run)\s+)?npm\s+(install|i|add)\b.*\s(-g|--global)\b",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex GlobalNpmInstallPattern();

    [GeneratedRegex(
            pattern: @"\bpnpm\b|\.packageManager\b",
            options: RegexOptions.IgnoreCase | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex PnpmPackagePattern();

    private static List<string> ConfigFiles(IReadOnlyList<string> trackedFiles)
    {
        return
        [
            .. DevcontainerFiles(trackedFiles: trackedFiles).Where(predicate: path => IsRootConfig(path: path)
                    || string.Equals(
                            a: Path.GetFileName(path: path),
                            b: ConfigName,
                            comparisonType: StringComparison.Ordinal)),
        ];
    }

    private static List<string> DevcontainerFiles(IReadOnlyList<string> trackedFiles)
    {
        return
        [
            .. trackedFiles.Where(predicate: path => IsRootConfig(path: path)
                    || path.StartsWith(value: FolderPrefix, comparisonType: StringComparison.Ordinal)),
        ];
    }

    private static bool IsRootConfig(string path)
    {
        return string.Equals(a: path, b: RootConfig, comparisonType: StringComparison.Ordinal);
    }

    private static List<string> FindHostDaemonReferences(string text)
    {
        return
        [
            .. HostDaemonPattern()
                    .Matches(input: text)
                    .Select(selector: match => match.Value)
                    .Distinct(comparer: StringComparer.OrdinalIgnoreCase),
        ];
    }

    private static string Instructions(string dockerfile)
    {
        IEnumerable<string> lines = dockerfile
                .Split(separator: '\n')
                .Where(predicate: line => !line.TrimStart().StartsWith(value: '#'));
        return string.Join(separator: "\n", values: lines)
                .Replace(oldValue: "\\\n", newValue: " ", comparisonType: StringComparison.Ordinal);
    }

    private static List<string> FindPnpmInstallProblems(string instructions)
    {
        List<string> installs =
        [
            .. instructions
                    .Split(
                            separator: _commandSeparators,
                            options: StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
                    .Where(predicate: command => GlobalNpmInstallPattern().IsMatch(input: command)
                            && PnpmPackagePattern().IsMatch(input: command)),
        ];
        List<string> findings =
        [
            .. installs
                    .Where(predicate: command => !command.Contains(
                            value: "--ignore-scripts",
                            comparisonType: StringComparison.Ordinal))
                    .Select(selector: command => $"installs pnpm without --ignore-scripts: '{command}'"),
        ];
        if (!installs.Any(predicate: command => command.Contains(
                value: ".packageManager",
                comparisonType: StringComparison.Ordinal)))
        {
            findings.Add(item: "does not install pnpm from packageManager with npm install -g --ignore-scripts");
        }

        return findings;
    }
}
