using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using ArchUnitNET.Fluent;
using LangProject.Core.ArchitectureTests.Types.Fixtures;
using LangProject.Core.Domain.Languages;
using Microsoft.Extensions.DependencyInjection;
using Shouldly;
using Xunit;
using Architecture = ArchUnitNET.Domain.Architecture;
using ArchLoader = ArchUnitNET.Loader.ArchLoader;

namespace LangProject.Core.ArchitectureTests.Types;

/// <summary>
/// Tests of the SPEC R6 layer-purity rules, written as ArchUnitNET dependency rules: Domain depends only on
/// <c>System</c> types; Application avoids <c>Microsoft.EntityFrameworkCore</c>, <c>Microsoft.AspNetCore</c> and
/// <c>System.Net.Http</c>; only CompositionRoot uses <see cref="IServiceProvider"/> or another service-location
/// type; Application.Abstractions and API.Abstractions never see Domain (D-42). Each rule also reads the
/// compiler-generated code of its subjects (lambdas, <c>async</c> methods, iterators), which ArchUnitNET does not
/// always credit to them. Each rule runs on the production assemblies and on a fixture <see cref="Architecture"/>
/// holding the bad-on-purpose types. ArchUnitNET fails a rule whose selector matches zero types, so no rule passes
/// vacuously.
/// </summary>
public sealed class LayerPurityTests
{
    /// <summary>Domain types depend only on <c>System*</c> namespaces and on Domain itself.</summary>
    [Fact]
    public void Domain_Production_DependsOnlyOnSystem()
    {
        PurityRule rule = DomainDependsOnlyOnSystem(
                subjects: ProductionTypes.TypesOf(assembly: ProductionTypes.Domain),
                ownNamespace: DomainNamespace);

        ShouldHaveNoViolations(rule: rule, architecture: ProductionTypes.Architecture);
    }

    /// <summary>A Domain type holding a <c>Microsoft.Extensions.Logging.ILogger</c> is reported.</summary>
    [Fact]
    public void Domain_NonSystemDependency_IsReported()
    {
        PurityRule rule = DomainDependsOnlyOnSystem(
                subjects: [typeof(PurityFixtures.CleanType), typeof(PurityFixtures.DomainWithLogger)],
                ownNamespace: _fixtureNamespace);

        string violation = SingleViolation(rule: rule);
        violation.ShouldContain(expected: nameof(PurityFixtures.DomainWithLogger));
        violation.ShouldContain(expected: "Microsoft.Extensions.Logging.ILogger");
    }

    /// <summary>
    /// A Domain dependency that appears only in a lambda, an <c>async</c> method or an iterator, whose code the
    /// compiler moves into a generated nested type, is reported against the type that wrote it.
    /// </summary>
    /// <param name="fixture">The fixture type.</param>
    [Theory]
    [InlineData(typeof(PurityFixtures.DomainLoggerInLambda))]
    [InlineData(typeof(PurityFixtures.DomainLoggerInAsyncMethod))]
    [InlineData(typeof(PurityFixtures.DomainLoggerInIterator))]
    public void Domain_DependencyInGeneratedCode_IsReported(Type fixture)
    {
        PurityRule rule = DomainDependsOnlyOnSystem(
                subjects: [typeof(PurityFixtures.CleanType), fixture],
                ownNamespace: _fixtureNamespace);

        ShouldReport(rule: rule, fixture: fixture, dependency: "Microsoft.Extensions.Logging.ILogger");
    }

    /// <summary>
    /// Application types do not depend on <c>Microsoft.EntityFrameworkCore*</c>, <c>Microsoft.AspNetCore*</c> or
    /// <c>System.Net.Http*</c>.
    /// </summary>
    [Fact]
    public void Application_Production_AvoidsInfrastructure()
    {
        PurityRule rule = ApplicationAvoidsInfrastructure(
                subjects: ProductionTypes.TypesOf(assembly: ProductionTypes.Application));

        ShouldHaveNoViolations(rule: rule, architecture: ProductionTypes.Architecture);
    }

    /// <summary>An Application type holding a <c>System.Net.Http.HttpClient</c> is reported.</summary>
    [Fact]
    public void Application_HttpClientDependency_IsReported()
    {
        PurityRule rule = ApplicationAvoidsInfrastructure(
                subjects: [typeof(PurityFixtures.CleanType), typeof(PurityFixtures.ApplicationWithHttpClient)]);

        string violation = SingleViolation(rule: rule);
        violation.ShouldContain(expected: nameof(PurityFixtures.ApplicationWithHttpClient));
        violation.ShouldContain(expected: "System.Net.Http.HttpClient");
    }

    /// <summary>An Application type holding an EF Core <c>DbContext</c> is reported.</summary>
    [Fact]
    public void Application_EfCoreDependency_IsReported()
    {
        PurityRule rule = ApplicationAvoidsInfrastructure(
                subjects: [typeof(PurityFixtures.CleanType), typeof(PurityFixtures.ApplicationWithDbContext)]);

        string violation = SingleViolation(rule: rule);
        violation.ShouldContain(expected: nameof(PurityFixtures.ApplicationWithDbContext));
        violation.ShouldContain(expected: "Microsoft.EntityFrameworkCore.DbContext");
    }

    /// <summary>
    /// An Application <c>async</c> method that touches an EF Core <c>DbContext</c> only in its body is reported.
    /// </summary>
    [Fact]
    public void Application_EfCoreInAsyncMethod_IsReported()
    {
        Type fixture = typeof(PurityFixtures.ApplicationDbContextInAsyncMethod);
        PurityRule rule = ApplicationAvoidsInfrastructure(subjects: [typeof(PurityFixtures.CleanType), fixture]);

        ShouldReport(rule: rule, fixture: fixture, dependency: "Microsoft.EntityFrameworkCore.DbContext");
    }

    /// <summary>
    /// No production type outside CompositionRoot depends on <see cref="IServiceProvider"/> or another
    /// service-location type. Test assemblies are not subjects: they use it legitimately, for example through
    /// <c>WebApplicationFactory.Services</c>.
    /// </summary>
    [Fact]
    public void ServiceProvider_Production_UsedOnlyInCompositionRoot()
    {
        PurityRule rule = DoesNotUseServiceProvider(
                subjects: ProductionTypes.TypesOf(filter: static name => !string.Equals(
                        a: name,
                        b: ProductionTypes.NameOf(assembly: ProductionTypes.CompositionRoot),
                        comparisonType: StringComparison.Ordinal)));

        ShouldHaveNoViolations(rule: rule, architecture: ProductionTypes.Architecture);
    }

    /// <summary>A type with an <see cref="IServiceProvider"/> constructor parameter is reported.</summary>
    [Fact]
    public void ServiceProvider_Dependency_IsReported()
    {
        PurityRule rule = DoesNotUseServiceProvider(
                subjects: [typeof(PurityFixtures.CleanType), typeof(PurityFixtures.ServiceLocatorUser)]);

        string violation = SingleViolation(rule: rule);
        violation.ShouldContain(expected: nameof(PurityFixtures.ServiceLocatorUser));
        violation.ShouldContain(expected: "System.IServiceProvider");
    }

    /// <summary>
    /// Every service-location type is reported, not only <see cref="IServiceProvider"/>, and so is a factory lambda
    /// that resolves through the provider.
    /// </summary>
    /// <param name="fixture">The fixture type.</param>
    /// <param name="serviceLocator">The name of the service-location type it uses.</param>
    [Theory]
    [InlineData(typeof(PurityFixtures.ScopeFactoryUser), nameof(IServiceScopeFactory))]
    [InlineData(typeof(PurityFixtures.ScopeUser), nameof(IServiceScope))]
    [InlineData(typeof(PurityFixtures.KeyedProviderUser), nameof(IKeyedServiceProvider))]
    [InlineData(typeof(PurityFixtures.ActivatorUser), nameof(ActivatorUtilities))]
    [InlineData(typeof(PurityFixtures.ServiceProviderInFactoryLambda), nameof(IServiceProvider))]
    public void ServiceProvider_ServiceLocationType_IsReported(Type fixture, string serviceLocator)
    {
        PurityRule rule = DoesNotUseServiceProvider(subjects: [typeof(PurityFixtures.CleanType), fixture]);

        ShouldReport(rule: rule, fixture: fixture, dependency: "." + serviceLocator);
    }

    /// <summary>
    /// Application.Abstractions and API.Abstractions types do not depend on Domain types, and a contract type with a
    /// <see cref="Language"/> property is reported (D-42).
    /// </summary>
    [Fact]
    public void Abstractions_ContractProjects_DoNotDependOnDomain()
    {
        PurityRule production = DoesNotDependOnDomain(
                subjects:
                [
                    .. ProductionTypes.TypesOf(assembly: ProductionTypes.ApplicationAbstractions),
                    .. ProductionTypes.TypesOf(assembly: ProductionTypes.ApiAbstractions),
                ]);
        PurityRule proof = DoesNotDependOnDomain(
                subjects: [typeof(PurityFixtures.CleanType), typeof(PurityFixtures.ContractWithEntityDto)]);

        ShouldHaveNoViolations(rule: production, architecture: ProductionTypes.Architecture);
        string violation = SingleViolation(rule: proof);
        violation.ShouldContain(expected: nameof(PurityFixtures.ContractWithEntityDto));
        violation.ShouldContain(expected: typeof(Language).FullName ?? nameof(Language));
    }

    /// <summary>Every purity rule fails when its selector matches zero types.</summary>
    /// <param name="rule">The name of the rule builder.</param>
    [Theory]
    [InlineData(nameof(DomainDependsOnlyOnSystem))]
    [InlineData(nameof(ApplicationAvoidsInfrastructure))]
    [InlineData(nameof(DoesNotUseServiceProvider))]
    [InlineData(nameof(DoesNotDependOnDomain))]
    public void LayerPurity_EmptySelector_Fails(string rule)
    {
        PurityRule empty = BuildRule(rule: rule, subjects: []);

        empty.Rule.HasNoViolations(architecture: ProductionTypes.Architecture).ShouldBeFalse();
        empty.Violations(architecture: ProductionTypes.Architecture)
                .ShouldHaveSingleItem()
                .ShouldContain(expected: "positive evaluation");
    }

    private const string DomainNamespace = "LangProject.Core.Domain";

    private const string InfrastructurePattern =
            @"^(Microsoft\.EntityFrameworkCore|Microsoft\.AspNetCore|System\.Net\.Http)(\..+)?$";

    private static readonly string _fixtureNamespace = typeof(PurityFixtures).Namespace ?? string.Empty;

    private static readonly Lazy<Architecture> _fixtureArchitecture = new(valueFactory: BuildFixtureArchitecture);

    private static readonly Type[] _serviceLocationTypes =
    [
        typeof(IServiceProvider),
        typeof(IKeyedServiceProvider),
        typeof(IServiceScopeFactory),
        typeof(IServiceScope),
        typeof(ActivatorUtilities),
    ];

    private static readonly TimeSpan _regexTimeout = TimeSpan.FromSeconds(seconds: 10);

    private static PurityRule DomainDependsOnlyOnSystem(IReadOnlyCollection<Type> subjects, string ownNamespace)
    {
        string allowed = $@"^(System|{Regex.Escape(str: ownNamespace)})(\..+)?$";
        return new PurityRule(
                rule: ArchRuleDefinition.Types()
                        .That()
                        .Are(types: subjects)
                        .Should()
                        .NotDependOnAnyTypesThat()
                        .DoNotResideInNamespaceMatching(pattern: allowed),
                subjects: subjects,
                isForbidden: dependency => !Matches(input: dependency.UsedNamespace, pattern: allowed));
    }

    private static PurityRule ApplicationAvoidsInfrastructure(IReadOnlyCollection<Type> subjects)
    {
        return new PurityRule(
                rule: ArchRuleDefinition.Types()
                        .That()
                        .Are(types: subjects)
                        .Should()
                        .NotDependOnAnyTypesThat()
                        .ResideInNamespaceMatching(pattern: InfrastructurePattern),
                subjects: subjects,
                isForbidden: dependency => Matches(input: dependency.UsedNamespace, pattern: InfrastructurePattern));
    }

    private static PurityRule DoesNotUseServiceProvider(IReadOnlyCollection<Type> subjects)
    {
        return new PurityRule(
                rule: ArchRuleDefinition.Types()
                        .That()
                        .Are(types: subjects)
                        .Should()
                        .NotDependOnAnyTypesThat()
                        .HaveFullNameMatching(pattern: ServiceLocationPattern()),
                subjects: subjects,
                isForbidden: dependency => _serviceLocationTypes.Any(predicate: type => string.Equals(
                        a: type.FullName,
                        b: dependency.UsedFullName,
                        comparisonType: StringComparison.Ordinal)));
    }

    private static PurityRule DoesNotDependOnDomain(IReadOnlyCollection<Type> subjects)
    {
        string domain = $@"^{Regex.Escape(str: DomainNamespace)}(\..+)?$";
        return new PurityRule(
                rule: ArchRuleDefinition.Types()
                        .That()
                        .Are(types: subjects)
                        .Should()
                        .NotDependOnAnyTypesThat()
                        .ResideInNamespaceMatching(pattern: domain),
                subjects: subjects,
                isForbidden: dependency => Matches(input: dependency.UsedNamespace, pattern: domain));
    }

    private static string ServiceLocationPattern()
    {
        IEnumerable<string> names = _serviceLocationTypes
                .Select(selector: type => Regex.Escape(str: type.FullName ?? type.Name));
        return $"^({string.Join(separator: "|", values: names)})$";
    }

    private static PurityRule BuildRule(string rule, IReadOnlyCollection<Type> subjects)
    {
        return rule switch
        {
            nameof(DomainDependsOnlyOnSystem) => DomainDependsOnlyOnSystem(
                    subjects: subjects,
                    ownNamespace: DomainNamespace),
            nameof(ApplicationAvoidsInfrastructure) => ApplicationAvoidsInfrastructure(subjects: subjects),
            nameof(DoesNotUseServiceProvider) => DoesNotUseServiceProvider(subjects: subjects),
            nameof(DoesNotDependOnDomain) => DoesNotDependOnDomain(subjects: subjects),
            _ => throw new ArgumentOutOfRangeException(paramName: nameof(rule), message: "Unknown rule: " + rule),
        };
    }

    private static bool Matches(string input, string pattern)
    {
        return Regex.IsMatch(
                input: input,
                pattern: pattern,
                options: RegexOptions.CultureInvariant,
                matchTimeout: _regexTimeout);
    }

    private static Architecture BuildFixtureArchitecture()
    {
        return new ArchLoader().LoadAssemblies(assemblies: [typeof(PurityFixtures).Assembly]).Build();
    }

    private static void ShouldHaveNoViolations(PurityRule rule, Architecture architecture)
    {
        IReadOnlyList<string> violations = rule.Violations(architecture: architecture);
        rule.Rule.HasNoViolations(architecture: architecture)
                .ShouldBeTrue(customMessage: string.Join(separator: "\n", values: violations));
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    private static string SingleViolation(PurityRule rule)
    {
        return rule.Violations(architecture: _fixtureArchitecture.Value).ShouldHaveSingleItem();
    }

    private static void ShouldReport(PurityRule rule, Type fixture, string dependency)
    {
        IReadOnlyList<string> violations = rule.Violations(architecture: _fixtureArchitecture.Value);
        string message = string.Join(separator: "\n", values: violations);

        violations.ShouldNotBeEmpty();
        violations.ShouldAllBe(
                elementPredicate: violation => violation.Contains(
                        value: fixture.Name,
                        comparisonType: StringComparison.Ordinal),
                customMessage: message);
        violations.ShouldContain(
                elementPredicate: violation => violation.Contains(
                        value: dependency,
                        comparisonType: StringComparison.Ordinal),
                customMessage: message);
    }
}
