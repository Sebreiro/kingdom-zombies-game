namespace LangProject.Core.ArchitectureTests.Documentation;

/// <summary>
/// One relative link in a Markdown document: where it is, what it says, and the repository path it points at. The
/// <c>#anchor</c> part is dropped, because anchors are not checked (SPEC R17).
/// </summary>
internal sealed class MarkdownLink
{
    /// <summary>Initializes a new instance of the <see cref="MarkdownLink"/> class.</summary>
    /// <param name="line">The 1-based line of the document the link is on.</param>
    /// <param name="rawTarget">The link target as written, without its <c>#anchor</c> part.</param>
    /// <param name="target">
    /// The repository-relative path the link points at, with forward slashes and no trailing slash, or
    /// <see langword="null"/> when the link leaves the repository.
    /// </param>
    internal MarkdownLink(int line, string rawTarget, string? target)
    {
        Line = line;
        RawTarget = rawTarget;
        Target = target;
    }

    /// <summary>Gets the 1-based line of the document the link is on.</summary>
    internal int Line { get; }

    /// <summary>Gets the link target as written, without its <c>#anchor</c> part.</summary>
    internal string RawTarget { get; }

    /// <summary>
    /// Gets the repository-relative path the link points at, or <see langword="null"/> when it leaves the
    /// repository. The empty string is the repository root.
    /// </summary>
    internal string? Target { get; }
}
