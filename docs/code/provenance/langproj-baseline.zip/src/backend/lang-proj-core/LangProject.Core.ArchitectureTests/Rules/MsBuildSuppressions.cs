using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Linq;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// The MSBuild part of the suppression scan. A csproj, props or targets file is parsed as XML, so an element split
/// over several lines and a differently cased name are seen as MSBuild sees them; the subject of a hit is the one
/// element it comes from. A response file is read as command-line switches.
/// </summary>
internal static class MsBuildSuppressions
{
    /// <summary>Finds every suppression in one csproj, props or targets file.</summary>
    /// <param name="relativePath">The repository-relative path, with forward slashes.</param>
    /// <param name="content">The file text.</param>
    /// <returns>The hits, in file order.</returns>
    internal static IReadOnlyList<SuppressionHit> Scan(string relativePath, string content)
    {
        XDocument document;
        try
        {
            document = Parse(xml: content);
        }
        catch (XmlException exception)
        {
            string name = Path.GetFileName(path: relativePath);
            return
            [
                new SuppressionHit(
                        path: relativePath,
                        lineNumber: 0,
                        text: name,
                        subject: name,
                        pattern: $"unreadable MSBuild XML: {exception.Message}"),
            ];
        }

        string[] lines = content.Split(separator: '\n');
        var hits = new List<SuppressionHit>();
        foreach (XElement element in document.Descendants())
        {
            string? pattern = ElementPattern(element: element);
            if (pattern is not null)
            {
                hits.Add(item: Hit(relativePath: relativePath, lines: lines, element: element, pattern: pattern));
            }

            hits.AddRange(collection: element.Attributes()
                    .Where(predicate: attribute => !attribute.IsNamespaceDeclaration)
                    .Select(selector: attribute => MsBuildPropertyRules.AnyValuePattern(name: attribute.Name.LocalName))
                    .OfType<string>()
                    .Select(selector: found => Hit(
                            relativePath: relativePath,
                            lines: lines,
                            element: element,
                            pattern: found + " metadata")));
        }

        return hits;
    }

    /// <summary>
    /// Finds every switch in one response file, such as <c>Directory.Build.rsp</c>, that weakens a rule. MSBuild
    /// reads such a file into every build below it.
    /// </summary>
    /// <param name="relativePath">The repository-relative path, with forward slashes.</param>
    /// <param name="content">The file text.</param>
    /// <returns>The hits, in file order.</returns>
    internal static IReadOnlyList<SuppressionHit> ScanResponseFile(string relativePath, string content)
    {
        var hits = new List<SuppressionHit>();
        string[] lines = content.Split(separator: '\n');
        for (int index = 0; index < lines.Length; index++)
        {
            string line = lines[index].Trim();
            if (line.Length > 0 && !line.StartsWith(value: '#'))
            {
                int lineNumber = index + 1;
                hits.AddRange(collection: CommandLineSuppressions
                        .Patterns(line: line)
                        .Select(selector: pattern => new SuppressionHit(
                                path: relativePath,
                                lineNumber: lineNumber,
                                text: line,
                                subject: line,
                                pattern: pattern)));
            }
        }

        return hits;
    }

    private static readonly string[] _removableItems = ["AdditionalFiles", "Analyzer"];

    private static XDocument Parse(string xml)
    {
        var settings = new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null };
        using var text = new StringReader(s: xml);
        using var reader = XmlReader.Create(input: text, settings: settings);
        return XDocument.Load(reader: reader, options: LoadOptions.SetLineInfo);
    }

    private static string? ElementPattern(XElement element)
    {
        string name = element.Name.LocalName;
        bool removesItem = _removableItems.Contains(value: name, comparer: StringComparer.OrdinalIgnoreCase)
                && element.Attributes().Any(predicate: attribute => string.Equals(
                        a: attribute.Name.LocalName,
                        b: "Remove",
                        comparisonType: StringComparison.OrdinalIgnoreCase));
        if (removesItem)
        {
            return name + " Remove";
        }

        return element.HasElements
                ? MsBuildPropertyRules.AnyValuePattern(name: name)
                : MsBuildPropertyRules.ValuePattern(name: name, value: element.Value.Trim());
    }

    private static SuppressionHit Hit(string relativePath, string[] lines, XElement element, string pattern)
    {
        int lineNumber = ((IXmlLineInfo)element).LineNumber;
        string text = lineNumber > 0 && lineNumber <= lines.Length ? lines[lineNumber - 1].Trim() : string.Empty;
        return new SuppressionHit(
                path: relativePath,
                lineNumber: lineNumber,
                text: text,
                subject: element.ToString(options: SaveOptions.DisableFormatting),
                pattern: pattern);
    }
}
