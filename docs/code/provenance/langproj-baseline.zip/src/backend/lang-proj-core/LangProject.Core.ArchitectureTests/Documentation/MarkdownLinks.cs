using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace LangProject.Core.ArchitectureTests.Documentation;

/// <summary>
/// The relative-link rule (SPEC R17, D-12): every relative link in a checked Markdown document points at a file or
/// folder that git tracks. A link is the target of an inline link <c>](...)</c> (RESEARCH Pattern 8), of a
/// reference definition <c>[label]: target</c>, or of an HTML <c>href</c> or <c>src</c> attribute. Links in fenced
/// code blocks (<see cref="MarkdownFences"/>) and code spans are not links; <c>http:</c>, <c>https:</c>,
/// <c>mailto:</c>, <c>data:</c> and <c>ftp:</c> links, links to an anchor of the same document and footnote
/// definitions are skipped; the <c>#anchor</c> part of any link is not checked.
/// </summary>
internal static partial class MarkdownLinks
{
    /// <summary>Reads every relative link of a document, in order.</summary>
    /// <param name="documentPath">The document's repository-relative path, which relative links start from.</param>
    /// <param name="markdown">The document's text.</param>
    /// <returns>The links, each with its line and the repository path it points at.</returns>
    internal static IReadOnlyList<MarkdownLink> ReadLinks(string documentPath, string markdown)
    {
        var links = new List<MarkdownLink>();
        foreach (KeyValuePair<int, string> line in MarkdownFences.ContentLines(markdown: markdown))
        {
            links.AddRange(collection: ReadLineLinks(
                    documentPath: documentPath,
                    line: line.Value,
                    lineNumber: line.Key + 1));
        }

        return links;
    }

    /// <summary>
    /// Reports every relative link of every checked document whose target git does not track, or that leaves the
    /// repository.
    /// </summary>
    /// <param name="docs">The repository's docs.</param>
    /// <returns>One message per broken link, starting with the document path and line; empty when none.</returns>
    internal static IReadOnlyList<string> CheckLinks(RepositoryDocs docs)
    {
        return
        [
            .. docs.Documents.Keys
                    .Order(comparer: StringComparer.Ordinal)
                    .SelectMany(selector: path => CheckDocument(docs: docs, documentPath: path)),
        ];
    }

    /// <summary>
    /// Resolves a link target against the document's folder. A target that starts with <c>/</c> starts at the
    /// repository root. <c>.</c> and empty segments are dropped and <c>..</c> goes one folder up.
    /// </summary>
    /// <param name="documentPath">The document's repository-relative path.</param>
    /// <param name="rawTarget">The link target, without its <c>#anchor</c> part.</param>
    /// <returns>
    /// The repository-relative path with no trailing slash, the empty string for the root, or
    /// <see langword="null"/> when the target goes above the repository root.
    /// </returns>
    internal static string? Resolve(string documentPath, string rawTarget)
    {
        int slash = documentPath.LastIndexOf(value: '/');
        string folder = slash < 0 ? string.Empty : documentPath[..slash];
        string combined = rawTarget.StartsWith(value: '/') ? rawTarget : folder + "/" + rawTarget;
        var segments = new List<string>();
        foreach (string segment in combined.Split(separator: '/'))
        {
            if (segment.Length == 0 || string.Equals(a: segment, b: ".", comparisonType: StringComparison.Ordinal))
            {
                continue;
            }

            if (!string.Equals(a: segment, b: "..", comparisonType: StringComparison.Ordinal))
            {
                segments.Add(item: segment);
            }
            else if (segments.Count == 0)
            {
                return null;
            }
            else
            {
                segments.RemoveAt(index: segments.Count - 1);
            }
        }

        return string.Join(separator: "/", values: segments);
    }

    private static readonly string[] _skippedSchemes = ["http:", "https:", "mailto:", "data:", "ftp:"];

    private static IEnumerable<string> CheckDocument(RepositoryDocs docs, string documentPath)
    {
        string text = docs.Documents[documentPath];
        foreach (MarkdownLink link in ReadLinks(documentPath: documentPath, markdown: text))
        {
            if (link.Target is null)
            {
                yield return $"{documentPath}:{link.Line}: link '{link.RawTarget}' leaves the repository";
            }
            else if (!docs.Exists(path: link.Target))
            {
                yield return $"{documentPath}:{link.Line}: link '{link.RawTarget}' points at '{link.Target}', "
                        + "which git does not track";
            }
        }
    }

    private static IEnumerable<MarkdownLink> ReadLineLinks(string documentPath, string line, int lineNumber)
    {
        string text = MarkdownFences.WithoutCodeSpans(line: line);
        IEnumerable<Match> matches = LinkPattern()
                .Matches(input: text)
                .Concat(second: ReferenceDefinitionPattern().Matches(input: text))
                .Concat(second: HtmlLinkPattern().Matches(input: text))
                .OrderBy(keySelector: match => match.Index);
        foreach (Match match in matches)
        {
            string rawTarget = CleanTarget(target: match.Groups["target"].Value);
            if (rawTarget.Length > 0 && !IsSkippedScheme(target: rawTarget))
            {
                yield return new MarkdownLink(
                        line: lineNumber,
                        rawTarget: rawTarget,
                        target: Resolve(documentPath: documentPath, rawTarget: rawTarget));
            }
        }
    }

    private static string CleanTarget(string target)
    {
        string trimmed = target.Trim();
        string path;
        if (trimmed.StartsWith(value: '<'))
        {
            int close = trimmed.IndexOf(value: '>');
            path = close < 0 ? trimmed[1..] : trimmed[1..close];
        }
        else
        {
            int space = trimmed.IndexOfAny(anyOf: [' ', '\t']);
            path = space < 0 ? trimmed : trimmed[..space];
        }

        int anchor = path.IndexOf(value: '#');
        return Uri.UnescapeDataString(stringToUnescape: anchor < 0 ? path : path[..anchor]);
    }

    private static bool IsSkippedScheme(string target)
    {
        return _skippedSchemes.Any(predicate: scheme => target.StartsWith(
                value: scheme,
                comparisonType: StringComparison.OrdinalIgnoreCase));
    }

    [GeneratedRegex(
            pattern: @"\]\((?<target>[^)#]+)",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex LinkPattern();

    [GeneratedRegex(
            pattern: @"^ {0,3}\[(?!\^)[^\]]+\]:[ \t]*(?<target><[^>]*>|[^\s]+)",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex ReferenceDefinitionPattern();

    [GeneratedRegex(
            pattern: @"\b(href|src)\s*=\s*(""(?<target>[^""]*)""|'(?<target>[^']*)')",
            options: RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex HtmlLinkPattern();
}
