using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace LangProject.Core.ArchitectureTests.Projects;

/// <summary>
/// Reads the allowed-edges table under <c>### Allowed project references</c> in <c>code-architecture.md</c> and
/// compares it, row by row, with <see cref="AllowedEdges"/>, so the written table and its C# copy cannot drift apart.
/// </summary>
/// <remarks>
/// A cell is a comma-separated list of short names, <c>none</c>, <c>every non-test project except the analyzer</c>,
/// or <c>X, plus any other non-test project except the analyzer</c> for a row that requires <c>X</c> and allows the
/// rest; a trailing <c>(...)</c> note is ignored. Short names drop the <c>LangProject.Core.</c> prefix; names that
/// start with <c>Sebreiro.</c> are full names. The italic analyzer-edge row is prose and is skipped.
/// </remarks>
internal static partial class EdgeTableDocument
{
    internal const string Heading = "### Allowed project references";

    /// <summary>Reads the table rows: the first cell, unformatted, and the second cell, without its note.</summary>
    /// <param name="markdown">The text of <c>code-architecture.md</c>.</param>
    /// <returns>The rows in document order; empty when the heading or the table is missing.</returns>
    internal static IReadOnlyList<(string Project, string Cell)> ReadRows(string markdown)
    {
        IEnumerable<string> lines = markdown.Split(separator: '\n')
                .SkipWhile(predicate: line => !string.Equals(
                        a: line.TrimEnd(),
                        b: Heading,
                        comparisonType: StringComparison.Ordinal))
                .Skip(count: 1)
                .TakeWhile(predicate: line => !line.StartsWith(value: '#'))
                .SkipWhile(predicate: line => !IsTableLine(line: line))
                .TakeWhile(predicate: IsTableLine)
                .Skip(count: 2);
        return
        [
            .. lines.Select(selector: line => line.Trim().Trim(trimChar: '|').Split(separator: '|'))
                    .Where(predicate: cells => cells.Length == 2)
                    .Select(selector: cells => (Project: cells[0].Trim(), Cell: WithoutNote(cell: cells[1])))
                    .Where(predicate: row => !row.Project.StartsWith(value: '*')),
        ];
    }

    /// <summary>Compares the written rows with <see cref="AllowedEdges"/>.</summary>
    /// <param name="rows">The rows from <see cref="ReadRows"/>.</param>
    /// <param name="solutionProjects">Every project name in the solution, for the computed rows.</param>
    /// <returns>One violation per missing, extra or different row; empty when the two copies agree.</returns>
    internal static IReadOnlyList<string> Compare(
            IReadOnlyList<(string Project, string Cell)> rows,
            IReadOnlyCollection<string> solutionProjects)
    {
        List<string> violations = [];
        var written = new HashSet<string>(comparer: StringComparer.Ordinal);
        foreach ((string project, string cell) in rows)
        {
            string name = ExpandProject(project: project);
            written.Add(item: name);
            AllowedEdgeRow? expected = AllowedEdges.FindRow(projectName: name, solutionProjects: solutionProjects);
            AllowedEdgeRow? actual = ParseCell(cell: cell, projectName: name, solutionProjects: solutionProjects);
            if (expected is null)
            {
                violations.Add(item: $"{project}: the written table has a row that AllowedEdges does not");
            }
            else if (actual is null)
            {
                violations.Add(item: $"{project}: the cell '{cell}' is not a list, 'none' or a known phrase");
            }
            else if (!actual.Allowed.SetEquals(other: expected.Allowed)
                    || !actual.Required.SetEquals(other: expected.Required))
            {
                violations.Add(item: $"{project}: the written row allows [{Describe(names: actual.Allowed)}] and "
                        + $"requires [{Describe(names: actual.Required)}]; AllowedEdges allows "
                        + $"[{Describe(names: expected.Allowed)}] and requires [{Describe(names: expected.Required)}]");
            }
        }

        violations.AddRange(collection: AllowedEdges.NamedRows
                .Append(element: VendorRowName)
                .Where(predicate: name => !written.Contains(item: name))
                .Order(comparer: StringComparer.Ordinal)
                .Select(selector: name => $"{name}: AllowedEdges has a row that the written table does not"));
        return violations;
    }

    private const string ProductPrefix = "LangProject.Core.";
    private const string EveryNonTest = "every non-test project except the analyzer";
    private const string PlusEveryNonTest = ", plus any other non-test project except the analyzer";
    private const string VendorRowName = AllowedEdges.IntegrationPrefix + "Vendor";

    [GeneratedRegex(
            pattern: @"\s*\([^()]*\)\s*$",
            options: RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex NotePattern();

    private static bool IsTableLine(string line)
    {
        return line.TrimStart().StartsWith(value: '|');
    }

    private static string WithoutNote(string cell)
    {
        return NotePattern().Replace(input: cell.Trim(), replacement: string.Empty);
    }

    private static string ExpandProject(string project)
    {
        string name = project.Replace(oldValue: "`", newValue: string.Empty, comparisonType: StringComparison.Ordinal);
        int note = name.IndexOf(value: " (", comparisonType: StringComparison.Ordinal);
        name = note < 0 ? name : name[..note];
        name = name.Replace(oldValue: "<Vendor>", newValue: "Vendor", comparisonType: StringComparison.Ordinal);
        return Expand(shortName: name.Trim());
    }

    private static string Expand(string shortName)
    {
        return shortName.StartsWith(value: "Sebreiro.", comparisonType: StringComparison.Ordinal)
                ? shortName
                : ProductPrefix + shortName;
    }

    private static AllowedEdgeRow? ParseCell(
            string cell,
            string projectName,
            IReadOnlyCollection<string> solutionProjects)
    {
        List<string> everyOther =
        [
            .. solutionProjects
                    .Where(predicate: name => !AllowedEdges.IsTest(projectName: name))
                    .Where(predicate: name => !IsSameName(left: name, right: AllowedEdges.Analyzers))
                    .Where(predicate: name => !IsSameName(left: name, right: projectName)),
        ];
        if (string.Equals(a: cell, b: "none", comparisonType: StringComparison.Ordinal))
        {
            return Row(allowed: [], required: []);
        }

        if (string.Equals(a: cell, b: EveryNonTest, comparisonType: StringComparison.Ordinal))
        {
            return Row(allowed: everyOther, required: everyOther);
        }

        if (cell.EndsWith(value: PlusEveryNonTest, comparisonType: StringComparison.Ordinal))
        {
            HashSet<string> required = List(cell: cell[..^PlusEveryNonTest.Length]);
            return Row(allowed: everyOther, required: required);
        }

        HashSet<string> names = List(cell: cell);
        return names.Any(predicate: name => name.Contains(value: ' ', comparisonType: StringComparison.Ordinal))
                ? null
                : Row(allowed: names, required: names);
    }

    private static HashSet<string> List(string cell)
    {
        string[] names = cell.Split(
                separator: ',',
                options: StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        return names.Select(selector: Expand).ToHashSet(comparer: StringComparer.Ordinal);
    }

    private static AllowedEdgeRow Row(IEnumerable<string> allowed, IEnumerable<string> required)
    {
        return new AllowedEdgeRow(
                allowed: allowed.ToHashSet(comparer: StringComparer.Ordinal),
                required: required.ToHashSet(comparer: StringComparer.Ordinal));
    }

    private static bool IsSameName(string left, string right)
    {
        return string.Equals(a: left, b: right, comparisonType: StringComparison.Ordinal);
    }

    private static string Describe(IEnumerable<string> names)
    {
        return string.Join(separator: ", ", values: names.Order(comparer: StringComparer.Ordinal));
    }
}
