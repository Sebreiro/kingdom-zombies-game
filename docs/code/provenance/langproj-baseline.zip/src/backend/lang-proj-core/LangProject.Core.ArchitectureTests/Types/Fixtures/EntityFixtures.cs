using System;

namespace LangProject.Core.ArchitectureTests.Types.Fixtures;

/// <summary>
/// Domain entity shapes for the entity rule: one valid shape and one bad-on-purpose shape per violation. They compile
/// under every house rule; only the ArchitectureTests entity rule rejects the bad ones.
/// </summary>
internal static class EntityFixtures
{
    /// <summary>A valid entity: private setters, a parameterized constructor and a private [Obsolete] one.</summary>
    internal sealed class ValidEntity
    {
        public ValidEntity(string name)
        {
            Name = name;
        }

        public string Name { get; private set; }

        [Obsolete("Used by EF Core only.", error: true)]
        private ValidEntity()
        {
            Name = string.Empty;
        }
    }

    /// <summary>Bad: a public setter.</summary>
    internal sealed class PublicSetterEntity
    {
        public PublicSetterEntity(string name)
        {
            Name = name;
        }

        public string Name { get; set; }

        [Obsolete("Used by EF Core only.", error: true)]
        private PublicSetterEntity()
        {
            Name = string.Empty;
        }
    }

    /// <summary>Bad: an internal setter.</summary>
    internal sealed class InternalSetterEntity
    {
        public InternalSetterEntity(string name)
        {
            Name = name;
        }

        public string Name { get; internal set; }

        [Obsolete("Used by EF Core only.", error: true)]
        private InternalSetterEntity()
        {
            Name = string.Empty;
        }
    }

    /// <summary>Bad: a protected setter. The class is abstract because a sealed class cannot declare one.</summary>
    internal abstract class ProtectedSetterEntity
    {
        public string Name { get; protected set; }

        protected ProtectedSetterEntity(string name)
        {
            Name = name;
        }

        [Obsolete("Used by EF Core only.", error: true)]
        private ProtectedSetterEntity()
        {
            Name = string.Empty;
        }
    }

    /// <summary>Bad: an <c>init</c> setter.</summary>
    internal sealed class InitSetterEntity
    {
        public InitSetterEntity(string name)
        {
            Name = name;
        }

        public string Name { get; init; }

        [Obsolete("Used by EF Core only.", error: true)]
        private InitSetterEntity()
        {
            Name = string.Empty;
        }
    }

    /// <summary>Bad: no parameterless ORM constructor at all.</summary>
    internal sealed class MissingOrmConstructorEntity
    {
        public MissingOrmConstructorEntity(string name)
        {
            Name = name;
        }

        public string Name { get; private set; }
    }

    /// <summary>Bad: the parameterless ORM constructor is internal, not private.</summary>
    internal sealed class OrmConstructorNotPrivateEntity
    {
        public OrmConstructorNotPrivateEntity(string name)
        {
            Name = name;
        }

        public string Name { get; private set; }

        [Obsolete("Used by EF Core only.", error: true)]
        internal OrmConstructorNotPrivateEntity()
        {
            Name = string.Empty;
        }
    }

    /// <summary>Bad: the private parameterless ORM constructor has no [Obsolete] attribute.</summary>
    internal sealed class OrmConstructorNotObsoleteEntity
    {
        public OrmConstructorNotObsoleteEntity(string name)
        {
            Name = name;
        }

        public string Name { get; private set; }

        private OrmConstructorNotObsoleteEntity()
        {
            Name = string.Empty;
        }
    }

    /// <summary>Bad: only the ORM constructor, no constructor with parameters.</summary>
    internal sealed class MissingParameterizedConstructorEntity
    {
        public string Name { get; private set; }

        [Obsolete("Used by EF Core only.", error: true)]
        private MissingParameterizedConstructorEntity()
        {
            Name = string.Empty;
        }
    }
}
