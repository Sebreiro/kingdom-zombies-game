using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Xunit;

namespace LangProject.Core.ArchitectureTests.RealBuild;

/// <summary>
/// The shared real build of <see cref="RuleProofTests"/>: one throwaway solution copy with every fixture of
/// <see cref="RuleProofSources"/>, and one <c>dotnet build</c> of each fixture project, run once for the whole test
/// class. The copy is deleted as soon as the builds finish; only their output is kept.
/// </summary>
public sealed class RuleProofBuild : IAsyncLifetime
{
    /// <summary>Writes the fixtures into a fresh solution copy and builds the three fixture projects.</summary>
    /// <returns>A task that completes when the builds have finished.</returns>
    public async ValueTask InitializeAsync()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        using SolutionCopy copy = await SolutionCopy.CreateAsync(
                cancellationToken: cancellationToken);
        foreach (KeyValuePair<string, string> file in RuleProofSources.Files)
        {
            copy.WriteFile(relativePath: file.Key, content: file.Value);
        }

        Rules = await DotnetCli.BuildAsync(
                target: RuleProofSources.RulesProject,
                workingDirectory: copy.SolutionRoot,
                cancellationToken: cancellationToken);
        Compile = await DotnetCli.BuildAsync(
                target: RuleProofSources.CompileProject,
                workingDirectory: copy.SolutionRoot,
                cancellationToken: cancellationToken);
        Tests = await DotnetCli.BuildAsync(
                target: RuleProofSources.TestsProject,
                workingDirectory: copy.SolutionRoot,
                cancellationToken: cancellationToken);
    }

    /// <summary>Nothing to release: the solution copy is deleted at the end of <see cref="InitializeAsync"/>.</summary>
    /// <returns>A completed task.</returns>
    public ValueTask DisposeAsync()
    {
        return ValueTask.CompletedTask;
    }

    /// <summary>Gets the build of the ordinary fixture library.</summary>
    internal ProcessResult Rules { get; private set; } = _notBuilt;

    /// <summary>Gets the build of the fixture library that fails the compiler.</summary>
    internal ProcessResult Compile { get; private set; } = _notBuilt;

    /// <summary>Gets the build of the fixture test project.</summary>
    internal ProcessResult Tests { get; private set; } = _notBuilt;

    private static readonly ProcessResult _notBuilt = new(exitCode: -1, output: string.Empty);
}
