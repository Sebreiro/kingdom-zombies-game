using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// The rule matrix, <c>src/backend/docs/rule-matrix.md</c>, is complete (SPEC R7, R20): every rule heading in the
/// code-rule docs links to a row, every row names its mechanisms and proof tests, and every diagnostic ID, banned
/// symbol and test the matrix names exists in the solution.
/// </summary>
public sealed partial class RuleMatrixTests
{
    /// <summary>
    /// Every <c>###</c> heading in <c>code-style.md</c> and <c>code-architecture.md</c> is followed by an
    /// <c>Enforcement:</c> line that links to existing rows, and every row links back to a heading that links to it.
    /// </summary>
    [Fact]
    public void Matrix_EveryRuleHeading_HasARowAndALink()
    {
        RuleMatrix matrix = LoadMatrix();
        var rowIds = matrix.Rules.Select(selector: rule => rule.Id).ToHashSet(comparer: StringComparer.Ordinal);
        var violations = new List<string>();
        var headingsByDocument = new Dictionary<string, IReadOnlyList<RuleHeading>>(comparer: StringComparer.Ordinal);
        foreach (string document in _ruleDocuments)
        {
            IReadOnlyList<RuleHeading> headings = RuleDocument.Headings(markdown: ReadDoc(relativePath: document));
            headings.ShouldContain(elementPredicate: heading => heading.Level == 3, customMessage: document);
            headingsByDocument[document] = headings;
            violations.AddRange(collection: CheckHeadingLinks(
                    document: document,
                    headings: headings,
                    rowIds: rowIds));
        }

        foreach (MatrixRule rule in matrix.Rules)
        {
            violations.AddRange(collection: CheckRowLinksBack(rule: rule, headingsByDocument: headingsByDocument));
        }

        matrix.Rules.ShouldNotBeEmpty();
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// Every row has an ID with its anchor, a rule, a mechanism, a scope, at least one proof test and a known level,
    /// and the matrix lists at least the 14 exemption rows the suppression scan and the rules rely on.
    /// </summary>
    [Fact]
    public void Matrix_EveryRow_HasMechanismAndProof()
    {
        RuleMatrix matrix = LoadMatrix();

        IReadOnlyList<string> violations = RuleMatrix.CheckRows(matrix: matrix);

        matrix.Rules.ShouldNotBeEmpty();
        matrix.Exemptions.Count.ShouldBeGreaterThanOrEqualTo(expected: 14);
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// Every diagnostic ID the matrix names exists: SCR IDs are analyzer descriptors listed in the release-tracking
    /// file; IDE, CA, MA and RCS IDs are set in the solution <c>.editorconfig</c>; RS0030 rows name banned symbols
    /// that a BannedSymbols file lists; CS IDs come from a short allow-list. Every analyzer rule and every banned
    /// symbol also has a row.
    /// </summary>
    [Fact]
    public void Matrix_NamedDiagnostics_Exist()
    {
        RuleMatrix matrix = LoadMatrix();
        HashSet<string> analyzerIds = AnalyzerRuleIds();
        HashSet<string> editorConfigIds = EditorConfigIds();
        HashSet<string> bannedSymbols = BannedSymbolEntries();

        var violations = new List<string>();
        foreach (MatrixRule rule in matrix.Rules)
        {
            violations.AddRange(collection: CheckDiagnostics(
                    rule: rule,
                    analyzerIds: analyzerIds,
                    editorConfigIds: editorConfigIds,
                    bannedSymbols: bannedSymbols));
        }

        var namedIds = matrix.Rules
                .SelectMany(selector: rule => RuleMatrix.DiagnosticIds(cell: rule.Mechanisms))
                .ToHashSet(comparer: StringComparer.Ordinal);
        var namedSymbols = matrix.Rules
                .SelectMany(selector: rule => RuleMatrix.BannedSymbols(cell: rule.Mechanisms))
                .ToHashSet(comparer: StringComparer.Ordinal);
        violations.AddRange(collection: analyzerIds
                .Where(predicate: id => !namedIds.Contains(item: id))
                .Select(selector: id => $"Analyzer rule {id} has no matrix row"));
        violations.AddRange(collection: bannedSymbols
                .Where(predicate: symbol => !namedSymbols.Contains(item: symbol))
                .Select(selector: symbol => $"Banned symbol {symbol} has no matrix row (D-32)"));

        analyzerIds.ShouldNotBeEmpty();
        bannedSymbols.ShouldNotBeEmpty();
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// Every proof test the matrix names is a <c>[Fact]</c> or <c>[Theory]</c> method declared in one of the three
    /// test projects.
    /// </summary>
    [Fact]
    public void Matrix_NamedTests_Exist()
    {
        RuleMatrix matrix = LoadMatrix();
        var declared = TestSourceIndex.ProductionTestMethods().ToHashSet(comparer: StringComparer.Ordinal);

        List<string> violations =
        [
            .. matrix.Rules.SelectMany(selector: rule => RuleMatrix.ProofTests(cell: rule.Proof)
                    .Where(predicate: test => !declared.Contains(item: test))
                    .Select(selector: test => $"{rule.Id}: proof test {test} is not declared in a test project")),
        ];

        declared.ShouldNotBeEmpty();
        matrix.Rules.ShouldNotBeEmpty();
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// A synthetic matrix whose row has an empty proof cell is reported; its complete neighbour is not.
    /// </summary>
    [Fact]
    public void Matrix_Parser_RejectsRowWithoutProof()
    {
        string withoutProof = SyntheticRow(
                id: "<a id=\"r-01\"></a>R-01",
                rule: "[Braces always](CodeRules/code-style.md#braces-always)",
                proof: string.Empty,
                level: "real build");
        string complete = SyntheticRow(
                id: "<a id=\"r-02\"></a>R-02",
                rule: "[Final newline](CodeRules/code-style.md#final-newline)",
                proof: SyntheticProof,
                level: "ArchitectureTests");
        var matrix = RuleMatrix.Parse(markdown: SyntheticMatrix(rows: withoutProof + "\n" + complete));

        IReadOnlyList<string> violations = RuleMatrix.CheckRows(matrix: matrix);

        matrix.Rules.Count.ShouldBe(expected: 2);
        string violation = violations.ShouldHaveSingleItem();
        violation.ShouldContain(expected: "R-01");
        violation.ShouldContain(expected: "proof");
    }

    /// <summary>
    /// A synthetic row with an unknown level, a missing anchor and an exemption ID with no exemption row is
    /// reported once for each problem.
    /// </summary>
    [Fact]
    public void Matrix_Parser_RejectsUnknownLevelAnchorAndExemption()
    {
        string row = SyntheticRow(
                id: "R-01",
                rule: "[Braces always](CodeRules/code-style.md#braces-always)",
                proof: SyntheticProof,
                level: "wishful thinking");
        var matrix = RuleMatrix.Parse(markdown: SyntheticMatrix(rows: row.Replace(
                oldValue: "C# files",
                newValue: "C# files; EX-07",
                comparisonType: StringComparison.Ordinal)));

        IReadOnlyList<string> violations = RuleMatrix.CheckRows(matrix: matrix);

        violations.Count.ShouldBe(expected: 3, customMessage: string.Join(separator: "\n", values: violations));
        violations.ShouldContain(elementPredicate: message => message.Contains(
                value: "anchor",
                comparisonType: StringComparison.Ordinal));
        violations.ShouldContain(elementPredicate: message => message.Contains(
                value: "EX-07",
                comparisonType: StringComparison.Ordinal));
        violations.ShouldContain(elementPredicate: message => message.Contains(
                value: "wishful thinking",
                comparisonType: StringComparison.Ordinal));
    }

    private const string SyntheticProof = "`LangProject.Core.ArchitectureTests.Files.SourceFileFormatTests."
            + "FormatRule_MissingFinalNewline_IsReported`";

    private static readonly string[] _ruleDocuments = ["CodeRules/code-style.md", "CodeRules/code-architecture.md"];

    private static readonly string[] _bannedSymbolFiles = ["BannedSymbols.txt", "BannedSymbols.Tests.txt"];

    private static readonly HashSet<string> _allowedCompilerIds = new(
            collection: ["CS1591", "CS0246", "CS0012"],
            comparer: StringComparer.Ordinal);

    [GeneratedRegex(
            pattern: @"DiagnosticId\s*=\s*""(?<id>SCR[0-9]{4})""",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex AnalyzerDescriptorPattern();

    [GeneratedRegex(
            pattern: @"^(?<id>SCR[0-9]{4})\s*\|",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant | RegexOptions.Multiline,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex ReleaseTrackingPattern();

    [GeneratedRegex(
            pattern: @"^\s*dotnet_diagnostic\.(?<id>[A-Z]+[0-9]+)\.severity\s*=",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant | RegexOptions.Multiline,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex EditorConfigSeverityPattern();

    private static RuleMatrix LoadMatrix()
    {
        return RuleMatrix.Parse(markdown: ReadDoc(relativePath: "rule-matrix.md"));
    }

    private static string ReadDoc(string relativePath)
    {
        return File.ReadAllText(path: Path.Combine(path1: RepositoryLayout.BackendDocs, path2: relativePath));
    }

    private static List<string> CheckHeadingLinks(
            string document,
            IReadOnlyList<RuleHeading> headings,
            HashSet<string> rowIds)
    {
        var violations = new List<string>();
        foreach (RuleHeading heading in headings.Where(predicate: heading => heading.Level == 3))
        {
            if (heading.EnforcementIds.Count == 0)
            {
                violations.Add(item: $"{document}: '### {heading.Text}' has no Enforcement: line with a matrix link");
            }

            violations.AddRange(collection: heading.EnforcementIds
                    .Where(predicate: id => !rowIds.Contains(item: id))
                    .Select(selector: id => $"{document}: '### {heading.Text}' links to {id}, which has no row"));
        }

        return violations;
    }

    private static List<string> CheckRowLinksBack(
            MatrixRule rule,
            Dictionary<string, IReadOnlyList<RuleHeading>> headingsByDocument)
    {
        IReadOnlyList<KeyValuePair<string, string>> links = RuleMatrix.DocLinks(cell: rule.Rule);
        if (links.Count == 0)
        {
            return [$"{rule.Id}: the rule cell links to no code-rule doc heading"];
        }

        var violations = new List<string>();
        foreach (KeyValuePair<string, string> link in links)
        {
            IReadOnlyList<RuleHeading> headings = headingsByDocument.GetValueOrDefault(key: link.Key) ?? [];
            bool linksBack = headings.Any(predicate: heading => string.Equals(
                    a: heading.Slug,
                    b: link.Value,
                    comparisonType: StringComparison.Ordinal)
                    && heading.EnforcementIds.Contains(value: rule.Id, comparer: StringComparer.Ordinal));
            if (!linksBack)
            {
                violations.Add(item: $"{rule.Id}: {link.Key}#{link.Value} is not a heading that links back to the row");
            }
        }

        return violations;
    }

    private static List<string> CheckDiagnostics(
            MatrixRule rule,
            HashSet<string> analyzerIds,
            HashSet<string> editorConfigIds,
            HashSet<string> bannedSymbols)
    {
        IReadOnlyList<string> namedSymbols = RuleMatrix.BannedSymbols(cell: rule.Mechanisms);
        List<string> violations =
        [
            .. RuleMatrix.DiagnosticIds(cell: rule.Mechanisms)
                    .Where(predicate: id => !IsKnownDiagnostic(
                            id: id,
                            analyzerIds: analyzerIds,
                            editorConfigIds: editorConfigIds,
                            namedSymbolCount: namedSymbols.Count))
                    .Select(selector: id => $"{rule.Id}: diagnostic {id} is not configured or not known"),
            .. namedSymbols
                    .Where(predicate: symbol => !bannedSymbols.Contains(item: symbol))
                    .Select(selector: symbol => $"{rule.Id}: banned symbol {symbol} is in no BannedSymbols file"),
        ];
        return violations;
    }

    private static bool IsKnownDiagnostic(
            string id,
            HashSet<string> analyzerIds,
            HashSet<string> editorConfigIds,
            int namedSymbolCount)
    {
        if (id.StartsWith(value: "SCR", comparisonType: StringComparison.Ordinal))
        {
            return analyzerIds.Contains(item: id);
        }

        if (id.StartsWith(value: "CS", comparisonType: StringComparison.Ordinal))
        {
            return _allowedCompilerIds.Contains(item: id);
        }

        if (id.StartsWith(value: "RS", comparisonType: StringComparison.Ordinal))
        {
            return string.Equals(a: id, b: "RS0030", comparisonType: StringComparison.Ordinal) && namedSymbolCount > 0;
        }

        return editorConfigIds.Contains(item: id);
    }

    private static HashSet<string> AnalyzerRuleIds()
    {
        string analyzerFolder = Path.Combine(
                path1: RepositoryLayout.PackagesDirectory,
                path2: "Sebreiro.CodeRules.Analyzers");
        var descriptorIds = Directory.EnumerateFiles(path: analyzerFolder, searchPattern: "*.cs")
                .SelectMany(selector: path => AnalyzerDescriptorPattern().Matches(input: File.ReadAllText(path: path)))
                .Select(selector: match => match.Groups["id"].Value)
                .ToHashSet(comparer: StringComparer.Ordinal);
        string releases = File.ReadAllText(path: Path.Combine(
                path1: analyzerFolder,
                path2: "AnalyzerReleases.Unshipped.md"));
        var trackedIds = ReleaseTrackingPattern()
                .Matches(input: releases)
                .Select(selector: match => match.Groups["id"].Value)
                .ToHashSet(comparer: StringComparer.Ordinal);

        descriptorIds.ShouldBe(expected: trackedIds, ignoreOrder: true);
        return descriptorIds;
    }

    private static HashSet<string> EditorConfigIds()
    {
        string editorConfig = File.ReadAllText(path: Path.Combine(
                path1: RepositoryLayout.SolutionRoot,
                path2: ".editorconfig"));
        return EditorConfigSeverityPattern()
                .Matches(input: editorConfig)
                .Select(selector: match => match.Groups["id"].Value)
                .ToHashSet(comparer: StringComparer.Ordinal);
    }

    private static HashSet<string> BannedSymbolEntries()
    {
        return _bannedSymbolFiles
                .SelectMany(selector: name => File.ReadAllLines(path: Path.Combine(
                        path1: RepositoryLayout.SolutionRoot,
                        path2: name)))
                .Where(predicate: line => line.Length > 0)
                .Select(selector: line => line.Split(separator: ';')[0].Trim())
                .ToHashSet(comparer: StringComparer.Ordinal);
    }

    private static string SyntheticRow(string id, string rule, string proof, string level)
    {
        return $"| {id} | {rule} | `IDE0011` | C# files | {proof} | {level} |";
    }

    private static string SyntheticMatrix(string rows)
    {
        return $"""
                # Rule matrix

                ## Rules

                | ID | Rule | Mechanism ids | Scope and exemptions | Proof test | Level |
                |----|------|---------------|----------------------|------------|-------|
                {rows}

                ## Exemptions

                | ID | Path glob | Exact text the scan will meet | Reason | Rule ID |
                |----|-----------|-------------------------------|--------|---------|

                """;
    }
}
