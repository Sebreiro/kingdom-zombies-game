using System.IO;
using System.Xml;
using System.Xml.Linq;

namespace LangProject.Core.ArchitectureTests.Infrastructure;

/// <summary>Parses the repository's own XML build files with DTD processing prohibited.</summary>
internal static class XmlText
{
    /// <summary>Parses <paramref name="xml"/> into a document.</summary>
    /// <param name="xml">The XML text of a solution, project, props or targets file.</param>
    /// <returns>The parsed document.</returns>
    internal static XDocument Parse(string xml)
    {
        var settings = new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null };
        using var text = new StringReader(s: xml);
        using var reader = XmlReader.Create(input: text, settings: settings);
        return XDocument.Load(reader: reader);
    }
}
