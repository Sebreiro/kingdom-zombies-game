using System;

namespace LangProject.Core.ArchitectureTests.Types;

/// <summary>One type that the compiler-generated code of a source type uses.</summary>
internal sealed class GeneratedDependency
{
    /// <summary>Describes the dependency as a violation message.</summary>
    /// <returns>For example <c>X (compiler-generated &lt;RunAsync&gt;d__0) depends on Y</c>.</returns>
    public override string ToString()
    {
        return $"{Subject.FullName} (compiler-generated {GeneratedType}) depends on {UsedFullName}";
    }

    /// <summary>Initializes a new instance of the <see cref="GeneratedDependency"/> class.</summary>
    /// <param name="subject">The source-declared type whose generated code uses the type.</param>
    /// <param name="generatedType">The name of the generated nested type, such as <c>&lt;RunAsync&gt;d__0</c>.</param>
    /// <param name="usedNamespace">The namespace of the used type's outermost declaring type.</param>
    /// <param name="usedFullName">The full name of the used type, with <c>+</c> for nesting.</param>
    internal GeneratedDependency(Type subject, string generatedType, string usedNamespace, string usedFullName)
    {
        Subject = subject;
        GeneratedType = generatedType;
        UsedNamespace = usedNamespace;
        UsedFullName = usedFullName;
    }

    /// <summary>Gets the source-declared type whose generated code uses the type.</summary>
    internal Type Subject { get; }

    /// <summary>Gets the name of the generated nested type.</summary>
    internal string GeneratedType { get; }

    /// <summary>Gets the namespace of the used type's outermost declaring type.</summary>
    internal string UsedNamespace { get; }

    /// <summary>Gets the full name of the used type.</summary>
    internal string UsedFullName { get; }
}
