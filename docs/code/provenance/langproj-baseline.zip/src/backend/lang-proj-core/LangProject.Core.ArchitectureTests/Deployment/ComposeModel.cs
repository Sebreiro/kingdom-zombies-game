using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using LangProject.Core.ArchitectureTests.Infrastructure;

namespace LangProject.Core.ArchitectureTests.Deployment;

/// <summary>
/// Reads the parts of a rendered Compose model (<c>docker compose config --format json</c>) that the deployment
/// checks use, as plain sorted text, so a test compares a whole list at once and its failure shows every entry.
/// Pure functions of the JSON, so proofs can feed synthetic models.
/// </summary>
internal static class ComposeModel
{
    /// <summary>Lists the service names, in ordinal order.</summary>
    /// <param name="config">The root of the rendered model.</param>
    /// <returns>The service names.</returns>
    internal static IReadOnlyList<string> ServiceNames(JsonElement config)
    {
        return Sorted(entries: Services(config: config).Select(selector: service => service.Name));
    }

    /// <summary>
    /// Lists every published port as <c>service host:published-&gt;target</c>, with <c>*</c> as the host when the
    /// port is published on all interfaces, in ordinal order.
    /// </summary>
    /// <param name="config">The root of the rendered model.</param>
    /// <returns>One entry per published port.</returns>
    internal static IReadOnlyList<string> PublishedPorts(JsonElement config)
    {
        return Sorted(entries: Services(config: config).SelectMany(selector: service =>
                Items(service: service.Value, property: "ports").Select(selector: port =>
                        $"{service.Name} {Text(element: port, property: "host_ip", fallback: "*")}:"
                                + $"{Text(element: port, property: "published", fallback: "?")}->"
                                + Text(element: port, property: "target", fallback: "?"))));
    }

    /// <summary>Lists every start dependency as <c>service -&gt; dependency: condition</c>, in ordinal order.</summary>
    /// <param name="config">The root of the rendered model.</param>
    /// <returns>One entry per dependency.</returns>
    internal static IReadOnlyList<string> Dependencies(JsonElement config)
    {
        return Sorted(entries: Services(config: config).SelectMany(selector: service =>
                Properties(element: service.Value, property: "depends_on").Select(selector: dependency =>
                        $"{service.Name} -> {dependency.Name}: "
                                + Text(element: dependency.Value, property: "condition", fallback: "?"))));
    }

    /// <summary>Lists every service's image as <c>service image</c>, in ordinal order.</summary>
    /// <param name="config">The root of the rendered model.</param>
    /// <returns>One entry per service.</returns>
    internal static IReadOnlyList<string> Images(JsonElement config)
    {
        return Sorted(entries: Services(config: config).Select(selector: service =>
                $"{service.Name} {Text(element: service.Value, property: "image", fallback: "?")}"));
    }

    /// <summary>
    /// Lists every service that is built from a Dockerfile as <c>service context target pull_policy</c>, with the
    /// context relative to the repository root, in ordinal order.
    /// </summary>
    /// <param name="config">The root of the rendered model.</param>
    /// <returns>One entry per built service.</returns>
    internal static IReadOnlyList<string> Builds(JsonElement config)
    {
        return Sorted(entries: Services(config: config)
                .Where(predicate: service => service.Value.TryGetProperty(propertyName: "build", value: out _))
                .Select(selector: service => BuildEntry(name: service.Name, service: service.Value)));
    }

    /// <summary>
    /// Lists every volume mount as <c>service type source:target</c> and every tmpfs mount as
    /// <c>service tmpfs target</c>, in ordinal order.
    /// </summary>
    /// <param name="config">The root of the rendered model.</param>
    /// <returns>One entry per mount.</returns>
    internal static IReadOnlyList<string> Mounts(JsonElement config)
    {
        IEnumerable<string> volumes = Services(config: config).SelectMany(selector: service =>
                Items(service: service.Value, property: "volumes").Select(selector: mount =>
                        $"{service.Name} {Text(element: mount, property: "type", fallback: "?")} "
                                + $"{Text(element: mount, property: "source", fallback: "?")}:"
                                + Text(element: mount, property: "target", fallback: "?")));
        IEnumerable<string> tmpfs = Services(config: config).SelectMany(selector: service =>
                Items(service: service.Value, property: "tmpfs").Select(selector: target =>
                        $"{service.Name} tmpfs {target.GetString()}"));
        return Sorted(entries: volumes.Concat(second: tmpfs));
    }

    /// <summary>
    /// Lists every service's log settings as <c>service driver max-size max-file</c>, with <c>none</c> for a service
    /// without a <c>logging</c> block and <c>-</c> for a missing option, in ordinal order.
    /// </summary>
    /// <param name="config">The root of the rendered model.</param>
    /// <returns>One entry per service.</returns>
    internal static IReadOnlyList<string> Logging(JsonElement config)
    {
        return Sorted(entries: Services(config: config).Select(selector: service => LoggingEntry(
                name: service.Name,
                service: service.Value)));
    }

    /// <summary>
    /// Lists every service that sets <c>network_mode</c> as <c>service mode</c>, in ordinal order. A mode such as
    /// <c>host</c> or <c>service:api</c> exposes ports that the <c>ports</c> list does not show.
    /// </summary>
    /// <param name="config">The root of the rendered model.</param>
    /// <returns>One entry per service with a network mode.</returns>
    internal static IReadOnlyList<string> NetworkModes(JsonElement config)
    {
        return Sorted(entries: Services(config: config)
                .Where(predicate: service => service.Value.TryGetProperty(propertyName: "network_mode", value: out _))
                .Select(selector: service =>
                        $"{service.Name} {Text(element: service.Value, property: "network_mode", fallback: "?")}"));
    }

    /// <summary>Reads one service's environment variables.</summary>
    /// <param name="config">The root of the rendered model.</param>
    /// <param name="service">The service name.</param>
    /// <returns>The variables by name; empty when the service sets none.</returns>
    internal static IReadOnlyDictionary<string, string> ServiceEnvironment(JsonElement config, string service)
    {
        JsonProperty match = Services(config: config).FirstOrDefault(predicate: candidate => string.Equals(
                a: candidate.Name,
                b: service,
                comparisonType: StringComparison.Ordinal));
        return Properties(element: match.Value, property: "environment").ToDictionary(
                keySelector: variable => variable.Name,
                elementSelector: variable => variable.Value.GetString() ?? string.Empty,
                comparer: StringComparer.Ordinal);
    }

    private static IEnumerable<JsonProperty> Services(JsonElement config)
    {
        return Properties(element: config, property: "services");
    }

    private static IEnumerable<JsonProperty> Properties(JsonElement element, string property)
    {
        if (element.ValueKind != JsonValueKind.Object
                || !element.TryGetProperty(propertyName: property, value: out JsonElement child)
                || child.ValueKind != JsonValueKind.Object)
        {
            yield break;
        }

        foreach (JsonProperty item in child.EnumerateObject())
        {
            yield return item;
        }
    }

    private static IEnumerable<JsonElement> Items(JsonElement service, string property)
    {
        if (!service.TryGetProperty(propertyName: property, value: out JsonElement child)
                || child.ValueKind != JsonValueKind.Array)
        {
            yield break;
        }

        foreach (JsonElement item in child.EnumerateArray())
        {
            yield return item;
        }
    }

    private static string Text(JsonElement element, string property, string fallback)
    {
        if (!element.TryGetProperty(propertyName: property, value: out JsonElement child))
        {
            return fallback;
        }

        return child.ValueKind switch
        {
            JsonValueKind.String => child.GetString() ?? fallback,
            JsonValueKind.Number => child.GetInt64().ToString(provider: CultureInfo.InvariantCulture),
            _ => child.GetRawText(),
        };
    }

    private static string BuildEntry(string name, JsonElement service)
    {
        JsonElement build = service.GetProperty(propertyName: "build");
        string context = Path.GetRelativePath(
                relativeTo: RepositoryLayout.RepositoryRoot,
                path: Text(element: build, property: "context", fallback: "?")).Replace(oldChar: '\\', newChar: '/');
        return $"{name} {context} {Text(element: build, property: "target", fallback: "?")} "
                + Text(element: service, property: "pull_policy", fallback: "?");
    }

    private static string LoggingEntry(string name, JsonElement service)
    {
        if (!service.TryGetProperty(propertyName: "logging", value: out JsonElement logging))
        {
            return $"{name} none";
        }

        string options = logging.TryGetProperty(propertyName: "options", value: out JsonElement values)
                ? $"{Text(element: values, property: "max-size", fallback: "-")} "
                        + Text(element: values, property: "max-file", fallback: "-")
                : "- -";
        return $"{name} {Text(element: logging, property: "driver", fallback: "-")} {options}";
    }

    private static List<string> Sorted(IEnumerable<string> entries)
    {
        return [.. entries.Order(comparer: StringComparer.Ordinal)];
    }
}
