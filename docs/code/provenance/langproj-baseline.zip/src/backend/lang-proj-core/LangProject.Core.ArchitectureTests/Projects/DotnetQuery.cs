using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;
using LangProject.Core.ArchitectureTests.RealBuild;

namespace LangProject.Core.ArchitectureTests.Projects;

/// <summary>
/// Runs a short <c>dotnet</c> query, such as <c>--version</c> or an MSBuild evaluation, through
/// <see cref="DotnetCli"/>, so it gets the same clean environment and redirected output, but with its own short time
/// limit instead of the build limit.
/// </summary>
internal static class DotnetQuery
{
    /// <summary>Runs <c>dotnet</c> and kills it with its process tree when it runs past the limit.</summary>
    /// <param name="arguments">The arguments, one item per argument.</param>
    /// <param name="workingDirectory">The folder to run in; <c>global.json</c> above it selects the SDK.</param>
    /// <param name="timeout">How long the query may run.</param>
    /// <param name="cancellationToken">Cancels the run and kills the process.</param>
    /// <returns>The exit code, the standard output and the standard error.</returns>
    /// <exception cref="TimeoutException">The query ran longer than <paramref name="timeout"/>.</exception>
    internal static async Task<ProcessResult> RunAsync(
            IReadOnlyList<string> arguments,
            string workingDirectory,
            TimeSpan timeout,
            CancellationToken cancellationToken)
    {
        using var limit = CancellationTokenSource.CreateLinkedTokenSource(token: cancellationToken);
        limit.CancelAfter(delay: timeout);
        try
        {
            return await DotnetCli.RunAsync(
                    arguments: arguments,
                    workingDirectory: workingDirectory,
                    cancellationToken: limit.Token);
        }
        catch (OperationCanceledException exception) when (!cancellationToken.IsCancellationRequested)
        {
            throw new TimeoutException(
                    message: $"dotnet {string.Join(separator: " ", values: arguments)} ran longer than {timeout}.",
                    innerException: exception);
        }
    }
}
