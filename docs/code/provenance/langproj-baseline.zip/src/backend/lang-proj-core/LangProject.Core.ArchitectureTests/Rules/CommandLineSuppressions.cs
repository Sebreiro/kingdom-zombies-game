using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// Reads one command line, from a response file or a workflow, for the switches that weaken a rule: a
/// <c>-p:</c>, <c>/p:</c>, <c>-property:</c> or <c>--property</c> switch that sets a property of
/// <see cref="MsBuildPropertyRules"/> to a weakening value, the MSBuild warning switches <c>-nowarn</c>,
/// <c>-warnNotAsError</c> and <c>-warnAsMessage</c>, <c>-warnaserror-</c>, <c>dotnet test --ignore-exit-code</c>,
/// and a command that ignores its own failure with <c>|| true</c>, <c>|| :</c> or <c>|| exit 0</c>.
/// </summary>
internal static partial class CommandLineSuppressions
{
    /// <summary>Lists the pattern names that match one line.</summary>
    /// <param name="line">The line.</param>
    /// <returns>One pattern name per weakening switch, in line order.</returns>
    internal static IReadOnlyList<string> Patterns(string line)
    {
        var patterns = new List<string>();
        foreach (Match property in PropertySwitchPattern().Matches(input: line))
        {
            foreach (string assignment in property.Groups["properties"].Value.Split(separator: ';'))
            {
                int equals = assignment.IndexOf(value: '=');
                if (equals > 0)
                {
                    string name = assignment[..equals].Trim().Trim('"', '\'');
                    string value = assignment[(equals + 1)..].Trim().Trim('"', '\'', '\\');
                    string? pattern = MsBuildPropertyRules.ValuePattern(name: name, value: value);
                    if (pattern is not null)
                    {
                        patterns.Add(item: "command-line " + pattern);
                    }
                }
            }
        }

        patterns.AddRange(collection: WarningSwitchPattern()
                .Matches(input: line)
                .Select(selector: match => "command-line " + match.Groups["switch"].Value.ToLowerInvariant()));
        if (IgnoredFailurePattern().IsMatch(input: line))
        {
            patterns.Add(item: "ignored command failure");
        }

        return patterns;
    }

    [GeneratedRegex(
            pattern: @"(^|[\s""'])(-{1,2}(p|property)(:|\s+)|/(p|property):)(?<properties>[^\s]+)",
            options: RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex PropertySwitchPattern();

    [GeneratedRegex(
            pattern: @"(^|[\s""'])[-/]{1,2}(?<switch>nowarn|warnnotaserror|noerr|warnasmessage|warnaserror-|err-"
                    + @"|ignore-exit-code)(?=$|[\s:=""'])",
            options: RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex WarningSwitchPattern();

    [GeneratedRegex(
            pattern: @"\|\|\s*(true\b|exit\s+0\b|:(\s|$))",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex IgnoredFailurePattern();
}
