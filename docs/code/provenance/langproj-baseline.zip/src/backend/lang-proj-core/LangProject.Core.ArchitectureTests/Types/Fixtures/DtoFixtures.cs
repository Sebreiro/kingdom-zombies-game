namespace LangProject.Core.ArchitectureTests.Types.Fixtures;

/// <summary>
/// DTO shapes for the DTO and naming rules: one valid DTO and one bad-on-purpose shape per violation. They compile
/// under every house rule; only the ArchitectureTests rules reject the bad ones.
/// </summary>
internal static class DtoFixtures
{
    /// <summary>A valid DTO: a class with private setters, every property set through the constructor.</summary>
    internal sealed class ValidDto
    {
        public ValidDto(string code, string name)
        {
            Code = code;
            Name = name;
        }

        public string Code { get; private set; }

        public string Name { get; private set; }
    }

    /// <summary>Bad: a non-positional <c>record class</c>.</summary>
    internal sealed record RecordClassDto
    {
        public RecordClassDto(string name)
        {
            Name = name;
        }

        public string Name { get; private set; }
    }

    /// <summary>Bad: a non-positional <c>record struct</c>.</summary>
    internal record struct RecordStructDto
    {
        public RecordStructDto(string name)
        {
            Name = name;
        }

        public string Name { get; private set; }
    }

    /// <summary>Bad: a public setter.</summary>
    internal sealed class PublicSetterDto
    {
        public PublicSetterDto(string name)
        {
            Name = name;
        }

        public string Name { get; set; }
    }

    /// <summary>Bad: an <c>init</c> setter.</summary>
    internal sealed class InitSetterDto
    {
        public InitSetterDto(string name)
        {
            Name = name;
        }

        public string Name { get; init; }
    }

    /// <summary>Bad: <see cref="Name"/> has no constructor parameter, so no constructor initialises it.</summary>
    internal sealed class PropertyNotSetByConstructorDto
    {
        public PropertyNotSetByConstructorDto(string code)
        {
            Code = code;
        }

        public string Code { get; private set; }

        public string Name { get; private set; } = string.Empty;
    }

    /// <summary>Bad name: ends in plain <c>Request</c>.</summary>
    internal sealed class SampleRequest
    {
    }

    /// <summary>Bad name: ends in plain <c>Response</c>.</summary>
    internal sealed class SampleResponse
    {
    }

    /// <summary>Valid name: an HTTP DTO ends in <c>ResponseDto</c>.</summary>
    internal sealed class SampleResponseDto
    {
    }

    /// <summary>Bad HTTP DTO name: part of a response, but ends in plain <c>Dto</c>.</summary>
    internal sealed class FooEntryDto
    {
    }

    /// <summary>Valid HTTP DTO name: part of a response, and ends in <c>ResponseDto</c>.</summary>
    internal sealed class FooEntryResponseDto
    {
    }

    /// <summary>Valid HTTP DTO name: a request body ends in <c>RequestDto</c>.</summary>
    internal sealed class FooRequestDto
    {
    }
}
