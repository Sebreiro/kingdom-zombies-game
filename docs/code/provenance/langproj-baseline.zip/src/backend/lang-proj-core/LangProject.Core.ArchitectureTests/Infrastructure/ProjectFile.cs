using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace LangProject.Core.ArchitectureTests.Infrastructure;

/// <summary>
/// An immutable view of the text of one MSBuild file (csproj, props or targets): its properties, project references
/// and package items, with each item's semicolon list split the way MSBuild splits it. It is built from a file on
/// disk or from an XML string. It reads one file only: the project-graph rules read what MSBuild evaluates instead
/// (<c>Projects.ProjectEvaluator</c>), so imports and SDK defaults count there.
/// </summary>
internal sealed class ProjectFile
{
    /// <summary>Gets the file name without its extension; for a csproj this is the project name.</summary>
    internal string Name { get; }

    /// <summary>Gets the path relative to the solution root, with forward slashes.</summary>
    internal string RelativePath { get; }

    /// <summary>Gets every property set in any <c>PropertyGroup</c>, at any depth, in document order.</summary>
    internal IReadOnlyList<KeyValuePair<string, string>> Properties { get; }

    /// <summary>Gets the <c>Include</c> path of every <c>ProjectReference</c>, with forward slashes.</summary>
    internal IReadOnlyList<string> ProjectReferencePaths { get; }

    /// <summary>Gets the project names of every <c>ProjectReference</c>.</summary>
    internal IReadOnlySet<string> ProjectReferences { get; }

    /// <summary>
    /// Gets the package IDs of every <c>PackageReference</c>, <c>PackageVersion</c> and
    /// <c>GlobalPackageReference</c> item.
    /// </summary>
    internal IReadOnlyList<string> PackageIds { get; }

    /// <summary>Gets a value indicating whether the file sets <c>IsTestProject</c> to <c>true</c>.</summary>
    internal bool IsTestProject => string.Equals(
            a: GetProperty(name: "IsTestProject")?.Trim(),
            b: "true",
            comparisonType: StringComparison.OrdinalIgnoreCase);

    /// <summary>Loads a build file from disk.</summary>
    /// <param name="solutionRoot">The solution root the relative path starts from.</param>
    /// <param name="relativePath">The solution-relative path of the file.</param>
    /// <returns>The parsed file.</returns>
    internal static ProjectFile Load(string solutionRoot, string relativePath)
    {
        string xml = File.ReadAllText(path: Path.Combine(path1: solutionRoot, path2: relativePath));
        return Parse(relativePath: relativePath, xml: xml);
    }

    /// <summary>
    /// Loads every csproj, props and targets file under the solution root from disk, proof fixtures included, but
    /// not <c>bin</c> or <c>obj</c>.
    /// </summary>
    /// <returns>The parsed build files, in ordinal path order.</returns>
    internal static IReadOnlyList<ProjectFile> LoadBuildFiles()
    {
        return
        [
            .. RepositoryLayout.FindBuildFiles(root: RepositoryLayout.SolutionRoot)
                    .Select(selector: path => Load(
                            solutionRoot: RepositoryLayout.SolutionRoot,
                            relativePath: RepositoryLayout.ToSolutionRelative(fullPath: path))),
        ];
    }

    /// <summary>Parses a build file from its XML text.</summary>
    /// <param name="relativePath">The solution-relative path the file has, or would have.</param>
    /// <param name="xml">The XML text.</param>
    /// <returns>The parsed file.</returns>
    internal static ProjectFile Parse(string relativePath, string xml)
    {
        XElement root = XmlText.Parse(xml: xml).Root
                ?? throw new InvalidOperationException(message: $"{relativePath} has no root element.");
        return new ProjectFile(relativePath: relativePath.Replace(oldChar: '\\', newChar: '/'), root: root);
    }

    /// <summary>Gets the last value set for a property; MSBuild property names are case-insensitive.</summary>
    /// <param name="name">The property name.</param>
    /// <returns>The last value, or <see langword="null"/> when the file does not set the property.</returns>
    internal string? GetProperty(string name)
    {
        IReadOnlyList<string> values = GetPropertyValues(name: name);
        return values.Count == 0 ? null : values[^1];
    }

    /// <summary>Gets every value set for a property, in document order.</summary>
    /// <param name="name">The property name, matched case-insensitively.</param>
    /// <returns>The values; empty when the file does not set the property.</returns>
    internal IReadOnlyList<string> GetPropertyValues(string name)
    {
        return Properties
                .Where(predicate: property => string.Equals(
                        a: property.Key,
                        b: name,
                        comparisonType: StringComparison.OrdinalIgnoreCase))
                .Select(selector: property => property.Value)
                .ToList();
    }

    private static readonly string[] _packageItemNames =
            ["PackageReference", "PackageVersion", "GlobalPackageReference"];

    private ProjectFile(string relativePath, XElement root)
    {
        RelativePath = relativePath;
        Name = Path.GetFileNameWithoutExtension(path: relativePath);
        Properties = ReadProperties(root: root);
        ProjectReferencePaths = ReadItems(root: root, itemNames: ["ProjectReference"])
                .Select(selector: path => path.Replace(oldChar: '\\', newChar: '/'))
                .ToList();
        ProjectReferences = ProjectReferencePaths
                .Select(selector: path => Path.GetFileNameWithoutExtension(path: path))
                .ToHashSet(comparer: StringComparer.Ordinal);
        PackageIds = ReadItems(root: root, itemNames: _packageItemNames);
    }

    private static List<KeyValuePair<string, string>> ReadProperties(XElement root)
    {
        IEnumerable<KeyValuePair<string, string>> properties = root.Descendants()
                .Where(predicate: group => HasLocalName(element: group, localName: "PropertyGroup"))
                .SelectMany(selector: group => group.Elements())
                .Select(selector: property => new KeyValuePair<string, string>(
                        key: property.Name.LocalName,
                        value: property.Value));
        return [.. properties];
    }

    private static List<string> ReadItems(XElement root, IReadOnlyCollection<string> itemNames)
    {
        IEnumerable<string> specs = root.Descendants()
                .Where(predicate: group => HasLocalName(element: group, localName: "ItemGroup"))
                .SelectMany(selector: group => group.Elements())
                .Where(predicate: item => itemNames.Contains(
                        value: item.Name.LocalName,
                        comparer: StringComparer.Ordinal))
                .SelectMany(selector: ReadItemSpecs);
        return [.. specs];
    }

    private static string[] ReadItemSpecs(XElement item)
    {
        string? spec = (string?)item.Attribute(name: "Include") ?? (string?)item.Attribute(name: "Update");
        return spec is null
                ? []
                : spec.Split(
                        separator: ';',
                        options: StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
    }

    private static bool HasLocalName(XElement element, string localName)
    {
        return string.Equals(a: element.Name.LocalName, b: localName, comparisonType: StringComparison.Ordinal);
    }
}
