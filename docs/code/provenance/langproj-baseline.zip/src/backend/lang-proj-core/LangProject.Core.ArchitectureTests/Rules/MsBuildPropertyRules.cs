using System;
using System.Linq;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// The MSBuild properties and items that weaken a house rule, shared by the scan of MSBuild files, response
/// files and workflow command lines. Names are matched without regard to case, as MSBuild matches them.
/// </summary>
internal static class MsBuildPropertyRules
{
    /// <summary>
    /// Tells whether setting a property, item or item metadata of this name weakens a rule whatever its value:
    /// <c>NoWarn</c>, the warnings-not-as-errors and warnings-as-messages lists, <c>RunAnalyzers</c>, a rule set,
    /// <c>WarningLevel</c>, and extra analyzer config files.
    /// </summary>
    /// <param name="name">The property, item or metadata name.</param>
    /// <returns>The pattern name, or <see langword="null"/> when the name is not one of these.</returns>
    internal static string? AnyValuePattern(string name)
    {
        return _anyValue.FirstOrDefault(predicate: known => string.Equals(
                a: known,
                b: name,
                comparisonType: StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>
    /// Tells whether a property value weakens a rule: <c>TreatWarningsAsErrors</c>,
    /// <c>MSBuildTreatWarningsAsErrors</c>, <c>CodeAnalysisTreatWarningsAsErrors</c>,
    /// <c>EnforceCodeStyleInBuild</c>, <c>EnableNETAnalyzers</c> and <c>GenerateDocumentationFile</c> other than
    /// <c>true</c>, <c>Nullable</c> other than <c>enable</c>, and an <c>AnalysisLevel*</c> or <c>AnalysisMode*</c>
    /// below the recommended set. A property reference such as <c>$(Loose)</c> is not an allowed value.
    /// </summary>
    /// <param name="name">The property name.</param>
    /// <param name="value">The trimmed value.</param>
    /// <returns>The pattern name, or <see langword="null"/> when the value keeps the rule.</returns>
    internal static string? ValuePattern(string name, string value)
    {
        string? anyValue = AnyValuePattern(name: name);
        if (anyValue is not null)
        {
            return anyValue;
        }

        foreach ((string known, string[] allowed) in _requiredValues)
        {
            bool matches = known.EndsWith(value: '*')
                    ? name.StartsWith(value: known[..^1], comparisonType: StringComparison.OrdinalIgnoreCase)
                    : string.Equals(a: known, b: name, comparisonType: StringComparison.OrdinalIgnoreCase);
            if (matches)
            {
                return allowed.Contains(value: value, comparer: StringComparer.OrdinalIgnoreCase)
                        ? null
                        : $"{known} other than {string.Join(separator: " or ", value: allowed)}";
            }
        }

        return null;
    }

    private static readonly string[] _anyValue =
    [
        "NoWarn",
        "WarningsNotAsErrors",
        "WarningsAsMessages",
        "MSBuildWarningsNotAsErrors",
        "MSBuildWarningsAsMessages",
        "RunAnalyzers",
        "RunAnalyzersDuringBuild",
        "CodeAnalysisRuleSet",
        "WarningLevel",
        "EditorConfigFiles",
        "GlobalAnalyzerConfigFiles",
    ];

    private static readonly (string Name, string[] Allowed)[] _requiredValues =
    [
        ("TreatWarningsAsErrors", ["true"]),
        ("MSBuildTreatWarningsAsErrors", ["true"]),
        ("CodeAnalysisTreatWarningsAsErrors", ["true"]),
        ("EnforceCodeStyleInBuild", ["true"]),
        ("EnableNETAnalyzers", ["true"]),
        ("GenerateDocumentationFile", ["true"]),
        ("Nullable", ["enable"]),
        ("AnalysisLevel*", ["latest-recommended", "latest-all", "preview-recommended", "preview-all"]),
        ("AnalysisMode*", ["Recommended", "All"]),
    ];
}
