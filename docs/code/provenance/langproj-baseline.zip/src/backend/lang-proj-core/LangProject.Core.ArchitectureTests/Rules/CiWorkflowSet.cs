using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// Every tracked workflow, <c>.github/workflows/*.yml</c>, and every tracked composite action,
/// <c>.github/actions/*/action.yml</c>, each parsed with <see cref="CiWorkflow"/> and keyed by its repository-relative
/// path. A step that uses a local action expands to that action's steps, with the step's <c>with:</c> values standing
/// in for the action's <c>$NAME</c> variables that are set from <c>${{ inputs.* }}</c>, so a check reads the
/// effective command words. A pure function of the texts, so proofs can feed changed copies.
/// </summary>
internal sealed partial class CiWorkflowSet
{
    /// <summary>Gets the repository-relative paths of the files, in path order.</summary>
    internal IReadOnlyList<string> Paths => _paths;

    /// <summary>Parses a set of workflow and composite action texts.</summary>
    /// <param name="texts">The texts, keyed by repository-relative path with forward slashes.</param>
    /// <returns>The parsed set.</returns>
    internal static CiWorkflowSet Parse(IReadOnlyDictionary<string, string> texts)
    {
        return new CiWorkflowSet(texts: new Dictionary<string, string>(
                collection: texts,
                comparer: StringComparer.Ordinal));
    }

    /// <summary>Reads every tracked workflow and composite action of the repository.</summary>
    /// <param name="cancellationToken">Stops the run when the test run is cancelled.</param>
    /// <returns>The parsed set.</returns>
    internal static async Task<CiWorkflowSet> LoadAsync(CancellationToken cancellationToken)
    {
        IReadOnlyList<string> trackedFiles = await TrackedFiles.ListAsync(cancellationToken: cancellationToken);
        var texts = new Dictionary<string, string>(comparer: StringComparer.Ordinal);
        foreach (string path in trackedFiles.Where(predicate: path => IsWorkflowPath(relativePath: path)
                || IsActionPath(relativePath: path)))
        {
            texts[path] = await File.ReadAllTextAsync(
                    path: Path.Combine(path1: RepositoryLayout.RepositoryRoot, path2: path),
                    cancellationToken: cancellationToken);
        }

        return new CiWorkflowSet(texts: texts);
    }

    /// <summary>
    /// Tells whether a path is a workflow: a <c>.yml</c> or <c>.yaml</c> file directly in <c>.github/workflows/</c>.
    /// </summary>
    /// <param name="relativePath">A repository-relative path.</param>
    /// <returns>Whether the path is a workflow.</returns>
    internal static bool IsWorkflowPath(string relativePath)
    {
        return WorkflowPathPattern().IsMatch(input: relativePath);
    }

    /// <summary>Tells whether a path is a composite action: <c>.github/actions/&lt;name&gt;/action.yml</c>.</summary>
    /// <param name="relativePath">A repository-relative path.</param>
    /// <returns>Whether the path is an action file.</returns>
    internal static bool IsActionPath(string relativePath)
    {
        return ActionPathPattern().IsMatch(input: relativePath);
    }

    /// <summary>Reads one parsed file.</summary>
    /// <param name="relativePath">The repository-relative path.</param>
    /// <returns>The file, or <see langword="null"/> when the set has no such file.</returns>
    internal CiWorkflow? FileAt(string relativePath)
    {
        return _files.GetValueOrDefault(key: relativePath);
    }

    /// <summary>Lists the files whose text holds a string.</summary>
    /// <param name="text">The exact text.</param>
    /// <returns>The repository-relative paths, in path order.</returns>
    internal IReadOnlyList<string> PathsContaining(string text)
    {
        return
        [
            .. _paths.Where(predicate: path => _texts[path].Contains(
                    value: text,
                    comparisonType: StringComparison.Ordinal)),
        ];
    }

    /// <summary>Builds a copy of the set with every occurrence of a text in one file replaced.</summary>
    /// <param name="relativePath">The file to change.</param>
    /// <param name="original">The text to replace.</param>
    /// <param name="replacement">The new text.</param>
    /// <returns>The changed set.</returns>
    internal CiWorkflowSet Replace(string relativePath, string original, string replacement)
    {
        var texts = new Dictionary<string, string>(dictionary: _texts, comparer: StringComparer.Ordinal)
        {
            [relativePath] = _texts[relativePath].Replace(
                    oldValue: original,
                    newValue: replacement,
                    comparisonType: StringComparison.Ordinal),
        };
        return new CiWorkflowSet(texts: texts);
    }

    /// <summary>Resolves a <c>uses</c> value to the file of a local reusable workflow.</summary>
    /// <param name="uses">The value, such as <c>./.github/workflows/backend-fast.yml</c>.</param>
    /// <returns>The repository-relative path, or <see langword="null"/> when the set has no such workflow.</returns>
    internal string? LocalWorkflow(string uses)
    {
        string path = uses.StartsWith(value: "./", comparisonType: StringComparison.Ordinal) ? uses[2..] : string.Empty;
        return IsWorkflowPath(relativePath: path) && _files.ContainsKey(key: path) ? path : null;
    }

    /// <summary>Resolves a <c>uses</c> value to the file of a local composite action.</summary>
    /// <param name="uses">The value, such as <c>./.github/actions/setup-dotnet</c>.</param>
    /// <returns>The repository-relative path, or <see langword="null"/> when the set has no such action.</returns>
    internal string? LocalAction(string uses)
    {
        string folder = uses.StartsWith(value: "./", comparisonType: StringComparison.Ordinal)
                ? uses[2..].TrimEnd(trimChar: '/')
                : string.Empty;
        string[] candidates = [folder + "/action.yml", folder + "/action.yaml"];
        return candidates.FirstOrDefault(predicate: path => IsActionPath(relativePath: path)
                && _files.ContainsKey(key: path));
    }

    /// <summary>
    /// Expands a step that uses a local composite action to that action's steps. In each expanded <c>run</c>, a
    /// <c>$NAME</c> or <c>${NAME}</c> whose <c>env.NAME</c> is exactly <c>${{ inputs.&lt;input&gt; }}</c> is replaced
    /// by the step's <c>with.&lt;input&gt;</c> value, else by the input's default, else by nothing.
    /// </summary>
    /// <param name="step">A job step.</param>
    /// <returns>The action's steps, or <see langword="null"/> when the step uses no existing local action.</returns>
    internal IReadOnlyList<IReadOnlyDictionary<string, string>>? Expand(IReadOnlyDictionary<string, string> step)
    {
        string? path = LocalAction(uses: step.GetValueOrDefault(key: "uses") ?? string.Empty);
        if (path is null)
        {
            return null;
        }

        CiWorkflow action = _files[path];
        return
        [
            .. action.ActionSteps().Select(selector: actionStep => Substitute(
                    actionStep: actionStep,
                    callerStep: step,
                    action: action)),
        ];
    }

    private readonly Dictionary<string, string> _texts;
    private readonly Dictionary<string, CiWorkflow> _files;
    private readonly List<string> _paths;

    private CiWorkflowSet(Dictionary<string, string> texts)
    {
        _texts = texts;
        _files = texts.ToDictionary(
                keySelector: pair => pair.Key,
                elementSelector: pair => CiWorkflow.Parse(text: pair.Value),
                comparer: StringComparer.Ordinal);
        _paths = [.. texts.Keys.Order(comparer: StringComparer.Ordinal)];
    }

    private static Dictionary<string, string> Substitute(
            IReadOnlyDictionary<string, string> actionStep,
            IReadOnlyDictionary<string, string> callerStep,
            CiWorkflow action)
    {
        var inputValues = new Dictionary<string, string>(comparer: StringComparer.Ordinal);
        foreach (KeyValuePair<string, string> setting in actionStep)
        {
            Match input = InputExpressionPattern().Match(input: setting.Value);
            if (setting.Key.StartsWith(value: "env.", comparisonType: StringComparison.Ordinal) && input.Success)
            {
                string name = input.Groups["input"].Value;
                string defaultValue = action.Value(path: $"inputs.{name}.default") ?? string.Empty;
                inputValues[setting.Key["env.".Length..]] = callerStep.GetValueOrDefault(
                        key: "with." + name,
                        defaultValue: defaultValue);
            }
        }

        var expanded = new Dictionary<string, string>(collection: actionStep, comparer: StringComparer.Ordinal);
        if (expanded.TryGetValue(key: "run", value: out string? run))
        {
            expanded["run"] = VariablePattern().Replace(
                    input: run,
                    evaluator: match => inputValues.GetValueOrDefault(
                            key: match.Groups["name"].Value,
                            defaultValue: match.Value));
        }

        return expanded;
    }

    [GeneratedRegex(
            pattern: @"^\.github/workflows/[^/]+\.ya?ml$",
            options: RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex WorkflowPathPattern();

    [GeneratedRegex(
            pattern: @"^\.github/actions/[^/]+/action\.ya?ml$",
            options: RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex ActionPathPattern();

    [GeneratedRegex(
            pattern: @"^\$\{\{\s*inputs\.(?<input>[A-Za-z0-9_-]+)\s*\}\}$",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex InputExpressionPattern();

    [GeneratedRegex(
            pattern: @"\$(\{(?<name>[A-Za-z_][A-Za-z0-9_]*)\}|(?<name>[A-Za-z_][A-Za-z0-9_]*))",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex VariablePattern();
}
