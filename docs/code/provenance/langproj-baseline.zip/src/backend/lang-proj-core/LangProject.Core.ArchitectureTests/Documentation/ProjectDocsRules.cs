using System;
using System.Collections.Generic;
using System.Linq;

namespace LangProject.Core.ArchitectureTests.Documentation;

/// <summary>
/// The per-project docs rules (SPEC R18, DOCS-01): every project has a <c>docs/</c> folder with a Markdown file, a
/// <c>docs/README.md</c> with the three required sections, and a dependency list that names exactly the projects its
/// csproj references. Each rule is a pure function over <see cref="ProjectDocs"/> values.
/// </summary>
internal static class ProjectDocsRules
{
    /// <summary>The heading of the section that says what the project owns.</summary>
    internal const string ResponsibilityHeading = "## Responsibility";

    /// <summary>The heading of the section that lists the projects the csproj references.</summary>
    internal const string AllowedDependenciesHeading = "## Allowed dependencies";

    /// <summary>The heading of the section that states the project's rules.</summary>
    internal const string RulesHeading = "## Rules";

    /// <summary>The single bullet of a project whose csproj has no <c>ProjectReference</c>.</summary>
    internal const string NoDependencies = "None";

    /// <summary>
    /// Reports every project without a <c>docs/</c> folder, or whose folder holds no <c>.md</c> file.
    /// </summary>
    /// <param name="projects">The projects to check.</param>
    /// <returns>One message per violation; empty when every project complies.</returns>
    internal static IReadOnlyList<string> CheckDocsFolders(IReadOnlyList<ProjectDocs> projects)
    {
        return [.. projects.SelectMany(selector: CheckDocsFolder)];
    }

    /// <summary>
    /// Reports every project without a <c>docs/README.md</c>, and every required heading its README lacks.
    /// </summary>
    /// <param name="projects">The projects to check.</param>
    /// <returns>One message per violation; empty when every project complies.</returns>
    internal static IReadOnlyList<string> CheckSections(IReadOnlyList<ProjectDocs> projects)
    {
        return [.. projects.SelectMany(selector: CheckReadmeSections)];
    }

    /// <summary>
    /// Reports every project whose <c>## Allowed dependencies</c> list differs from its csproj's
    /// <c>ProjectReference</c> names. The list must name each referenced project once, or be the single bullet
    /// <c>None</c> when the csproj references none.
    /// </summary>
    /// <param name="projects">The projects to check.</param>
    /// <returns>One message per violation; empty when every project complies.</returns>
    internal static IReadOnlyList<string> CheckDependencyLists(IReadOnlyList<ProjectDocs> projects)
    {
        return [.. projects.SelectMany(selector: CheckDependencyList)];
    }

    /// <summary>
    /// Reads the top-level bullets of the <c>## Allowed dependencies</c> section. A bullet that starts with a code
    /// span names the project in that span, and any text after it is ignored; any other bullet is read whole.
    /// Nested bullets and lines inside fenced code blocks are skipped.
    /// </summary>
    /// <param name="readme">The README text.</param>
    /// <returns>The bullet names in order, or <see langword="null"/> when the README has no such section.</returns>
    internal static IReadOnlyList<string>? ReadDependencyList(string readme)
    {
        List<string>? lines = ReadSectionLines(readme: readme, heading: AllowedDependenciesHeading);
        if (lines is null)
        {
            return null;
        }

        return
        [
            .. lines
                    .Where(predicate: line => line.StartsWith(
                            value: BulletPrefix,
                            comparisonType: StringComparison.Ordinal))
                    .Select(selector: BulletName),
        ];
    }

    private const string BulletPrefix = "- ";
    private const char CodeSpanMark = '`';

    private static readonly string[] _requiredHeadings =
            [ResponsibilityHeading, AllowedDependenciesHeading, RulesHeading];

    private static IEnumerable<string> CheckDocsFolder(ProjectDocs project)
    {
        if (project.MarkdownFiles is null)
        {
            yield return $"{project.ProjectName}: no {ProjectDocs.DocsFolderName}/ folder beside the csproj (SPEC R18)";
        }
        else if (project.MarkdownFiles.Count == 0)
        {
            yield return $"{project.ProjectName}: {ProjectDocs.DocsFolderName}/ holds no .md file (SPEC R18)";
        }
    }

    private static IEnumerable<string> CheckReadmeSections(ProjectDocs project)
    {
        if (project.Readme is null)
        {
            yield return $"{project.ProjectName}: no {ProjectDocs.DocsFolderName}/{ProjectDocs.ReadmeFileName}";
            yield break;
        }

        foreach (string heading in _requiredHeadings)
        {
            if (ReadSectionLines(readme: project.Readme, heading: heading) is null)
            {
                yield return $"{project.ProjectName}: {ProjectDocs.ReadmeFileName} has no '{heading}' heading";
            }
        }
    }

    private static IEnumerable<string> CheckDependencyList(ProjectDocs project)
    {
        IReadOnlyList<string>? names = project.Readme is null ? null : ReadDependencyList(readme: project.Readme);
        if (names is null)
        {
            yield return $"{project.ProjectName}: no '{AllowedDependenciesHeading}' section in "
                    + $"{ProjectDocs.DocsFolderName}/{ProjectDocs.ReadmeFileName}";
        }
        else if (names.Count == 0)
        {
            yield return $"{project.ProjectName}: the '{AllowedDependenciesHeading}' section has no bullet list; "
                    + $"write '{BulletPrefix}{NoDependencies}' when the csproj references no project";
        }
        else if (names.Count > 1 && names.Contains(value: NoDependencies, comparer: StringComparer.Ordinal))
        {
            yield return $"{project.ProjectName}: '{NoDependencies}' must be the only bullet of the "
                    + $"'{AllowedDependenciesHeading}' section";
        }
        else
        {
            foreach (string violation in CompareNames(project: project, names: names))
            {
                yield return violation;
            }
        }
    }

    private static IEnumerable<string> CompareNames(ProjectDocs project, IReadOnlyList<string> names)
    {
        foreach (string repeated in names
                .GroupBy(keySelector: name => name, comparer: StringComparer.Ordinal)
                .Where(predicate: group => group.Count() > 1)
                .Select(selector: group => group.Key))
        {
            yield return $"{project.ProjectName}: '{AllowedDependenciesHeading}' lists {repeated} more than once";
        }

        HashSet<string> documented = IsNoneList(names: names)
                ? new HashSet<string>(comparer: StringComparer.Ordinal)
                : names.ToHashSet(comparer: StringComparer.Ordinal);
        string missing = JoinSorted(
                names: project.ProjectReferences.Except(second: documented, comparer: StringComparer.Ordinal));
        string extra = JoinSorted(
                names: documented.Except(second: project.ProjectReferences, comparer: StringComparer.Ordinal));
        if (missing.Length > 0 || extra.Length > 0)
        {
            yield return $"{project.ProjectName}: '{AllowedDependenciesHeading}' differs from the csproj's "
                    + $"ProjectReferences: missing [{missing}], not referenced [{extra}]";
        }
    }

    private static bool IsNoneList(IReadOnlyList<string> names)
    {
        return names.Count == 1
                && string.Equals(a: names[0], b: NoDependencies, comparisonType: StringComparison.Ordinal);
    }

    private static string JoinSorted(IEnumerable<string> names)
    {
        return string.Join(separator: ", ", values: names.Order(comparer: StringComparer.Ordinal));
    }

    private static List<string>? ReadSectionLines(string readme, string heading)
    {
        List<string>? section = null;
        foreach (KeyValuePair<int, string> rawLine in MarkdownFences.ContentLines(markdown: readme))
        {
            string line = rawLine.Value.TrimEnd();
            if (IsSectionHeading(line: line))
            {
                if (section is not null)
                {
                    return section;
                }

                section = string.Equals(a: line, b: heading, comparisonType: StringComparison.Ordinal) ? [] : null;
            }
            else
            {
                section?.Add(item: line);
            }
        }

        return section;
    }

    private static bool IsSectionHeading(string line)
    {
        return line.StartsWith(value: "# ", comparisonType: StringComparison.Ordinal)
                || line.StartsWith(value: "## ", comparisonType: StringComparison.Ordinal);
    }

    private static string BulletName(string bullet)
    {
        string text = bullet[BulletPrefix.Length..].Trim();
        if (text.StartsWith(value: CodeSpanMark))
        {
            int end = text.IndexOf(value: CodeSpanMark, startIndex: 1);
            if (end > 1)
            {
                return text[1..end];
            }
        }

        return text;
    }
}
