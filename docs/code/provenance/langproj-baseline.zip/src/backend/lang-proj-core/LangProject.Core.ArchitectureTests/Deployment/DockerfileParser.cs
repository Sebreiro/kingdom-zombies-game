using System;
using System.Collections.Generic;
using System.Text;

namespace LangProject.Core.ArchitectureTests.Deployment;

/// <summary>
/// Splits a Dockerfile into its build stages. A pure function of the text, so proofs can feed synthetic Dockerfiles.
/// Comment lines and blank lines are dropped, and a line that ends with <c>\</c> is joined with the next one.
/// </summary>
internal static class DockerfileParser
{
    /// <summary>Parses the stages of a Dockerfile, in file order.</summary>
    /// <param name="text">The Dockerfile's text.</param>
    /// <returns>One stage per <c>FROM</c> instruction; instructions before the first <c>FROM</c> are dropped.</returns>
    internal static IReadOnlyList<DockerfileStage> Parse(string text)
    {
        var stages = new List<DockerfileStage>();
        string image = string.Empty;
        string name = string.Empty;
        List<string>? instructions = null;
        foreach (string instruction in Instructions(text: text))
        {
            string[] words = instruction.Split(separator: ' ', options: StringSplitOptions.RemoveEmptyEntries);
            if (!IsWord(value: words[0], expected: "FROM"))
            {
                instructions?.Add(item: instruction);
                continue;
            }

            if (instructions is not null)
            {
                stages.Add(item: new DockerfileStage(image: image, name: name, instructions: instructions));
            }

            image = words.Length > 1 ? words[1] : string.Empty;
            name = words.Length > 3 && IsWord(value: words[2], expected: "AS") ? words[3] : string.Empty;
            instructions = [];
        }

        if (instructions is not null)
        {
            stages.Add(item: new DockerfileStage(image: image, name: name, instructions: instructions));
        }

        return stages;
    }

    private static IEnumerable<string> Instructions(string text)
    {
        var current = new StringBuilder();
        foreach (string rawLine in text.Split(separator: '\n'))
        {
            string line = rawLine.Trim();
            if (line.Length == 0 || line.StartsWith(value: '#'))
            {
                continue;
            }

            if (line.EndsWith(value: '\\'))
            {
                current.Append(value: line[..^1].TrimEnd()).Append(value: ' ');
                continue;
            }

            current.Append(value: line);
            yield return current.ToString();
            current.Clear();
        }

        if (current.Length > 0)
        {
            yield return current.ToString().TrimEnd();
        }
    }

    private static bool IsWord(string value, string expected)
    {
        return string.Equals(a: value, b: expected, comparisonType: StringComparison.OrdinalIgnoreCase);
    }
}
