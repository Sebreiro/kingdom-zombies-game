using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace LangProject.Core.ArchitectureTests.Types;

/// <summary>
/// Reflection rules over a set of types. Each returns one message per violation, so the production checks and the
/// bad-on-purpose fixture proofs run through the same code. Every rule reports <see cref="EmptySelector"/> when
/// its input is empty, so no rule can pass vacuously (SPEC R6).
/// </summary>
internal static class TypeConventionRules
{
    internal const string EmptySelector = "The selector matched zero types, so the rule would pass vacuously (SPEC R6)";

    /// <summary>
    /// The namespace of the EF Core migrations that <c>dotnet ef</c> generates in DAL. The generated types are public,
    /// so they are the one listed exclusion from the implementation-visibility rule (SPEC R8, D-41).
    /// </summary>
    internal const string GeneratedMigrationsNamespace = "LangProject.Core.DAL.Migrations";

    /// <summary>Selects the entities among the Domain types: every class that is not static.</summary>
    /// <param name="domainTypes">The types declared in the Domain assembly.</param>
    /// <returns>The entity classes.</returns>
    internal static IReadOnlyList<Type> SelectEntities(IEnumerable<Type> domainTypes)
    {
        return [.. domainTypes.Where(predicate: type => type.IsClass && !IsStatic(type: type))];
    }

    /// <summary>Selects the DTOs: every type whose name ends in <c>Dto</c> (D-37).</summary>
    /// <param name="types">The types to select from.</param>
    /// <returns>The DTO types.</returns>
    internal static IReadOnlyList<Type> SelectDtos(IEnumerable<Type> types)
    {
        return [.. types.Where(predicate: type => SimpleName(type: type).EndsWith(
                value: DtoSuffix,
                comparisonType: StringComparison.Ordinal))];
    }

    /// <summary>
    /// Checks the Domain entity rule (SPEC R6, ARCH-05): every property setter is private and not <c>init</c>, at
    /// least one constructor takes parameters, and a private parameterless ORM constructor carries <c>[Obsolete]</c>.
    /// </summary>
    /// <param name="entities">The entity classes.</param>
    /// <returns>The violations; <see cref="EmptySelector"/> alone when <paramref name="entities"/> is empty.</returns>
    internal static IReadOnlyList<string> CheckEntities(IReadOnlyCollection<Type> entities)
    {
        if (entities.Count == 0)
        {
            return [EmptySelector];
        }

        return [.. entities.SelectMany(selector: CheckEntity)];
    }

    /// <summary>
    /// Checks the DTO rule (SPEC R6, D-37): a DTO is a class, not a <c>record class</c> or <c>record struct</c>;
    /// every setter is private and not <c>init</c>; every public property is matched by a constructor parameter of
    /// the same name, ignoring case, so the constructor initialises it.
    /// </summary>
    /// <param name="dtos">The DTO types.</param>
    /// <returns>The violations; <see cref="EmptySelector"/> alone when <paramref name="dtos"/> is empty.</returns>
    internal static IReadOnlyList<string> CheckDtos(IReadOnlyCollection<Type> dtos)
    {
        if (dtos.Count == 0)
        {
            return [EmptySelector];
        }

        return [.. dtos.SelectMany(selector: CheckDto)];
    }

    /// <summary>
    /// Checks that no type name ends in plain <c>Request</c> or <c>Response</c>; HTTP DTOs end in <c>RequestDto</c>
    /// or <c>ResponseDto</c> (D-37).
    /// </summary>
    /// <param name="types">The product types.</param>
    /// <returns>The violations; <see cref="EmptySelector"/> alone when <paramref name="types"/> is empty.</returns>
    internal static IReadOnlyList<string> CheckNaming(IReadOnlyCollection<Type> types)
    {
        if (types.Count == 0)
        {
            return [EmptySelector];
        }

        return
        [
            .. types
                    .Where(predicate: type => SimpleName(type: type).EndsWith(
                            value: "Request",
                            comparisonType: StringComparison.Ordinal)
                            || SimpleName(type: type).EndsWith(
                                    value: "Response",
                                    comparisonType: StringComparison.Ordinal))
                    .Select(selector: type => $"{Describe(type: type)} ends in plain Request or Response; HTTP DTO "
                            + "names end in RequestDto or ResponseDto (D-37)"),
        ];
    }

    /// <summary>
    /// Checks that every DTO of the HTTP contract ends in <c>RequestDto</c> or <c>ResponseDto</c> (D-37), so a type
    /// that is part of a request or response body, such as one entry of a response, is named for its side.
    /// </summary>
    /// <param name="httpContractTypes">The types declared in the HTTP contract project, API.Abstractions.</param>
    /// <returns>
    /// The violations; <see cref="EmptySelector"/> alone when <paramref name="httpContractTypes"/> holds no DTO.
    /// </returns>
    internal static IReadOnlyList<string> CheckHttpDtoNames(IReadOnlyCollection<Type> httpContractTypes)
    {
        IReadOnlyList<Type> dtos = SelectDtos(types: httpContractTypes);
        if (dtos.Count == 0)
        {
            return [EmptySelector];
        }

        return
        [
            .. dtos
                    .Where(predicate: dto => !SimpleName(type: dto).EndsWith(
                            value: "RequestDto",
                            comparisonType: StringComparison.Ordinal)
                            && !SimpleName(type: dto).EndsWith(
                                    value: "ResponseDto",
                                    comparisonType: StringComparison.Ordinal))
                    .Select(selector: dto => $"{Describe(type: dto)} is an HTTP DTO that ends in plain Dto; HTTP "
                            + "DTO names end in RequestDto or ResponseDto (D-37)"),
        ];
    }

    /// <summary>
    /// Checks the content of the <c>.Abstractions</c> projects (SPEC R6, D-40, D-41, D-44): only interfaces, enums,
    /// classes whose name ends in <c>Dto</c>, and static classes that hold nothing but constants.
    /// </summary>
    /// <param name="types">The types declared in <c>.Abstractions</c> assemblies.</param>
    /// <returns>The violations; <see cref="EmptySelector"/> alone when <paramref name="types"/> is empty.</returns>
    internal static IReadOnlyList<string> CheckAbstractionsContent(IReadOnlyCollection<Type> types)
    {
        if (types.Count == 0)
        {
            return [EmptySelector];
        }

        return
        [
            .. types
                    .Where(predicate: type => !IsAllowedInAbstractions(type: type))
                    .Select(selector: type => $"{Describe(type: type)} in {AssemblyName(type: type)} is not an "
                            + "interface, an enum, a DTO class or a constants-only static class; an .Abstractions "
                            + "project holds only those (D-40, D-41)"),
        ];
    }

    /// <summary>
    /// Checks that each implementation project's only public type is its registration class: a static class whose
    /// name ends in <c>Registration</c> with a public static <c>Add*</c> method (D-41). Types are grouped by
    /// assembly. Types in <see cref="GeneratedMigrationsNamespace"/> are excluded.
    /// </summary>
    /// <param name="types">The types declared in implementation assemblies.</param>
    /// <returns>The violations; <see cref="EmptySelector"/> alone when <paramref name="types"/> is empty.</returns>
    internal static IReadOnlyList<string> CheckImplementationVisibility(IReadOnlyCollection<Type> types)
    {
        if (types.Count == 0)
        {
            return [EmptySelector];
        }

        return
        [
            .. types
                    .GroupBy(keySelector: AssemblyName, comparer: StringComparer.Ordinal)
                    .OrderBy(keySelector: group => group.Key, comparer: StringComparer.Ordinal)
                    .SelectMany(selector: group => CheckProjectVisibility(project: group.Key, types: group)),
        ];
    }

    /// <summary>Selects the enums among a set of types.</summary>
    /// <param name="types">The types to select from.</param>
    /// <returns>The enum types.</returns>
    internal static IReadOnlyList<Type> SelectEnums(IEnumerable<Type> types)
    {
        return [.. types.Where(predicate: type => type.IsEnum)];
    }

    /// <summary>
    /// Checks the enum rule (D-52): every enum declares a member named <c>Unknown</c> with the value 0, every member
    /// carries <see cref="JsonStringEnumMemberNameAttribute"/>, and no two members share a pinned name.
    /// </summary>
    /// <param name="enums">The enum types.</param>
    /// <returns>The violations; <see cref="EmptySelector"/> alone when <paramref name="enums"/> is empty.</returns>
    internal static IReadOnlyList<string> CheckEnums(IReadOnlyCollection<Type> enums)
    {
        if (enums.Count == 0)
        {
            return [EmptySelector];
        }

        return [.. enums.SelectMany(selector: CheckEnum)];
    }

    /// <summary>
    /// Checks the time rule (D-55): no property holds a <see cref="DateTime"/> or a <see cref="TimeSpan"/>, nullable
    /// or not, and no property name ends in a bare <c>Duration</c> without a unit suffix such as <c>DurationMs</c>.
    /// </summary>
    /// <param name="types">The DTO and entity types.</param>
    /// <returns>The violations; <see cref="EmptySelector"/> alone when <paramref name="types"/> is empty.</returns>
    internal static IReadOnlyList<string> CheckTimeTypes(IReadOnlyCollection<Type> types)
    {
        if (types.Count == 0)
        {
            return [EmptySelector];
        }

        return [.. types.SelectMany(selector: CheckTimes)];
    }

    /// <summary>
    /// Selects the options classes: every class that is not static and whose name ends in <c>Options</c> (D-38).
    /// A static helper such as <c>LangDbContextOptions</c> is never bound, so it is not an options class.
    /// </summary>
    /// <param name="types">The types to select from.</param>
    /// <returns>The options classes.</returns>
    internal static IReadOnlyList<Type> SelectOptions(IEnumerable<Type> types)
    {
        return
        [
            .. types.Where(predicate: type => type.IsClass
                    && !IsStatic(type: type)
                    && SimpleName(type: type).EndsWith(value: OptionsSuffix, comparisonType: StringComparison.Ordinal)),
        ];
    }

    /// <summary>
    /// Checks the options rule (D-38): every property setter of an options class is private and not <c>init</c>, so
    /// only a binder with <c>BindNonPublicProperties = true</c> fills it.
    /// </summary>
    /// <param name="options">The options classes.</param>
    /// <returns>The violations; <see cref="EmptySelector"/> alone when <paramref name="options"/> is empty.</returns>
    internal static IReadOnlyList<string> CheckOptions(IReadOnlyCollection<Type> options)
    {
        if (options.Count == 0)
        {
            return [EmptySelector];
        }

        return [.. options.SelectMany(selector: type => CheckSetters(type: type, reference: "D-38"))];
    }

    private const string DtoSuffix = "Dto";
    private const string OptionsSuffix = "Options";
    private const string RegistrationSuffix = "Registration";
    private const string AddPrefix = "Add";
    private const string UnknownMemberName = "Unknown";
    private const string SpecR6 = "SPEC R6";

    private const BindingFlags AllInstance = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

    private const BindingFlags AllDeclared = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public
            | BindingFlags.NonPublic | BindingFlags.DeclaredOnly;

    private static IEnumerable<string> CheckEntity(Type entity)
    {
        List<string> violations = [.. CheckSetters(type: entity, reference: SpecR6)];
        ConstructorInfo[] constructors = entity.GetConstructors(bindingAttr: AllInstance);
        if (!constructors.Any(predicate: constructor => constructor.GetParameters().Length > 0))
        {
            violations.Add(item: $"{Describe(type: entity)} has no constructor with parameters; an entity is "
                    + "created through a parameterized constructor (ARCH-05)");
        }

        ConstructorInfo? ormConstructor = constructors.FirstOrDefault(
                predicate: constructor => constructor.GetParameters().Length == 0);
        if (ormConstructor is null)
        {
            violations.Add(item: $"{Describe(type: entity)} has no parameterless ORM constructor; add a private "
                    + "[Obsolete] one (ARCH-05)");
            return violations;
        }

        if (!ormConstructor.IsPrivate)
        {
            violations.Add(item: $"{Describe(type: entity)}'s parameterless ORM constructor is not private (ARCH-05)");
        }

        if (!ormConstructor.IsDefined(attributeType: typeof(ObsoleteAttribute), inherit: false))
        {
            violations.Add(item: $"{Describe(type: entity)}'s parameterless ORM constructor is not marked "
                    + "[Obsolete] (ARCH-05)");
        }

        return violations;
    }

    private static List<string> CheckEnum(Type enumType)
    {
        var violations = new List<string>();
        FieldInfo[] members = enumType.GetFields(bindingAttr: BindingFlags.Public | BindingFlags.Static);
        FieldInfo? unknown = members.FirstOrDefault(predicate: member => string.Equals(
                a: member.Name,
                b: UnknownMemberName,
                comparisonType: StringComparison.Ordinal));
        if (unknown is null)
        {
            violations.Add(item: $"{Describe(type: enumType)} has no Unknown member; every enum declares "
                    + "Unknown = 0 (D-52)");
        }
        else
        {
            decimal value = Convert.ToDecimal(
                    value: unknown.GetRawConstantValue(),
                    provider: CultureInfo.InvariantCulture);
            if (value != 0)
            {
                violations.Add(item: $"{Describe(type: enumType)}: Unknown has the value {value}, not 0 (D-52)");
            }
        }

        violations.AddRange(collection: members
                .Where(predicate: member => PinnedName(member: member) is null)
                .Select(selector: member => $"{Describe(type: enumType)}.{member.Name} has no "
                        + "[JsonStringEnumMemberName]; every enum member is pinned (D-52)"));
        violations.AddRange(collection: members
                .Where(predicate: member => PinnedName(member: member) is not null)
                .GroupBy(keySelector: member => PinnedName(member: member), comparer: StringComparer.Ordinal)
                .Where(predicate: group => group.Count() > 1)
                .Select(selector: group => $"{Describe(type: enumType)} pins "
                        + $"{string.Join(separator: ", ", values: group.Select(selector: member => member.Name))} "
                        + $"as '{group.Key}'; every pinned name is unique (D-52)"));
        return violations;
    }

    private static string? PinnedName(FieldInfo member)
    {
        return member.GetCustomAttribute<JsonStringEnumMemberNameAttribute>()?.Name;
    }

    private static IEnumerable<string> CheckTimes(Type type)
    {
        IEnumerable<(string Name, Type ValueType, bool IsProperty)> members = type
                .GetProperties(bindingAttr: AllInstance | BindingFlags.Static)
                .Select(selector: property => (property.Name, property.PropertyType, IsProperty: true))
                .Concat(second: type.GetFields(bindingAttr: AllInstance)
                        .Where(predicate: field => !field.IsDefined(
                                attributeType: typeof(CompilerGeneratedAttribute),
                                inherit: false))
                        .Select(selector: field => (field.Name, field.FieldType, IsProperty: false)));
        foreach ((string name, Type valueType, bool isProperty) in members)
        {
            Type? banned = FindBannedTime(type: valueType);
            if (banned == typeof(DateTime))
            {
                yield return $"{Describe(type: type)}.{name} holds a DateTime ({Describe(type: valueType)}); times "
                        + "are DateTimeOffset values in UTC (D-55)";
            }
            else if (banned == typeof(TimeSpan))
            {
                yield return $"{Describe(type: type)}.{name} holds a TimeSpan ({Describe(type: valueType)}), which "
                        + "goes on the wire as a string; a duration is a number named with its unit, such as "
                        + "DurationMs (D-55)";
            }
            else if (isProperty && name.EndsWith(value: "Duration", comparisonType: StringComparison.Ordinal))
            {
                yield return $"{Describe(type: type)}.{name} has no unit suffix; a duration is named "
                        + "with its unit, such as DurationMs (D-55)";
            }
        }
    }

    private static Type? FindBannedTime(Type type)
    {
        Type valueType = Nullable.GetUnderlyingType(nullableType: type) ?? type;
        if (valueType == typeof(DateTime) || valueType == typeof(TimeSpan))
        {
            return valueType;
        }

        if (valueType.HasElementType && valueType.GetElementType() is { } element)
        {
            return FindBannedTime(type: element);
        }

        return valueType.IsGenericType
                ? valueType.GetGenericArguments()
                        .Select(selector: FindBannedTime)
                        .FirstOrDefault(predicate: banned => banned is not null)
                : null;
    }

    private static IEnumerable<string> CheckDto(Type dto)
    {
        List<string> violations = [];
        if (dto.IsValueType)
        {
            violations.Add(item: $"{Describe(type: dto)} is a struct or record struct; a DTO is a class (D-37)");
        }
        else if (!dto.IsClass)
        {
            violations.Add(item: $"{Describe(type: dto)} is not a class; a DTO is a class (D-37)");
        }
        else if (IsRecordClass(type: dto))
        {
            violations.Add(item: $"{Describe(type: dto)} is a record class; a DTO is a plain class (D-37)");
        }

        violations.AddRange(collection: CheckSetters(type: dto, reference: SpecR6));
        violations.AddRange(collection: CheckConstructorInitialisation(dto: dto));
        return violations;
    }

    private static IEnumerable<string> CheckSetters(Type type, string reference)
    {
        return type.GetProperties(bindingAttr: AllInstance | BindingFlags.Static)
                .Where(predicate: property => property.SetMethod is not null)
                .Select(selector: property => (Property: property, Kind: SetterKind(setter: property.SetMethod)))
                .Where(predicate: pair => pair.Kind is not null)
                .Select(selector: pair => $"{Describe(type: type)}.{pair.Property.Name} has a non-private setter "
                        + $"({pair.Kind} setter); setters must be private and not init ({reference})");
    }

    private static string? SetterKind(MethodInfo? setter)
    {
        if (setter is null)
        {
            return null;
        }

        if (setter.ReturnParameter.GetRequiredCustomModifiers().Contains(value: typeof(IsExternalInit)))
        {
            return "init";
        }

        return setter switch
        {
            { IsPrivate: true } => null,
            { IsPublic: true } => "public",
            { IsAssembly: true } => "internal",
            { IsFamily: true } => "protected",
            { IsFamilyOrAssembly: true } => "protected internal",
            _ => "private protected",
        };
    }

    private static IEnumerable<string> CheckConstructorInitialisation(Type dto)
    {
        var parameterNames = dto.GetConstructors(bindingAttr: AllInstance)
                .SelectMany(selector: constructor => constructor.GetParameters())
                .Select(selector: parameter => parameter.Name ?? string.Empty)
                .ToHashSet(comparer: StringComparer.OrdinalIgnoreCase);
        return dto.GetProperties(bindingAttr: BindingFlags.Instance | BindingFlags.Public)
                .Where(predicate: property => !parameterNames.Contains(item: property.Name))
                .Select(selector: property => $"{Describe(type: dto)}.{property.Name} has no constructor parameter "
                        + $"named {property.Name}, so the constructor does not initialise it (D-37)");
    }

    private static bool IsRecordClass(Type type)
    {
        return type.GetMethod(name: "<Clone>$", bindingAttr: AllInstance) is not null
                || type.GetProperty(name: "EqualityContract", bindingAttr: AllInstance) is not null;
    }

    private static bool IsAllowedInAbstractions(Type type)
    {
        if (type.IsInterface || type.IsEnum)
        {
            return true;
        }

        if (!type.IsClass)
        {
            return false;
        }

        return IsStatic(type: type) ? HoldsOnlyConstants(type: type) : SelectDtos(types: [type]).Count == 1;
    }

    private static bool HoldsOnlyConstants(Type type)
    {
        return type.GetMembers(bindingAttr: AllDeclared)
                .Where(predicate: member => member.MemberType != MemberTypes.NestedType)
                .All(predicate: member => member is FieldInfo { IsLiteral: true });
    }

    private static List<string> CheckProjectVisibility(string project, IEnumerable<Type> types)
    {
        List<Type> exposed =
        [
            .. types
                    .Where(predicate: type => type.IsPublic || type.IsNestedPublic)
                    .Where(predicate: type => !IsGeneratedMigration(type: type)),
        ];
        List<string> violations =
        [
            .. exposed
                    .Where(predicate: type => !IsRegistration(type: type))
                    .Select(selector: type => $"{project} exposes public type {Describe(type: type)}; only its "
                            + "AddXxx registration class may be public (D-41)"),
        ];
        int registrations = exposed.Count(predicate: IsRegistration);
        if (registrations != 1)
        {
            violations.Add(item: $"{project} exposes {registrations} public registration classes; it must expose "
                    + "exactly one static class whose name ends in Registration with a public static Add* method "
                    + "(D-41)");
        }

        return violations;
    }

    private static bool IsRegistration(Type type)
    {
        return IsStatic(type: type)
                && SimpleName(type: type).EndsWith(value: RegistrationSuffix, comparisonType: StringComparison.Ordinal)
                && type.GetMethods(bindingAttr: BindingFlags.Public | BindingFlags.Static | BindingFlags.DeclaredOnly)
                        .Any(predicate: method => method.Name.StartsWith(
                                value: AddPrefix,
                                comparisonType: StringComparison.Ordinal));
    }

    private static bool IsGeneratedMigration(Type type)
    {
        string space = type.Namespace ?? string.Empty;
        return string.Equals(a: space, b: GeneratedMigrationsNamespace, comparisonType: StringComparison.Ordinal)
                || space.StartsWith(
                        value: GeneratedMigrationsNamespace + ".",
                        comparisonType: StringComparison.Ordinal);
    }

    private static bool IsStatic(Type type)
    {
        return type is { IsClass: true, IsAbstract: true, IsSealed: true };
    }

    private static string SimpleName(Type type)
    {
        int arity = type.Name.IndexOf(value: '`', comparisonType: StringComparison.Ordinal);
        return arity < 0 ? type.Name : type.Name[..arity];
    }

    private static string AssemblyName(Type type)
    {
        return type.Assembly.GetName().Name ?? string.Empty;
    }

    private static string Describe(Type type)
    {
        return type.FullName ?? type.Name;
    }
}
