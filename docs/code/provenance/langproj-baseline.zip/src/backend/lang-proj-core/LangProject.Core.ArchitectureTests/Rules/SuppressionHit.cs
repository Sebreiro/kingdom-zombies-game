namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// One suppression in a tracked file, found by <see cref="SuppressionScanner"/>: where it is, the line it sits on,
/// and its subject, the normalized text of exactly what it suppresses, which an exemption row must equal.
/// </summary>
internal sealed class SuppressionHit
{
    /// <inheritdoc />
    public override string ToString()
    {
        return $"{Path}:{LineNumber}: {Pattern}: {Subject}";
    }

    /// <summary>Initializes a new instance of the <see cref="SuppressionHit"/> class.</summary>
    /// <param name="path">The repository-relative path, with forward slashes.</param>
    /// <param name="lineNumber">The 1-based line number; 0 for a hit on the file name.</param>
    /// <param name="text">The trimmed line, or the file name for a hit on the file name.</param>
    /// <param name="subject">
    /// The normalized text of what the hit suppresses: a directive without its trailing comment, one attribute,
    /// one MSBuild element, one <c>.editorconfig</c> setting prefixed with its section, or one workflow line.
    /// </param>
    /// <param name="pattern">The name of the pattern that matched.</param>
    internal SuppressionHit(string path, int lineNumber, string text, string subject, string pattern)
    {
        Path = path;
        LineNumber = lineNumber;
        Text = text;
        Subject = subject;
        Pattern = pattern;
    }

    /// <summary>Gets the repository-relative path, with forward slashes.</summary>
    internal string Path { get; }

    /// <summary>Gets the 1-based line number; 0 for a hit on the file name.</summary>
    internal int LineNumber { get; }

    /// <summary>Gets the trimmed line the hit starts on.</summary>
    internal string Text { get; }

    /// <summary>Gets the normalized text of what the hit suppresses, which a row's text must equal.</summary>
    internal string Subject { get; }

    /// <summary>Gets the name of the pattern that matched.</summary>
    internal string Pattern { get; }
}
