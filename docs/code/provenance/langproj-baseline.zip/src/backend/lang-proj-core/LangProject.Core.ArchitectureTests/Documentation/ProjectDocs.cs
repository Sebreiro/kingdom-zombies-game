using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using LangProject.Core.ArchitectureTests.Infrastructure;

namespace LangProject.Core.ArchitectureTests.Documentation;

/// <summary>
/// One project's docs as the docs checks see them: the project name, the projects its csproj references, the
/// Markdown files in its <c>docs/</c> folder and the text of <c>docs/README.md</c>. It is built from disk or from
/// plain values, so the proofs need no files.
/// </summary>
internal sealed class ProjectDocs
{
    /// <summary>The name of the docs folder beside every csproj.</summary>
    internal const string DocsFolderName = "docs";

    /// <summary>The name of the file in the docs folder that holds the three required sections.</summary>
    internal const string ReadmeFileName = "README.md";

    /// <summary>Initializes a new instance of the <see cref="ProjectDocs"/> class.</summary>
    /// <param name="projectName">The project name, which is the csproj file name without its extension.</param>
    /// <param name="projectReferences">The project names of the csproj's <c>ProjectReference</c> items.</param>
    /// <param name="markdownFiles">
    /// The names of the <c>.md</c> files in the project's <c>docs/</c> folder, or <see langword="null"/> when the
    /// project has no <c>docs/</c> folder.
    /// </param>
    /// <param name="readme">
    /// The text of <c>docs/README.md</c>, or <see langword="null"/> when it does not exist.
    /// </param>
    internal ProjectDocs(
            string projectName,
            IReadOnlySet<string> projectReferences,
            IReadOnlyList<string>? markdownFiles,
            string? readme)
    {
        ProjectName = projectName;
        ProjectReferences = projectReferences;
        MarkdownFiles = markdownFiles;
        Readme = readme;
    }

    /// <summary>Gets the project name.</summary>
    internal string ProjectName { get; }

    /// <summary>Gets the project names of the csproj's <c>ProjectReference</c> items.</summary>
    internal IReadOnlySet<string> ProjectReferences { get; }

    /// <summary>
    /// Gets the names of the <c>.md</c> files in the <c>docs/</c> folder, or <see langword="null"/> when there is no
    /// <c>docs/</c> folder.
    /// </summary>
    internal IReadOnlyList<string>? MarkdownFiles { get; }

    /// <summary>Gets the text of <c>docs/README.md</c>, or <see langword="null"/> when it does not exist.</summary>
    internal string? Readme { get; }

    /// <summary>
    /// Loads a solution project's docs from disk. The folder and file names are matched with their exact case, so
    /// a <c>Docs</c> folder or a <c>readme.md</c> file does not count on a case-insensitive file system either.
    /// </summary>
    /// <param name="project">A project of the solution.</param>
    /// <returns>The project's docs.</returns>
    internal static ProjectDocs Load(ProjectFile project)
    {
        string projectPath = Path.Combine(path1: RepositoryLayout.SolutionRoot, path2: project.RelativePath);
        string projectDirectory = Path.GetDirectoryName(path: projectPath)
                ?? throw new InvalidOperationException(message: $"{project.RelativePath} has no folder.");
        string? docsDirectory = FindExactName(
                paths: Directory.EnumerateDirectories(path: projectDirectory),
                name: DocsFolderName);
        if (docsDirectory is null)
        {
            return new ProjectDocs(
                    projectName: project.Name,
                    projectReferences: project.ProjectReferences,
                    markdownFiles: null,
                    readme: null);
        }

        List<string> markdownFiles =
        [
            .. Directory.EnumerateFiles(path: docsDirectory)
                    .Select(selector: path => Path.GetFileName(path: path))
                    .Where(predicate: name => name.EndsWith(value: ".md", comparisonType: StringComparison.Ordinal))
                    .Order(comparer: StringComparer.Ordinal),
        ];
        string? readme = markdownFiles.Contains(value: ReadmeFileName, comparer: StringComparer.Ordinal)
                ? File.ReadAllText(path: Path.Combine(path1: docsDirectory, path2: ReadmeFileName))
                : null;
        return new ProjectDocs(
                projectName: project.Name,
                projectReferences: project.ProjectReferences,
                markdownFiles: markdownFiles,
                readme: readme);
    }

    private static string? FindExactName(IEnumerable<string> paths, string name)
    {
        return paths.FirstOrDefault(predicate: path => string.Equals(
                a: Path.GetFileName(path: path),
                b: name,
                comparisonType: StringComparison.Ordinal));
    }
}
