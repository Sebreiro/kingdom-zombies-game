using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Files;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Prototype;

/// <summary>
/// The HTML prototype under <c>src/frontend/prototype/</c> is checked here, in the backend CI that runs on every PR,
/// because prototype edits do not start the frontend CI (D-14). Each rule of <see cref="PrototypeRules"/> runs once
/// over the tracked prototype files and once on synthetic bad input.
/// </summary>
public sealed class PrototypeTests
{
    /// <summary>
    /// No tracked prototype text file loads a remote resource through <c>src</c>, <c>href</c>, <c>@import</c> or
    /// <c>url()</c>, so every page opens fully styled with networking disabled (SPEC R1).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task PrototypeFiles_TrackedFiles_LoadNoRemoteResource()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        IReadOnlyDictionary<string, string> files = await ReadTextFilesAsync(cancellationToken: cancellationToken);

        List<string> violations =
        [
            .. files.SelectMany(selector: file => PrototypeRules.FindRemoteReferences(text: file.Value)
                    .Select(selector: reference => $"{file.Key}: loads {reference}")),
        ];

        files.ShouldNotBeEmpty();
        files.ShouldContainKey(key: PrototypeRules.PrototypeFolder + "assets/prototype.css");
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>Every tracked prototype HTML page declares <c>&lt;meta charset="utf-8"&gt;</c> (SPEC R1).</summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task PrototypePages_EveryHtmlFile_DeclaresUtf8()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        IReadOnlyDictionary<string, string> files = await ReadTextFilesAsync(cancellationToken: cancellationToken);
        List<KeyValuePair<string, string>> pages = [.. files.Where(predicate: file => IsHtml(path: file.Key))];

        List<string> violations =
        [
            .. pages.Where(predicate: page => !PrototypeRules.HasUtf8Charset(html: page.Value))
                    .Select(selector: page => $"{page.Key}: has no <meta charset=\"utf-8\">"),
        ];

        pages.ShouldNotBeEmpty();
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// Every stress mark in the tracked prototype text is U+0301 directly after a Cyrillic vowel, and <c>ё</c> is
    /// U+0451 (SPEC R3).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task PrototypeText_StressMarks_FollowACyrillicVowel()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        IReadOnlyDictionary<string, string> files = await ReadTextFilesAsync(cancellationToken: cancellationToken);

        List<string> violations =
        [
            .. files.SelectMany(selector: file => PrototypeRules.FindStressMarkProblems(text: file.Value)
                    .Select(selector: problem => $"{file.Key}: {problem}")),
        ];

        files.ShouldNotBeEmpty();
        files.Values.ShouldContain(elementPredicate: text => text.Contains(
                value: StressMark,
                comparisonType: StringComparison.Ordinal));
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// The prototype index links every state of the state table as <c>page.html#state</c>, and each link opens an
    /// existing page with a section of that id (SPEC R2).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task PrototypeIndex_ChecklistStates_AreLinkedAndPresent()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        IReadOnlyDictionary<string, string> files = await ReadTextFilesAsync(cancellationToken: cancellationToken);
        var pages = files.Where(predicate: file => IsHtml(path: file.Key)).ToDictionary(
                keySelector: file => file.Key[PrototypeRules.PrototypeFolder.Length..],
                elementSelector: file => file.Value,
                comparer: StringComparer.Ordinal);

        pages.ShouldContainKey(key: PrototypeRules.IndexPage);
        PrototypeRules.ExpectedStates.ShouldNotBeEmpty();
        IReadOnlyList<string> problems = PrototypeRules.FindStateProblems(
                indexHtml: pages[PrototypeRules.IndexPage],
                pages: pages,
                expectedStates: PrototypeRules.ExpectedStates);

        problems.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: problems));
    }

    /// <summary>
    /// A remote URL in a <c>src</c>, <c>href</c>, <c>@import</c> or <c>url()</c> is reported: <c>http://</c>,
    /// <c>https://</c> and protocol-relative <c>//</c>, with double, single or no quotes, in any letter case.
    /// </summary>
    /// <param name="text">A synthetic line of HTML or CSS.</param>
    [Theory]
    [InlineData("<script src=\"https://cdn.example.com/app.js\"></script>")]
    [InlineData("<link rel=\"stylesheet\" href='http://example.com/site.css'>")]
    [InlineData("<img src=https://example.com/logo.png alt=\"\">")]
    [InlineData("<LINK REL=\"stylesheet\" HREF=\"HTTPS://EXAMPLE.COM/SITE.CSS\">")]
    [InlineData("<script src=\"//cdn.example.com/app.js\"></script>")]
    [InlineData("@import \"https://example.com/theme.css\";")]
    [InlineData("@import url(https://example.com/theme.css);")]
    [InlineData("body { background: url('http://example.com/paper.png'); }")]
    [InlineData("src: url(\"//fonts.example.com/noto.woff2\") format(\"woff2\");")]
    [InlineData("<a href = \"https://example.com/\">Example</a>")]
    public void RemoteResourceRule_RemoteReference_IsReported(string text)
    {
        PrototypeRules.FindRemoteReferences(text: text).ShouldHaveSingleItem();
    }

    /// <summary>
    /// Relative paths, same-page fragments and a URL that is only text, outside any reference, are accepted.
    /// </summary>
    /// <param name="text">A synthetic line of HTML, CSS or prose.</param>
    [Theory]
    [InlineData("<link rel=\"stylesheet\" href=\"assets/prototype.css\">")]
    [InlineData("src: url(\"fonts/noto-sans-regular.woff2\") format(\"woff2\");")]
    [InlineData("<a href=\"word-result.html#status-result\">castle</a>")]
    [InlineData("<svg class=\"icon\"><use href=\"#i-copy\"/></svg>")]
    [InlineData("@import \"base.css\";")]
    [InlineData("The fonts come from `https://notofonts.github.io/` and are bundled.")]
    public void RemoteResourceRule_LocalReference_IsAccepted(string text)
    {
        PrototypeRules.FindRemoteReferences(text: text).ShouldBeEmpty();
    }

    /// <summary>A page with no meta charset, another charset, or the word only outside a charset is reported.</summary>
    /// <param name="html">A synthetic page head.</param>
    [Theory]
    [InlineData("<!DOCTYPE html><html><head><title>Lookup</title></head></html>")]
    [InlineData("<head><meta charset=\"iso-8859-1\"><title>Lookup</title></head>")]
    [InlineData("<head><meta name=\"charset\" content=\"utf-8\"></head>")]
    [InlineData("<head><title>charset=\"utf-8\"</title></head>")]
    public void CharsetRule_MissingMeta_IsReported(string html)
    {
        PrototypeRules.HasUtf8Charset(html: html).ShouldBeFalse();
    }

    /// <summary>A meta charset of UTF-8 is accepted, with or without quotes and in any letter case.</summary>
    /// <param name="html">A synthetic page head.</param>
    [Theory]
    [InlineData("<head>\n    <meta charset=\"utf-8\">\n</head>")]
    [InlineData("<HEAD><META CHARSET=UTF-8></HEAD>")]
    [InlineData("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">")]
    public void CharsetRule_MetaUtf8_IsAccepted(string html)
    {
        PrototypeRules.HasUtf8Charset(html: html).ShouldBeTrue();
    }

    /// <summary>
    /// U+0301 after a consonant, a Latin letter or a space, U+0308 after <c>е</c>, and an ASCII or typographic
    /// apostrophe between a Cyrillic vowel and a Cyrillic letter are each reported.
    /// </summary>
    /// <param name="text">A synthetic word.</param>
    [Theory]
    [InlineData("зам́ок")]
    [InlineData("castlé")]
    [InlineData("за ́мок")]
    [InlineData("́замок")]
    [InlineData("ёж")]
    [InlineData("Ёж")]
    [InlineData("за'мок")]
    [InlineData("замо’к")]
    public void StressMarkRule_BadEncoding_IsReported(string text)
    {
        PrototypeRules.FindStressMarkProblems(text: text).ShouldHaveSingleItem();
    }

    /// <summary>
    /// U+0301 after a Cyrillic vowel in either case, <c>ё</c> as U+0451, precomposed Spanish letters and apostrophes
    /// in English or Spanish text are accepted.
    /// </summary>
    /// <param name="text">A synthetic word or phrase.</param>
    [Theory]
    [InlineData("за́мок")]
    [InlineData("замо́к")]
    [InlineData("ЗА́МОК")]
    [InlineData("ёж")]
    [InlineData("niño")]
    [InlineData("sí")]
    [InlineData("a knight's castle, I’m on my way")]
    public void StressMarkRule_CombiningAfterVowel_IsAccepted(string text)
    {
        PrototypeRules.FindStressMarkProblems(text: text).ShouldBeEmpty();
    }

    /// <summary>
    /// A state of the table with no index link, an index link to a page without that section id, and an index link
    /// to a page that does not exist are each reported with the page and the state.
    /// </summary>
    /// <param name="indexHtml">A synthetic index page.</param>
    /// <param name="pageHtml">A synthetic <c>lookup.html</c>.</param>
    /// <param name="expected">Text the single reported problem holds.</param>
    [Theory]
    [InlineData("<a href=\"variants/index.html\">Design origin</a>", "<section id=\"initial\" data-state></section>",
            "no link to lookup.html#initial")]
    [InlineData("<a href=\"lookup.html#initial\">Initial</a>", "<section id=\"other\" data-state></section>",
            "lookup.html has no section with id \"initial\"")]
    [InlineData("<a href=\"lookup.html#initial\">Initial</a> <a href='history.html#filled'>History</a>",
            "<section id=\"initial\" data-state></section>", "history.html does not exist")]
    public void StateRule_MissingLinkOrSection_IsReported(string indexHtml, string pageHtml, string expected)
    {
        var pages = new Dictionary<string, string>(comparer: StringComparer.Ordinal) { ["lookup.html"] = pageHtml };
        var expectedStates = new Dictionary<string, IReadOnlyList<string>>(comparer: StringComparer.Ordinal)
        {
            ["lookup.html"] = ["initial"],
        };

        IReadOnlyList<string> problems = PrototypeRules.FindStateProblems(
                indexHtml: indexHtml,
                pages: pages,
                expectedStates: expectedStates);

        problems.ShouldHaveSingleItem().ShouldContain(expected: expected);
    }

    /// <summary>An index that links every state to a page holding a section of that id has no problem.</summary>
    [Fact]
    public void StateRule_CompleteIndex_IsAccepted()
    {
        var pages = new Dictionary<string, string>(comparer: StringComparer.Ordinal)
        {
            ["lookup.html"] = "<section id=\"initial\" data-state></section>\n<section id='signed-out' data-state>",
        };
        var expectedStates = new Dictionary<string, IReadOnlyList<string>>(comparer: StringComparer.Ordinal)
        {
            ["lookup.html"] = ["initial", "signed-out"],
        };
        const string Index = "<a href=\"lookup.html#initial\">Initial</a> <a href=\"lookup.html#signed-out\">Out</a>"
                + " <a href=\"variants/index.html\">Design origin</a>";

        PrototypeRules.FindStateProblems(indexHtml: Index, pages: pages, expectedStates: expectedStates)
                .ShouldBeEmpty();
    }

    private const string StressMark = "́";

    private static bool IsHtml(string path)
    {
        return path.EndsWith(value: ".html", comparisonType: StringComparison.OrdinalIgnoreCase);
    }

    private static async Task<IReadOnlyDictionary<string, string>> ReadTextFilesAsync(
            CancellationToken cancellationToken)
    {
        IReadOnlyList<string> trackedFiles = await TrackedFiles.ListAsync(cancellationToken: cancellationToken);
        var files = new Dictionary<string, string>(comparer: StringComparer.Ordinal);
        foreach (string path in trackedFiles.Where(predicate: path => path.StartsWith(
                value: PrototypeRules.PrototypeFolder,
                comparisonType: StringComparison.Ordinal)))
        {
            byte[] content = await File.ReadAllBytesAsync(
                    path: Path.Combine(path1: RepositoryLayout.RepositoryRoot, path2: path),
                    cancellationToken: cancellationToken);
            if (SourceFileFormat.IsChecked(relativePath: path) && SourceFileFormat.IsText(content: content))
            {
                files[path] = Encoding.UTF8.GetString(bytes: content);
            }
        }

        return files;
    }
}
