using System;
using System.Collections.Generic;

namespace LangProject.Core.ArchitectureTests.RealBuild;

/// <summary>
/// The bad-on-purpose fixture files of <see cref="RuleProofTests"/>, written into a throwaway solution copy. Each
/// file breaks exactly one rule and follows every other rule. Three fixture projects hold them: an ordinary library,
/// a library for compiler errors (a compiler error stops the analyzers of its own compilation) and an xUnit v3 test
/// project outside the three test-project folders.
/// </summary>
internal static class RuleProofSources
{
    /// <summary>The ordinary library: one file per analyzer or style rule, plus a clean control.</summary>
    internal const string RulesProject = "ProofRules/ProofRules.csproj";

    /// <summary>The library whose only file fails the compiler itself.</summary>
    internal const string CompileProject = "ProofCompile/ProofCompile.csproj";

    /// <summary>The xUnit v3 test project, outside the folders of the test-name exemption.</summary>
    internal const string TestsProject = "ProofTests/ProofTests.csproj";

    /// <summary>
    /// The fixture that calls every member of <c>BannedSymbols.txt</c> once, each on its own line, in the list's
    /// order.
    /// </summary>
    internal const string BannedSymbolsFile = "ProofRules/EveryBannedSymbolProof.cs";

    /// <summary>Gets every fixture file, as a path relative to the solution root and its content.</summary>
    internal static IReadOnlyList<KeyValuePair<string, string>> Files { get; } =
    [
        new(key: RulesProject, value: RulesProjectXml),
        new(key: CompileProject, value: PlainProjectXml),
        new(key: TestsProject, value: TestsProjectXml),
        new(key: "ProofRules/TrailingWhitespaceProof.cs", value: TrailingWhitespace.Replace(
                oldValue: "return 1;",
                newValue: "return 1; ",
                comparisonType: StringComparison.Ordinal)),
        new(key: "ProofRules/TwoSpaceIndentProof.cs", value: TwoSpaceIndent),
        new(key: "ProofRules/BracesProof.cs", value: Braces),
        new(key: "ProofRules/UsingInsideNamespaceProof.cs", value: UsingInsideNamespace),
        new(key: "ProofRules/UnusedUsingProof.cs", value: UnusedUsing),
        new(key: "ProofRules/VarNotApparentProof.cs", value: VarNotApparent),
        new(key: "ProofRules/TypedNewLocalProof.cs", value: TypedNewLocal),
        new(key: "ProofRules/FieldNewProof.cs", value: FieldNew),
        new(key: "ProofRules/CollectionExpressionProof.cs", value: CollectionExpression),
        new(key: "ProofRules/ReferenceEqualsNullProof.cs", value: ReferenceEqualsNull),
        new(key: "ProofRules/EqualsNullProof.cs", value: EqualsNull),
        new(key: "ProofRules/ExpressionBodiedMethodProof.cs", value: ExpressionBodiedMethod),
        new(key: "ProofRules/PrivateFieldNameProof.cs", value: PrivateFieldName),
        new(key: "ProofRules/ConstantNameProof.cs", value: ConstantName),
        new(key: "ProofRules/UnsealedClassProof.cs", value: UnsealedClass),
        new(key: "ProofRules/OneTypePerFileProof.cs", value: TwoTypes),
        new(key: "ProofRules/MissingXmlDocProof.cs", value: MissingXmlDoc),
        new(key: "ProofRules/BannedDateTimeProof.cs", value: BannedDateTime),
        new(key: "ProofRules/BannedConsoleProof.cs", value: BannedConsole),
        new(key: "ProofRules/BannedThreadSleepProof.cs", value: BannedThreadSleep),
        new(key: "ProofRules/BannedTaskWaitProof.cs", value: BannedTaskWait),
        new(key: "ProofRules/BannedTaskResultProof.cs", value: BannedTaskResult),
        new(key: "ProofRules/BannedHttpClientProof.cs", value: BannedHttpClient),
        new(key: BannedSymbolsFile, value: EveryBannedSymbol),
        new(key: "ProofRules/DirectLoggingProof.cs", value: DirectLogging),
        new(key: "ProofRules/ConfigureAwaitProof.cs", value: MissingConfigureAwait),
        new(key: "ProofRules/CleanControlProof.cs", value: CleanControl),
        new(key: "ProofCompile/ImplicitUsingsProof.cs", value: ImplicitUsings),
        new(key: "ProofTests/AssertProofTests.cs", value: XunitAssert),
        new(key: "ProofTests/PositionalArgumentProofTests.cs", value: PositionalArgumentInTest),
        new(key: "ProofTests/UnderscoreNameProofTests.cs", value: UnderscoreTestName),
    ];

    private const string RulesProjectXml = """
            <Project Sdk="Microsoft.NET.Sdk">
              <ItemGroup>
                <FrameworkReference Include="Microsoft.AspNetCore.App" />
              </ItemGroup>
            </Project>

            """;

    private const string PlainProjectXml = """
            <Project Sdk="Microsoft.NET.Sdk">
            </Project>

            """;

    private const string TestsProjectXml = """
            <Project Sdk="Microsoft.NET.Sdk">
              <PropertyGroup>
                <OutputType>Exe</OutputType>
                <IsTestProject>true</IsTestProject>
                <IsPackable>false</IsPackable>
              </PropertyGroup>
            </Project>

            """;

    private const string TrailingWhitespace = """
            namespace ProofRules;

            internal static class TrailingWhitespaceProof
            {
                internal static int Value()
                {
                    return 1;
                }
            }

            """;

    private const string TwoSpaceIndent = """
            namespace ProofRules;

            internal static class TwoSpaceIndentProof
            {
              internal static int Value()
              {
                  return 1;
              }
            }

            """;

    private const string Braces = """
            namespace ProofRules;

            internal static class BracesProof
            {
                internal static int Value(bool flag)
                {
                    if (flag)
                        return 1;

                    return 0;
                }
            }

            """;

    private const string UsingInsideNamespace = """
            namespace ProofRules;

            using System;

            internal static class UsingInsideNamespaceProof
            {
                internal static int Value()
                {
                    return Math.Abs(value: -1);
                }
            }

            """;

    private const string UnusedUsing = """
            using System.Text;

            namespace ProofRules;

            internal static class UnusedUsingProof
            {
                internal static int Value()
                {
                    return 1;
                }
            }

            """;

    private const string VarNotApparent = """
            namespace ProofRules;

            internal static class VarNotApparentProof
            {
                internal static int Value(string text)
                {
                    var length = text.Length;
                    return length;
                }
            }

            """;

    private const string TypedNewLocal = """
            using System.Text;

            namespace ProofRules;

            internal static class TypedNewLocalProof
            {
                internal static string Value()
                {
                    StringBuilder builder = new StringBuilder();
                    return builder.ToString();
                }
            }

            """;

    private const string FieldNew = """
            using System.Text;

            namespace ProofRules;

            internal static class FieldNewProof
            {
                internal static string Value()
                {
                    return _builder.ToString();
                }

                private static readonly StringBuilder _builder = new StringBuilder();
            }

            """;

    private const string CollectionExpression = """
            namespace ProofRules;

            internal static class CollectionExpressionProof
            {
                internal static int Value()
                {
                    return _values.Length;
                }

                private static readonly int[] _values = new int[] { 1, 2 };
            }

            """;

    private const string ReferenceEqualsNull = """
            namespace ProofRules;

            internal static class ReferenceEqualsNullProof
            {
                internal static bool IsMissing(object? value)
                {
                    return ReferenceEquals(objA: value, objB: null);
                }
            }

            """;

    private const string EqualsNull = """
            namespace ProofRules;

            internal static class EqualsNullProof
            {
                internal static bool IsMissing(object? value)
                {
                    return value == null;
                }
            }

            """;

    private const string ExpressionBodiedMethod = """
            namespace ProofRules;

            internal static class ExpressionBodiedMethodProof
            {
                internal static int Value() => 1;
            }

            """;

    private const string PrivateFieldName = """
            namespace ProofRules;

            internal sealed class PrivateFieldNameProof
            {
                internal PrivateFieldNameProof(int count)
                {
                    value = count;
                }

                internal int Value()
                {
                    return value;
                }

                private readonly int value;
            }

            """;

    private const string ConstantName = """
            namespace ProofRules;

            internal static class ConstantNameProof
            {
                internal static int Value()
                {
                    return maxCount;
                }

                private const int maxCount = 1;
            }

            """;

    private const string UnsealedClass = """
            namespace ProofRules;

            internal class UnsealedClassProof
            {
                internal int Value()
                {
                    return GetHashCode();
                }
            }

            """;

    private const string TwoTypes = """
            namespace ProofRules;

            internal static class OneTypePerFileProof
            {
                internal static int Value()
                {
                    return 1;
                }
            }

            internal static class SecondTypeProof
            {
                internal static int Value()
                {
                    return 2;
                }
            }

            """;

    private const string MissingXmlDoc = """
            namespace ProofRules;

            public static class MissingXmlDocProof
            {
                public static int Value()
                {
                    return 1;
                }
            }

            """;

    private const string BannedDateTime = """
            using System;

            namespace ProofRules;

            internal static class BannedDateTimeProof
            {
                internal static DateTime Value()
                {
                    return DateTime.UtcNow;
                }
            }

            """;

    private const string BannedConsole = """
            using System;

            namespace ProofRules;

            internal static class BannedConsoleProof
            {
                internal static void Write()
                {
                    Console.WriteLine(value: 1);
                }
            }

            """;

    private const string BannedThreadSleep = """
            using System.Threading;

            namespace ProofRules;

            internal static class BannedThreadSleepProof
            {
                internal static void Wait()
                {
                    Thread.Sleep(millisecondsTimeout: 1);
                }
            }

            """;

    private const string BannedTaskWait = """
            using System.Threading.Tasks;

            namespace ProofRules;

            internal static class BannedTaskWaitProof
            {
                internal static void Wait(Task task)
                {
                    task.Wait();
                }
            }

            """;

    private const string BannedTaskResult = """
            using System.Threading.Tasks;

            namespace ProofRules;

            internal static class BannedTaskResultProof
            {
                internal static int Value(Task<int> task)
                {
                    return task.Result;
                }
            }

            """;

    private const string BannedHttpClient = """
            using System.Net.Http;

            namespace ProofRules;

            internal static class BannedHttpClientProof
            {
                internal static HttpClient Create()
                {
                    return new HttpClient();
                }
            }

            """;

    private const string EveryBannedSymbol = """
            using System;
            using System.Collections.Generic;
            using System.Net.Http;
            using System.Threading;
            using System.Threading.Tasks;

            namespace ProofRules;

            internal static class EveryBannedSymbolProof
            {
                internal static void Clocks()
                {
                    _ = DateTime.Now;
                    _ = DateTime.UtcNow;
                    _ = DateTime.Today;
                    _ = DateTimeOffset.Now;
                    _ = DateTimeOffset.UtcNow;
                    Console.WriteLine(value: 1);
                    Thread.Sleep(millisecondsTimeout: 1);
                    Thread.Sleep(timeout: TimeSpan.Zero);
                }

                internal static void Waits(Task task)
                {
                    task.Wait();
                    _ = task.Wait(millisecondsTimeout: 1);
                    _ = task.Wait(timeout: TimeSpan.Zero);
                }

                internal static void WaitsWithToken(Task task, CancellationToken token)
                {
                    task.Wait(cancellationToken: token);
                    _ = task.Wait(millisecondsTimeout: 1, cancellationToken: token);
                    _ = task.Wait(timeout: TimeSpan.Zero, cancellationToken: token);
                }

                internal static void WaitAlls(Task[] tasks)
                {
                    ReadOnlySpan<Task> span = tasks;
                    Task.WaitAll(tasks: tasks);
                    _ = Task.WaitAll(tasks: tasks, millisecondsTimeout: 1);
                    _ = Task.WaitAll(tasks: tasks, timeout: TimeSpan.Zero);
                    Task.WaitAll(tasks: span);
                }

                internal static void WaitAllsWithToken(
                        Task[] tasks,
                        IEnumerable<Task> sequence,
                        CancellationToken token)
                {
                    Task.WaitAll(tasks: tasks, cancellationToken: token);
                    _ = Task.WaitAll(tasks: tasks, millisecondsTimeout: 1, cancellationToken: token);
                    Task.WaitAll(tasks: sequence, cancellationToken: token);
                }

                internal static void WaitAnys(Task[] tasks)
                {
                    _ = Task.WaitAny(tasks: tasks);
                    _ = Task.WaitAny(tasks: tasks, millisecondsTimeout: 1);
                    _ = Task.WaitAny(tasks: tasks, timeout: TimeSpan.Zero);
                }

                internal static void WaitAnysWithToken(Task[] tasks, CancellationToken token)
                {
                    _ = Task.WaitAny(tasks: tasks, cancellationToken: token);
                    _ = Task.WaitAny(tasks: tasks, millisecondsTimeout: 1, cancellationToken: token);
                }

                internal static int Results(Task<int> first, ValueTask<int> second)
                {
                    return first.Result
                            + second.Result;
                }

                internal static int TaskAwaiters(Task task, Task<int> value, Task other, Task<int> last)
                {
                    task.GetAwaiter().GetResult();
                    int result = value.GetAwaiter().GetResult();
                    other.ConfigureAwait(continueOnCapturedContext: false).GetAwaiter().GetResult();
                    int late = last.ConfigureAwait(continueOnCapturedContext: false).GetAwaiter().GetResult();
                    return result + late;
                }

                internal static int ValueTaskAwaiters(
                        ValueTask task,
                        ValueTask<int> value,
                        ValueTask other,
                        ValueTask<int> last)
                {
                    task.GetAwaiter().GetResult();
                    int result = value.GetAwaiter().GetResult();
                    other.ConfigureAwait(continueOnCapturedContext: false).GetAwaiter().GetResult();
                    int late = last.ConfigureAwait(continueOnCapturedContext: false).GetAwaiter().GetResult();
                    return result + late;
                }

                internal static HttpClient[] Clients(HttpMessageHandler handler)
                {
                    return
                    [
                        new HttpClient(),
                        new HttpClient(handler: handler),
                        new HttpClient(handler: handler, disposeHandler: false),
                    ];
                }
            }

            """;

    private const string DirectLogging = """
            using Microsoft.Extensions.Logging;

            namespace ProofRules;

            internal static class DirectLoggingProof
            {
                internal static void Write(ILogger logger)
                {
                    logger.LogInformation(message: "Started");
                }
            }

            """;

    private const string MissingConfigureAwait = """
            using System.Threading.Tasks;

            namespace ProofRules;

            internal static class ConfigureAwaitProof
            {
                internal static async Task Wait()
                {
                    await Task.Delay(millisecondsDelay: 1);
                }
            }

            """;

    private const string CleanControl = """
            using System.Collections.Generic;
            using System.Text;
            using System.Threading.Tasks;

            namespace ProofRules;

            /// <summary>Follows every rule: the control for the rule proofs.</summary>
            public sealed class CleanControlProof
            {
                /// <summary>Gets the text.</summary>
                public string Text => _builder.ToString();

                /// <summary>Returns a task, without an Async suffix on the name.</summary>
                /// <param name="value">A value to check.</param>
                /// <returns>A completed task.</returns>
                public Task Run(object? value)
                {
                    var builder = new StringBuilder();
                    List<int> items = [];
                    if (value is null && _builder.Length == 0)
                    {
                        items.Add(item: builder.Length);
                    }

                    return Task.CompletedTask;
                }

                /// <inheritdoc />
                public override string ToString()
                {
                    return Text;
                }

                private readonly StringBuilder _builder = new();
            }

            """;

    private const string ImplicitUsings = """
            namespace ProofCompile;

            internal static class ImplicitUsingsProof
            {
                internal static int Count(List<int> values)
                {
                    return values.Count;
                }
            }

            """;

    private const string XunitAssert = """
            using Xunit;

            namespace ProofTests;

            /// <summary>Asserts with the test framework's Assert instead of Shouldly.</summary>
            public sealed class AssertProofTests
            {
                /// <summary>Asserts with Assert.True.</summary>
                [Fact]
                public void ValueIsTrue()
                {
                    Assert.True(condition: true);
                }
            }

            """;

    private const string PositionalArgumentInTest = """
            using Shouldly;
            using Xunit;

            namespace ProofTests;

            /// <summary>Passes an argument positionally in a test project.</summary>
            public sealed class PositionalArgumentProofTests
            {
                /// <summary>Compares two values with a positional argument.</summary>
                [Fact]
                public void ValueIsOne()
                {
                    1.ShouldBe(1);
                }
            }

            """;

    private const string UnderscoreTestName = """
            using Shouldly;
            using Xunit;

            namespace ProofTests;

            /// <summary>Names a test with underscores outside the three test-project folders.</summary>
            public sealed class UnderscoreNameProofTests
            {
                /// <summary>Compares two values.</summary>
                [Fact]
                public void Value_Always_IsOne()
                {
                    1.ShouldBe(expected: 1);
                }
            }

            """;
}
