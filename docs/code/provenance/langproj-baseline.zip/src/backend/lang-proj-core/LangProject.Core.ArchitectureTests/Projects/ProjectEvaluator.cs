using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;

namespace LangProject.Core.ArchitectureTests.Projects;

/// <summary>
/// Asks MSBuild for what it evaluates in each project: <c>dotnet msbuild &lt;csproj&gt; -getItem:ProjectReference
/// -getItem:PackageReference -getProperty:...</c>, one call per project, run in parallel. The graph rules read this
/// instead of the csproj text, so semicolon lists, wildcards, <c>Directory.Build.*</c> files, imports and SDK
/// defaults all count.
/// </summary>
internal static class ProjectEvaluator
{
    internal const string TransitiveProperty = "DisableTransitiveProjectReferences";
    internal const string OutputTypeProperty = "OutputType";
    internal const string IsTestProjectProperty = "IsTestProject";
    internal const string AssemblyNameProperty = "AssemblyName";
    internal const string ImportPropsProperty = "ImportDirectoryBuildProps";
    internal const string ImportTargetsProperty = "ImportDirectoryBuildTargets";
    internal const string PropsPathProperty = "DirectoryBuildPropsPath";
    internal const string TargetsPathProperty = "DirectoryBuildTargetsPath";

    /// <summary>
    /// The folder whose tracked csproj files are not part of the backend solution, such as a frontend app.
    /// </summary>
    internal const string FrontendFolder = "src/frontend/";

    /// <summary>
    /// Evaluates every project of the working tree once per test run: each project in <c>LangProject.Core.slnx</c>
    /// and each tracked csproj outside <see cref="FrontendFolder"/>, so a project left out of the solution is still
    /// read.
    /// </summary>
    /// <returns>The evaluated projects, in ordinal path order.</returns>
    internal static Task<IReadOnlyList<EvaluatedProject>> LoadWorkingTreeAsync()
    {
        return _workingTree.Value;
    }

    /// <summary>
    /// Lists the projects to evaluate: the solution's projects plus every tracked csproj outside
    /// <see cref="FrontendFolder"/>.
    /// </summary>
    /// <param name="solutionPaths">The solution-relative project paths listed in the <c>.slnx</c>.</param>
    /// <param name="trackedFiles">The repository-relative tracked paths.</param>
    /// <param name="solutionPrefix">The solution root relative to the repository root, ending with a slash.</param>
    /// <returns>Solution-relative csproj paths, distinct, in ordinal order.</returns>
    internal static IReadOnlyList<string> ListProjectPaths(
            IEnumerable<string> solutionPaths,
            IEnumerable<string> trackedFiles,
            string solutionPrefix)
    {
        IEnumerable<string> tracked = trackedFiles
                .Where(predicate: path => path.EndsWith(value: ".csproj", comparisonType: StringComparison.Ordinal))
                .Where(predicate: path => !path.StartsWith(
                        value: FrontendFolder,
                        comparisonType: StringComparison.Ordinal))
                .Select(selector: path => Path.GetRelativePath(relativeTo: solutionPrefix, path: path)
                        .Replace(oldChar: '\\', newChar: '/'));
        return
        [
            .. solutionPaths.Concat(second: tracked)
                    .Distinct(comparer: StringComparer.Ordinal)
                    .Order(comparer: StringComparer.Ordinal),
        ];
    }

    /// <summary>Evaluates projects under a root, one MSBuild call per project, several at a time.</summary>
    /// <param name="solutionRoot">The folder every path is relative to.</param>
    /// <param name="relativePaths">The csproj paths relative to <paramref name="solutionRoot"/>.</param>
    /// <param name="cancellationToken">Cancels the calls and kills their processes.</param>
    /// <returns>The evaluated projects, in ordinal path order.</returns>
    internal static async Task<IReadOnlyList<EvaluatedProject>> EvaluateAsync(
            string solutionRoot,
            IReadOnlyCollection<string> relativePaths,
            CancellationToken cancellationToken)
    {
        var results = new ConcurrentBag<EvaluatedProject>();
        var options = new ParallelOptions
        {
            MaxDegreeOfParallelism = Math.Clamp(value: Environment.ProcessorCount, min: 2, max: 8),
            CancellationToken = cancellationToken,
        };
        await Parallel.ForEachAsync(
                source: relativePaths,
                parallelOptions: options,
                body: async (relativePath, token) => results.Add(item: await EvaluateOneAsync(
                        solutionRoot: solutionRoot,
                        relativePath: relativePath,
                        cancellationToken: token)));
        return [.. results.OrderBy(keySelector: project => project.RelativePath, comparer: StringComparer.Ordinal)];
    }

    /// <summary>Parses the JSON that <c>dotnet msbuild -getItem -getProperty</c> prints.</summary>
    /// <param name="solutionRoot">The folder the returned paths are made relative to.</param>
    /// <param name="relativePath">The evaluated csproj's path relative to <paramref name="solutionRoot"/>.</param>
    /// <param name="json">The JSON text.</param>
    /// <returns>The evaluated project.</returns>
    internal static EvaluatedProject Parse(string solutionRoot, string relativePath, string json)
    {
        using var document = JsonDocument.Parse(json: json);
        JsonElement root = document.RootElement;
        var properties = new Dictionary<string, string>(comparer: StringComparer.OrdinalIgnoreCase);
        foreach (JsonProperty property in root.GetProperty(propertyName: "Properties").EnumerateObject())
        {
            string value = property.Value.GetString() ?? string.Empty;
            properties[property.Name] = _pathProperties.Contains(item: property.Name) && value.Length > 0
                    ? ToRelative(solutionRoot: solutionRoot, fullPath: value)
                    : value;
        }

        List<EvaluatedReference> references =
        [
            .. Items(root: root, itemType: "ProjectReference").Select(selector: item => new EvaluatedReference(
                    relativePath: ToRelative(
                            solutionRoot: solutionRoot,
                            fullPath: Metadata(item: item, name: "FullPath")),
                    definedIn: ToRelative(
                            solutionRoot: solutionRoot,
                            fullPath: Metadata(item: item, name: "DefiningProjectFullPath")),
                    isAnalyzerOnly: IsAnalyzerOnly(item: item))),
        ];
        List<string> packages =
        [
            .. Items(root: root, itemType: "PackageReference")
                    .Select(selector: item => Metadata(item: item, name: "Identity")),
        ];
        return new EvaluatedProject(
                relativePath: relativePath,
                properties: properties,
                projectReferences: references,
                packageReferences: packages);
    }

    private static readonly string[] _propertyNames =
    [
        TransitiveProperty,
        OutputTypeProperty,
        IsTestProjectProperty,
        AssemblyNameProperty,
        ImportPropsProperty,
        ImportTargetsProperty,
        PropsPathProperty,
        TargetsPathProperty,
    ];

    private static readonly HashSet<string> _pathProperties = new(
            collection: [PropsPathProperty, TargetsPathProperty],
            comparer: StringComparer.OrdinalIgnoreCase);

    private static readonly TimeSpan _evaluationTimeout = TimeSpan.FromMinutes(minutes: 2);

    private static readonly Lazy<Task<IReadOnlyList<EvaluatedProject>>> _workingTree =
            new(valueFactory: EvaluateWorkingTreeAsync);

    private static async Task<IReadOnlyList<EvaluatedProject>> EvaluateWorkingTreeAsync()
    {
        IReadOnlyList<string> trackedFiles = await TrackedFiles.ListAsync(cancellationToken: CancellationToken.None);
        string solutionXml = await File.ReadAllTextAsync(path: RepositoryLayout.SolutionFilePath);
        string solutionPrefix = Path.GetRelativePath(
                relativeTo: RepositoryLayout.RepositoryRoot,
                path: RepositoryLayout.SolutionRoot).Replace(oldChar: '\\', newChar: '/') + "/";
        IReadOnlyList<string> paths = ListProjectPaths(
                solutionPaths: SolutionFile.ReadProjectPaths(solutionXml: solutionXml),
                trackedFiles: trackedFiles,
                solutionPrefix: solutionPrefix);
        return await EvaluateAsync(
                solutionRoot: RepositoryLayout.SolutionRoot,
                relativePaths: [.. paths],
                cancellationToken: CancellationToken.None);
    }

    private static async Task<EvaluatedProject> EvaluateOneAsync(
            string solutionRoot,
            string relativePath,
            CancellationToken cancellationToken)
    {
        List<string> arguments =
        [
            "msbuild",
            Path.Combine(path1: solutionRoot, path2: relativePath),
            "-nologo",
            "-p:Configuration=Release",
            "-getItem:ProjectReference",
            "-getItem:PackageReference",
            .. _propertyNames.Select(selector: name => "-getProperty:" + name),
        ];
        ProcessResult result = await DotnetQuery.RunAsync(
                arguments: arguments,
                workingDirectory: solutionRoot,
                timeout: _evaluationTimeout,
                cancellationToken: cancellationToken);
        if (result.ExitCode != 0)
        {
            throw new InvalidOperationException(
                    message: $"MSBuild could not evaluate {relativePath}: {result.Output}");
        }

        return Parse(solutionRoot: solutionRoot, relativePath: relativePath, json: result.StandardOutput);
    }

    private static List<JsonElement> Items(JsonElement root, string itemType)
    {
        return root.TryGetProperty(propertyName: "Items", value: out JsonElement items)
                && items.TryGetProperty(propertyName: itemType, value: out JsonElement list)
                ? [.. list.EnumerateArray()]
                : [];
    }

    private static string Metadata(JsonElement item, string name)
    {
        return item.TryGetProperty(propertyName: name, value: out JsonElement value)
                ? value.GetString() ?? string.Empty
                : string.Empty;
    }

    private static bool IsAnalyzerOnly(JsonElement item)
    {
        string outputItemType = Metadata(item: item, name: "OutputItemType");
        string referencesAssembly = Metadata(item: item, name: "ReferenceOutputAssembly");
        return string.Equals(a: outputItemType, b: "Analyzer", comparisonType: StringComparison.OrdinalIgnoreCase)
                && string.Equals(a: referencesAssembly, b: "false", comparisonType: StringComparison.OrdinalIgnoreCase);
    }

    private static string ToRelative(string solutionRoot, string fullPath)
    {
        return Path.GetRelativePath(relativeTo: solutionRoot, path: fullPath).Replace(oldChar: '\\', newChar: '/');
    }
}
