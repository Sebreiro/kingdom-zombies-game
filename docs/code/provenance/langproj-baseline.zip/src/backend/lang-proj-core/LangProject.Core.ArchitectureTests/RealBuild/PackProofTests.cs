using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.RealBuild;

/// <summary>
/// A real <c>dotnet pack</c> of every non-test project under <c>packages/</c> (SPEC R3). It runs in a throwaway
/// solution copy, so restore, build output and the packages stay out of the working tree; restore runs in locked
/// mode, so the copied lock files must already match.
/// </summary>
public sealed class PackProofTests
{
    /// <summary>
    /// Every non-test package project packs into exactly one <c>.nupkg</c>, the analyzer package holds its DLL
    /// under <c>analyzers/dotnet/cs</c>, and no pack builds or restores in the working tree.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Pack_EveryNonTestPackage_ProducesNupkg()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        using SolutionCopy copy = await SolutionCopy.CreateAsync(cancellationToken: cancellationToken);
        string output = Path.Combine(path1: copy.CopyRoot, path2: "pack-output");
        List<ProjectFile> projects = NonTestPackageProjects();

        projects.ShouldContain(elementPredicate: project => IsAnalyzer(name: project.Name));
        foreach (ProjectFile project in projects)
        {
            ProcessResult pack = await DotnetCli.RunAsync(
                    arguments:
                    [
                        "pack",
                        project.RelativePath,
                        "-c",
                        "Release",
                        "-o",
                        output,
                        "-p:RestoreLockedMode=true",
                        DotnetCli.NoAudit,
                    ],
                    workingDirectory: copy.SolutionRoot,
                    cancellationToken: cancellationToken);
            pack.ExitCode.ShouldBe(expected: 0, customMessage: DotnetCli.Explain(result: pack));
            pack.Output.ShouldNotContain(expected: RepositoryLayout.SolutionRoot, customMessage: pack.Output);
        }

        List<string> packages =
        [
            .. Directory.EnumerateFiles(path: output, searchPattern: "*.nupkg")
                    .Select(selector: path => Path.GetFileName(path: path)),
        ];
        string packageList = string.Join(separator: ", ", values: packages);
        packages.Count.ShouldBe(expected: projects.Count, customMessage: packageList);
        foreach (ProjectFile project in projects)
        {
            packages.Count(predicate: package => IsPackageOf(package: package, projectName: project.Name))
                    .ShouldBe(expected: 1, customMessage: project.Name + ": " + packageList);
        }

        string analyzerPackage = packages.Single(
                predicate: package => IsPackageOf(package: package, projectName: AnalyzerPackage));
        using ZipArchive archive = ZipFile.OpenRead(
                archiveFileName: Path.Combine(path1: output, path2: analyzerPackage));
        archive.Entries.ShouldContain(elementPredicate: entry => string.Equals(
                a: entry.FullName,
                b: AnalyzerDllEntry,
                comparisonType: StringComparison.Ordinal));
    }

    private const string AnalyzerPackage = "Sebreiro.CodeRules.Analyzers";
    private const string AnalyzerDllEntry = "analyzers/dotnet/cs/Sebreiro.CodeRules.Analyzers.dll";

    private static List<ProjectFile> NonTestPackageProjects()
    {
        return
        [
            .. RepositoryLayout.FindBuildFiles(root: RepositoryLayout.PackagesDirectory)
                    .Where(predicate: path => path.EndsWith(value: ".csproj", comparisonType: StringComparison.Ordinal))
                    .Select(selector: path => ProjectFile.Load(
                            solutionRoot: RepositoryLayout.SolutionRoot,
                            relativePath: RepositoryLayout.ToSolutionRelative(fullPath: path)))
                    .Where(predicate: project => !project.IsTestProject),
        ];
    }

    private static bool IsAnalyzer(string name)
    {
        return string.Equals(a: name, b: AnalyzerPackage, comparisonType: StringComparison.Ordinal);
    }

    private static bool IsPackageOf(string package, string projectName)
    {
        string prefix = projectName + ".";
        return package.StartsWith(value: prefix, comparisonType: StringComparison.Ordinal)
                && package.Length > prefix.Length
                && char.IsAsciiDigit(c: package[prefix.Length]);
    }
}
