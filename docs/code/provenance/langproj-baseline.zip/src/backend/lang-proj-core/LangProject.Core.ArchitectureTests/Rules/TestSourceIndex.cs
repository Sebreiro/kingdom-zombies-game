using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using LangProject.Core.ArchitectureTests.Infrastructure;
using LangProject.Core.ArchitectureTests.Projects;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// Finds the test methods declared in the three test projects' sources, as fully qualified
/// <c>Namespace.Class.Method</c> names, and checks their names against the <c>Method_State_Expected</c> rule. The
/// test projects are read as source: ArchitectureTests does not reference the other test projects (D-46).
/// </summary>
internal static partial class TestSourceIndex
{
    /// <summary>
    /// Lists the test methods of one source file, parsed with Roslyn: every method with an attribute whose name,
    /// without its namespace and <c>Attribute</c> suffix, is <c>Fact</c> or <c>Theory</c> or ends in one of them,
    /// whatever its modifiers, return type, type parameters or attribute layout. Each is qualified with its
    /// namespace and containing types. Sample code inside string literals is not read as a test.
    /// </summary>
    /// <param name="content">The C# source text.</param>
    /// <returns>The fully qualified test method names, in source order.</returns>
    internal static IReadOnlyList<string> TestMethods(string content)
    {
        SyntaxNode root = CSharpSyntaxTree.ParseText(text: content, options: _parseOptions).GetRoot();
        return
        [
            .. root.DescendantNodes()
                    .OfType<MethodDeclarationSyntax>()
                    .Where(predicate: IsTestMethod)
                    .Select(selector: QualifiedName),
        ];
    }

    /// <summary>Lists every test method in the sources of the three test projects.</summary>
    /// <returns>The fully qualified names, in ordinal order.</returns>
    internal static IReadOnlyList<string> ProductionTestMethods()
    {
        string solutionXml = File.ReadAllText(path: RepositoryLayout.SolutionFilePath);
        List<string> testFolders =
        [
            .. SolutionFile.ReadProjectPaths(solutionXml: solutionXml)
                    .Where(predicate: path => AllowedEdges.IsTest(
                            projectName: Path.GetFileNameWithoutExtension(path: path)))
                    .Select(selector: path => Path.Combine(
                            path1: RepositoryLayout.SolutionRoot,
                            path2: Path.GetDirectoryName(path: path) ?? string.Empty)),
        ];

        return
        [
            .. testFolders
                    .SelectMany(selector: folder => Directory.EnumerateFiles(
                            path: folder,
                            searchPattern: "*.cs",
                            searchOption: SearchOption.AllDirectories))
                    .Where(predicate: path => !IsBuildOutput(path: path))
                    .SelectMany(selector: path => TestMethods(content: File.ReadAllText(path: path)))
                    .Order(comparer: StringComparer.Ordinal),
        ];
    }

    /// <summary>
    /// Tells whether a test method name follows <c>Method_State_Expected</c>: exactly three parts joined by
    /// underscores, each starting with an upper-case letter or a digit and holding only letters and digits.
    /// </summary>
    /// <param name="methodName">The method name.</param>
    /// <returns><see langword="true"/> when the name follows the rule.</returns>
    internal static bool FollowsMethodStateExpected(string methodName)
    {
        return TestNamePattern().IsMatch(input: methodName);
    }

    private static readonly CSharpParseOptions _parseOptions = new(languageVersion: LanguageVersion.Preview);

    private static readonly string[] _testAttributeSuffixes = ["Fact", "Theory"];

    [GeneratedRegex(
            pattern: "^[A-Z0-9][A-Za-z0-9]*(_[A-Z0-9][A-Za-z0-9]*){2}$",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex TestNamePattern();

    private static bool IsTestMethod(MethodDeclarationSyntax method)
    {
        return method.AttributeLists
                .SelectMany(selector: list => list.Attributes)
                .Select(selector: attribute => AttributeName(name: attribute.Name))
                .Any(predicate: name => _testAttributeSuffixes.Any(predicate: suffix => name.EndsWith(
                        value: suffix,
                        comparisonType: StringComparison.Ordinal)));
    }

    private static string AttributeName(NameSyntax name)
    {
        string simple = name switch
        {
            QualifiedNameSyntax qualified => qualified.Right.Identifier.ValueText,
            AliasQualifiedNameSyntax alias => alias.Name.Identifier.ValueText,
            SimpleNameSyntax plain => plain.Identifier.ValueText,
            _ => name.ToString(),
        };
        return simple.EndsWith(value: "Attribute", comparisonType: StringComparison.Ordinal)
                ? simple[..^"Attribute".Length]
                : simple;
    }

    private static string QualifiedName(MethodDeclarationSyntax method)
    {
        IEnumerable<string> containers = method
                .Ancestors()
                .Reverse()
                .Select(selector: ContainerName)
                .Where(predicate: name => name.Length > 0);
        return string.Join(separator: ".", values: containers.Append(element: method.Identifier.ValueText));
    }

    private static string ContainerName(SyntaxNode node)
    {
        return node switch
        {
            BaseNamespaceDeclarationSyntax space => space.Name.ToString(),
            BaseTypeDeclarationSyntax type => type.Identifier.ValueText,
            _ => string.Empty,
        };
    }

    private static bool IsBuildOutput(string path)
    {
        string[] segments = path.Split(separator: [Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar]);
        return segments.Any(predicate: segment =>
                string.Equals(a: segment, b: "bin", comparisonType: StringComparison.Ordinal)
                        || string.Equals(a: segment, b: "obj", comparisonType: StringComparison.Ordinal));
    }
}
