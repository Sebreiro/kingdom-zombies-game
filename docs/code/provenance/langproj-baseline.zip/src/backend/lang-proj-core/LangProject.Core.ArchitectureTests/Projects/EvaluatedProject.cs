using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace LangProject.Core.ArchitectureTests.Projects;

/// <summary>
/// One project as MSBuild evaluates it, with every import applied: the SDK props and targets, the
/// <c>Directory.Build.*</c> files MSBuild finds and every <c>Import</c>. The graph rules read this view rather than
/// the csproj text, so a reference or a property set outside the csproj still counts.
/// </summary>
internal sealed class EvaluatedProject
{
    /// <summary>Initializes a new instance of the <see cref="EvaluatedProject"/> class.</summary>
    /// <param name="relativePath">The csproj path relative to the solution root, with forward slashes.</param>
    /// <param name="properties">The evaluated properties that were asked for; names are case-insensitive.</param>
    /// <param name="projectReferences">Every evaluated <c>ProjectReference</c> item.</param>
    /// <param name="packageReferences">The ID of every evaluated <c>PackageReference</c> item.</param>
    internal EvaluatedProject(
            string relativePath,
            IReadOnlyDictionary<string, string> properties,
            IReadOnlyList<EvaluatedReference> projectReferences,
            IReadOnlyList<string> packageReferences)
    {
        RelativePath = relativePath;
        Name = Path.GetFileNameWithoutExtension(path: relativePath);
        _properties = new Dictionary<string, string>(
                collection: properties,
                comparer: StringComparer.OrdinalIgnoreCase);
        ProjectReferences = projectReferences;
        PackageReferences = packageReferences;
        ReferencedProjects = projectReferences
                .Where(predicate: reference => !reference.IsAnalyzerOnly)
                .Select(selector: reference => reference.Name)
                .ToHashSet(comparer: StringComparer.Ordinal);
    }

    /// <summary>Gets the csproj file name without its extension; this is the project name.</summary>
    internal string Name { get; }

    /// <summary>Gets the csproj path relative to the solution root, with forward slashes.</summary>
    internal string RelativePath { get; }

    /// <summary>Gets every evaluated <c>ProjectReference</c> item, analyzer-only edges included.</summary>
    internal IReadOnlyList<EvaluatedReference> ProjectReferences { get; }

    /// <summary>
    /// Gets the ID of every evaluated <c>PackageReference</c> item, central global packages included.
    /// </summary>
    internal IReadOnlyList<string> PackageReferences { get; }

    /// <summary>
    /// Gets the project names of every reference that is not an analyzer-only edge: the references the D-46 table
    /// governs.
    /// </summary>
    internal IReadOnlySet<string> ReferencedProjects { get; }

    /// <summary>Gets an evaluated property value; MSBuild treats an unset property as empty.</summary>
    /// <param name="name">The property name, matched case-insensitively.</param>
    /// <returns>The value, or an empty string when the property is unset or was not asked for.</returns>
    internal string GetProperty(string name)
    {
        return _properties.TryGetValue(key: name, value: out string? value) ? value : string.Empty;
    }

    private readonly Dictionary<string, string> _properties;
}
