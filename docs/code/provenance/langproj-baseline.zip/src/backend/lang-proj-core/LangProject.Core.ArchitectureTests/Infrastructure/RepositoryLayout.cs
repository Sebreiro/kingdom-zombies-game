using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace LangProject.Core.ArchitectureTests.Infrastructure;

/// <summary>
/// Paths of the repository and the backend solution, found from the test run's output folder, so the tests read
/// the working tree they were built from.
/// </summary>
internal static class RepositoryLayout
{
    /// <summary>Gets the repository root: the nearest folder above the test output with <c>global.json</c>.</summary>
    internal static string RepositoryRoot { get; } = FindRepositoryRoot();

    /// <summary>Gets the solution root, <c>src/backend/lang-proj-core</c>.</summary>
    internal static string SolutionRoot =>
            Path.Combine(path1: RepositoryRoot, path2: "src", path3: "backend", path4: "lang-proj-core");

    /// <summary>Gets the path of <c>LangProject.Core.slnx</c>.</summary>
    internal static string SolutionFilePath => Path.Combine(path1: SolutionRoot, path2: "LangProject.Core.slnx");

    /// <summary>Gets the path of the solution's <c>Directory.Build.props</c>, the only file with a version.</summary>
    internal static string DirectoryBuildProps => Path.Combine(path1: SolutionRoot, path2: "Directory.Build.props");

    /// <summary>Gets the backend docs folder, <c>src/backend/docs</c>, which holds the rule matrix.</summary>
    internal static string BackendDocs =>
            Path.Combine(path1: RepositoryRoot, path2: "src", path3: "backend", path4: "docs");

    /// <summary>Gets the folder that holds the reusable <c>Sebreiro.*</c> packages.</summary>
    internal static string PackagesDirectory => Path.Combine(path1: SolutionRoot, path2: "packages");

    /// <summary>
    /// Finds every csproj, props and targets file under <paramref name="root"/>, skipping <c>bin</c> and
    /// <c>obj</c> folders. Proof fixtures are included on purpose: a bad value in any build file matters.
    /// </summary>
    /// <param name="root">The folder to search.</param>
    /// <returns>Full paths, in ordinal order.</returns>
    internal static IReadOnlyList<string> FindBuildFiles(string root)
    {
        return Directory.EnumerateFiles(path: root, searchPattern: "*", searchOption: SearchOption.AllDirectories)
                .Where(predicate: IsBuildFile)
                .Where(predicate: path => !IsUnderBuildOutput(root: root, path: path))
                .Order(comparer: StringComparer.Ordinal)
                .ToList();
    }

    /// <summary>Converts a full path under the solution root to a relative path with forward slashes.</summary>
    /// <param name="fullPath">A full path under <see cref="SolutionRoot"/>.</param>
    /// <returns>The relative path, for example <c>packages/Sebreiro.UnitOfWork.Abstractions/x.csproj</c>.</returns>
    internal static string ToSolutionRelative(string fullPath)
    {
        return Path.GetRelativePath(relativeTo: SolutionRoot, path: fullPath).Replace(oldChar: '\\', newChar: '/');
    }

    private static readonly string[] _buildFileExtensions = [".csproj", ".props", ".targets"];

    private static string FindRepositoryRoot()
    {
        var directory = new DirectoryInfo(path: AppContext.BaseDirectory);
        while (directory is not null)
        {
            if (File.Exists(path: Path.Combine(path1: directory.FullName, path2: "global.json")))
            {
                return directory.FullName;
            }

            directory = directory.Parent;
        }

        throw new InvalidOperationException(message: $"No global.json found above {AppContext.BaseDirectory}.");
    }

    private static bool IsBuildFile(string path)
    {
        string extension = Path.GetExtension(path: path);
        return _buildFileExtensions.Any(predicate: buildExtension => string.Equals(
                a: extension,
                b: buildExtension,
                comparisonType: StringComparison.OrdinalIgnoreCase));
    }

    private static bool IsUnderBuildOutput(string root, string path)
    {
        string[] segments = Path.GetRelativePath(relativeTo: root, path: path)
                .Split(separator: [Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar]);
        return segments.Any(predicate: segment =>
                string.Equals(a: segment, b: "bin", comparisonType: StringComparison.Ordinal)
                        || string.Equals(a: segment, b: "obj", comparisonType: StringComparison.Ordinal));
    }
}
