namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// One row of the rule matrix's "Rules" table: a written rule, every mechanism that enforces it, its scope and
/// exemptions, its proof tests and the level they run at. Cells hold the Markdown text as written.
/// </summary>
internal sealed class MatrixRule
{
    /// <summary>Initializes a new instance of the <see cref="MatrixRule"/> class.</summary>
    /// <param name="id">The row ID, for example <c>R-01</c>.</param>
    /// <param name="anchor">The HTML anchor ID in the ID cell, for example <c>r-01</c>; empty when missing.</param>
    /// <param name="rule">The rule cell: the rule name and its links to the code-rule docs.</param>
    /// <param name="mechanisms">The mechanism cell: diagnostic IDs, banned symbols and checks.</param>
    /// <param name="scope">The scope cell, naming any exemption rows (<c>EX-NN</c>).</param>
    /// <param name="proof">The proof cell: fully qualified proof test names.</param>
    /// <param name="level">The level cell, for example <c>real build</c> or <c>analyzer test</c>.</param>
    internal MatrixRule(
            string id,
            string anchor,
            string rule,
            string mechanisms,
            string scope,
            string proof,
            string level)
    {
        Id = id;
        Anchor = anchor;
        Rule = rule;
        Mechanisms = mechanisms;
        Scope = scope;
        Proof = proof;
        Level = level;
    }

    /// <summary>Gets the row ID, for example <c>R-01</c>.</summary>
    internal string Id { get; }

    /// <summary>Gets the HTML anchor ID in the ID cell; empty when the cell has none.</summary>
    internal string Anchor { get; }

    /// <summary>Gets the rule cell.</summary>
    internal string Rule { get; }

    /// <summary>Gets the mechanism cell.</summary>
    internal string Mechanisms { get; }

    /// <summary>Gets the scope and exemptions cell.</summary>
    internal string Scope { get; }

    /// <summary>Gets the proof test cell.</summary>
    internal string Proof { get; }

    /// <summary>Gets the level cell.</summary>
    internal string Level { get; }
}
