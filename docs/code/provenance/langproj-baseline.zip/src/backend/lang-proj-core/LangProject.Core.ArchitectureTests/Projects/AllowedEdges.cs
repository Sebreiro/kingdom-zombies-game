using System;
using System.Collections.Generic;
using System.Linq;

namespace LangProject.Core.ArchitectureTests.Projects;

/// <summary>
/// The C# copy of the D-46 allowed-edges table in <c>src/backend/docs/CodeRules/code-architecture.md</c>;
/// <see cref="EdgeTableDocument"/> compares the two row by row. Changing an edge means changing the csproj, this
/// table, the written table, the layer-graph decision record and the per-project docs together.
/// </summary>
internal static class AllowedEdges
{
    internal const string CompositionRoot = "LangProject.Core.CompositionRoot";
    internal const string Api = "LangProject.Core.API";
    internal const string ApiAbstractions = "LangProject.Core.API.Abstractions";
    internal const string Application = "LangProject.Core.Application";
    internal const string ApplicationAbstractions = "LangProject.Core.Application.Abstractions";
    internal const string Dal = "LangProject.Core.DAL";
    internal const string DalAbstractions = "LangProject.Core.DAL.Abstractions";
    internal const string Domain = "LangProject.Core.Domain";
    internal const string IntegrationAbstractions = "LangProject.Core.Integration.Abstractions";
    internal const string IntegrationPrefix = "LangProject.Core.Integration.";
    internal const string UnitOfWorkEntityFrameworkCore = "Sebreiro.UnitOfWork.EntityFrameworkCore";
    internal const string UnitOfWorkAbstractions = "Sebreiro.UnitOfWork.Abstractions";
    internal const string Analyzers = "Sebreiro.CodeRules.Analyzers";
    internal const string IntegrationTests = "LangProject.Core.IntegrationTests";
    internal const string ArchitectureTests = "LangProject.Core.ArchitectureTests";
    internal const string AnalyzersTests = "Sebreiro.CodeRules.Analyzers.Tests";

    /// <summary>Gets the three xUnit v3 test projects, the only executables besides CompositionRoot (RD-10).</summary>
    internal static IReadOnlySet<string> TestProjects { get; } = new HashSet<string>(
            collection: [IntegrationTests, ArchitectureTests, AnalyzersTests],
            comparer: StringComparer.Ordinal);

    /// <summary>
    /// Gets every project name with its own row, including the rows whose allowed set depends on the solution.
    /// The <c>Integration.&lt;Vendor&gt;</c> row is a name pattern; see <see cref="IsIntegrationVendor"/>.
    /// </summary>
    internal static IReadOnlySet<string> NamedRows => _fixedRows.Keys
            .Concat(second: [CompositionRoot, IntegrationTests, ArchitectureTests])
            .ToHashSet(comparer: StringComparer.Ordinal);

    /// <summary>Gets a value indicating whether a project is one of the three test projects.</summary>
    /// <param name="projectName">The project name.</param>
    /// <returns><see langword="true"/> for a test project.</returns>
    internal static bool IsTest(string projectName)
    {
        return TestProjects.Contains(item: projectName);
    }

    /// <summary>Gets whether a project is a Phase 2 <c>Integration.&lt;Vendor&gt;</c> project.</summary>
    /// <param name="projectName">The project name.</param>
    /// <returns><see langword="true"/> for a provider integration project.</returns>
    internal static bool IsIntegrationVendor(string projectName)
    {
        return projectName.StartsWith(value: IntegrationPrefix, comparisonType: StringComparison.Ordinal)
                && !IsSameName(left: projectName, right: IntegrationAbstractions);
    }

    /// <summary>
    /// Gets a value indicating whether a project is an implementation project, which only CompositionRoot and the
    /// test projects may reference (D-40, D-41).
    /// </summary>
    /// <param name="projectName">The project name.</param>
    /// <returns><see langword="true"/> for API, Application, DAL, an Integration vendor, the EF Unit of Work.</returns>
    internal static bool IsImplementation(string projectName)
    {
        return _implementationProjects.Contains(item: projectName) || IsIntegrationVendor(projectName: projectName);
    }

    /// <summary>Finds the table row for a project.</summary>
    /// <param name="projectName">The project to look up.</param>
    /// <param name="solutionProjects">
    /// Every project in the solution; the "every non-test project" rows are computed from it.
    /// </param>
    /// <returns>
    /// The row: the projects the project may reference and the ones it must reference. IntegrationTests must reference
    /// CompositionRoot and may draw any other project of its allowed set. <see langword="null"/> when the table has
    /// no row.
    /// </returns>
    internal static AllowedEdgeRow? FindRow(string projectName, IReadOnlyCollection<string> solutionProjects)
    {
        if (_fixedRows.TryGetValue(key: projectName, value: out string[]? fixedRow))
        {
            return Exact(names: fixedRow);
        }

        if (IsIntegrationVendor(projectName: projectName))
        {
            return Exact(names: [IntegrationAbstractions]);
        }

        return projectName switch
        {
            CompositionRoot or ArchitectureTests => Exact(
                    names: EveryNonTestProject(solutionProjects: solutionProjects, except: projectName)),
            IntegrationTests => new AllowedEdgeRow(
                    allowed: EveryNonTestProject(solutionProjects: solutionProjects, except: projectName),
                    required: new HashSet<string>(collection: [CompositionRoot], comparer: StringComparer.Ordinal)),
            _ => null,
        };
    }

    private static readonly Dictionary<string, string[]> _fixedRows = new(comparer: StringComparer.Ordinal)
    {
        [Api] = [ApiAbstractions, ApplicationAbstractions],
        [ApiAbstractions] = [],
        [Application] =
        [
            ApplicationAbstractions,
            DalAbstractions,
            IntegrationAbstractions,
            Domain,
            UnitOfWorkAbstractions,
        ],
        [ApplicationAbstractions] = [],
        [Dal] = [DalAbstractions, Domain],
        [DalAbstractions] = [Domain],
        [Domain] = [],
        [IntegrationAbstractions] = [],
        [UnitOfWorkEntityFrameworkCore] = [UnitOfWorkAbstractions],
        [UnitOfWorkAbstractions] = [],
        [Analyzers] = [],
        [AnalyzersTests] = [Analyzers],
    };

    private static readonly HashSet<string> _implementationProjects = new(
            collection: [Api, Application, Dal, UnitOfWorkEntityFrameworkCore],
            comparer: StringComparer.Ordinal);

    /// <summary>
    /// The "every non-test project" set. The analyzer is left out: every project reaches it through the analyzer-only
    /// edge in <c>Directory.Build.targets</c> (D-46), never through a csproj <c>ProjectReference</c>.
    /// </summary>
    private static HashSet<string> EveryNonTestProject(IReadOnlyCollection<string> solutionProjects, string except)
    {
        return solutionProjects
                .Where(predicate: name => !IsTest(projectName: name))
                .Where(predicate: name => !IsSameName(left: name, right: Analyzers))
                .Where(predicate: name => !IsSameName(left: name, right: except))
                .ToHashSet(comparer: StringComparer.Ordinal);
    }

    private static AllowedEdgeRow Exact(IEnumerable<string> names)
    {
        var set = names.ToHashSet(comparer: StringComparer.Ordinal);
        return new AllowedEdgeRow(allowed: set, required: set);
    }

    private static bool IsSameName(string left, string right)
    {
        return string.Equals(a: left, b: right, comparisonType: StringComparison.Ordinal);
    }
}
