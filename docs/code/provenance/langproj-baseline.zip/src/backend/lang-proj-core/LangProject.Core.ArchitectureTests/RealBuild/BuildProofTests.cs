using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;
using LangProject.Core.ArchitectureTests.Rules;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.RealBuild;

/// <summary>
/// Real <c>dotnet build</c> runs on bad-on-purpose input in a throwaway copy of the solution (D-34). The copy keeps
/// the real props, targets, central versions and <c>.editorconfig</c> files, so it builds exactly like the working
/// tree. Every fixture follows every house rule except the one it breaks on purpose, and each failing build is
/// checked to fail for that reason only.
/// </summary>
public sealed class BuildProofTests
{
    /// <summary>A block-scoped namespace in Domain fails the build with IDE0161 (SPEC R4, style).</summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Build_StyleViolation_FailsWithIde0161()
    {
        using SolutionCopy copy = await SolutionCopy.CreateAsync(
                cancellationToken: TestContext.Current.CancellationToken);
        copy.WriteFile(
                relativePath: "LangProject.Core.Domain/Proof/BlockNamespaceProof.cs",
                content: DomainBlockSource);

        ProcessResult result = await DotnetCli.BuildAsync(
                target: DomainProject,
                workingDirectory: copy.SolutionRoot,
                cancellationToken: TestContext.Current.CancellationToken);

        ShouldFailWith(result: result, expectedErrorIds: ["IDE0161"]);
    }

    /// <summary>
    /// An unsealed public class and a positional argument in Domain fail the build with MA0053 (Meziantou) and
    /// SCR0001 (the custom analyzer) (SPEC R4, analyzers).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Build_AnalyzerViolation_FailsWithMa0053AndScr0001()
    {
        using SolutionCopy copy = await SolutionCopy.CreateAsync(
                cancellationToken: TestContext.Current.CancellationToken);
        copy.WriteFile(
                relativePath: "LangProject.Core.Domain/Proof/AnalyzerProof.cs",
                content: DomainAnalyzerSource);

        ProcessResult result = await DotnetCli.BuildAsync(
                target: DomainProject,
                workingDirectory: copy.SolutionRoot,
                cancellationToken: TestContext.Current.CancellationToken);

        ShouldFailWith(result: result, expectedErrorIds: ["MA0053", "SCR0001"]);
    }

    /// <summary>
    /// A compiler warning (CS0168, an unused local) and an MSBuild warning (a <c>Warning</c> task with the code
    /// PROOF001) both fail the build as errors, and nothing stays a warning: <c>TreatWarningsAsErrors</c> and
    /// <c>MSBuildTreatWarningsAsErrors</c> are in force. Neither diagnostic is an error on its own (SPEC R4).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Build_CompilerAndMsBuildWarnings_FailAsErrors()
    {
        using SolutionCopy copy = await SolutionCopy.CreateAsync(
                cancellationToken: TestContext.Current.CancellationToken);
        copy.WriteFile(relativePath: WarningsProject, content: WarningsProjectXml);
        copy.WriteFile(relativePath: "ProofWarnings/UnusedVariableProof.cs", content: UnusedVariableSource);

        ProcessResult result = await DotnetCli.BuildAsync(
                target: WarningsProject,
                workingDirectory: copy.SolutionRoot,
                cancellationToken: TestContext.Current.CancellationToken);

        ShouldFailWith(result: result, expectedErrorIds: ["CS0168", "PROOF001"]);
        result.WarningIds.ShouldBeEmpty(customMessage: result.Output);
        result.ErrorIdsInFile(pathEnding: "ProofWarnings/UnusedVariableProof.cs")
                .ShouldBe(expected: ["CS0168"], customMessage: result.Output);
    }

    /// <summary>
    /// A project that references Newtonsoft.Json 12.0.1 (advisory GHSA-5crp-9r3c-p9vr) builds with exit code 0 and
    /// the NU1903 warning, and with no other warning (SPEC R4, audit edge). The advisory comes from a local
    /// <see cref="AdvisoryFeed"/>, the copy's only audit source, so the result needs no network and no live
    /// advisory database. The package version is added to the copy's central versions only.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Build_AuditAdvisoryPackage_WarnsButSucceeds()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        await using var feed = AdvisoryFeed.Start();
        using SolutionCopy copy = await SolutionCopy.CreateAsync(cancellationToken: cancellationToken);
        copy.UseAuditSource(serviceIndex: feed.ServiceIndex);
        copy.AddPackageVersion(packageId: "Newtonsoft.Json", version: "12.0.1");
        copy.WriteFile(relativePath: "ProofAdvisory/ProofAdvisory.csproj", content: AdvisoryProject);

        ProcessResult result = await DotnetCli.BuildWithAuditAsync(
                target: "ProofAdvisory/ProofAdvisory.csproj",
                workingDirectory: copy.SolutionRoot,
                cancellationToken: cancellationToken);

        result.ExitCode.ShouldBe(expected: 0, customMessage: DotnetCli.Explain(result: result));
        result.ErrorIds.ShouldBeEmpty(customMessage: result.Output);
        result.WarningIds.ShouldBe(expected: ["NU1903"], customMessage: result.Output);
        feed.RequestCount.ShouldBeGreaterThan(expected: 0, customMessage: result.Output);
    }

    /// <summary>
    /// Upper references Middle only, and Middle references Lower. Upper using Lower's type fails the compile with
    /// CS0246, because transitive project references are disabled (SPEC R2).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Build_TypeFromUnreferencedProject_FailsWithCs0246()
    {
        using SolutionCopy copy = await SolutionCopy.CreateAsync(
                cancellationToken: TestContext.Current.CancellationToken);
        WriteLayerProjects(copy: copy, upperSource: UpperUsesLowerSource);

        ProcessResult result = await DotnetCli.BuildAsync(
                target: UpperProject,
                workingDirectory: copy.SolutionRoot,
                cancellationToken: TestContext.Current.CancellationToken);

        ShouldFailWith(result: result, expectedErrorIds: ["CS0246"]);
    }

    /// <summary>
    /// Upper calling a Middle method whose return type is Lower's type fails the compile with CS0012, because Lower's
    /// type leaks through Middle's public signature and Upper does not reference Lower (SPEC R2).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Build_UnreferencedTypeInPublicSignature_FailsWithCs0012()
    {
        using SolutionCopy copy = await SolutionCopy.CreateAsync(
                cancellationToken: TestContext.Current.CancellationToken);
        WriteLayerProjects(copy: copy, upperSource: UpperCallsMiddleSource);

        ProcessResult result = await DotnetCli.BuildAsync(
                target: UpperProject,
                workingDirectory: copy.SolutionRoot,
                cancellationToken: TestContext.Current.CancellationToken);

        ShouldFailWith(result: result, expectedErrorIds: ["CS0012"]);
    }

    /// <summary>
    /// A block-scoped namespace in a DAL file outside <c>Migrations/</c> fails the build with IDE0161, while the same
    /// violation in a file under DAL <c>Migrations/</c> is not reported: the generated-code exemption covers that
    /// folder only (SPEC R8).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Build_DalViolationOutsideMigrations_Fails()
    {
        using SolutionCopy copy = await SolutionCopy.CreateAsync(
                cancellationToken: TestContext.Current.CancellationToken);
        copy.WriteFile(relativePath: DalOutsideFile, content: DalBlockSource);
        copy.WriteFile(relativePath: DalInsideFile, content: DalMigrationsBlockSource);

        ProcessResult result = await DotnetCli.BuildAsync(
                target: "LangProject.Core.DAL/LangProject.Core.DAL.csproj",
                workingDirectory: copy.SolutionRoot,
                cancellationToken: TestContext.Current.CancellationToken);

        ShouldFailWith(result: result, expectedErrorIds: ["IDE0161"]);
        result.Output.ShouldContain(expected: DalOutsideFile, customMessage: result.Output);
        result.Output.ShouldNotContain(expected: DalInsideFile, customMessage: result.Output);
    }

    /// <summary>
    /// Roslyn honours the <c>.editorconfig</c> forms the suppression scan parses: a section header with a trailing
    /// comment, <c>:</c> as the separator, a trailing comment after the value and the <c>refactoring</c> severity
    /// each switch IDE0161 off for their own file, while a file with no such section still fails with IDE0161.
    /// The scan reports each of the four settings, so the scan and the compiler read the file alike (R-67).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Build_EditorConfigAlternateSyntax_IsHonoured()
    {
        using SolutionCopy copy = await SolutionCopy.CreateAsync(
                cancellationToken: TestContext.Current.CancellationToken);
        string editorConfig = copy.ReadFile(relativePath: ".editorconfig") + AlternateSyntaxSections;
        copy.WriteFile(relativePath: ".editorconfig", content: editorConfig);
        foreach (string name in _alternateSyntaxFiles.Append(element: "Control"))
        {
            copy.WriteFile(
                    relativePath: $"{AlternateSyntaxFolder}{name}Proof.cs",
                    content: DomainBlockSource.Replace(
                            oldValue: "BlockNamespaceProof",
                            newValue: name + "Proof",
                            comparisonType: StringComparison.Ordinal));
        }

        ProcessResult result = await DotnetCli.BuildAsync(
                target: DomainProject,
                workingDirectory: copy.SolutionRoot,
                cancellationToken: TestContext.Current.CancellationToken);

        ShouldFailWith(result: result, expectedErrorIds: ["IDE0161"]);
        result.ErrorIdsInFile(pathEnding: AlternateSyntaxFolder + "ControlProof.cs")
                .ShouldBe(expected: ["IDE0161"], customMessage: result.Output);
        _alternateSyntaxFiles
                .SelectMany(selector: name => result.ErrorIdsInFile(
                        pathEnding: $"{AlternateSyntaxFolder}{name}Proof.cs"))
                .ShouldBeEmpty(customMessage: result.Output);
        SuppressionScanner.Scan(relativePath: SolutionEditorConfig, content: AlternateSyntaxSections)
                .Count.ShouldBe(expected: _alternateSyntaxFiles.Length);
    }

    private const string DomainProject = "LangProject.Core.Domain/LangProject.Core.Domain.csproj";
    private const string WarningsProject = "ProofWarnings/ProofWarnings.csproj";
    private const string AlternateSyntaxFolder = "LangProject.Core.Domain/Proof/";
    private const string SolutionEditorConfig = "src/backend/lang-proj-core/.editorconfig";

    private const string AlternateSyntaxSections = """

            [LangProject.Core.Domain/Proof/HeaderCommentProof.cs] # a trailing comment
            dotnet_diagnostic.IDE0161.severity = none

            [LangProject.Core.Domain/Proof/ColonSeparatorProof.cs]
            dotnet_diagnostic.IDE0161.severity: none

            [LangProject.Core.Domain/Proof/ValueCommentProof.cs]
            dotnet_diagnostic.IDE0161.severity = none # a trailing comment

            [LangProject.Core.Domain/Proof/RefactoringProof.cs]
            dotnet_diagnostic.IDE0161.severity = refactoring

            """;
    private const string UpperProject = "ProofUpper/ProofUpper.csproj";
    private const string DalOutsideFile = "LangProject.Core.DAL/Languages/BlockNamespaceProof.cs";
    private const string DalInsideFile = "LangProject.Core.DAL/Migrations/BlockNamespaceProof.cs";

    private const string DomainBlockSource = """
            namespace LangProject.Core.Domain.Proof
            {
                /// <summary>A type in a block-scoped namespace.</summary>
                public sealed class BlockNamespaceProof
                {
                }
            }

            """;

    private const string DomainAnalyzerSource = """
            namespace LangProject.Core.Domain.Proof;

            /// <summary>An unsealed public class with a positional argument.</summary>
            public class AnalyzerProof
            {
                /// <summary>Initializes a new instance of the <see cref="AnalyzerProof"/> class.</summary>
                /// <param name="text">The text to pad.</param>
                public AnalyzerProof(string text)
                {
                    _text = text;
                }

                /// <summary>Pads the text, passing the width positionally.</summary>
                /// <returns>The padded text.</returns>
                public string Pad()
                {
                    return _text.PadLeft(8);
                }

                private readonly string _text;
            }

            """;

    private const string WarningsProjectXml = """
            <Project Sdk="Microsoft.NET.Sdk">
              <Target Name="ProofWarning" BeforeTargets="BeforeBuild">
                <Warning Code="PROOF001" Text="An MSBuild warning, which must fail the build as an error." />
              </Target>
            </Project>

            """;

    private const string UnusedVariableSource = """
            namespace ProofWarnings;

            internal static class UnusedVariableProof
            {
                internal static int Value()
                {
                    int unused;
                    return 1;
                }
            }

            """;

    private const string AdvisoryProject = """
            <Project Sdk="Microsoft.NET.Sdk">
              <ItemGroup>
                <PackageReference Include="Newtonsoft.Json" />
              </ItemGroup>
            </Project>

            """;

    private const string LowerProject = """
            <Project Sdk="Microsoft.NET.Sdk">
            </Project>

            """;

    private const string MiddleProject = """
            <Project Sdk="Microsoft.NET.Sdk">
              <ItemGroup>
                <ProjectReference Include="../ProofLower/ProofLower.csproj" />
              </ItemGroup>
            </Project>

            """;

    private const string UpperProjectXml = """
            <Project Sdk="Microsoft.NET.Sdk">
              <ItemGroup>
                <ProjectReference Include="../ProofMiddle/ProofMiddle.csproj" />
              </ItemGroup>
            </Project>

            """;

    private const string LowerSource = """
            namespace ProofLower;

            /// <summary>A type that only Middle references directly.</summary>
            public sealed class LowerThing
            {
            }

            """;

    private const string MiddleSource = """
            using ProofLower;

            namespace ProofMiddle;

            /// <summary>Creates Lower's type, so Lower's type is part of Middle's public signature.</summary>
            public static class MiddleFactory
            {
                /// <summary>Creates a <see cref="LowerThing"/>.</summary>
                /// <returns>A new <see cref="LowerThing"/>.</returns>
                public static LowerThing Create()
                {
                    return new LowerThing();
                }
            }

            """;

    private const string UpperUsesLowerSource = """
            using ProofLower;

            namespace ProofUpper;

            /// <summary>Uses Lower's type, although Upper references only Middle.</summary>
            public static class UpperUser
            {
                /// <summary>Creates Lower's type directly.</summary>
                /// <returns>The created value.</returns>
                public static object Use()
                {
                    return new LowerThing();
                }
            }

            """;

    private const string UpperCallsMiddleSource = """
            using ProofMiddle;

            namespace ProofUpper;

            /// <summary>Calls Middle, whose return type comes from Lower.</summary>
            public static class UpperUser
            {
                /// <summary>Calls <see cref="MiddleFactory.Create"/>.</summary>
                /// <returns>The created value.</returns>
                public static object Use()
                {
                    return MiddleFactory.Create();
                }
            }

            """;

    private const string DalBlockSource = """
            namespace LangProject.Core.DAL.Languages
            {
                /// <summary>A type in a block-scoped namespace, outside Migrations.</summary>
                internal sealed class BlockNamespaceProof
                {
                }
            }

            """;

    private const string DalMigrationsBlockSource = """
            namespace LangProject.Core.DAL.Migrations
            {
                /// <summary>A type in a block-scoped namespace, inside Migrations.</summary>
                internal sealed class BlockNamespaceProof
                {
                }
            }

            """;

    private static readonly string[] _alternateSyntaxFiles =
            ["HeaderComment", "ColonSeparator", "ValueComment", "Refactoring"];

    private static void WriteLayerProjects(SolutionCopy copy, string upperSource)
    {
        copy.WriteFile(relativePath: "ProofLower/ProofLower.csproj", content: LowerProject);
        copy.WriteFile(relativePath: "ProofLower/LowerThing.cs", content: LowerSource);
        copy.WriteFile(relativePath: "ProofMiddle/ProofMiddle.csproj", content: MiddleProject);
        copy.WriteFile(relativePath: "ProofMiddle/MiddleFactory.cs", content: MiddleSource);
        copy.WriteFile(relativePath: UpperProject, content: UpperProjectXml);
        copy.WriteFile(relativePath: "ProofUpper/UpperUser.cs", content: upperSource);
    }

    private static void ShouldFailWith(ProcessResult result, IReadOnlyList<string> expectedErrorIds)
    {
        result.ExitCode.ShouldNotBe(expected: 0, customMessage: result.Output);
        result.ErrorIds.ShouldNotContain(
                elementPredicate: id => id.StartsWith(value: "NU", comparisonType: StringComparison.Ordinal),
                customMessage: DotnetCli.Explain(result: result));
        result.ErrorIds.ShouldBe(expected: expectedErrorIds, customMessage: result.Output);
    }
}
