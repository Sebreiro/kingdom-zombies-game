using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Files;

/// <summary>
/// The D-84 file scan: every tracked text file is valid UTF-8, has LF line endings only, ends with a newline and
/// contains no tab character and no trailing whitespace. Two scoped exemptions exist. Files under
/// <c>src/backend/lang-proj-core/LangProject.Core.DAL/Migrations/</c> may start with a UTF-8 BOM, because
/// <c>dotnet ef</c> writes one (SPEC R8, generated code); every other rule still applies to them. Files named
/// <c>packages.lock.json</c> may lack the final newline, because NuGet writes them without one.
/// </summary>
public sealed class SourceFileFormatTests
{
    /// <summary>
    /// Every tracked text file outside <c>.claude/</c> and <c>.planning/</c> follows the format rules, as listed by
    /// <c>git ls-files</c> from the repository root; text is told from binary by content.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task FormatRule_TrackedFiles_HaveNoViolations()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        IReadOnlyList<string> trackedFiles = await TrackedFiles.ListAsync(cancellationToken: cancellationToken);
        List<string> checkedFiles = [.. trackedFiles.Where(predicate: SourceFileFormat.IsChecked)];

        var violations = new List<string>();
        foreach (string relativePath in checkedFiles)
        {
            string fullPath = Path.Combine(path1: RepositoryLayout.RepositoryRoot, path2: relativePath);
            byte[]? content = File.Exists(path: fullPath)
                    ? await File.ReadAllBytesAsync(path: fullPath, cancellationToken: cancellationToken)
                    : null;
            violations.AddRange(
                    collection: SourceFileFormat.CheckTracked(relativePath: relativePath, content: content));
        }

        checkedFiles.ShouldContain(elementPredicate: path => path.EndsWith(
                value: "Directory.Build.props",
                comparisonType: StringComparison.Ordinal));
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>A tracked path with no file in the working tree is reported instead of skipped.</summary>
    [Fact]
    public void FormatRule_MissingTrackedFile_IsReported()
    {
        IReadOnlyList<string> violations = SourceFileFormat.CheckTracked(relativePath: OrdinaryPath, content: null);

        violations.ShouldHaveSingleItem().ShouldContain(expected: "not a regular file");
    }

    /// <summary>
    /// A warning that the file-list command writes to the standard error stays out of the tracked-file list, so the
    /// last path is still read and checked.
    /// </summary>
    [Fact]
    public void TrackedFiles_StandardErrorWarning_IsNotAPath()
    {
        var result = new ProcessResult(
                exitCode: 0,
                standardOutput: "README.md\0docs/how-to-launch.md\0",
                standardError: "warning: unable to access '/home/user/.config/attributes': Permission denied\n");

        TrackedFiles.ParsePaths(result: result).ShouldBe(expected: ["README.md", "docs/how-to-launch.md"]);
    }

    /// <summary>
    /// A shell script, a file type the old extension allow-list did not name, is checked: its CRLF ending is reported.
    /// </summary>
    [Fact]
    public void FormatRule_UnlistedTextFileType_IsChecked()
    {
        IReadOnlyList<string> violations = SourceFileFormat.CheckTracked(
                relativePath: "scripts/build.sh",
                content: Utf8(text: "#!/bin/sh\r\necho hi\r\n"));

        violations.ShouldHaveSingleItem().ShouldContain(expected: "CR");
    }

    /// <summary>Content with a NUL byte near its start is binary and is not checked, whatever its name.</summary>
    [Fact]
    public void FormatRule_BinaryContent_IsSkipped()
    {
        byte[] content = [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00, 0x00, 0x09];

        SourceFileFormat.CheckTracked(relativePath: "assets/sample.bin", content: content).ShouldBeEmpty();
        SourceFileFormat.IsText(content: content).ShouldBeFalse();
    }

    /// <summary>A CRLF line ending is reported.</summary>
    [Fact]
    public void FormatRule_Crlf_IsReported()
    {
        IReadOnlyList<string> violations = SourceFileFormat.Check(
                relativePath: OrdinaryPath,
                content: Utf8(text: "namespace A;\r\n"));

        violations.ShouldHaveSingleItem().ShouldContain(expected: "CR");
    }

    /// <summary>A tab character is reported.</summary>
    [Fact]
    public void FormatRule_Tab_IsReported()
    {
        IReadOnlyList<string> violations = SourceFileFormat.Check(
                relativePath: OrdinaryPath,
                content: Utf8(text: "namespace A;\n\tclass B;\n"));

        violations.ShouldHaveSingleItem().ShouldContain(expected: "tab");
    }

    /// <summary>A file whose last byte is not a newline is reported.</summary>
    [Fact]
    public void FormatRule_MissingFinalNewline_IsReported()
    {
        IReadOnlyList<string> violations = SourceFileFormat.Check(
                relativePath: OrdinaryPath,
                content: Utf8(text: "namespace A;"));

        violations.ShouldHaveSingleItem().ShouldContain(expected: "newline");
    }

    /// <summary>A line that ends with a space is reported, in any checked file type.</summary>
    [Fact]
    public void FormatRule_TrailingWhitespace_IsReported()
    {
        IReadOnlyList<string> violations = SourceFileFormat.Check(
                relativePath: "docs/workflow/git-workflow.md",
                content: Utf8(text: "# Title \n\nText.\n"));

        violations.ShouldHaveSingleItem().ShouldContain(expected: "whitespace");
    }

    /// <summary>A UTF-8 BOM outside DAL <c>Migrations/</c> is reported, even in another DAL folder.</summary>
    [Fact]
    public void FormatRule_Bom_IsReportedOutsideMigrations()
    {
        IReadOnlyList<string> violations = SourceFileFormat.Check(
                relativePath: "src/backend/lang-proj-core/LangProject.Core.DAL/Languages/LanguageConfiguration.cs",
                content: WithBom(text: "namespace A;\n"));

        violations.ShouldHaveSingleItem().ShouldContain(expected: "BOM");
    }

    /// <summary>A byte sequence that is not valid UTF-8 is reported.</summary>
    [Fact]
    public void FormatRule_InvalidUtf8_IsReported()
    {
        IReadOnlyList<string> violations = SourceFileFormat.Check(
                relativePath: OrdinaryPath,
                content: [0x61, 0xC3, 0x28, 0x0A]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: "UTF-8");
    }

    /// <summary>A UTF-8 BOM in a file under DAL <c>Migrations/</c> is allowed.</summary>
    [Fact]
    public void FormatRule_BomInMigrations_IsAllowed()
    {
        IReadOnlyList<string> violations = SourceFileFormat.Check(
                relativePath: MigrationsPath,
                content: WithBom(text: "namespace A;\n"));

        violations.ShouldBeEmpty();
    }

    /// <summary>The Migrations exemption covers the BOM only: a tab in a migration is still reported.</summary>
    [Fact]
    public void FormatRule_TabInMigrations_IsReported()
    {
        IReadOnlyList<string> violations = SourceFileFormat.Check(
                relativePath: MigrationsPath,
                content: WithBom(text: "namespace A;\n\tclass B;\n"));

        violations.ShouldHaveSingleItem().ShouldContain(expected: "tab");
    }

    /// <summary>A NuGet lock file without a final newline is allowed; a tab in it is still reported.</summary>
    [Fact]
    public void FormatRule_LockFileWithoutFinalNewline_IsAllowed()
    {
        const string LockFile = "src/backend/lang-proj-core/LangProject.Core.Domain/packages.lock.json";

        SourceFileFormat.Check(relativePath: LockFile, content: Utf8(text: "{\n}")).ShouldBeEmpty();
        SourceFileFormat.Check(relativePath: LockFile, content: Utf8(text: "{\n\t}"))
                .ShouldHaveSingleItem()
                .ShouldContain(expected: "tab");
    }

    /// <summary>A clean UTF-8 file with Cyrillic text, LF endings and a final newline passes.</summary>
    [Fact]
    public void FormatRule_CleanFile_HasNoViolations()
    {
        IReadOnlyList<string> violations = SourceFileFormat.Check(
                relativePath: OrdinaryPath,
                content: Utf8(text: "namespace A;\n\n// Привет\n"));

        violations.ShouldBeEmpty();
    }

    /// <summary>
    /// The scan reads every path except agent and planning files and the binary deny-list, whatever its extension,
    /// so a new text file type is covered without an edit.
    /// </summary>
    /// <param name="relativePath">A repository-relative path.</param>
    /// <param name="expected">Whether the scan checks the file.</param>
    [Theory]
    [InlineData("src/backend/lang-proj-core/LangProject.Core.slnx", true)]
    [InlineData("src/backend/lang-proj-core/.editorconfig", true)]
    [InlineData(".gitattributes", true)]
    [InlineData(".devcontainer/Dockerfile", true)]
    [InlineData(".devcontainer/Dockerfile.dockerignore", true)]
    [InlineData(".github/workflows/backend-fast.yml", true)]
    [InlineData("docs/workflow/git-workflow.md", true)]
    [InlineData("deploy/.env.example", true)]
    [InlineData("deploy/compose.yaml", true)]
    [InlineData("deploy/db-roles.sql", true)]
    [InlineData("src/backend/lang-proj-core/Dockerfile", true)]
    [InlineData("scripts/build.sh", true)]
    [InlineData("scripts/build.ps1", true)]
    [InlineData("src/backend/lang-proj-core/.globalconfig", true)]
    [InlineData("src/frontend/app/lib/main.dart", true)]
    [InlineData("LICENSE", true)]
    [InlineData("deploy/Dockerfile.api", true)]
    [InlineData(".planning/STATE.md", false)]
    [InlineData(".claude/settings.json", false)]
    [InlineData("assets/logo.png", false)]
    public void FormatRule_FileSelection_MatchesTextFiles(string relativePath, bool expected)
    {
        SourceFileFormat.IsChecked(relativePath: relativePath).ShouldBe(expected: expected);
    }

    private const string OrdinaryPath = "src/backend/lang-proj-core/LangProject.Core.Domain/Languages/Language.cs";
    private const string MigrationsPath =
            "src/backend/lang-proj-core/LangProject.Core.DAL/Migrations/20261019165104_InitialCreate.cs";

    private static byte[] Utf8(string text)
    {
        return Encoding.UTF8.GetBytes(s: text);
    }

    private static byte[] WithBom(string text)
    {
        return [0xEF, 0xBB, 0xBF, .. Utf8(text: text)];
    }
}
