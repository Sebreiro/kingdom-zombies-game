using System;
using System.Collections.Generic;
using LangProject.Core.ArchitectureTests.Types.Fixtures;
using LangProject.Core.Domain.Languages;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Types;

/// <summary>
/// Tests of the Domain entity rule (SPEC R6, ARCH-05): every setter private and not <c>init</c>, a parameterized
/// constructor, and a private <c>[Obsolete]</c> parameterless ORM constructor. The rule runs on the Domain
/// assembly and on one bad-on-purpose fixture per violation.
/// </summary>
public sealed class EntityRuleTests
{
    /// <summary>Every entity in the Domain assembly passes; the selector matches <see cref="Language"/>.</summary>
    [Fact]
    public void Entities_Production_FollowEntityRules()
    {
        IReadOnlyList<Type> entities = TypeConventionRules.SelectEntities(
                domainTypes: ProductionTypes.TypesOf(assembly: ProductionTypes.Domain));

        entities.ShouldContain(expected: typeof(Language));
        IReadOnlyList<string> violations = TypeConventionRules.CheckEntities(entities: entities);
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>The valid fixture passes, so the rule does not over-report.</summary>
    [Fact]
    public void Entities_ValidFixture_IsAccepted()
    {
        IReadOnlyList<string> violations =
                TypeConventionRules.CheckEntities(entities: [typeof(EntityFixtures.ValidEntity)]);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>A public setter is reported.</summary>
    [Fact]
    public void Entities_PublicSetter_IsReported()
    {
        string violation = SingleViolation(entity: typeof(EntityFixtures.PublicSetterEntity));

        violation.ShouldContain(expected: nameof(EntityFixtures.PublicSetterEntity));
        violation.ShouldContain(expected: "public setter");
    }

    /// <summary>An internal setter is reported.</summary>
    [Fact]
    public void Entities_InternalSetter_IsReported()
    {
        string violation = SingleViolation(entity: typeof(EntityFixtures.InternalSetterEntity));

        violation.ShouldContain(expected: nameof(EntityFixtures.InternalSetterEntity));
        violation.ShouldContain(expected: "internal setter");
    }

    /// <summary>A protected setter is reported.</summary>
    [Fact]
    public void Entities_ProtectedSetter_IsReported()
    {
        string violation = SingleViolation(entity: typeof(EntityFixtures.ProtectedSetterEntity));

        violation.ShouldContain(expected: nameof(EntityFixtures.ProtectedSetterEntity));
        violation.ShouldContain(expected: "protected setter");
    }

    /// <summary>An <c>init</c> setter is reported.</summary>
    [Fact]
    public void Entities_InitSetter_IsReported()
    {
        string violation = SingleViolation(entity: typeof(EntityFixtures.InitSetterEntity));

        violation.ShouldContain(expected: nameof(EntityFixtures.InitSetterEntity));
        violation.ShouldContain(expected: "init setter");
    }

    /// <summary>An entity without a parameterless ORM constructor is reported.</summary>
    [Fact]
    public void Entities_MissingOrmConstructor_IsReported()
    {
        string violation = SingleViolation(entity: typeof(EntityFixtures.MissingOrmConstructorEntity));

        violation.ShouldContain(expected: nameof(EntityFixtures.MissingOrmConstructorEntity));
        violation.ShouldContain(expected: "no parameterless ORM constructor");
    }

    /// <summary>An ORM constructor that is not private is reported.</summary>
    [Fact]
    public void Entities_OrmConstructorNotPrivate_IsReported()
    {
        string violation = SingleViolation(entity: typeof(EntityFixtures.OrmConstructorNotPrivateEntity));

        violation.ShouldContain(expected: nameof(EntityFixtures.OrmConstructorNotPrivateEntity));
        violation.ShouldContain(expected: "is not private");
    }

    /// <summary>An ORM constructor without <c>[Obsolete]</c> is reported.</summary>
    [Fact]
    public void Entities_OrmConstructorNotObsolete_IsReported()
    {
        string violation = SingleViolation(entity: typeof(EntityFixtures.OrmConstructorNotObsoleteEntity));

        violation.ShouldContain(expected: nameof(EntityFixtures.OrmConstructorNotObsoleteEntity));
        violation.ShouldContain(expected: "[Obsolete]");
    }

    /// <summary>An entity without a constructor that takes parameters is reported.</summary>
    [Fact]
    public void Entities_MissingParameterizedConstructor_IsReported()
    {
        string violation = SingleViolation(entity: typeof(EntityFixtures.MissingParameterizedConstructorEntity));

        violation.ShouldContain(expected: nameof(EntityFixtures.MissingParameterizedConstructorEntity));
        violation.ShouldContain(expected: "no constructor with parameters");
    }

    private static string SingleViolation(Type entity)
    {
        return TypeConventionRules.CheckEntities(entities: [entity]).ShouldHaveSingleItem();
    }
}
