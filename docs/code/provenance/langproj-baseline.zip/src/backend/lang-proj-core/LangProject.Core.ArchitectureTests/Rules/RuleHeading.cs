using System.Collections.Generic;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// A Markdown heading of a code-rule doc, its GitHub anchor and the rule-matrix rows its <c>Enforcement:</c> line
/// links to.
/// </summary>
internal sealed class RuleHeading
{
    /// <summary>Initializes a new instance of the <see cref="RuleHeading"/> class.</summary>
    /// <param name="level">The heading level: 2 for <c>##</c>, 3 for <c>###</c>.</param>
    /// <param name="text">The heading text without the leading hashes.</param>
    /// <param name="slug">The anchor GitHub gives the heading.</param>
    /// <param name="enforcementIds">
    /// The rule-matrix row IDs linked from the first non-blank line after the heading when that line starts with
    /// <c>Enforcement:</c>; empty otherwise.
    /// </param>
    internal RuleHeading(int level, string text, string slug, IReadOnlyList<string> enforcementIds)
    {
        Level = level;
        Text = text;
        Slug = slug;
        EnforcementIds = enforcementIds;
    }

    /// <summary>Gets the heading level.</summary>
    internal int Level { get; }

    /// <summary>Gets the heading text.</summary>
    internal string Text { get; }

    /// <summary>Gets the anchor GitHub gives the heading.</summary>
    internal string Slug { get; }

    /// <summary>Gets the rule-matrix row IDs the heading's <c>Enforcement:</c> line links to.</summary>
    internal IReadOnlyList<string> EnforcementIds { get; }
}
