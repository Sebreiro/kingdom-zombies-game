using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Documentation;

/// <summary>
/// The docs index tree (SPEC R17, R19, DOCS-02 to DOCS-04): root, backend and frontend <c>CLAUDE.md</c> files that
/// are exactly <c>@AGENTS.md</c>, <c>AGENTS.md</c> files without <c>@</c> imports that the root index links, exactly
/// one linked GSD workflow doc of at most 150 lines with no generated markers, and complete backend decision
/// records linked from the backend index. Each rule runs on the repository and on synthetic docs.
/// </summary>
public sealed class AgentIndexTests
{
    /// <summary>Root, backend and frontend <c>CLAUDE.md</c> each equal <c>@AGENTS.md</c> and a final newline.</summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task ClaudeFiles_Content_IsExactlyAtAgents()
    {
        RepositoryDocs docs = await LoadAsync();

        docs.Text(path: "src/backend/CLAUDE.md").ShouldNotBeNull();
        IReadOnlyList<string> violations = AgentIndexRules.CheckClaudeFiles(docs: docs);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// A <c>CLAUDE.md</c> without the final newline, with a second import or with prose is reported, and so is one
    /// without an <c>AGENTS.md</c> beside it.
    /// </summary>
    /// <param name="text">The text of the synthetic backend <c>CLAUDE.md</c>.</param>
    [Theory]
    [InlineData("@AGENTS.md")]
    [InlineData("@AGENTS.md\n@docs/rules.md\n")]
    [InlineData("Read AGENTS.md.\n")]
    public void ClaudeFiles_OtherContent_IsReported(string text)
    {
        Dictionary<string, string> documents = ValidTree();
        documents["src/backend/CLAUDE.md"] = text;

        IReadOnlyList<string> violations = AgentIndexRules.CheckClaudeFiles(docs: Repository(documents: documents));

        violations.ShouldHaveSingleItem().ShouldStartWith(expected: "src/backend/CLAUDE.md:");
    }

    /// <summary>A <c>CLAUDE.md</c> with no <c>AGENTS.md</c> beside it and a missing index file are reported.</summary>
    [Fact]
    public void ClaudeFiles_MissingPair_IsReported()
    {
        Dictionary<string, string> documents = ValidTree();
        documents.Remove(key: "src/frontend/AGENTS.md");
        documents.Remove(key: "src/backend/CLAUDE.md");
        RepositoryDocs docs = Repository(documents: documents);

        IReadOnlyList<string> claudeViolations = AgentIndexRules.CheckClaudeFiles(docs: docs);
        IReadOnlyList<string> agentsViolations = AgentIndexRules.CheckAtImports(docs: docs);

        claudeViolations.Count.ShouldBe(expected: 2);
        claudeViolations.ShouldContain(elementPredicate: violation => violation.Contains(
                value: "src/backend/CLAUDE.md does not exist",
                comparisonType: StringComparison.Ordinal));
        claudeViolations.ShouldContain(elementPredicate: violation => violation.Contains(
                value: "src/frontend/CLAUDE.md: no AGENTS.md",
                comparisonType: StringComparison.Ordinal));
        agentsViolations.ShouldHaveSingleItem().ShouldContain(expected: "src/frontend/AGENTS.md does not exist");
    }

    /// <summary>No line of any <c>AGENTS.md</c> starts with <c>@</c>.</summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task AgentsFiles_Lines_HaveNoAtImports()
    {
        RepositoryDocs docs = await LoadAsync();

        docs.Text(path: "src/backend/AGENTS.md").ShouldNotBeNull();
        IReadOnlyList<string> violations = AgentIndexRules.CheckAtImports(docs: docs);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>An <c>AGENTS.md</c> line that starts with <c>@</c>, indented or not, is reported.</summary>
    /// <param name="line">The import line added to the synthetic backend index.</param>
    [Theory]
    [InlineData("@docs/rule-matrix.md")]
    [InlineData("  @docs/rule-matrix.md")]
    public void AgentsFiles_AtImport_IsReported(string line)
    {
        Dictionary<string, string> documents = ValidTree();
        documents["src/backend/AGENTS.md"] = "# Backend\n\n" + line + "\n";

        IReadOnlyList<string> violations = AgentIndexRules.CheckAtImports(docs: Repository(documents: documents));

        violations.ShouldHaveSingleItem().ShouldStartWith(expected: "src/backend/AGENTS.md:3:");
    }

    /// <summary>
    /// An <c>@path</c> import in the middle of an <c>AGENTS.md</c> line is reported; one in a code span or a fenced
    /// block, an e-mail address and a bare <c>@name</c> are not.
    /// </summary>
    /// <param name="text">The text added to the synthetic backend index.</param>
    /// <param name="reported">Whether the text is reported.</param>
    [Theory]
    [InlineData("See @docs/rule-matrix.md for the rules.", true)]
    [InlineData("Rules: @AGENTS.md", true)]
    [InlineData("See `@docs/rule-matrix.md` for the rules.", false)]
    [InlineData("```\n@docs/rule-matrix.md\n```", false)]
    [InlineData("Mail admin@example.com or ask @maintainers.", false)]
    public void AgentsFiles_InlineAtImport_IsReported(string text, bool reported)
    {
        Dictionary<string, string> documents = ValidTree();
        documents["src/backend/AGENTS.md"] = "# Backend\n\n" + text + "\n";

        IReadOnlyList<string> violations = AgentIndexRules.CheckAtImports(docs: Repository(documents: documents));

        violations.Count.ShouldBe(
                expected: reported ? 1 : 0,
                customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// An agent memory file that Claude Code loads is reported wherever it is tracked: <c>.claude/CLAUDE.md</c>,
    /// which the docs checks skip, a differently cased <c>claude.md</c> and a <c>CLAUDE.local.md</c>.
    /// </summary>
    /// <param name="path">The tracked memory file.</param>
    [Theory]
    [InlineData(".claude/CLAUDE.md")]
    [InlineData("docs/claude.md")]
    [InlineData("CLAUDE.local.md")]
    public void ClaudeFiles_HiddenOrRenamedMemoryFile_IsReported(string path)
    {
        var docs = new RepositoryDocs(trackedFiles: [path], documents: ValidTree());

        IReadOnlyList<string> violations = AgentIndexRules.CheckClaudeFiles(docs: docs);

        violations.ShouldHaveSingleItem().ShouldStartWith(expected: path + ":");
    }

    /// <summary>The root <c>AGENTS.md</c> links every other <c>AGENTS.md</c> of the repository.</summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task AgentsFiles_RootIndex_LinksEverySubIndex()
    {
        RepositoryDocs docs = await LoadAsync();

        docs.Text(path: "src/frontend/AGENTS.md").ShouldNotBeNull();
        IReadOnlyList<string> violations = AgentIndexRules.CheckSubIndexesLinked(docs: docs);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>An <c>AGENTS.md</c> that the root index does not link is reported.</summary>
    [Fact]
    public void AgentsFiles_UnlinkedSubIndex_IsReported()
    {
        Dictionary<string, string> documents = ValidTree();
        documents["deploy/AGENTS.md"] = "# Deploy\n";

        IReadOnlyList<string> violations =
                AgentIndexRules.CheckSubIndexesLinked(docs: Repository(documents: documents));

        violations.ShouldHaveSingleItem().ShouldContain(expected: "deploy/AGENTS.md");
    }

    /// <summary>The <c>AGENTS.md</c> files link one GSD workflow doc, <c>docs/workflow/gsd.md</c>, once.</summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task GsdDoc_AgentsTree_LinksExactlyOne()
    {
        RepositoryDocs docs = await LoadAsync();

        docs.Text(path: AgentIndexRules.GsdDocPath).ShouldNotBeNull();
        IReadOnlyList<string> violations = AgentIndexRules.CheckGsdDocLinks(docs: docs);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// A second GSD workflow doc linked from an index, a second link to the one doc, and no link at all are each
    /// reported once.
    /// </summary>
    /// <param name="backendIndex">The text of the synthetic backend index.</param>
    /// <param name="rootIndex">The text of the synthetic root index, or <see langword="null"/> to keep it.</param>
    /// <param name="expected">Text the single violation contains.</param>
    [Theory]
    [InlineData("[Workflow](../../docs/workflow/GSD-quick.md)\n", null, "docs/workflow/GSD-quick.md")]
    [InlineData("[Workflow](../../docs/workflow/gsd.md)\n", null, "2 times")]
    [InlineData("# Backend\n", "# Root\n\n[Backend](src/backend/AGENTS.md)\n", "0 times")]
    public void GsdDoc_OtherOrRepeatedLink_IsReported(string backendIndex, string? rootIndex, string expected)
    {
        Dictionary<string, string> documents = ValidTree();
        documents["src/backend/AGENTS.md"] = backendIndex;
        documents["AGENTS.md"] = rootIndex ?? documents["AGENTS.md"];

        IReadOnlyList<string> violations = AgentIndexRules.CheckGsdDocLinks(docs: Repository(documents: documents));

        violations.ShouldHaveSingleItem().ShouldContain(expected: expected);
    }

    /// <summary>The GSD workflow doc has at most 150 lines and no generated <c>&lt;!-- GSD:</c> marker.</summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task GsdDoc_Content_IsShortAndMarkerFree()
    {
        RepositoryDocs docs = await LoadAsync();
        string? text = docs.Text(path: AgentIndexRules.GsdDocPath);

        text.ShouldNotBeNullOrEmpty();
        IReadOnlyList<string> violations = AgentIndexRules.CheckGsdDoc(text: text);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>The GSD doc rule accepts a doc of 150 lines and rejects one of 151 (SPEC R17 boundary).</summary>
    [Fact]
    public void GsdDocRule_150LinesPasses_151Fails()
    {
        string atLimit = Lines(count: 150);
        string overLimit = Lines(count: 151);

        AgentIndexRules.CountLines(text: atLimit).ShouldBe(expected: 150);
        AgentIndexRules.CheckGsdDoc(text: atLimit).ShouldBeEmpty();
        AgentIndexRules.CheckGsdDoc(text: overLimit).ShouldHaveSingleItem().ShouldContain(expected: "151 lines");
    }

    /// <summary>A generated section marker and a missing doc are reported; the line count reads a last line.</summary>
    [Fact]
    public void GsdDocRule_MarkerOrMissingDoc_IsReported()
    {
        IReadOnlyList<string> marker = AgentIndexRules.CheckGsdDoc(
                text: "# GSD\n\n<!-- GSD:workflow-start source:GSD defaults -->\n");
        IReadOnlyList<string> missing = AgentIndexRules.CheckGsdDoc(text: null);

        marker.ShouldHaveSingleItem().ShouldContain(expected: AgentIndexRules.GsdMarker);
        missing.ShouldHaveSingleItem().ShouldContain(expected: "does not exist");
        AgentIndexRules.CountLines(text: "one\ntwo").ShouldBe(expected: 2);
        AgentIndexRules.CountLines(text: string.Empty).ShouldBe(expected: 0);
    }

    /// <summary>
    /// The layer-graph, provider-abstraction and enforcement-approach records exist, are linked from
    /// <c>src/backend/AGENTS.md</c>, and each has its status line and the Context, Decision and Consequences
    /// headings (SPEC R19).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task DecisionRecords_BackendIndex_ExistLinkedAndComplete()
    {
        RepositoryDocs docs = await LoadAsync();

        docs.Documents.Keys.Count(predicate: path => path.StartsWith(
                value: AgentIndexRules.DecisionRecordsFolder,
                comparisonType: StringComparison.Ordinal)).ShouldBeGreaterThanOrEqualTo(expected: 3);
        IReadOnlyList<string> violations = AgentIndexRules.CheckDecisionRecords(docs: docs);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>A record that lacks a heading or the status line is reported once, naming what it lacks.</summary>
    /// <param name="line">The line the synthetic record lacks.</param>
    /// <param name="expected">Text the single violation contains.</param>
    [Theory]
    [InlineData("## Context", "'## Context'")]
    [InlineData("## Decision", "'## Decision'")]
    [InlineData("## Consequences", "'## Consequences'")]
    [InlineData("Status: Accepted", "'Status: ...'")]
    public void DecisionRecords_MissingSection_IsReported(string line, string expected)
    {
        Dictionary<string, string> documents = ValidTree();
        documents[LayerGraphRecord] = ValidRecord.Replace(
                oldValue: line + "\n",
                newValue: "Other.\n",
                comparisonType: StringComparison.Ordinal);

        IReadOnlyList<string> violations =
                AgentIndexRules.CheckDecisionRecords(docs: Repository(documents: documents));

        string violation = violations.ShouldHaveSingleItem();
        violation.ShouldStartWith(expected: LayerGraphRecord);
        violation.ShouldContain(expected: expected);
    }

    /// <summary>
    /// A missing required record, and a record the backend index does not link, are reported; a complete tree passes
    /// every index rule.
    /// </summary>
    [Fact]
    public void DecisionRecords_MissingOrUnlinked_AreReported()
    {
        Dictionary<string, string> documents = ValidTree();
        RepositoryDocs valid = Repository(documents: ValidTree());
        documents.Remove(key: LayerGraphRecord);
        documents[AgentIndexRules.DecisionRecordsFolder + "0004-extra.md"] = ValidRecord;

        IReadOnlyList<string> violations =
                AgentIndexRules.CheckDecisionRecords(docs: Repository(documents: documents));

        violations.Count.ShouldBe(expected: 2);
        violations.ShouldContain(elementPredicate: violation => violation.StartsWith(
                value: LayerGraphRecord + " does not exist",
                comparisonType: StringComparison.Ordinal));
        violations.ShouldContain(elementPredicate: violation => violation.Contains(
                value: "0004-extra.md: not linked",
                comparisonType: StringComparison.Ordinal));
        AgentIndexRules.CheckClaudeFiles(docs: valid).ShouldBeEmpty();
        AgentIndexRules.CheckAtImports(docs: valid).ShouldBeEmpty();
        AgentIndexRules.CheckSubIndexesLinked(docs: valid).ShouldBeEmpty();
        AgentIndexRules.CheckGsdDocLinks(docs: valid).ShouldBeEmpty();
        AgentIndexRules.CheckDecisionRecords(docs: valid).ShouldBeEmpty();
    }

    private const string LayerGraphRecord = "src/backend/docs/decisions/0001-layer-graph.md";

    private const string ValidRecord = """
            # 0001 Record

            Status: Accepted

            ## Context

            Why.

            ## Decision

            What.

            ## Consequences

            What follows.

            """;

    private static async Task<RepositoryDocs> LoadAsync()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        return await RepositoryDocs.LoadAsync(cancellationToken: cancellationToken);
    }

    private static Dictionary<string, string> ValidTree()
    {
        return new Dictionary<string, string>(comparer: StringComparer.Ordinal)
        {
            ["CLAUDE.md"] = AgentIndexRules.ClaudeFileContent,
            ["AGENTS.md"] = "# Root\n\n[GSD](docs/workflow/gsd.md)\n[Backend](src/backend/AGENTS.md)\n"
                    + "[Frontend](src/frontend/AGENTS.md)\n",
            ["src/backend/CLAUDE.md"] = AgentIndexRules.ClaudeFileContent,
            ["src/backend/AGENTS.md"] = "# Backend\n\n[0001](docs/decisions/0001-layer-graph.md)\n"
                    + "[0002](docs/decisions/0002-provider-abstraction.md)\n"
                    + "[0003](docs/decisions/0003-enforcement-approach.md)\n",
            ["src/frontend/CLAUDE.md"] = AgentIndexRules.ClaudeFileContent,
            ["src/frontend/AGENTS.md"] = "# Frontend\n\n[Root](../../AGENTS.md)\n",
            [AgentIndexRules.GsdDocPath] = "# GSD\n",
            [LayerGraphRecord] = ValidRecord,
            ["src/backend/docs/decisions/0002-provider-abstraction.md"] = ValidRecord,
            ["src/backend/docs/decisions/0003-enforcement-approach.md"] = ValidRecord,
        };
    }

    private static RepositoryDocs Repository(Dictionary<string, string> documents)
    {
        return new RepositoryDocs(trackedFiles: [], documents: documents);
    }

    private static string Lines(int count)
    {
        return string.Concat(
                values: Enumerable.Range(start: 1, count: count).Select(selector: number => $"{number}\n"));
    }
}
