using System.Collections.Generic;

namespace LangProject.Core.ArchitectureTests.Deployment;

/// <summary>One build stage of a Dockerfile: its <c>FROM</c> image, its name and its later instructions.</summary>
internal sealed class DockerfileStage
{
    /// <summary>Initializes a new instance of the <see cref="DockerfileStage"/> class.</summary>
    /// <param name="image">The image after <c>FROM</c>, such as <c>postgres:18.6</c>.</param>
    /// <param name="name">The stage name after <c>AS</c>; empty when the stage has none.</param>
    /// <param name="instructions">
    /// The stage's instructions after <c>FROM</c>, one per item, with continuation lines joined.
    /// </param>
    internal DockerfileStage(string image, string name, IReadOnlyList<string> instructions)
    {
        Image = image;
        Name = name;
        Instructions = instructions;
    }

    /// <summary>Gets the image after <c>FROM</c>.</summary>
    internal string Image { get; }

    /// <summary>Gets the stage name after <c>AS</c>; empty when the stage has none.</summary>
    internal string Name { get; }

    /// <summary>Gets the stage's instructions after <c>FROM</c>, with continuation lines joined.</summary>
    internal IReadOnlyList<string> Instructions { get; }

    /// <summary>Gets the image's repository, the part before the last <c>:</c> tag separator.</summary>
    internal string Repository => SplitImage().Repository;

    /// <summary>Gets the image's tag, the part after the last <c>:</c>; empty when the image has none.</summary>
    internal string Tag => SplitImage().Tag;

    private (string Repository, string Tag) SplitImage()
    {
        int colon = Image.LastIndexOf(value: ':');
        int slash = Image.LastIndexOf(value: '/');
        return colon > slash ? (Image[..colon], Image[(colon + 1)..]) : (Image, string.Empty);
    }
}
