# LangProject.Core.ArchitectureTests

## Responsibility

The architecture and docs tests of the backend, an xUnit v3 test executable. They read the working tree
they were built from (the `.slnx`, every build file, the tracked files, the docs and the production
assemblies) and fail when the code, the build settings or the docs break a written rule. Each rule is a pure
function that runs once on the repository and once on a bad-on-purpose input, so the check itself is
proven. Some proofs run a real `dotnet build`, `dotnet pack` or `dotnet ef` in a throwaway copy of the
solution.

## Allowed dependencies

- `LangProject.Core.API`
- `LangProject.Core.API.Abstractions`
- `LangProject.Core.Application`
- `LangProject.Core.Application.Abstractions`
- `LangProject.Core.CompositionRoot`
- `LangProject.Core.DAL`
- `LangProject.Core.DAL.Abstractions`
- `LangProject.Core.Domain`
- `LangProject.Core.Integration.Abstractions`
- `Sebreiro.UnitOfWork.Abstractions`
- `Sebreiro.UnitOfWork.EntityFrameworkCore`

This is every non-test project except the analyzer, as the
[edge table](../../../docs/CodeRules/code-architecture.md#allowed-project-references) says; each new
non-test project joins it. The analyzer-only edge to `Sebreiro.CodeRules.Analyzers` comes from
`Directory.Build.targets` and is not listed. Because the analyzer is not referenced, the matrix checks
read its `SCR` IDs from its sources and its release-tracking file.

## Rules

- Tests follow every production rule, use Shouldly and are named `Method_State_Expected`
  ([R-46](../../../docs/rule-matrix.md#r-46), [R-47](../../../docs/rule-matrix.md#r-47),
  [R-48](../../../docs/rule-matrix.md#r-48)).
- Every production check asserts that its input is not empty, so a check that selects nothing fails
  instead of passing.
- Every rule has at least one synthetic proof that the rule reports a bad input.
- The project set comes from `LangProject.Core.slnx`, never from a glob of csproj files; every
  tracked backend csproj must be listed there.
- The project-graph and project-property rules read what MSBuild evaluates for each project
  (`dotnet msbuild -getItem -getProperty`, one call per project), not the csproj text, so imports,
  `Directory.Build.*` files and SDK defaults count.
- Every rule in [code-style.md](../../../docs/CodeRules/code-style.md) and
  [code-architecture.md](../../../docs/CodeRules/code-architecture.md) applies.

## What each folder checks

| Folder | What it checks |
|--------|----------------|
| `Infrastructure/` | No rules: the readers of the repository layout, the `.slnx`, csproj files and tracked files, and helpers to run processes and use temporary folders. |
| `Projects/` | The project graph, on the MSBuild-evaluated projects (`ProjectEvaluator`): the exact edge table (`AllowedEdges`), where each reference is written, Integration isolation, references to implementation projects, the exact project set, the analyzer-only edge, product-free packages, transitive references, the build imports and the executables; and csproj text properties such as the single version value. |
| `Types/` | Type rules on the production assemblies, one per non-test project of the `.slnx` except the analyzer: layer purity (ArchUnitNET, plus the IL of compiler-generated lambda, `async` and iterator types read with Mono.Cecil), interface-only abstractions, DTOs, entities, enums, options classes and times. |
| `Rules/` | The rule matrix in both directions, the code-rule docs, test method names, the suppression scan, the devcontainer and CI workflow settings. |
| `Files/` | The format of every tracked text file (UTF-8, LF, final newline, no tabs, no trailing whitespace) and the `.editorconfig` settings. |
| `Documentation/` | The per-project docs: a `docs/` folder for every project, the three README sections and a dependency list that equals the csproj's references. The repository docs: every relative link in a tracked Markdown file resolves, each `CLAUDE.md` is `@AGENTS.md`, no `AGENTS.md` uses an `@` import and the root index links every other index, one short, marker-free GSD workflow doc is linked, and the backend decision records are complete and linked. |
| `Prototype/` | The HTML prototype under `src/frontend/prototype/`, which the frontend CI does not run for: no remote resource in a `src`, `href`, `@import` or `url()`, a UTF-8 meta charset on every page, stress marks as U+0301 after a Cyrillic vowel, and every state of the state table linked from the index to a page section of that id. |
| `Deployment/` | `deploy/compose.yaml` through `docker compose config`, and the image pins of the Dockerfile. |
| `RealBuild/` | Real `dotnet build`, `dotnet pack` and `dotnet ef migrations add` runs in a throwaway solution copy: each configured analyzer rule and banned API fails the build, packages pack, and migrations build clean. A copy holds only the files git tracks (a new file joins it once it is added to git), sits in `langproject-proofs/` under the user's local application-data folder (mode 0700 on Unix), and has guard files that stop MSBuild and NuGet from reading a `Directory.Build.rsp` or package sources above it. |

## How to add a rule

1. Write the rule under its own `###` heading in
   [code-style.md](../../../docs/CodeRules/code-style.md) or
   [code-architecture.md](../../../docs/CodeRules/code-architecture.md). The first line after the heading
   is `Enforcement:` with a link to the rule's matrix row.
2. Add the row to the [rule matrix](../../../docs/rule-matrix.md): every mechanism, the scope, the
   exemption rows, the fully qualified proof tests and the level. A scoped exemption gets its own `EX`
   row.
3. Put the check here as a pure function in the folder it belongs to, with one test on the repository and
   at least one synthetic proof that a bad input is reported.
4. Run the whole project. The matrix tests fail until the heading, the row and the named proof tests
   agree.

## How to run

From the repository root, with Docker available for the `Deployment/` tests:

`dotnet test --project src/backend/lang-proj-core/LangProject.Core.ArchitectureTests/LangProject.Core.ArchitectureTests.csproj -c Release`

The `RealBuild/` proofs restore inside each solution copy. They work without a network once the NuGet
global packages folder holds the solution's packages, `Newtonsoft.Json` 12.0.1 for the audit proof and the
`dotnet-ef` tool: run `dotnet restore` and `dotnet tool restore` for the solution once while online. The audit
proof reads its advisory from a local feed the test starts, and the other proof builds turn NuGet audit off,
so no proof needs the live advisory database. When restore cannot reach nuget.org for a missing package, the
failing assertion says so.
