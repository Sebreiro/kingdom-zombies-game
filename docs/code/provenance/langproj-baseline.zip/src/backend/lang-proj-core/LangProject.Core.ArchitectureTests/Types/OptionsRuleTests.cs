using System;
using System.Collections.Generic;
using LangProject.Core.ArchitectureTests.Types.Fixtures;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Types;

/// <summary>
/// Tests of the options rule (D-38): an options class, a non-static class whose name ends in <c>Options</c>, has only
/// private setters that are not <c>init</c>, so it is filled only by a binder with
/// <c>BindNonPublicProperties = true</c>. The rule runs on production and on bad-on-purpose fixtures.
/// </summary>
public sealed class OptionsRuleTests
{
    /// <summary>
    /// Every production options class passes; the selector matches <c>TelemetryOptions</c> and
    /// <c>RedactionOptions</c> and skips the static helper <c>LangDbContextOptions</c>.
    /// </summary>
    [Fact]
    public void OptionsRule_Production_Complies()
    {
        IReadOnlyList<Type> options = TypeConventionRules.SelectOptions(
                types: ProductionTypes.TypesOf(filter: static _ => true));

        options.ShouldContain(elementPredicate: type => IsNamed(type: type, fullName: TelemetryOptionsName));
        options.ShouldContain(elementPredicate: type => IsNamed(type: type, fullName: RedactionOptionsName));
        options.ShouldNotContain(elementPredicate: type => IsNamed(type: type, fullName: StaticHelperName));
        IReadOnlyList<string> violations = TypeConventionRules.CheckOptions(options: options);
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>The valid fixture passes, so the rule does not over-report.</summary>
    [Fact]
    public void OptionsRule_ValidFixture_IsAccepted()
    {
        IReadOnlyList<string> violations = TypeConventionRules.CheckOptions(
                options: [typeof(OptionsFixtures.ValidOptions)]);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>A public setter on an options class is reported.</summary>
    [Fact]
    public void OptionsRule_PublicSetter_IsReported()
    {
        string violation = SingleViolation(options: typeof(OptionsFixtures.PublicSetterOptions));

        violation.ShouldContain(expected: nameof(OptionsFixtures.PublicSetterOptions));
        violation.ShouldContain(expected: "public setter");
    }

    /// <summary>An <c>init</c> setter on an options class is reported.</summary>
    [Fact]
    public void OptionsRule_InitSetter_IsReported()
    {
        string violation = SingleViolation(options: typeof(OptionsFixtures.InitSetterOptions));

        violation.ShouldContain(expected: nameof(OptionsFixtures.InitSetterOptions));
        violation.ShouldContain(expected: "init setter");
    }

    /// <summary>An empty selector fails instead of passing vacuously (SPEC R6).</summary>
    [Fact]
    public void OptionsRule_EmptySelector_Fails()
    {
        TypeConventionRules.CheckOptions(options: []).ShouldHaveSingleItem().ShouldBe(
                expected: TypeConventionRules.EmptySelector);
    }

    private const string TelemetryOptionsName = "LangProject.Core.CompositionRoot.Hosting.TelemetryOptions";
    private const string RedactionOptionsName = "LangProject.Core.CompositionRoot.Hosting.RedactionOptions";
    private const string StaticHelperName = "LangProject.Core.DAL.LangDbContextOptions";

    private static bool IsNamed(Type type, string fullName)
    {
        return string.Equals(a: type.FullName, b: fullName, comparisonType: StringComparison.Ordinal);
    }

    private static string SingleViolation(Type options)
    {
        return TypeConventionRules.CheckOptions(options: [options]).ShouldHaveSingleItem();
    }
}
