using System;
using System.Collections.Generic;
using LangProject.Core.API.Abstractions.Health;
using LangProject.Core.ArchitectureTests.Types.Fixtures;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Types;

/// <summary>
/// Tests of the enum rule (D-52): every enum declares <c>Unknown = 0</c>, pins every member with
/// <c>[JsonStringEnumMemberName]</c> and gives each member its own pinned name. The rule runs on every enum of the
/// production assemblies and on one bad-on-purpose fixture per violation.
/// </summary>
public sealed class EnumRuleTests
{
    /// <summary>
    /// Every enum in the production assemblies passes; the selector matches <see cref="HealthCheckStatus"/>.
    /// </summary>
    [Fact]
    public void EnumRules_Production_Comply()
    {
        IReadOnlyList<Type> enums = TypeConventionRules.SelectEnums(
                types: ProductionTypes.TypesOf(filter: _ => true));

        enums.ShouldContain(expected: typeof(HealthCheckStatus));
        IReadOnlyList<string> violations = TypeConventionRules.CheckEnums(enums: enums);
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// The valid fixture passes, so the rule does not over-report; one of its pinned names differs from the C# name.
    /// </summary>
    [Fact]
    public void EnumRules_ValidFixture_IsAccepted()
    {
        IReadOnlyList<string> violations = TypeConventionRules.CheckEnums(enums: [typeof(EnumFixtures.ValidStatus)]);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>An enum without a member named <c>Unknown</c> is reported.</summary>
    [Fact]
    public void EnumRules_MissingUnknown_IsReported()
    {
        string violation = SingleViolation(enumType: typeof(EnumFixtures.MissingUnknownStatus));

        violation.ShouldContain(expected: nameof(EnumFixtures.MissingUnknownStatus));
        violation.ShouldContain(expected: "no Unknown member");
    }

    /// <summary>An <c>Unknown</c> member that is not the zero value is reported.</summary>
    [Fact]
    public void EnumRules_UnknownNotZero_IsReported()
    {
        string violation = SingleViolation(enumType: typeof(EnumFixtures.UnknownNotZeroStatus));

        violation.ShouldContain(expected: nameof(EnumFixtures.UnknownNotZeroStatus));
        violation.ShouldContain(expected: "Unknown has the value 1, not 0");
    }

    /// <summary>A member without <c>[JsonStringEnumMemberName]</c> is reported.</summary>
    [Fact]
    public void EnumRules_MemberWithoutPinnedName_IsReported()
    {
        string violation = SingleViolation(enumType: typeof(EnumFixtures.UnpinnedMemberStatus));

        violation.ShouldContain(expected: nameof(EnumFixtures.UnpinnedMemberStatus.NotPinned));
        violation.ShouldContain(expected: "[JsonStringEnumMemberName]");
    }

    /// <summary>Two members with the same pinned name are reported.</summary>
    [Fact]
    public void EnumRules_DuplicatePinnedName_IsReported()
    {
        string violation = SingleViolation(enumType: typeof(EnumFixtures.DuplicatePinnedNameStatus));

        violation.ShouldContain(expected: nameof(EnumFixtures.DuplicatePinnedNameStatus));
        violation.ShouldContain(expected: "'Same'");
    }

    /// <summary>An empty selector fails instead of passing vacuously (SPEC R6).</summary>
    [Fact]
    public void EnumRules_EmptySelector_Fails()
    {
        TypeConventionRules.CheckEnums(enums: []).ShouldHaveSingleItem().ShouldBe(
                expected: TypeConventionRules.EmptySelector);
    }

    /// <summary>The selector picks enums only.</summary>
    [Fact]
    public void EnumRules_Selector_PicksOnlyEnums()
    {
        IReadOnlyList<Type> enums = TypeConventionRules.SelectEnums(
                types: [typeof(EnumFixtures.ValidStatus), typeof(EnumFixtures), typeof(int)]);

        enums.ShouldHaveSingleItem().ShouldBe(expected: typeof(EnumFixtures.ValidStatus));
    }

    private static string SingleViolation(Type enumType)
    {
        return TypeConventionRules.CheckEnums(enums: [enumType]).ShouldHaveSingleItem();
    }
}
