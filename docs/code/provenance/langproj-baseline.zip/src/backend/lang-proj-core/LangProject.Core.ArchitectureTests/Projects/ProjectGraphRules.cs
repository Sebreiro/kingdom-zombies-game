using System;
using System.Collections.Generic;
using System.Linq;
using LangProject.Core.ArchitectureTests.Infrastructure;

namespace LangProject.Core.ArchitectureTests.Projects;

/// <summary>
/// Pure rule functions over evaluated projects and parsed build files. Each returns one message per violation, so
/// production checks and bad-on-purpose proofs run through the same code. The graph and property rules read what
/// MSBuild evaluates (<see cref="EvaluatedProject"/>), never the csproj text alone.
/// </summary>
internal static class ProjectGraphRules
{
    internal const string TransitiveProperty = ProjectEvaluator.TransitiveProperty;
    internal const string PackagesFolder = "packages/";
    internal const string ProductName = "LangProject";
    internal const string SolutionPropsPath = "Directory.Build.props";
    internal const string SolutionTargetsPath = "Directory.Build.targets";

    /// <summary>
    /// Checks that every project's evaluated ProjectReference set equals its D-46 allowed-edges row; IntegrationTests
    /// may draw from its row but must reference what the row requires. A project with no row is a violation, so a new
    /// project never passes silently. Analyzer-only edges are checked by <see cref="CheckReferenceSources"/>.
    /// </summary>
    /// <param name="projects">The evaluated projects.</param>
    /// <returns>The violations; empty when every project matches its row.</returns>
    internal static IReadOnlyList<string> CheckAllowedEdges(IReadOnlyCollection<EvaluatedProject> projects)
    {
        var solutionProjects = projects
                .Select(selector: project => project.Name)
                .ToHashSet(comparer: StringComparer.Ordinal);
        return
        [
            .. projects.SelectMany(selector: project => CheckProjectEdges(
                    project: project,
                    solutionProjects: solutionProjects)),
        ];
    }

    /// <summary>
    /// Checks that every evaluated project and every project it references is listed in <c>LangProject.Core.slnx</c>,
    /// so a tracked csproj left out of the solution, or a same-named csproj in another folder, is reported.
    /// </summary>
    /// <param name="projects">The evaluated projects.</param>
    /// <param name="solutionPaths">The solution-relative project paths listed in the <c>.slnx</c>.</param>
    /// <returns>One violation per project or reference outside the solution.</returns>
    internal static IReadOnlyList<string> CheckSolutionMembership(
            IEnumerable<EvaluatedProject> projects,
            IReadOnlyCollection<string> solutionPaths)
    {
        var listed = solutionPaths.ToHashSet(comparer: StringComparer.Ordinal);
        List<string> violations = [];
        foreach (EvaluatedProject project in projects)
        {
            if (!listed.Contains(item: project.RelativePath))
            {
                violations.Add(item: $"{project.RelativePath} is a project in the working tree but not in "
                        + "LangProject.Core.slnx; every backend project is in the solution (D-46)");
            }

            violations.AddRange(collection: project.ProjectReferences
                    .Where(predicate: reference => !listed.Contains(item: reference.RelativePath))
                    .Select(selector: reference => $"{project.Name} references {reference.RelativePath}, which is "
                            + "not a project in LangProject.Core.slnx (D-46)"));
        }

        return violations;
    }

    /// <summary>
    /// Checks where each evaluated reference comes from. A table edge is written only in the project's own csproj,
    /// never in a <c>Directory.Build.*</c> or imported file. The only analyzer-only edge is the one in the solution's
    /// <c>Directory.Build.targets</c>, to <c>Sebreiro.CodeRules.Analyzers</c>, and every other project has it (D-46).
    /// </summary>
    /// <param name="projects">The evaluated projects.</param>
    /// <returns>One violation per misplaced, foreign or missing edge.</returns>
    internal static IReadOnlyList<string> CheckReferenceSources(IEnumerable<EvaluatedProject> projects)
    {
        return [.. projects.SelectMany(selector: CheckProjectReferenceSources)];
    }

    /// <summary>Selects the projects the Integration isolation rule applies to.</summary>
    /// <param name="projects">The evaluated projects.</param>
    /// <returns>Every project whose name starts with <c>LangProject.Core.Integration.</c>.</returns>
    internal static IReadOnlyList<EvaluatedProject> SelectIntegrationProjects(IEnumerable<EvaluatedProject> projects)
    {
        return
        [
            .. projects.Where(predicate: project => project.Name.StartsWith(
                    value: AllowedEdges.IntegrationPrefix,
                    comparisonType: StringComparison.Ordinal)),
        ];
    }

    /// <summary>Checks that Integration projects reference only Integration.Abstractions (ARCH-03).</summary>
    /// <param name="projects">The evaluated projects.</param>
    /// <returns>One violation per forbidden reference.</returns>
    internal static IReadOnlyList<string> CheckIntegrationIsolation(IEnumerable<EvaluatedProject> projects)
    {
        return
        [
            .. SelectIntegrationProjects(projects: projects).SelectMany(selector: project => project.ReferencedProjects
                    .Where(predicate: reference => !IsSameName(
                            left: reference,
                            right: AllowedEdges.IntegrationAbstractions))
                    .Order(comparer: StringComparer.Ordinal)
                    .Select(selector: reference => $"{project.Name} references {reference}; an Integration project "
                            + $"may reference only {AllowedEdges.IntegrationAbstractions} (ARCH-03)")),
        ];
    }

    /// <summary>Checks that only CompositionRoot and test projects reference implementation projects (D-41).</summary>
    /// <param name="projects">The evaluated projects.</param>
    /// <returns>One violation per reference to an implementation project from any other project.</returns>
    internal static IReadOnlyList<string> CheckImplementationReferences(IEnumerable<EvaluatedProject> projects)
    {
        return
        [
            .. projects
                    .Where(predicate: project => !IsSameName(left: project.Name, right: AllowedEdges.CompositionRoot))
                    .Where(predicate: project => !AllowedEdges.IsTest(projectName: project.Name))
                    .SelectMany(selector: project => project.ReferencedProjects
                            .Where(predicate: reference => AllowedEdges.IsImplementation(projectName: reference))
                            .Order(comparer: StringComparer.Ordinal)
                            .Select(selector: reference => $"{project.Name} references implementation project "
                                    + $"{reference} instead of its .Abstractions sibling (D-41)")),
        ];
    }

    /// <summary>
    /// Checks that every project evaluates <c>DisableTransitiveProjectReferences</c> to <c>true</c> (SPEC R6). The SDK
    /// tests <c>'$(DisableTransitiveProjectReferences)' != 'true'</c>, so an empty value, <c>0</c> or <c>no</c> turns
    /// transitive references back on just as <c>false</c> does.
    /// </summary>
    /// <param name="projects">The evaluated projects.</param>
    /// <returns>One violation per project whose evaluated value is not <c>true</c>.</returns>
    internal static IReadOnlyList<string> CheckTransitiveReferencesDisabled(IEnumerable<EvaluatedProject> projects)
    {
        return
        [
            .. projects
                    .Where(predicate: project => !IsTrue(value: project.GetProperty(name: TransitiveProperty)))
                    .Select(selector: project => $"{project.Name} evaluates {TransitiveProperty} to "
                            + $"'{project.GetProperty(name: TransitiveProperty)}'; MSBuild turns transitive project "
                            + "references back on for any value other than 'true' (SPEC R6)"),
        ];
    }

    /// <summary>
    /// Checks that every project imports exactly the solution-root <c>Directory.Build.props</c> and
    /// <c>Directory.Build.targets</c>: both imports switched on, and no nearer <c>Directory.Build.*</c> file in its
    /// folder chain that would replace the solution settings.
    /// </summary>
    /// <param name="projects">The evaluated projects.</param>
    /// <returns>One violation per switched-off import or replaced file.</returns>
    internal static IReadOnlyList<string> CheckBuildImports(IEnumerable<EvaluatedProject> projects)
    {
        List<string> violations = [];
        foreach (EvaluatedProject project in projects)
        {
            foreach ((string property, string expected) in _importChecks)
            {
                string actual = project.GetProperty(name: property);
                bool matches = expected.Length == 0
                        ? IsTrue(value: actual)
                        : string.Equals(a: actual, b: expected, comparisonType: StringComparison.Ordinal);
                if (!matches)
                {
                    violations.Add(item: $"{project.Name} evaluates {property} to '{actual}'; every project imports "
                            + $"the solution-root {SolutionPropsPath} and {SolutionTargetsPath} and nothing nearer");
                }
            }
        }

        return violations;
    }

    /// <summary>
    /// Checks that every project's evaluated <c>AssemblyName</c> equals its project name, so the type rules, which
    /// load each production assembly by its project name, load the project's own output.
    /// </summary>
    /// <param name="projects">The evaluated projects.</param>
    /// <returns>One violation per project whose assembly has another name.</returns>
    internal static IReadOnlyList<string> CheckAssemblyNames(IEnumerable<EvaluatedProject> projects)
    {
        return
        [
            .. projects
                    .Where(predicate: project => !IsSameName(
                            left: project.GetProperty(name: ProjectEvaluator.AssemblyNameProperty),
                            right: project.Name))
                    .Select(selector: project => $"{project.Name} builds the assembly "
                            + $"'{project.GetProperty(name: ProjectEvaluator.AssemblyNameProperty)}'; every assembly "
                            + "is named after its project, so the type rules load every production project"),
        ];
    }

    /// <summary>
    /// Checks that no build file on disk sets <c>DisableTransitiveProjectReferences</c> to anything but <c>true</c>,
    /// and none switches off <c>ImportDirectoryBuildProps</c> or <c>ImportDirectoryBuildTargets</c> (SPEC R6). This
    /// text check also covers files no project imports today.
    /// </summary>
    /// <param name="buildFiles">Every csproj, props and targets file on disk.</param>
    /// <returns>One violation per offending value.</returns>
    internal static IReadOnlyList<string> CheckTransitiveReferencesNotDisabled(IEnumerable<ProjectFile> buildFiles)
    {
        return
        [
            .. buildFiles.SelectMany(selector: file => _mustBeTrueProperties.SelectMany(selector: property => file
                    .GetPropertyValues(name: property)
                    .Where(predicate: value => !IsTrue(value: value.Trim()))
                    .Select(selector: value => $"{file.RelativePath} sets {property} to '{value}'; it stays 'true', "
                            + "so transitive project references stay disabled (SPEC R6)"))),
        ];
    }

    /// <summary>Selects every project under <c>packages/</c>, packable or not.</summary>
    /// <param name="projects">The projects to select from.</param>
    /// <returns>The package projects.</returns>
    internal static IReadOnlyList<EvaluatedProject> SelectPackageProjects(IEnumerable<EvaluatedProject> projects)
    {
        return
        [
            .. projects.Where(predicate: project => project.RelativePath.StartsWith(
                    value: PackagesFolder,
                    comparisonType: StringComparison.Ordinal)),
        ];
    }

    /// <summary>
    /// Checks that no project under <c>packages/</c> has an evaluated ProjectReference or PackageReference whose
    /// solution-relative path or ID contains <c>LangProject</c>, in any casing (SPEC R3, ARCH-04).
    /// </summary>
    /// <param name="projects">The projects; the rule selects the package projects itself.</param>
    /// <returns>One violation per offending reference.</returns>
    internal static IReadOnlyList<string> CheckPackageIsolation(IEnumerable<EvaluatedProject> projects)
    {
        return
        [
            .. SelectPackageProjects(projects: projects).SelectMany(selector: project => project.ProjectReferences
                    .Select(selector: reference => reference.RelativePath)
                    .Concat(second: project.PackageReferences)
                    .Where(predicate: reference => reference.Contains(
                            value: ProductName,
                            comparisonType: StringComparison.OrdinalIgnoreCase))
                    .Select(selector: reference => $"{project.Name} ({project.RelativePath}) references {reference}; "
                            + $"projects under packages/ never reference {ProductName} (SPEC R3)")),
        ];
    }

    /// <summary>
    /// Checks that no build file other than the allowed one sets <c>Version</c>, <c>VersionPrefix</c>,
    /// <c>VersionSuffix</c>, <c>AssemblyVersion</c> or <c>FileVersion</c> (D-22).
    /// </summary>
    /// <param name="buildFiles">Every csproj, props and targets file on disk.</param>
    /// <param name="allowedRelativePath">The solution-relative path of the one file that holds the version.</param>
    /// <returns>One violation per version property set elsewhere.</returns>
    internal static IReadOnlyList<string> CheckVersionProperties(
            IEnumerable<ProjectFile> buildFiles,
            string allowedRelativePath)
    {
        return
        [
            .. buildFiles
                    .Where(predicate: file => !string.Equals(
                            a: file.RelativePath,
                            b: allowedRelativePath,
                            comparisonType: StringComparison.Ordinal))
                    .SelectMany(selector: file => file.Properties
                            .Where(predicate: property => _versionProperties.Contains(item: property.Key))
                            .Select(selector: property => $"{file.RelativePath} sets {property.Key}; only "
                                    + $"{allowedRelativePath} sets the version (D-22)")),
        ];
    }

    /// <summary>
    /// Selects the executable projects: an evaluated <c>OutputType</c> of <c>Exe</c> or <c>WinExe</c>, wherever it
    /// comes from (the csproj, an SDK such as the Web or Worker SDK, a props file or a package).
    /// </summary>
    /// <param name="projects">The evaluated projects.</param>
    /// <returns>The executable projects.</returns>
    internal static IReadOnlyList<EvaluatedProject> SelectExecutables(IEnumerable<EvaluatedProject> projects)
    {
        return [.. projects.Where(predicate: IsExecutable)];
    }

    /// <summary>
    /// Checks that CompositionRoot is the only executable among non-test projects; the three xUnit v3 test
    /// projects must be executables and are the only other ones (SPEC R2 as amended, RD-10).
    /// </summary>
    /// <param name="projects">The evaluated projects.</param>
    /// <returns>One violation per executable that is neither CompositionRoot nor a test project.</returns>
    internal static IReadOnlyList<string> CheckExecutables(IEnumerable<EvaluatedProject> projects)
    {
        return
        [
            .. SelectExecutables(projects: projects)
                    .Where(predicate: project => !IsSameName(left: project.Name, right: AllowedEdges.CompositionRoot))
                    .Where(predicate: project => !(AllowedEdges.IsTest(projectName: project.Name)
                            && IsTrue(value: project.GetProperty(name: ProjectEvaluator.IsTestProjectProperty))))
                    .Select(selector: project => $"{project.Name} builds an executable (OutputType "
                            + $"{project.GetProperty(name: ProjectEvaluator.OutputTypeProperty)}); among non-test "
                            + $"projects only {AllowedEdges.CompositionRoot} is one (SPEC R2, RD-10)"),
        ];
    }

    /// <summary>Checks that no package item references AutoMapper, Mapster or Riok.Mapperly (D-43).</summary>
    /// <param name="buildFiles">Every csproj, props and targets file, central package files included.</param>
    /// <returns>One violation per mapping-library item.</returns>
    internal static IReadOnlyList<string> CheckMappingLibraries(IEnumerable<ProjectFile> buildFiles)
    {
        return
        [
            .. buildFiles.SelectMany(selector: file => file.PackageIds
                    .Where(predicate: IsMappingLibrary)
                    .Select(selector: packageId => $"{file.RelativePath} references {packageId}; mapping is "
                            + "hand-written, no AutoMapper, Mapster or Mapperly (D-43)")),
        ];
    }

    private static readonly HashSet<string> _versionProperties = new(
            collection: ["Version", "VersionPrefix", "VersionSuffix", "AssemblyVersion", "FileVersion"],
            comparer: StringComparer.OrdinalIgnoreCase);

    private static readonly string[] _mappingLibraries = ["AutoMapper", "Mapster", "Riok.Mapperly"];

    private static readonly string[] _mustBeTrueProperties =
    [
        TransitiveProperty,
        ProjectEvaluator.ImportPropsProperty,
        ProjectEvaluator.ImportTargetsProperty,
    ];

    private static readonly (string Property, string Expected)[] _importChecks =
    [
        (ProjectEvaluator.ImportPropsProperty, string.Empty),
        (ProjectEvaluator.ImportTargetsProperty, string.Empty),
        (ProjectEvaluator.PropsPathProperty, SolutionPropsPath),
        (ProjectEvaluator.TargetsPathProperty, SolutionTargetsPath),
    ];

    private static IEnumerable<string> CheckProjectEdges(
            EvaluatedProject project,
            IReadOnlySet<string> solutionProjects)
    {
        AllowedEdgeRow? row = AllowedEdges.FindRow(projectName: project.Name, solutionProjects: solutionProjects);
        if (row is null)
        {
            return [$"{project.Name}: no row in the allowed-edges table (D-46); add one before adding the project"];
        }

        IEnumerable<string> extra = project.ReferencedProjects
                .Where(predicate: reference => !row.Allowed.Contains(item: reference))
                .Order(comparer: StringComparer.Ordinal)
                .Select(selector: reference => $"{project.Name}: references {reference}, which its D-46 row "
                        + "does not allow");
        IEnumerable<string> missing = row.Required
                .Where(predicate: required => !project.ReferencedProjects.Contains(item: required))
                .Order(comparer: StringComparer.Ordinal)
                .Select(selector: required => $"{project.Name}: does not reference {required}, which its "
                        + "D-46 row requires; the table and the csproj must match");
        return extra.Concat(second: missing);
    }

    private static IEnumerable<string> CheckProjectReferenceSources(EvaluatedProject project)
    {
        bool isAnalyzer = IsSameName(left: project.Name, right: AllowedEdges.Analyzers);
        foreach (EvaluatedReference reference in project.ProjectReferences)
        {
            if (!reference.IsAnalyzerOnly && !IsSameName(left: reference.DefinedIn, right: project.RelativePath))
            {
                yield return $"{project.Name}: the reference to {reference.Name} comes from {reference.DefinedIn}; a "
                        + "ProjectReference is written only in the project's own csproj (D-46)";
            }
            else if (reference.IsAnalyzerOnly && (isAnalyzer || !IsAnalyzerEdge(reference: reference)))
            {
                yield return $"{project.Name}: an analyzer-only reference to {reference.Name} from "
                        + $"{reference.DefinedIn}; the only one is to {AllowedEdges.Analyzers}, from the solution "
                        + $"{SolutionTargetsPath}, and the analyzer does not analyze itself (D-46)";
            }
        }

        if (!isAnalyzer && !project.ProjectReferences.Any(predicate: IsAnalyzerEdge))
        {
            yield return $"{project.Name}: has no analyzer-only reference to {AllowedEdges.Analyzers} from the "
                    + $"solution {SolutionTargetsPath}, so the SCR rules do not run on it (D-46)";
        }
    }

    private static bool IsAnalyzerEdge(EvaluatedReference reference)
    {
        return reference.IsAnalyzerOnly
                && IsSameName(left: reference.Name, right: AllowedEdges.Analyzers)
                && IsSameName(left: reference.DefinedIn, right: SolutionTargetsPath);
    }

    private static bool IsExecutable(EvaluatedProject project)
    {
        string outputType = project.GetProperty(name: ProjectEvaluator.OutputTypeProperty);
        return string.Equals(a: outputType, b: "Exe", comparisonType: StringComparison.OrdinalIgnoreCase)
                || string.Equals(a: outputType, b: "WinExe", comparisonType: StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsMappingLibrary(string packageId)
    {
        return _mappingLibraries.Any(predicate: library =>
                string.Equals(a: packageId, b: library, comparisonType: StringComparison.OrdinalIgnoreCase)
                        || packageId.StartsWith(
                                value: library + ".",
                                comparisonType: StringComparison.OrdinalIgnoreCase));
    }

    private static bool IsTrue(string value)
    {
        return string.Equals(a: value, b: "true", comparisonType: StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsSameName(string left, string right)
    {
        return string.Equals(a: left, b: right, comparisonType: StringComparison.Ordinal);
    }
}
