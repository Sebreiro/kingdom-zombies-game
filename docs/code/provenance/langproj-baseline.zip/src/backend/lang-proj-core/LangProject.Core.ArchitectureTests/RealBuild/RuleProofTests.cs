using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.RealBuild;

/// <summary>
/// Real-build proofs for every configured style, analyzer and banned-API rule (D-32, D-34, SPEC R7). One shared
/// <see cref="RuleProofBuild"/> builds three fixture projects in a throwaway solution copy with the real props,
/// targets and <c>.editorconfig</c> files; each test checks that one fixture file fails with exactly its rule's IDs.
/// </summary>
public sealed partial class RuleProofTests : IClassFixture<RuleProofBuild>
{
    /// <summary>Initializes a new instance of the <see cref="RuleProofTests"/> class.</summary>
    /// <param name="build">The shared build of the fixture projects.</param>
    public RuleProofTests(RuleProofBuild build)
    {
        _build = build;
    }

    /// <summary>
    /// Every fixture project fails, every fixture file except the clean control reports an error, and no other file
    /// does.
    /// </summary>
    [Fact]
    public void Build_FixtureProjects_FailOnlyInTheirFixtures()
    {
        HashSet<string> expectedFiles =
        [
            .. RuleProofSources.Files
                    .Select(selector: file => file.Key)
                    .Where(predicate: path => path.EndsWith(value: ".cs", comparisonType: StringComparison.Ordinal))
                    .Where(predicate: path => !string.Equals(
                            a: path,
                            b: CleanControlFile,
                            comparisonType: StringComparison.Ordinal)),
        ];
        ProcessResult[] results = [_build.Rules, _build.Compile, _build.Tests];
        List<string> filesWithErrors = [.. results.SelectMany(selector: result => result.FilesWithErrors())];

        List<string> unexpected =
        [
            .. filesWithErrors.Where(predicate: path => !expectedFiles.Any(
                    predicate: expected => IsFile(path: path, relativePath: expected))),
        ];
        List<string> silent =
        [
            .. expectedFiles.Where(predicate: expected => !filesWithErrors.Any(
                    predicate: path => IsFile(path: path, relativePath: expected))),
        ];

        results.ShouldAllBe(elementPredicate: result => result.ExitCode != 0);
        unexpected.ShouldBeEmpty(customMessage: _build.Rules.Output + _build.Compile.Output + _build.Tests.Output);
        silent.ShouldBeEmpty(customMessage: _build.Rules.Output + _build.Compile.Output + _build.Tests.Output);
    }

    /// <summary>
    /// A clean control file builds without an error: it uses an async method without an <c>Async</c> suffix,
    /// <c>/// &lt;inheritdoc /&gt;</c>, <c>var</c> with <c>new</c>, a collection expression and <c>is null</c>.
    /// </summary>
    [Fact]
    public void Build_CleanControl_HasNoErrors()
    {
        _build.Rules.ErrorIdsInFile(pathEnding: CleanControlFile).ShouldBeEmpty(customMessage: _build.Rules.Output);
        _build.Rules.FilesWithErrors().ShouldNotBeEmpty(customMessage: _build.Rules.Output);
    }

    /// <summary>A line that ends with a space fails with IDE0055.</summary>
    [Fact]
    public void Build_TrailingWhitespace_FailsWithIde0055()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/TrailingWhitespaceProof.cs", expected: ["IDE0055"]);
    }

    /// <summary>Members indented by 2 spaces fail with IDE0055.</summary>
    [Fact]
    public void Build_TwoSpaceIndent_FailsWithIde0055()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/TwoSpaceIndentProof.cs", expected: ["IDE0055"]);
    }

    /// <summary>An <c>if</c> without braces fails with IDE0011.</summary>
    [Fact]
    public void Build_MissingBraces_FailsWithIde0011()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/BracesProof.cs", expected: ["IDE0011"]);
    }

    /// <summary>A <c>using</c> directive after the file-scoped namespace fails with IDE0065.</summary>
    [Fact]
    public void Build_UsingInsideNamespace_FailsWithIde0065()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/UsingInsideNamespaceProof.cs", expected: ["IDE0065"]);
    }

    /// <summary>A <c>using</c> directive that nothing uses fails with IDE0005.</summary>
    [Fact]
    public void Build_UnusedUsing_FailsWithIde0005()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/UnusedUsingProof.cs", expected: ["IDE0005"]);
    }

    /// <summary><c>List&lt;int&gt;</c> without its <c>using</c> fails with CS0246: implicit usings are off.</summary>
    [Fact]
    public void Build_ImplicitUsing_FailsWithCs0246()
    {
        ShouldReport(result: _build.Compile, file: "ProofCompile/ImplicitUsingsProof.cs", expected: ["CS0246"]);
    }

    /// <summary><c>var</c> for a type that is not apparent fails with IDE0008.</summary>
    [Fact]
    public void Build_VarForNonApparentType_FailsWithIde0008()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/VarNotApparentProof.cs", expected: ["IDE0008"]);
    }

    /// <summary><c>StringBuilder builder = new StringBuilder();</c> in a local fails with IDE0007.</summary>
    [Fact]
    public void Build_TypedLocalWithNew_FailsWithIde0007()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/TypedNewLocalProof.cs", expected: ["IDE0007"]);
    }

    /// <summary>A field set with <c>new StringBuilder()</c> instead of <c>new()</c> fails with IDE0090.</summary>
    [Fact]
    public void Build_FieldWithExplicitNew_FailsWithIde0090()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/FieldNewProof.cs", expected: ["IDE0090"]);
    }

    /// <summary><c>new int[] { 1, 2 }</c> instead of a collection expression fails with IDE0300.</summary>
    [Fact]
    public void Build_ArrayCreation_FailsWithIde0300()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/CollectionExpressionProof.cs", expected: ["IDE0300"]);
    }

    /// <summary><c>ReferenceEquals(value, null)</c> fails with IDE0041.</summary>
    [Fact]
    public void Build_ReferenceEqualsNull_FailsWithIde0041()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/ReferenceEqualsNullProof.cs", expected: ["IDE0041"]);
    }

    /// <summary><c>value == null</c> fails with RCS1248.</summary>
    [Fact]
    public void Build_EqualsNull_FailsWithRcs1248()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/EqualsNullProof.cs", expected: ["RCS1248"]);
    }

    /// <summary>An expression-bodied method fails with IDE0022.</summary>
    [Fact]
    public void Build_ExpressionBodiedMethod_FailsWithIde0022()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/ExpressionBodiedMethodProof.cs", expected: ["IDE0022"]);
    }

    /// <summary>A private field named <c>value</c> fails with IDE1006.</summary>
    [Fact]
    public void Build_PrivateFieldName_FailsWithIde1006()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/PrivateFieldNameProof.cs", expected: ["IDE1006"]);
    }

    /// <summary>A private constant named <c>maxCount</c> fails with IDE1006.</summary>
    [Fact]
    public void Build_ConstantName_FailsWithIde1006()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/ConstantNameProof.cs", expected: ["IDE1006"]);
    }

    /// <summary>An internal class that is not sealed fails with CA1852 and MA0053.</summary>
    [Fact]
    public void Build_UnsealedClass_FailsWithCa1852AndMa0053()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/UnsealedClassProof.cs", expected: ["CA1852", "MA0053"]);
    }

    /// <summary>A second top-level type in a file fails with MA0048.</summary>
    [Fact]
    public void Build_TwoTypesInOneFile_FailsWithMa0048()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/OneTypePerFileProof.cs", expected: ["MA0048"]);
    }

    /// <summary>A public type and method without XML documentation fail with CS1591.</summary>
    [Fact]
    public void Build_MissingXmlDoc_FailsWithCs1591()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/MissingXmlDocProof.cs", expected: ["CS1591"]);
    }

    /// <summary><c>DateTime.UtcNow</c> fails with RS0030.</summary>
    [Fact]
    public void Build_DateTimeUtcNow_FailsWithRs0030()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/BannedDateTimeProof.cs", expected: ["RS0030"]);
    }

    /// <summary><c>Console.WriteLine</c> fails with RS0030.</summary>
    [Fact]
    public void Build_ConsoleWrite_FailsWithRs0030()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/BannedConsoleProof.cs", expected: ["RS0030"]);
    }

    /// <summary><c>Thread.Sleep</c> fails with RS0030.</summary>
    [Fact]
    public void Build_ThreadSleep_FailsWithRs0030()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/BannedThreadSleepProof.cs", expected: ["RS0030"]);
    }

    /// <summary><c>Task.Wait()</c> fails with RS0030.</summary>
    [Fact]
    public void Build_TaskWait_FailsWithRs0030()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/BannedTaskWaitProof.cs", expected: ["RS0030"]);
    }

    /// <summary><c>Task&lt;T&gt;.Result</c> fails with RS0030.</summary>
    [Fact]
    public void Build_TaskResult_FailsWithRs0030()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/BannedTaskResultProof.cs", expected: ["RS0030"]);
    }

    /// <summary><c>new HttpClient()</c> fails with RS0030.</summary>
    [Fact]
    public void Build_NewHttpClient_FailsWithRs0030()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/BannedHttpClientProof.cs", expected: ["RS0030"]);
    }

    /// <summary>
    /// A fixture that uses every member of <c>BannedSymbols.txt</c> once, each on its own line, fails with RS0030 on
    /// exactly as many lines as the list has entries: every entry resolves to a real symbol, because the banned-API
    /// analyzer silently ignores an entry with a mistyped documentation ID.
    /// </summary>
    [Fact]
    public void Build_EveryBannedSymbol_FailsWithRs0030()
    {
        int entries = File
                .ReadAllLines(path: Path.Combine(path1: RepositoryLayout.SolutionRoot, path2: "BannedSymbols.txt"))
                .Count(predicate: line => line.Trim().Length > 0);
        List<string> bannedLines =
        [
            .. BannedLinePattern()
                    .Matches(input: _build.Rules.Output)
                    .Select(selector: match => match.Groups["line"].Value)
                    .Distinct(comparer: StringComparer.Ordinal),
        ];

        ShouldReport(result: _build.Rules, file: RuleProofSources.BannedSymbolsFile, expected: ["RS0030"]);
        bannedLines.Count.ShouldBe(expected: entries, customMessage: _build.Rules.Output);
        entries.ShouldBeGreaterThan(expected: 30);
    }

    /// <summary><c>logger.LogInformation(...)</c>, not a <c>[LoggerMessage]</c> method, fails with CA1848.</summary>
    [Fact]
    public void Build_DirectLoggerCall_FailsWithCa1848()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/DirectLoggingProof.cs", expected: ["CA1848"]);
    }

    /// <summary>
    /// An await without <c>ConfigureAwait</c> fails with MA0004 outside <c>LangProject.Core.*</c>, as in the
    /// <c>Sebreiro.*</c> packages.
    /// </summary>
    [Fact]
    public void Build_AwaitWithoutConfigureAwait_FailsWithMa0004()
    {
        ShouldReport(result: _build.Rules, file: "ProofRules/ConfigureAwaitProof.cs", expected: ["MA0004"]);
    }

    /// <summary>The test framework's <c>Assert</c> in a test project fails with RS0030: use Shouldly.</summary>
    [Fact]
    public void Build_XunitAssertInTestProject_FailsWithRs0030()
    {
        ShouldReport(result: _build.Tests, file: "ProofTests/AssertProofTests.cs", expected: ["RS0030"]);
    }

    /// <summary>A positional argument in a test project fails with SCR0001: tests follow every rule.</summary>
    [Fact]
    public void Build_PositionalArgumentInTestProject_FailsWithScr0001()
    {
        ShouldReport(result: _build.Tests, file: "ProofTests/PositionalArgumentProofTests.cs", expected: ["SCR0001"]);
    }

    /// <summary>
    /// A test name with underscores fails with CA1707 in a test project outside the three exempt test-project folders:
    /// the CA1707 exemption is scoped to those folders.
    /// </summary>
    [Fact]
    public void Build_UnderscoreNameOutsideExemptFolders_FailsWithCa1707()
    {
        ShouldReport(result: _build.Tests, file: "ProofTests/UnderscoreNameProofTests.cs", expected: ["CA1707"]);
    }

    private const string CleanControlFile = "ProofRules/CleanControlProof.cs";

    private readonly RuleProofBuild _build;

    [GeneratedRegex(
            pattern: @"/EveryBannedSymbolProof\.cs\((?<line>[0-9]+),[0-9]+\): error RS0030:",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex BannedLinePattern();

    private static bool IsFile(string path, string relativePath)
    {
        return path.EndsWith(value: "/" + relativePath, comparisonType: StringComparison.Ordinal);
    }

    private static void ShouldReport(ProcessResult result, string file, IReadOnlyList<string> expected)
    {
        result.ExitCode.ShouldNotBe(expected: 0, customMessage: result.Output);
        result.ErrorIdsInFile(pathEnding: file).ShouldBe(expected: expected, customMessage: result.Output);
    }
}
