using System;
using System.Collections.Generic;
using System.IO;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Files;

/// <summary>
/// The indentation and file settings of both <c>.editorconfig</c> files (D-84): spaces, never tabs, an indent of 4
/// and a tab width of 4 in both files, the text settings at the repository root, and IDE0055 at error in the
/// solution file, which must not declare <c>root</c> so the root settings still apply. Each check reads the value
/// that takes effect, the last one in its section, and no section in either file may set one of these keys to
/// another value.
/// </summary>
public sealed class EditorConfigSettingsTests
{
    /// <summary>
    /// The repository-root <c>.editorconfig</c> declares <c>root = true</c> and, for every file, spaces with an indent
    /// of 4 and a tab width of 4, LF line endings, UTF-8, a final newline and trimmed trailing whitespace; no section
    /// sets any of these to another value.
    /// </summary>
    [Fact]
    public void RootEditorConfig_EveryFile_SetsSpacesIndentFourTabWidthFour()
    {
        EditorConfigFile root = Load(folder: RepositoryLayout.RepositoryRoot);

        IReadOnlyList<string> violations =
        [
            .. root.CheckEffective(section: EditorConfigFile.Preamble, expected: _rootPreamble),
            .. root.CheckEffective(section: "*", expected: _textSettings),
            .. root.FindConflicts(expected: _textSettings),
        ];

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// The solution <c>.editorconfig</c> sets IDE0055 (formatting) to error and spaces with an indent of 4 and a tab
    /// width of 4 for C# files, sets none of the text settings to another value in any section, and does not declare
    /// <c>root</c>.
    /// </summary>
    [Fact]
    public void SolutionEditorConfig_CSharpFiles_KeepFormattingAtError()
    {
        EditorConfigFile solution = Load(folder: RepositoryLayout.SolutionRoot);

        IReadOnlyList<string> violations =
        [
            .. solution.CheckEffective(section: "*.cs", expected: _csharpSettings),
            .. solution.FindConflicts(expected: _csharpSettings),
            .. solution.FindConflicts(expected: _textSettings),
        ];

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
        solution.Sets(key: "root").ShouldBeFalse();
    }

    /// <summary>
    /// A repeated key whose last value differs, and a later, more specific section with a tab indent, are both
    /// reported, though the expected line is also present.
    /// </summary>
    [Fact]
    public void EditorConfig_OverriddenSetting_IsReported()
    {
        var file = EditorConfigFile.Parse(text: """
                root = true

                [*]
                indent_style = space
                indent_size = 4
                indent_size = 2

                [*.md]
                indent_style = tab
                """);
        var expected = new Dictionary<string, string>(comparer: StringComparer.Ordinal)
        {
            ["indent_style"] = "space",
            ["indent_size"] = "4",
        };

        file.CheckEffective(section: "*", expected: expected).ShouldHaveSingleItem()
                .ShouldContain(expected: "indent_size takes effect as '2'");
        file.FindConflicts(expected: expected).Count.ShouldBe(expected: 2);
    }

    private static readonly Dictionary<string, string> _rootPreamble = new(comparer: StringComparer.Ordinal)
    {
        ["root"] = "true",
    };

    private static readonly Dictionary<string, string> _textSettings = new(comparer: StringComparer.Ordinal)
    {
        ["indent_style"] = "space",
        ["indent_size"] = "4",
        ["tab_width"] = "4",
        ["end_of_line"] = "lf",
        ["charset"] = "utf-8",
        ["insert_final_newline"] = "true",
        ["trim_trailing_whitespace"] = "true",
    };

    private static readonly Dictionary<string, string> _csharpSettings = new(comparer: StringComparer.Ordinal)
    {
        ["dotnet_diagnostic.ide0055.severity"] = "error",
        ["indent_style"] = "space",
        ["indent_size"] = "4",
        ["tab_width"] = "4",
    };

    private static EditorConfigFile Load(string folder)
    {
        string path = Path.Combine(path1: folder, path2: ".editorconfig");
        return EditorConfigFile.Parse(text: File.ReadAllText(path: path));
    }
}
