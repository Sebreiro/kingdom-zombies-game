using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;

namespace LangProject.Core.ArchitectureTests.Documentation;

/// <summary>
/// The repository's docs as the docs checks see them: every path git tracks, and the text of every tracked
/// Markdown file outside <c>.claude/</c> and <c>.planning/</c>. It is built from the working tree or from plain
/// values, so the proofs need no files. Paths are repository-relative with forward slashes and are compared with
/// their exact case, so the checks give the same answer on every file system.
/// </summary>
internal sealed class RepositoryDocs
{
    /// <summary>Initializes a new instance of the <see cref="RepositoryDocs"/> class.</summary>
    /// <param name="trackedFiles">Every tracked file; the documents are added to it.</param>
    /// <param name="documents">The checked Markdown documents, by path.</param>
    internal RepositoryDocs(IEnumerable<string> trackedFiles, IReadOnlyDictionary<string, string> documents)
    {
        Documents = documents;
        TrackedPaths = trackedFiles.Concat(second: documents.Keys).ToHashSet(comparer: StringComparer.Ordinal);
        _folders = TrackedPaths.SelectMany(selector: ParentFolders).ToHashSet(comparer: StringComparer.Ordinal);
    }

    /// <summary>Gets every tracked path.</summary>
    internal IReadOnlySet<string> TrackedPaths { get; }

    /// <summary>Gets the text of every checked Markdown document, by path.</summary>
    internal IReadOnlyDictionary<string, string> Documents { get; }

    /// <summary>
    /// Gets a value indicating whether a path is a tracked file or a folder that holds one. The empty path is the
    /// repository root, which always exists.
    /// </summary>
    /// <param name="path">A repository-relative path with forward slashes and no trailing slash.</param>
    /// <returns><see langword="true"/> when git tracks the file or a file in the folder.</returns>
    internal bool Exists(string path)
    {
        return path.Length == 0 || TrackedPaths.Contains(item: path) || _folders.Contains(item: path);
    }

    /// <summary>Gets the text of a checked document.</summary>
    /// <param name="path">A repository-relative path.</param>
    /// <returns>The text, or <see langword="null"/> when no checked document has that path.</returns>
    internal string? Text(string path)
    {
        return Documents.TryGetValue(key: path, value: out string? text) ? text : null;
    }

    /// <summary>
    /// Loads the tracked files from <c>git ls-files</c> and reads every tracked <c>.md</c> file outside
    /// <c>.claude/</c> and <c>.planning/</c> from the working tree.
    /// </summary>
    /// <param name="cancellationToken">Stops the load when the test run is cancelled.</param>
    /// <returns>The repository's docs.</returns>
    internal static async Task<RepositoryDocs> LoadAsync(CancellationToken cancellationToken)
    {
        IReadOnlyList<string> trackedFiles = await TrackedFiles.ListAsync(cancellationToken: cancellationToken);
        var documents = new Dictionary<string, string>(comparer: StringComparer.Ordinal);
        foreach (string path in trackedFiles.Where(predicate: IsCheckedDocument))
        {
            string fullPath = Path.Combine(path1: RepositoryLayout.RepositoryRoot, path2: path);
            if (File.Exists(path: fullPath))
            {
                documents[path] = await File.ReadAllTextAsync(path: fullPath, cancellationToken: cancellationToken);
            }
        }

        return new RepositoryDocs(trackedFiles: trackedFiles, documents: documents);
    }

    /// <summary>
    /// Gets a value indicating whether a tracked path is a checked Markdown document: a <c>.md</c> file outside
    /// <c>.claude/</c> and <c>.planning/</c>.
    /// </summary>
    /// <param name="path">A repository-relative path with forward slashes.</param>
    /// <returns><see langword="true"/> for a checked document.</returns>
    internal static bool IsCheckedDocument(string path)
    {
        return path.EndsWith(value: ".md", comparisonType: StringComparison.Ordinal)
                && !_skippedFolders.Any(predicate: folder => path.StartsWith(
                        value: folder,
                        comparisonType: StringComparison.Ordinal));
    }

    private static readonly string[] _skippedFolders = [".claude/", ".planning/"];

    private readonly HashSet<string> _folders;

    private static IEnumerable<string> ParentFolders(string path)
    {
        int slash = path.LastIndexOf(value: '/');
        while (slash > 0)
        {
            yield return path[..slash];
            slash = path.LastIndexOf(value: '/', startIndex: slash - 1);
        }
    }
}
