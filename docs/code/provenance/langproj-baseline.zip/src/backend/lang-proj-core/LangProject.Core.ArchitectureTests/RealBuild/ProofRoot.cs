using System;
using System.Globalization;
using System.IO;

namespace LangProject.Core.ArchitectureTests.RealBuild;

/// <summary>
/// The private folder that holds every solution copy: <c>langproject-proofs</c> under the user's local
/// application-data folder (<c>~/.local/share</c> on Linux), or a per-user folder under the system temporary
/// folder when there is none. On Unix it has mode 0700 and must be the user's own, so no other user can plant a
/// file in it or in a copy, and no shared folder such as <c>/tmp</c> sits between a copy and the user's home.
/// </summary>
internal static class ProofRoot
{
    /// <summary>The name of the private root folder.</summary>
    internal const string FolderName = "langproject-proofs";

    /// <summary>Creates a fresh, empty folder for one solution copy under the private root.</summary>
    /// <returns>The full path of the new folder.</returns>
    /// <exception cref="InvalidOperationException">The private root is not private to this user.</exception>
    internal static string CreateCopyFolder()
    {
        string folder = Path.Combine(
                path1: PrivateRoot(),
                path2: Guid.NewGuid().ToString(format: "N", provider: CultureInfo.InvariantCulture));
        Directory.CreateDirectory(path: folder);
        return folder;
    }

    /// <summary>Gets the private root folder, creating it with mode 0700 on Unix.</summary>
    /// <returns>The full path of the private root.</returns>
    /// <exception cref="InvalidOperationException">The folder is not private to this user.</exception>
    internal static string PrivateRoot()
    {
        string baseFolder = Environment.GetFolderPath(
                folder: Environment.SpecialFolder.LocalApplicationData,
                option: Environment.SpecialFolderOption.Create);
        string root = baseFolder.Length > 0
                ? Path.Combine(path1: baseFolder, path2: FolderName)
                : Path.Combine(path1: Path.GetTempPath(), path2: $"{FolderName}-{Environment.UserName}");
        if (OperatingSystem.IsWindows())
        {
            Directory.CreateDirectory(path: root);
            return root;
        }

        Directory.CreateDirectory(path: root, unixCreateMode: PrivateMode);
        File.SetUnixFileMode(path: root, mode: PrivateMode);
        if (File.GetUnixFileMode(path: root) != PrivateMode)
        {
            throw new InvalidOperationException(message: $"{root} is not private to {Environment.UserName}.");
        }

        return root;
    }

    private const UnixFileMode PrivateMode =
            UnixFileMode.UserRead | UnixFileMode.UserWrite | UnixFileMode.UserExecute;
}
