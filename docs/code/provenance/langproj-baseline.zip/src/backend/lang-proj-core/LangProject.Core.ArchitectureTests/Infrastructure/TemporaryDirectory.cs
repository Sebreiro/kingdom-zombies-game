using System;
using System.Globalization;
using System.IO;

namespace LangProject.Core.ArchitectureTests.Infrastructure;

/// <summary>
/// A fresh, empty folder under the system temporary folder, deleted with its contents on dispose. Proofs that
/// build, pack or restore write only here, never into the working tree.
/// </summary>
internal sealed class TemporaryDirectory : IDisposable
{
    /// <summary>Deletes the folder and everything in it.</summary>
    public void Dispose()
    {
        if (Directory.Exists(path: FullPath))
        {
            Directory.Delete(path: FullPath, recursive: true);
        }
    }

    /// <summary>Initializes a new instance of the <see cref="TemporaryDirectory"/> class.</summary>
    /// <param name="prefix">The start of the folder name, so a leftover folder shows which proof made it.</param>
    internal TemporaryDirectory(string prefix)
    {
        string name = string.Create(
                provider: CultureInfo.InvariantCulture,
                handler: $"{prefix}-{Guid.NewGuid():N}");
        FullPath = Path.Combine(path1: Path.GetTempPath(), path2: name);
        Directory.CreateDirectory(path: FullPath);
    }

    /// <summary>Gets the full path of the folder.</summary>
    internal string FullPath { get; }
}
