using System.Collections.Generic;

namespace LangProject.Core.ArchitectureTests.Projects;

/// <summary>
/// One row of the D-46 allowed-edges table: the projects a project may reference, and the ones it must reference.
/// For an exact row the two sets are equal; the IntegrationTests row allows more than it requires.
/// </summary>
internal sealed class AllowedEdgeRow
{
    /// <summary>Initializes a new instance of the <see cref="AllowedEdgeRow"/> class.</summary>
    /// <param name="allowed">The projects the project may reference.</param>
    /// <param name="required">The projects the project must reference; a subset of <paramref name="allowed"/>.</param>
    internal AllowedEdgeRow(IReadOnlySet<string> allowed, IReadOnlySet<string> required)
    {
        Allowed = allowed;
        Required = required;
    }

    /// <summary>Gets the projects the project may reference.</summary>
    internal IReadOnlySet<string> Allowed { get; }

    /// <summary>Gets the projects the project must reference.</summary>
    internal IReadOnlySet<string> Required { get; }

    /// <summary>
    /// Gets a value indicating whether the row is exact: the project references all and only its set.
    /// </summary>
    internal bool IsExact => Allowed.SetEquals(other: Required);
}
