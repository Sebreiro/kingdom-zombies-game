using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Infrastructure;

/// <summary>
/// Tests of the diagnostic parsing that the real-build proofs compare exactly: IDs that start with a lowercase
/// letter, long IDs and errors without an ID are all seen, so an exact comparison cannot miss an extra error.
/// </summary>
public sealed class ProcessResultTests
{
    /// <summary>An xUnit analyzer error, with its lowercase start, is listed by ID and by file.</summary>
    [Fact]
    public void ErrorIds_LowercaseAnalyzerId_IsListed()
    {
        var result = new ProcessResult(
                exitCode: 1,
                standardOutput: "/s/ProofTests/SampleTests.cs(12,9): error xUnit1004: Test methods should not be "
                        + "skipped [/s/ProofTests/ProofTests.csproj]\n",
                standardError: string.Empty);

        result.ErrorIds.ShouldBe(expected: ["xUnit1004"]);
        result.ErrorIdsInFile(pathEnding: "ProofTests/SampleTests.cs").ShouldBe(expected: ["xUnit1004"]);
    }

    /// <summary>An MSBuild error without an ID is listed as the no-ID entry, in the output and in its file.</summary>
    [Fact]
    public void ErrorIds_ErrorWithoutId_IsListedAsNoId()
    {
        var result = new ProcessResult(
                exitCode: 1,
                standardOutput: "/s/Proof/Proof.csproj : error : The project could not be read.\n"
                        + "/s/Proof/Broken.cs(3,1): error : An error without a code.\n"
                        + "/s/Proof/Other.cs(4,2): warning CS0168: The variable 'error' is declared but never "
                        + "used: error: in a message.\n",
                standardError: string.Empty);

        result.ErrorIds.ShouldBe(expected: [ProcessResult.NoId]);
        result.WarningIds.ShouldBe(expected: ["CS0168"]);
        result.ErrorIdsInFile(pathEnding: "Proof/Broken.cs").ShouldBe(expected: [ProcessResult.NoId]);
    }

    /// <summary>A long MSBuild ID and a standard compiler ID are both listed, in ordinal order.</summary>
    [Fact]
    public void ErrorIds_LongAndShortIds_AreListed()
    {
        var result = new ProcessResult(
                exitCode: 1,
                standardOutput: "/s/A.cs(1,1): error CS0246: The type was not found.\n",
                standardError: "/s/A.csproj : error NETSDK1004: Assets file not found.\n"
                        + "MSBUILD : error MSB1009: Project file does not exist.\n");

        result.ErrorIds.ShouldBe(expected: ["CS0246", "MSB1009", "NETSDK1004"]);
    }
}
