using System;
using System.Collections.Generic;
using System.Linq;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// A GitHub Actions workflow or composite action read as block-style YAML and flattened to paths, such as
/// <c>jobs.fast.steps[3].run</c> or <c>runs.steps[1].shell</c>, so a check can read one job's own steps, a composite
/// action's steps and their settings. Comment lines are dropped, as YAML drops them, so a commented-out step or setting
/// is absent; a <c>#</c> inside a <c>run</c> block stays part of the shell text, and <see cref="ShellWords"/> drops it
/// the way the shell does. A pure function of the text, so proofs can feed changed workflows.
/// </summary>
internal sealed class CiWorkflow
{
    /// <summary>Gets the job ids, in file order.</summary>
    internal IReadOnlyList<string> JobIds => _jobIds;

    /// <summary>
    /// Gets every key path of the file, including the paths of mappings and list items that hold no scalar, such as
    /// <c>on.pull_request</c> for an empty trigger.
    /// </summary>
    internal IReadOnlyCollection<string> Paths => _paths;

    /// <summary>Parses a workflow's or a composite action's text.</summary>
    /// <param name="text">The workflow YAML.</param>
    /// <returns>The flattened workflow.</returns>
    internal static CiWorkflow Parse(string text)
    {
        var parser = new Parser(lines: text.Replace(oldValue: "\r\n", newValue: "\n").Split(separator: '\n'));
        parser.Run();
        return new CiWorkflow(values: parser.Values, paths: parser.Paths);
    }

    /// <summary>
    /// Splits shell text into words, dropping every word from a <c>#</c> at word start to the end of its line. A
    /// workflow expression keeps no inner spaces, so <c>${{ runner.temp }}</c> stays in one word as
    /// <c>${{runner.temp}}</c>.
    /// </summary>
    /// <param name="run">The text of a <c>run</c> setting.</param>
    /// <returns>The words the shell runs, in order.</returns>
    internal static IReadOnlyList<string> ShellWords(string run)
    {
        List<string> words = [];
        foreach (string rawLine in run.Split(separator: '\n'))
        {
            string line = rawLine
                    .Replace(oldValue: "${{ ", newValue: "${{", comparisonType: StringComparison.Ordinal)
                    .Replace(oldValue: " }}", newValue: "}}", comparisonType: StringComparison.Ordinal);
            words.AddRange(collection: line
                    .Split(separator: [' ', '\t'], options: StringSplitOptions.RemoveEmptyEntries)
                    .TakeWhile(predicate: word => !word.StartsWith(value: '#')));
        }

        return words;
    }

    /// <summary>Reads one scalar value by its path.</summary>
    /// <param name="path">The path, such as <c>permissions.contents</c>.</param>
    /// <returns>The value, or <see langword="null"/> when the path is absent.</returns>
    internal string? Value(string path)
    {
        return _values.TryGetValue(key: path, value: out string? value) ? value : null;
    }

    /// <summary>Reads the scalar settings under one path, with paths relative to it.</summary>
    /// <param name="prefix">The path, such as <c>permissions</c>.</param>
    /// <returns>The settings below the path, such as <c>contents</c>.</returns>
    internal IReadOnlyDictionary<string, string> ValuesUnder(string prefix)
    {
        string start = prefix + ".";
        return _values
                .Where(predicate: pair => pair.Key.StartsWith(value: start, comparisonType: StringComparison.Ordinal))
                .ToDictionary(
                        keySelector: pair => pair.Key[start.Length..],
                        elementSelector: pair => pair.Value,
                        comparer: StringComparer.Ordinal);
    }

    /// <summary>Reads the scalar items of one block list, such as <c>on.push.paths</c>, in file order.</summary>
    /// <param name="path">The path of the list.</param>
    /// <returns>The items, or an empty list when the path holds no scalar items.</returns>
    internal IReadOnlyList<string> ListValues(string path)
    {
        List<string> items = [];
        for (int index = 0; _values.TryGetValue(key: $"{path}[{index}]", value: out string? item); index++)
        {
            items.Add(item: item);
        }

        return items;
    }

    /// <summary>Reads the settings of one job other than its steps, with paths relative to the job.</summary>
    /// <param name="jobId">The job id.</param>
    /// <returns>The settings, such as <c>timeout-minutes</c> or <c>permissions.contents</c>.</returns>
    internal IReadOnlyDictionary<string, string> JobSettings(string jobId)
    {
        string prefix = $"jobs.{jobId}.";
        return _values
                .Where(predicate: pair => pair.Key.StartsWith(value: prefix, comparisonType: StringComparison.Ordinal)
                        && !pair.Key.StartsWith(value: prefix + "steps[", comparisonType: StringComparison.Ordinal))
                .ToDictionary(
                        keySelector: pair => pair.Key[prefix.Length..],
                        elementSelector: pair => pair.Value,
                        comparer: StringComparer.Ordinal);
    }

    /// <summary>Reads the steps of one job, in order, each with paths relative to the step.</summary>
    /// <param name="jobId">The job id.</param>
    /// <returns>One dictionary per step, such as <c>name</c>, <c>run</c>, <c>if</c> and <c>with.path</c>.</returns>
    internal IReadOnlyList<IReadOnlyDictionary<string, string>> Steps(string jobId)
    {
        return StepsAt(listPath: $"jobs.{jobId}.steps");
    }

    /// <summary>Reads the steps of a composite action, <c>runs.steps</c>, in order.</summary>
    /// <returns>One dictionary per step, such as <c>name</c>, <c>shell</c>, <c>run</c> and <c>env.NAME</c>.</returns>
    internal IReadOnlyList<IReadOnlyDictionary<string, string>> ActionSteps()
    {
        return StepsAt(listPath: "runs.steps");
    }

    private readonly Dictionary<string, string> _values;
    private readonly List<string> _jobIds;
    private readonly HashSet<string> _paths;

    private CiWorkflow(Dictionary<string, string> values, HashSet<string> paths)
    {
        _values = values;
        _paths = paths;
        _jobIds =
        [
            .. values.Keys
                    .Where(predicate: key => key.StartsWith(value: "jobs.", comparisonType: StringComparison.Ordinal))
                    .Select(selector: key => key["jobs.".Length..].Split(separator: '.')[0])
                    .Distinct(comparer: StringComparer.Ordinal),
        ];
    }

    private List<IReadOnlyDictionary<string, string>> StepsAt(string listPath)
    {
        List<IReadOnlyDictionary<string, string>> steps = [];
        for (int index = 0; ; index++)
        {
            string prefix = $"{listPath}[{index}].";
            var step = _values
                    .Where(predicate: pair => pair.Key.StartsWith(
                            value: prefix,
                            comparisonType: StringComparison.Ordinal))
                    .ToDictionary(
                            keySelector: pair => pair.Key[prefix.Length..],
                            elementSelector: pair => pair.Value,
                            comparer: StringComparer.Ordinal);
            if (step.Count == 0)
            {
                return steps;
            }

            steps.Add(item: step);
        }
    }

    private sealed class Parser
    {
        internal Parser(string[] lines)
        {
            _lines = lines;
        }

        internal Dictionary<string, string> Values { get; } = new(comparer: StringComparer.Ordinal);

        internal HashSet<string> Paths { get; } = new(comparer: StringComparer.Ordinal);

        internal void Run()
        {
            for (_index = 0; _index < _lines.Length; _index++)
            {
                string line = _lines[_index];
                string trimmed = line.Trim();
                if (trimmed.Length == 0 || trimmed.StartsWith(value: '#'))
                {
                    continue;
                }

                int indent = line.Length - line.TrimStart(trimChars: ' ').Length;
                while (_frames.Count > 0 && _frames.Peek().Indent >= indent)
                {
                    _frames.Pop();
                }

                string parent = _frames.Count > 0 ? _frames.Peek().Path : string.Empty;
                bool isItem = trimmed.StartsWith(value: "- ", comparisonType: StringComparison.Ordinal)
                        || string.Equals(a: trimmed, b: "-", comparisonType: StringComparison.Ordinal);
                if (isItem)
                {
                    ReadItem(parent: parent, indent: indent, content: trimmed[1..].TrimStart());
                }
                else
                {
                    ReadEntry(parent: parent, indent: indent, content: trimmed);
                }
            }
        }

        private readonly string[] _lines;
        private readonly Stack<(int Indent, string Path)> _frames = new();
        private readonly Dictionary<string, int> _itemCounts = new(comparer: StringComparer.Ordinal);
        private int _index;

        private static string Join(string parent, string key)
        {
            return parent.Length == 0 ? key : $"{parent}.{key}";
        }

        private static string Scalar(string value)
        {
            string text = value.Trim();
            if (text.Length >= 2 && (text[0] == '"' || text[0] == '\'') && text[^1] == text[0])
            {
                return text[1..^1];
            }

            int comment = text.IndexOf(value: " #", comparisonType: StringComparison.Ordinal);
            return comment < 0 ? text : text[..comment].TrimEnd();
        }

        private void ReadItem(string parent, int indent, string content)
        {
            int count = _itemCounts.GetValueOrDefault(key: parent);
            _itemCounts[parent] = count + 1;
            string itemPath = $"{parent}[{count}]";
            Paths.Add(item: itemPath);
            _frames.Push(item: (indent, itemPath));
            int colon = content.IndexOf(value: ':', comparisonType: StringComparison.Ordinal);
            if (colon > 0 && !content.StartsWith(value: '"'))
            {
                ReadEntry(parent: itemPath, indent: indent + 2, content: content);
            }
            else if (content.Length > 0)
            {
                Values[itemPath] = Scalar(value: content);
            }
        }

        private void ReadEntry(string parent, int indent, string content)
        {
            int colon = content.IndexOf(value: ':', comparisonType: StringComparison.Ordinal);
            if (colon < 0)
            {
                Values[parent] = Scalar(value: content);
                return;
            }

            string path = Join(parent: parent, key: Scalar(value: content[..colon]));
            Paths.Add(item: path);
            string value = content[(colon + 1)..].Trim();
            if (value.Length == 0)
            {
                _frames.Push(item: (indent, path));
            }
            else if (value[0] == '|' || value[0] == '>')
            {
                Values[path] = ReadBlock(indent: indent, folded: value[0] == '>');
            }
            else
            {
                Values[path] = Scalar(value: value);
            }
        }

        private string ReadBlock(int indent, bool folded)
        {
            List<string> content = [];
            int blockIndent = -1;
            while (_index + 1 < _lines.Length)
            {
                string next = _lines[_index + 1];
                int nextIndent = next.Length - next.TrimStart(trimChars: ' ').Length;
                if (next.Trim().Length > 0 && nextIndent <= indent)
                {
                    break;
                }

                _index++;
                if (next.Trim().Length > 0)
                {
                    blockIndent = blockIndent < 0 ? nextIndent : blockIndent;
                    content.Add(item: next[Math.Min(val1: blockIndent, val2: nextIndent)..]);
                }
            }

            return string.Join(separator: folded ? " " : "\n", values: content);
        }
    }
}
