using System;
using System.Globalization;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LangProject.Core.ArchitectureTests.RealBuild;

/// <summary>
/// A NuGet vulnerability feed on the loopback interface, for the audit proof: a V3 service index with one
/// <c>VulnerabilityInfo/6.7.0</c> resource, whose single page lists one high-severity advisory for
/// <c>Newtonsoft.Json</c> below 13.0.1 (GHSA-5crp-9r3c-p9vr). A solution copy that names it as its only audit
/// source gets the same audit result on every run, with no network and no live advisory database.
/// </summary>
internal sealed class AdvisoryFeed : IAsyncDisposable
{
    /// <summary>Stops the listener and waits for the serving loop to end.</summary>
    /// <returns>A task that completes when the feed has stopped.</returns>
    public async ValueTask DisposeAsync()
    {
        _listener.Close();
        await _serving;
    }

    /// <summary>Gets the URL of the feed's service index.</summary>
    internal Uri ServiceIndex => new(uriString: _prefix + "index.json");

    /// <summary>Gets the number of requests the feed has answered.</summary>
    internal int RequestCount => Volatile.Read(location: ref _requestCount);

    /// <summary>Starts a feed on a free loopback port.</summary>
    /// <returns>The running feed.</returns>
    internal static AdvisoryFeed Start()
    {
        return new AdvisoryFeed(port: FreePort());
    }

    private const string PrefixToken = "{prefix}/";

    private const string ServiceIndexJson = """
            {
              "version": "3.0.0",
              "resources": [
                { "@id": "{prefix}/vulnerabilities/index.json", "@type": "VulnerabilityInfo/6.7.0" }
              ]
            }
            """;

    private const string VulnerabilityIndexJson = """
            [
              {
                "@name": "base",
                "@id": "{prefix}/vulnerabilities/base.json",
                "@updated": "2026-01-01T00:00:00Z",
                "comment": "The audit proof's only advisory."
              }
            ]
            """;

    private const string VulnerabilityPageJson = """
            {
              "newtonsoft.json": [
                {
                  "severity": 2,
                  "url": "https://github.com/advisories/GHSA-5crp-9r3c-p9vr",
                  "versions": "(, 13.0.1)"
                }
              ]
            }
            """;

    private readonly HttpListener _listener = new();
    private readonly string _prefix;
    private readonly Task _serving;
    private int _requestCount;

    private AdvisoryFeed(int port)
    {
        _prefix = string.Create(provider: CultureInfo.InvariantCulture, handler: $"http://127.0.0.1:{port}/");
        _listener.Prefixes.Add(uriPrefix: _prefix);
        _listener.Start();
        _serving = ServeAsync();
    }

    private static int FreePort()
    {
        var probe = new TcpListener(localaddr: IPAddress.Loopback, port: 0);
        probe.Start();
        int port = ((IPEndPoint)probe.LocalEndpoint).Port;
        probe.Stop();
        return port;
    }

    private async Task ServeAsync()
    {
        while (true)
        {
            HttpListenerContext context;
            try
            {
                context = await _listener.GetContextAsync();
            }
            catch (Exception exception) when (exception is HttpListenerException
                    or ObjectDisposedException
                    or InvalidOperationException)
            {
                return;
            }

            Interlocked.Increment(location: ref _requestCount);
            string? body = Body(path: context.Request.Url?.AbsolutePath ?? string.Empty);
            byte[] bytes = Encoding.UTF8.GetBytes(s: body ?? "{}");
            context.Response.StatusCode = body is null ? 404 : 200;
            context.Response.ContentType = "application/json";
            context.Response.ContentLength64 = bytes.Length;
            await context.Response.OutputStream.WriteAsync(buffer: bytes);
            context.Response.Close();
        }
    }

    private string? Body(string path)
    {
        return path switch
        {
            "/index.json" => WithPrefix(template: ServiceIndexJson),
            "/vulnerabilities/index.json" => WithPrefix(template: VulnerabilityIndexJson),
            "/vulnerabilities/base.json" => VulnerabilityPageJson,
            _ => null,
        };
    }

    private string WithPrefix(string template)
    {
        return template.Replace(oldValue: PrefixToken, newValue: _prefix, comparisonType: StringComparison.Ordinal);
    }
}
