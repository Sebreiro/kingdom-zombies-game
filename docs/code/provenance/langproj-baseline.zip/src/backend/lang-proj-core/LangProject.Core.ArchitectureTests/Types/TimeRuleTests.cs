using System;
using System.Collections.Generic;
using LangProject.Core.ArchitectureTests.Types.Fixtures;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Types;

/// <summary>
/// Tests of the time rule (D-55): DTO and Domain entity properties hold times as <see cref="DateTimeOffset"/>, never
/// as <see cref="DateTime"/> or <see cref="TimeSpan"/>, and a duration property names its unit, for example
/// <c>DurationMs</c>. The rule runs on the production DTOs and entities and on one fixture per violation.
/// </summary>
public sealed class TimeRuleTests
{
    /// <summary>Every production DTO and entity passes; the selector is not empty.</summary>
    [Fact]
    public void TimeTypes_Production_UseDateTimeOffsetAndUnitSuffixes()
    {
        IReadOnlyList<Type> types =
        [
            .. TypeConventionRules.SelectDtos(types: ProductionTypes.TypesOf(filter: _ => true)),
            .. TypeConventionRules.SelectEntities(domainTypes: ProductionTypes.TypesOf(
                    assembly: ProductionTypes.Domain)),
        ];

        types.ShouldNotBeEmpty();
        IReadOnlyList<string> violations = TypeConventionRules.CheckTimeTypes(types: types);
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>The valid fixture passes, so the rule does not over-report.</summary>
    [Fact]
    public void TimeTypes_ValidFixture_IsAccepted()
    {
        IReadOnlyList<string> violations =
                TypeConventionRules.CheckTimeTypes(types: [typeof(TimeFixtures.ValidTimesDto)]);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>A <see cref="DateTime"/> property, nullable or not, is reported.</summary>
    [Fact]
    public void TimeTypes_DateTimeProperty_IsReported()
    {
        string violation = SingleViolation(type: typeof(TimeFixtures.DateTimePropertyDto));

        violation.ShouldContain(expected: nameof(TimeFixtures.DateTimePropertyDto.CreatedAt));
        violation.ShouldContain(expected: nameof(DateTimeOffset));
    }

    /// <summary>A <see cref="TimeSpan"/> property is reported.</summary>
    [Fact]
    public void TimeTypes_TimeSpanProperty_IsReported()
    {
        string violation = SingleViolation(type: typeof(TimeFixtures.TimeSpanPropertyDto));

        violation.ShouldContain(expected: nameof(TimeFixtures.TimeSpanPropertyDto.Elapsed));
        violation.ShouldContain(expected: nameof(TimeSpan));
    }

    /// <summary>A duration property without a unit suffix is reported.</summary>
    [Fact]
    public void TimeTypes_DurationWithoutUnit_IsReported()
    {
        string violation = SingleViolation(type: typeof(TimeFixtures.DurationWithoutUnitDto));

        violation.ShouldContain(expected: nameof(TimeFixtures.DurationWithoutUnitDto.TotalDuration));
        violation.ShouldContain(expected: "unit suffix");
    }

    /// <summary>
    /// A <see cref="DateTime"/> or <see cref="TimeSpan"/> inside a list, an array, a dictionary or a field is
    /// reported, not only a property of that exact type.
    /// </summary>
    /// <param name="fixture">The fixture type.</param>
    /// <param name="member">The member that holds the banned time.</param>
    /// <param name="banned">The banned type's name.</param>
    [Theory]
    [InlineData(typeof(TimeFixtures.DateTimeListDto), "Timestamps", nameof(DateTime))]
    [InlineData(typeof(TimeFixtures.DateTimeArrayDto), "Days", nameof(DateTime))]
    [InlineData(typeof(TimeFixtures.TimeSpanDictionaryDto), "Timings", nameof(TimeSpan))]
    [InlineData(typeof(TimeFixtures.DateTimeFieldEntity), "_createdAt", nameof(DateTime))]
    public void TimeTypes_TimeInsideCollectionOrField_IsReported(Type fixture, string member, string banned)
    {
        IReadOnlyList<string> violations = TypeConventionRules.CheckTimeTypes(types: [fixture]);

        violations.ShouldContain(
                elementPredicate: violation => violation.Contains(
                        value: $".{member} holds a {banned}",
                        comparisonType: StringComparison.Ordinal),
                customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>An empty selector fails instead of passing vacuously (SPEC R6).</summary>
    [Fact]
    public void TimeTypes_EmptySelector_Fails()
    {
        TypeConventionRules.CheckTimeTypes(types: []).ShouldHaveSingleItem().ShouldBe(
                expected: TypeConventionRules.EmptySelector);
    }

    private static string SingleViolation(Type type)
    {
        return TypeConventionRules.CheckTimeTypes(types: [type]).ShouldHaveSingleItem();
    }
}
