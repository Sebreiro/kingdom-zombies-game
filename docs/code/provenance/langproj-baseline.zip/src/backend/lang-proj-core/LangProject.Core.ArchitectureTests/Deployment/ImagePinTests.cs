using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Deployment;

/// <summary>
/// Pin checks of the backend Dockerfile: the SDK image tag equals <c>sdk.version</c> in <c>global.json</c>, which is
/// outside the build context (RESEARCH Pitfall 13); the two runtime images share one version and are chiseled
/// (D-66 as amended); every image has an exact tag (T-01-SC); the runtime stages run as the non-root app user with
/// exec-form entrypoints (RESEARCH Pitfall 14); every restore is locked; and the migration bundle's runtime
/// identifier follows the target architecture.
/// </summary>
public sealed class ImagePinTests
{
    /// <summary>The build stage's SDK image tag is <c>&lt;global.json sdk.version&gt;-noble</c>.</summary>
    [Fact]
    public void Dockerfile_SdkTag_EqualsGlobalJson()
    {
        using var globalJson = JsonDocument.Parse(json: File.ReadAllText(path: Path.Combine(
                path1: RepositoryLayout.RepositoryRoot,
                path2: "global.json")));
        string sdkVersion = globalJson.RootElement.GetProperty(propertyName: "sdk").GetProperty(propertyName: "version")
                .GetString() ?? string.Empty;

        DockerfileStage sdk = StagesFrom(repository: SdkRepository).ShouldHaveSingleItem();

        sdkVersion.ShouldNotBeEmpty();
        sdk.Tag.ShouldBe(expected: sdkVersion + "-noble");
    }

    /// <summary>The ASP.NET Core and runtime-deps images use the same runtime version.</summary>
    [Fact]
    public void Dockerfile_RuntimeTags_ShareOneVersion()
    {
        DockerfileStage aspnet = StagesFrom(repository: AspNetRepository).ShouldHaveSingleItem();
        DockerfileStage runtimeDeps = StagesFrom(repository: RuntimeDepsRepository).ShouldHaveSingleItem();

        string aspnetVersion = VersionOf(tag: aspnet.Tag);
        aspnetVersion.ShouldMatch(regexPattern: ExactVersion);
        VersionOf(tag: runtimeDeps.Tag).ShouldBe(expected: aspnetVersion);
    }

    /// <summary>
    /// The <c>api</c> target runs on the chiseled ASP.NET Core image with ICU and tzdata, and the <c>migrator</c>
    /// target on the chiseled runtime-deps image (D-66 as amended).
    /// </summary>
    [Fact]
    public void Dockerfile_RuntimeImages_AreChiseled()
    {
        DockerfileStage api = Stage(name: "api");
        DockerfileStage migrator = Stage(name: "migrator");

        api.Repository.ShouldBe(expected: AspNetRepository);
        api.Tag.ShouldEndWith(expected: "-noble-chiseled-extra");
        migrator.Repository.ShouldBe(expected: RuntimeDepsRepository);
        migrator.Tag.ShouldEndWith(expected: "-noble-chiseled");
    }

    /// <summary>
    /// Every image a stage starts from is either an earlier stage or an external image pinned to an exact
    /// <c>major.minor.patch</c> version (T-01-SC).
    /// </summary>
    [Fact]
    public void Dockerfile_ExternalImages_ArePinnedToExactVersions()
    {
        IReadOnlyList<DockerfileStage> stages = Stages();
        HashSet<string> stageNames = [.. stages.Select(selector: stage => stage.Name)];

        List<DockerfileStage> external = [.. stages.Where(predicate: stage => !stageNames.Contains(item: stage.Image))];

        external.Count.ShouldBe(expected: 3);
        foreach (DockerfileStage stage in external)
        {
            VersionOf(tag: stage.Tag).ShouldMatch(regexPattern: ExactVersion, customMessage: stage.Image);
        }
    }

    /// <summary>
    /// In the <c>api</c> and <c>migrator</c> stages the last <c>USER</c> instruction is the image's non-root app
    /// user, and each stage has one <c>ENTRYPOINT</c>; every <c>ENTRYPOINT</c> and <c>CMD</c> of every stage is in
    /// exec form, because the chiseled images have no shell. Instruction keywords match in any case, as Docker reads
    /// them.
    /// </summary>
    [Fact]
    public void Dockerfile_RuntimeStages_RunAsNonRootWithExecForm()
    {
        IReadOnlyList<string> findings = FindStartProblems(stages: Stages(), runtimeStages: _runtimeStages);

        findings.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: findings));
    }

    /// <summary>
    /// A runtime stage that switches back to <c>root</c> after the app user, a mixed-case shell-form
    /// <c>Entrypoint</c> and a lower-case shell-form <c>cmd</c> are each reported.
    /// </summary>
    [Fact]
    public void StartProblems_SyntheticStages_AreReported()
    {
        const string Text = "FROM base:1.0.0 AS api\nUSER $APP_UID\nUSER root\nENTRYPOINT [\"x\"]\n"
                + "FROM base:1.0.0 AS migrator\nuser $APP_UID\nEntrypoint /bin/sh -c x\ncmd dotnet x.dll\n";

        IReadOnlyList<string> findings = FindStartProblems(
                stages: DockerfileParser.Parse(text: Text),
                runtimeStages: _runtimeStages);

        findings.Count.ShouldBe(expected: 3, customMessage: string.Join(separator: "\n", values: findings));
        findings.ShouldContain(elementPredicate: finding => finding.Contains(
                value: "USER root",
                comparisonType: StringComparison.Ordinal));
        findings.ShouldContain(elementPredicate: finding => finding.Contains(
                value: "Entrypoint /bin/sh",
                comparisonType: StringComparison.Ordinal));
        findings.ShouldContain(elementPredicate: finding => finding.Contains(
                value: "cmd dotnet",
                comparisonType: StringComparison.Ordinal));
    }

    /// <summary>
    /// Every <c>dotnet restore</c> of the Dockerfile, the solution restore and the bundle stage's DAL restore, runs in
    /// locked mode against the committed lock files (D-79).
    /// </summary>
    [Fact]
    public void Dockerfile_EveryRestore_UsesLockedMode()
    {
        IReadOnlyList<DockerfileStage> stages = Stages();

        Stage(name: "build").Instructions
                .Contains(value: LockedSolutionRestore, comparer: StringComparer.Ordinal)
                .ShouldBeTrue();
        RestoreCommands(stages: stages).Count.ShouldBeGreaterThanOrEqualTo(expected: 2);
        FindUnlockedRestores(stages: stages).ShouldBeEmpty();
    }

    /// <summary>A restore without <c>--locked-mode</c>, alone or inside a chained <c>RUN</c>, is reported.</summary>
    [Fact]
    public void UnlockedRestores_SyntheticStage_AreReported()
    {
        const string Text = "FROM base:1.0.0 AS build\nRUN dotnet restore A.slnx --locked-mode\n"
                + "RUN dotnet tool restore\nRUN x=1 && dotnet restore B.csproj --runtime linux-x64 && echo done\n";

        IReadOnlyList<string> findings = FindUnlockedRestores(stages: DockerfileParser.Parse(text: Text));

        findings.ShouldHaveSingleItem().ShouldContain(expected: "B.csproj");
    }

    /// <summary>
    /// The bundle stage picks the bundle's runtime identifier from the target platform, <c>linux-x64</c> for amd64
    /// and <c>linux-arm64</c> for arm64, and fails on any other; the DAL project lists both identifiers and its lock
    /// file holds a section for each, so the locked restore covers the bundle.
    /// </summary>
    [Fact]
    public void Dockerfile_BundleRuntime_FollowsTargetArchitecture()
    {
        List<string> bundle = [.. Stage(name: "bundle").Instructions];
        string bundleRun = bundle.Single(predicate: instruction => instruction.Contains(
                value: "ef migrations bundle",
                comparisonType: StringComparison.Ordinal));
        string dalFolder = Path.Combine(path1: RepositoryLayout.SolutionRoot, path2: "LangProject.Core.DAL");
        string project = File.ReadAllText(path: Path.Combine(path1: dalFolder, path2: "LangProject.Core.DAL.csproj"));
        string lockFile = File.ReadAllText(path: Path.Combine(path1: dalFolder, path2: "packages.lock.json"));

        bundle.Contains(value: "ARG TARGETARCH", comparer: StringComparer.Ordinal).ShouldBeTrue();
        bundleRun.ShouldContain(expected: "amd64) rid=linux-x64 ;;");
        bundleRun.ShouldContain(expected: "arm64) rid=linux-arm64 ;;");
        bundleRun.ShouldContain(expected: "*) echo");
        bundleRun.ShouldContain(expected: "--runtime \"$rid\"");
        bundleRun.ShouldNotContain(expected: "--runtime linux-");
        project.ShouldContain(expected: "<RuntimeIdentifiers>linux-x64;linux-arm64</RuntimeIdentifiers>");
        lockFile.ShouldContain(expected: "\"net10.0/linux-x64\"");
        lockFile.ShouldContain(expected: "\"net10.0/linux-arm64\"");
    }

    /// <summary>
    /// The parser drops comments and blank lines, joins continuation lines and splits the stages at each <c>FROM</c>.
    /// </summary>
    [Fact]
    public void DockerfileParser_SyntheticText_JoinsContinuationsAndSkipsComments()
    {
        const string Text = "# header\nFROM registry.example/sdk:1.2.3 AS build\n\nRUN one \\\n        two\n"
                + "# step\nFROM build\nENTRYPOINT [\"x\"]\n";

        IReadOnlyList<DockerfileStage> stages = DockerfileParser.Parse(text: Text);

        stages.Count.ShouldBe(expected: 2);
        stages[0].Repository.ShouldBe(expected: "registry.example/sdk");
        stages[0].Tag.ShouldBe(expected: "1.2.3");
        stages[0].Name.ShouldBe(expected: "build");
        stages[0].Instructions.ShouldBe(expected: ["RUN one two"]);
        stages[1].Image.ShouldBe(expected: "build");
        stages[1].Name.ShouldBeEmpty();
        stages[1].Instructions.ShouldBe(expected: ["ENTRYPOINT [\"x\"]"]);
    }

    /// <summary>
    /// Finds the start problems of a Dockerfile: a runtime stage whose last <c>USER</c> is not the app user or whose
    /// <c>ENTRYPOINT</c> count is not one, and any shell-form <c>ENTRYPOINT</c> or <c>CMD</c>.
    /// </summary>
    /// <param name="stages">The parsed stages.</param>
    /// <param name="runtimeStages">The names of the stages that run as containers.</param>
    /// <returns>One message per problem.</returns>
    internal static IReadOnlyList<string> FindStartProblems(
            IReadOnlyList<DockerfileStage> stages,
            IReadOnlyCollection<string> runtimeStages)
    {
        List<string> findings = [];
        foreach (DockerfileStage stage in stages.Where(predicate: stage => runtimeStages.Contains(
                value: stage.Name,
                comparer: StringComparer.Ordinal)))
        {
            string? lastUser = stage.Instructions.LastOrDefault(predicate: instruction =>
                    HasKeyword(instruction: instruction, keyword: "USER"));
            if (lastUser is null || !string.Equals(
                    a: Arguments(instruction: lastUser),
                    b: AppUser,
                    comparisonType: StringComparison.Ordinal))
            {
                findings.Add(item: $"{stage.Name}: the last USER instruction is '{lastUser}', not 'USER {AppUser}'");
            }

            int entrypoints = stage.Instructions.Count(predicate: instruction =>
                    HasKeyword(instruction: instruction, keyword: "ENTRYPOINT"));
            if (entrypoints != 1)
            {
                findings.Add(item: $"{stage.Name}: {entrypoints} ENTRYPOINT instructions, expected 1");
            }
        }

        findings.AddRange(collection: stages
                .SelectMany(selector: stage => stage.Instructions)
                .Where(predicate: IsShellFormStart)
                .Select(selector: instruction => $"'{instruction}' is in shell form; use the exec form"));
        return findings;
    }

    /// <summary>Finds every <c>dotnet restore</c> command of a Dockerfile that lacks <c>--locked-mode</c>.</summary>
    /// <param name="stages">The parsed stages.</param>
    /// <returns>One message per unlocked restore.</returns>
    internal static IReadOnlyList<string> FindUnlockedRestores(IReadOnlyList<DockerfileStage> stages)
    {
        return
        [
            .. RestoreCommands(stages: stages)
                    .Where(predicate: command => !command.Contains(
                            value: "--locked-mode",
                            comparisonType: StringComparison.Ordinal))
                    .Select(selector: command => $"'{command}' restores without --locked-mode"),
        ];
    }

    private const string SdkRepository = "mcr.microsoft.com/dotnet/sdk";
    private const string AspNetRepository = "mcr.microsoft.com/dotnet/aspnet";
    private const string RuntimeDepsRepository = "mcr.microsoft.com/dotnet/runtime-deps";
    private const string ExactVersion = @"^[0-9]+\.[0-9]+\.[0-9]+$";
    private const string AppUser = "$APP_UID";
    private const string LockedSolutionRestore = "RUN dotnet restore LangProject.Core.slnx --locked-mode";

    private static readonly string[] _runtimeStages = ["api", "migrator"];
    private static readonly string[] _commandSeparators = ["&&", ";"];

    private static IReadOnlyList<DockerfileStage> Stages()
    {
        string path = Path.Combine(path1: RepositoryLayout.SolutionRoot, path2: "Dockerfile");
        return DockerfileParser.Parse(text: File.ReadAllText(path: path));
    }

    private static List<DockerfileStage> StagesFrom(string repository)
    {
        return
        [
            .. Stages().Where(predicate: stage => string.Equals(
                    a: stage.Repository,
                    b: repository,
                    comparisonType: StringComparison.Ordinal)),
        ];
    }

    private static DockerfileStage Stage(string name)
    {
        return Stages()
                .Where(predicate: stage => string.Equals(
                        a: stage.Name,
                        b: name,
                        comparisonType: StringComparison.Ordinal))
                .ShouldHaveSingleItem(customMessage: name);
    }

    private static string VersionOf(string tag)
    {
        int dash = tag.IndexOf(value: '-', comparisonType: StringComparison.Ordinal);
        return dash < 0 ? tag : tag[..dash];
    }

    private static List<string> RestoreCommands(IReadOnlyList<DockerfileStage> stages)
    {
        return
        [
            .. stages
                    .SelectMany(selector: stage => stage.Instructions)
                    .Where(predicate: instruction => HasKeyword(instruction: instruction, keyword: "RUN"))
                    .SelectMany(selector: instruction => Arguments(instruction: instruction).Split(
                            separator: _commandSeparators,
                            options: StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries))
                    .Where(predicate: command => command.StartsWith(
                            value: "dotnet restore ",
                            comparisonType: StringComparison.Ordinal)),
        ];
    }

    private static bool IsShellFormStart(string instruction)
    {
        bool isStart = HasKeyword(instruction: instruction, keyword: "ENTRYPOINT")
                || HasKeyword(instruction: instruction, keyword: "CMD");
        return isStart && !Arguments(instruction: instruction).StartsWith(value: '[');
    }

    private static bool HasKeyword(string instruction, string keyword)
    {
        string first = instruction.Split(separator: ' ', count: 2)[0];
        return string.Equals(a: first, b: keyword, comparisonType: StringComparison.OrdinalIgnoreCase);
    }

    private static string Arguments(string instruction)
    {
        int space = instruction.IndexOf(value: ' ', comparisonType: StringComparison.Ordinal);
        return space < 0 ? string.Empty : instruction[(space + 1)..].Trim();
    }
}
