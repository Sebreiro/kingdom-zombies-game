namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>The kinds of tracked file the suppression scan reads, each with its own parser.</summary>
internal enum SuppressionFileKind
{
    /// <summary>A file the scan does not read.</summary>
    Other = 0,

    /// <summary>A C# file, parsed with Roslyn.</summary>
    CSharp,

    /// <summary>A csproj, props or targets file, parsed as XML.</summary>
    MsBuild,

    /// <summary>An MSBuild response file such as <c>Directory.Build.rsp</c>, read as command-line switches.</summary>
    ResponseFile,

    /// <summary>An <c>.editorconfig</c> or <c>.globalconfig</c> file, parsed the way Roslyn parses it.</summary>
    Config,

    /// <summary>A GitHub workflow or composite action.</summary>
    Workflow,
}
