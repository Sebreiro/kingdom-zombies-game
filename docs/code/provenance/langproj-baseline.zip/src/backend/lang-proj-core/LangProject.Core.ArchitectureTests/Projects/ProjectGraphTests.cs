using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Projects;

/// <summary>
/// Tests of the project graph: the exact D-46 allowed-edges table, where each edge is written, solution membership,
/// Integration isolation (ARCH-03) and references to implementation projects (D-41). Each rule runs on the
/// production projects as MSBuild evaluates them and on a bad-on-purpose project.
/// </summary>
public sealed class ProjectGraphTests
{
    /// <summary>Every evaluated project references exactly the projects in its allowed-edges row.</summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task ProductionGraph_EveryProject_MatchesAllowedEdges()
    {
        IReadOnlyList<EvaluatedProject> projects = await ProjectEvaluator.LoadWorkingTreeAsync();

        projects.Select(selector: project => project.RelativePath).ShouldBe(expected: SolutionPaths());
        IReadOnlyList<string> violations = ProjectGraphRules.CheckAllowedEdges(projects: projects);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// Every tracked backend csproj is in the solution, every evaluated reference points at a solution project, table
    /// edges are written only in the csproj, and the analyzer-only edge comes only from <c>Directory.Build.targets</c>.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task ProductionGraph_EveryReference_ComesFromItsCsprojAndTheSolution()
    {
        IReadOnlyList<EvaluatedProject> projects = await ProjectEvaluator.LoadWorkingTreeAsync();

        projects.ShouldNotBeEmpty();
        IReadOnlyList<string> violations =
        [
            .. ProjectGraphRules.CheckSolutionMembership(projects: projects, solutionPaths: SolutionPaths()),
            .. ProjectGraphRules.CheckReferenceSources(projects: projects),
        ];

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>The production solution's Integration projects reference only Integration.Abstractions.</summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task ProductionGraph_IntegrationProjects_AreIsolated()
    {
        IReadOnlyList<string> violations = ProjectGraphRules.CheckIntegrationIsolation(
                projects: await ProjectEvaluator.LoadWorkingTreeAsync());

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>In production only CompositionRoot and the test projects reference implementation projects.</summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task ProductionGraph_ImplementationReferences_OnlyFromRootAndTests()
    {
        IReadOnlyList<string> violations = ProjectGraphRules.CheckImplementationReferences(
                projects: await ProjectEvaluator.LoadWorkingTreeAsync());

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>A synthetic API project that also references DAL yields one violation naming API and DAL.</summary>
    [Fact]
    public void ProjectGraph_ExtraReference_IsReported()
    {
        EvaluatedProject api = SyntheticProjects.Library(
                projectName: AllowedEdges.Api,
                AllowedEdges.ApiAbstractions,
                AllowedEdges.ApplicationAbstractions,
                AllowedEdges.Dal);

        IReadOnlyList<string> violations = ProjectGraphRules.CheckAllowedEdges(projects: [api]);

        string violation = violations.ShouldHaveSingleItem();
        violation.ShouldContain(expected: AllowedEdges.Api + ":");
        violation.ShouldContain(expected: AllowedEdges.Dal);
    }

    /// <summary>A project with no row in the table is reported, so a new project never passes silently.</summary>
    [Fact]
    public void ProjectGraph_MissingRow_IsReported()
    {
        EvaluatedProject unknown = SyntheticProjects.Library(projectName: "LangProject.Core.Unknown");

        IReadOnlyList<string> violations = ProjectGraphRules.CheckAllowedEdges(projects: [unknown]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: "LangProject.Core.Unknown");
    }

    /// <summary>
    /// A tracked csproj that the solution does not list, and a reference to a same-named csproj in another folder,
    /// are both reported: the file name alone never makes a project part of the solution.
    /// </summary>
    [Fact]
    public void ProjectGraph_ProjectOutsideSolution_IsReported()
    {
        EvaluatedProject stray = SyntheticProjects.Library(projectName: "LangProject.Core.Stray");
        EvaluatedProject api = SyntheticProjects.Build(
                relativePath: SyntheticProjects.PathOf(projectName: AllowedEdges.Api),
                references: ["../elsewhere/LangProject.Core.API.Abstractions.csproj"],
                properties: new Dictionary<string, string>(comparer: StringComparer.Ordinal));

        IReadOnlyList<string> violations = ProjectGraphRules.CheckSolutionMembership(
                projects: [stray, api],
                solutionPaths: SolutionPaths());

        violations.Count.ShouldBe(expected: 2, customMessage: string.Join(separator: "\n", values: violations));
        violations.ShouldContain(elementPredicate: violation => violation.Contains(
                value: "LangProject.Core.Stray/LangProject.Core.Stray.csproj is a project",
                comparisonType: StringComparison.Ordinal));
        violations.ShouldContain(elementPredicate: violation => violation.Contains(
                value: "../elsewhere/",
                comparisonType: StringComparison.Ordinal));
    }

    /// <summary>
    /// A table edge added by a props file, a second analyzer-only edge and a project without the analyzer edge are
    /// each reported.
    /// </summary>
    [Fact]
    public void ProjectGraph_ReferenceOutsideCsproj_IsReported()
    {
        EvaluatedProject fromProps = WithExtraReference(reference: new EvaluatedReference(
                relativePath: SyntheticProjects.PathOf(projectName: AllowedEdges.Dal),
                definedIn: "LangProject.Core.API/Directory.Build.props",
                isAnalyzerOnly: false));
        EvaluatedProject foreignAnalyzer = WithExtraReference(reference: new EvaluatedReference(
                relativePath: SyntheticProjects.PathOf(projectName: AllowedEdges.Domain),
                definedIn: ProjectGraphRules.SolutionTargetsPath,
                isAnalyzerOnly: true));
        var withoutAnalyzer = new EvaluatedProject(
                relativePath: SyntheticProjects.PathOf(projectName: AllowedEdges.Domain),
                properties: new Dictionary<string, string>(comparer: StringComparer.Ordinal),
                projectReferences: [],
                packageReferences: []);

        ProjectGraphRules.CheckReferenceSources(projects: [fromProps]).ShouldHaveSingleItem()
                .ShouldContain(expected: "Directory.Build.props");
        ProjectGraphRules.CheckReferenceSources(projects: [foreignAnalyzer]).ShouldHaveSingleItem()
                .ShouldContain(expected: AllowedEdges.Domain);
        ProjectGraphRules.CheckReferenceSources(projects: [withoutAnalyzer]).ShouldHaveSingleItem()
                .ShouldContain(expected: "has no analyzer-only reference");
    }

    /// <summary>An Integration project referencing DAL is reported (ARCH-03).</summary>
    [Fact]
    public void ProjectGraph_IntegrationReferencesDal_IsReported()
    {
        EvaluatedProject fake = SyntheticProjects.Library(
                projectName: FakeIntegration,
                AllowedEdges.IntegrationAbstractions,
                AllowedEdges.Dal);

        IReadOnlyList<string> violations = ProjectGraphRules.CheckIntegrationIsolation(projects: [fake]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: AllowedEdges.Dal);
    }

    /// <summary>An Integration project referencing Application is reported (ARCH-03).</summary>
    [Fact]
    public void ProjectGraph_IntegrationReferencesApplication_IsReported()
    {
        EvaluatedProject fake = SyntheticProjects.Library(
                projectName: FakeIntegration,
                AllowedEdges.IntegrationAbstractions,
                AllowedEdges.Application);

        IReadOnlyList<string> violations = ProjectGraphRules.CheckIntegrationIsolation(projects: [fake]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: AllowedEdges.Application);
    }

    /// <summary>An Integration project referencing another Integration project is reported (ARCH-03).</summary>
    [Fact]
    public void ProjectGraph_IntegrationReferencesOtherIntegration_IsReported()
    {
        EvaluatedProject fake = SyntheticProjects.Library(
                projectName: FakeIntegration,
                AllowedEdges.IntegrationAbstractions,
                "LangProject.Core.Integration.Other");

        IReadOnlyList<string> violations = ProjectGraphRules.CheckIntegrationIsolation(projects: [fake]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: "LangProject.Core.Integration.Other");
    }

    /// <summary>A synthetic API project referencing Application, not Application.Abstractions, is reported.</summary>
    [Fact]
    public void ProjectGraph_NonRootReferencesImplementation_IsReported()
    {
        EvaluatedProject api = SyntheticProjects.Library(
                projectName: AllowedEdges.Api,
                AllowedEdges.ApiAbstractions,
                AllowedEdges.Application);

        IReadOnlyList<string> violations = ProjectGraphRules.CheckImplementationReferences(projects: [api]);

        string violation = violations.ShouldHaveSingleItem();
        violation.ShouldContain(expected: AllowedEdges.Api + " ");
        violation.ShouldContain(expected: AllowedEdges.Application + " ");
    }

    /// <summary>On production the Integration rule selects Integration.Abstractions, so it is never vacuous.</summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task IntegrationRule_Selector_MatchesAtLeastOneProject()
    {
        IReadOnlyList<EvaluatedProject> selected = ProjectGraphRules.SelectIntegrationProjects(
                projects: await ProjectEvaluator.LoadWorkingTreeAsync());

        selected.Select(selector: project => project.Name)
                .Contains(value: AllowedEdges.IntegrationAbstractions, comparer: StringComparer.Ordinal)
                .ShouldBeTrue();
    }

    /// <summary>
    /// The projects to evaluate are the solution's plus every tracked csproj outside the frontend folder, so a csproj
    /// left out of the solution is still evaluated and then reported.
    /// </summary>
    [Fact]
    public void Evaluation_ProjectList_IncludesTrackedCsprojOutsideSolution()
    {
        IReadOnlyList<string> paths = ProjectEvaluator.ListProjectPaths(
                solutionPaths: ["LangProject.Core.API/LangProject.Core.API.csproj"],
                trackedFiles:
                [
                    "README.md",
                    "src/backend/lang-proj-core/LangProject.Core.API/LangProject.Core.API.csproj",
                    "src/backend/lang-proj-core/LangProject.Core.Stray/LangProject.Core.Stray.csproj",
                    "src/backend/tools/Tool/Tool.csproj",
                    "src/frontend/App/App.csproj",
                ],
                solutionPrefix: "src/backend/lang-proj-core/");

        paths.ShouldBe(expected:
        [
            "../tools/Tool/Tool.csproj",
            "LangProject.Core.API/LangProject.Core.API.csproj",
            "LangProject.Core.Stray/LangProject.Core.Stray.csproj",
        ]);
    }

    /// <summary>The table has a row for each of the 15 projects named in code-architecture.md.</summary>
    [Fact]
    public void AllowedEdges_Table_HasEveryDocumentedProject()
    {
        AllowedEdges.NamedRows.Order(comparer: StringComparer.Ordinal)
                .ShouldBe(expected: _documentedProjects.Order(comparer: StringComparer.Ordinal));
        AllowedEdges.IsIntegrationVendor(projectName: "LangProject.Core.Integration.Vendor").ShouldBeTrue();
    }

    /// <summary>
    /// The written allowed-edges table in code-architecture.md has the same rows as <see cref="AllowedEdges"/>, with
    /// the same allowed and required projects in each.
    /// </summary>
    [Fact]
    public void AllowedEdges_WrittenTable_MatchesCode()
    {
        string markdown = File.ReadAllText(path: Path.Combine(
                path1: RepositoryLayout.BackendDocs,
                path2: "CodeRules",
                path3: "code-architecture.md"));

        IReadOnlyList<(string Project, string Cell)> rows = EdgeTableDocument.ReadRows(markdown: markdown);
        IReadOnlyList<string> violations = EdgeTableDocument.Compare(rows: rows, solutionProjects: SolutionNames());

        rows.Count.ShouldBe(expected: AllowedEdges.NamedRows.Count + 1);
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// A written table that drifted from the code is reported row by row: a missing analyzer exclusion, an extra
    /// edge, a missing required edge, a missing row and an unknown row.
    /// </summary>
    [Fact]
    public void AllowedEdges_DriftedWrittenTable_IsReported()
    {
        string markdown = File.ReadAllText(path: Path.Combine(
                path1: RepositoryLayout.BackendDocs,
                path2: "CodeRules",
                path3: "code-architecture.md"));
        List<(string Project, string Cell)> rows =
        [
            .. EdgeTableDocument.ReadRows(markdown: markdown)
                    .Where(predicate: row => !string.Equals(
                            a: row.Project,
                            b: "Domain",
                            comparisonType: StringComparison.Ordinal))
                    .Select(selector: row => row.Project switch
                    {
                        "ArchitectureTests" => (row.Project, "every non-test project"),
                        "DAL" => (row.Project, "DAL.Abstractions, Domain, Application"),
                        "IntegrationTests" => (row.Project, "Domain" + PlusEveryOther),
                        _ => row,
                    }),
            ("Unknown", "none"),
        ];

        IReadOnlyList<string> violations = EdgeTableDocument.Compare(rows: rows, solutionProjects: SolutionNames());

        violations.Count.ShouldBe(expected: 5, customMessage: string.Join(separator: "\n", values: violations));
        foreach (string project in new[] { "ArchitectureTests:", "DAL:", "IntegrationTests:", "Unknown:", "Domain:" })
        {
            violations.ShouldContain(
                    elementPredicate: violation => violation.Contains(
                            value: project,
                            comparisonType: StringComparison.Ordinal),
                    customMessage: project);
        }
    }

    /// <summary>IntegrationTests without a reference to CompositionRoot is reported: its row requires it.</summary>
    [Fact]
    public void ProjectGraph_IntegrationTestsWithoutCompositionRoot_IsReported()
    {
        EvaluatedProject tests = SyntheticProjects.Library(
                projectName: AllowedEdges.IntegrationTests,
                AllowedEdges.Api,
                AllowedEdges.Domain);

        IReadOnlyList<string> violations = ProjectGraphRules.CheckAllowedEdges(
                projects: [tests, SyntheticProjects.Library(projectName: AllowedEdges.CompositionRoot)]);

        violations.ShouldContain(elementPredicate: violation => violation.StartsWith(
                value: $"{AllowedEdges.IntegrationTests}: does not reference {AllowedEdges.CompositionRoot}",
                comparisonType: StringComparison.Ordinal));
    }

    private const string FakeIntegration = "LangProject.Core.Integration.Fake";

    private const string PlusEveryOther = ", plus any other non-test project except the analyzer";

    private static readonly string[] _documentedProjects =
    [
        AllowedEdges.CompositionRoot,
        AllowedEdges.Api,
        AllowedEdges.ApiAbstractions,
        AllowedEdges.Application,
        AllowedEdges.ApplicationAbstractions,
        AllowedEdges.Dal,
        AllowedEdges.DalAbstractions,
        AllowedEdges.Domain,
        AllowedEdges.IntegrationAbstractions,
        AllowedEdges.UnitOfWorkEntityFrameworkCore,
        AllowedEdges.UnitOfWorkAbstractions,
        AllowedEdges.Analyzers,
        AllowedEdges.IntegrationTests,
        AllowedEdges.ArchitectureTests,
        AllowedEdges.AnalyzersTests,
    ];

    private static IReadOnlyList<string> SolutionPaths()
    {
        return SolutionFile.ReadProjectPaths(solutionXml: File.ReadAllText(path: RepositoryLayout.SolutionFilePath));
    }

    private static List<string> SolutionNames()
    {
        return [.. SolutionPaths().Select(selector: path => Path.GetFileNameWithoutExtension(path: path))];
    }

    private static EvaluatedProject WithExtraReference(EvaluatedReference reference)
    {
        EvaluatedProject api = SyntheticProjects.Library(
                projectName: AllowedEdges.Api,
                AllowedEdges.ApiAbstractions,
                AllowedEdges.ApplicationAbstractions);
        return new EvaluatedProject(
                relativePath: api.RelativePath,
                properties: new Dictionary<string, string>(comparer: StringComparer.Ordinal),
                projectReferences: [.. api.ProjectReferences, reference],
                packageReferences: []);
    }
}
