using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// The P1 suppression scan: finds every suppression in a tracked C#, MSBuild, response, <c>.editorconfig</c>,
/// <c>.globalconfig</c>, workflow or composite-action file, so a test can require a rule-matrix exemption row for
/// each. A pure function of the path and the content, so proofs can feed synthetic files.
/// </summary>
/// <remarks>
/// Each file kind has its own parser, which reads the file the way the tool that consumes it does:
/// <see cref="CSharpSuppressions"/> (Roslyn), <see cref="MsBuildSuppressions"/> (XML, and switches for response
/// files), <see cref="ConfigSuppressions"/> (Roslyn's <c>AnalyzerConfig</c> patterns) and
/// <see cref="WorkflowSuppressions"/>. A generated file name (<c>.g.cs</c>, <c>.g.i.cs</c>, <c>.designer.cs</c>,
/// <c>.generated.cs</c>, <c>TemporaryGeneratedFile_</c>) and a <c>GlobalSuppressions</c> file name are hits on
/// line 0. Every hit has a subject, the normalized text of exactly what it suppresses; an exemption row covers a
/// hit only when its text equals that subject.
/// </remarks>
internal static partial class SuppressionScanner
{
    /// <summary>
    /// Tells whether the scan reads a tracked file: C# files, csproj, props, targets and response files,
    /// <c>.editorconfig</c> and <c>.globalconfig</c> files, workflows under <c>.github/workflows/</c> and
    /// composite actions under <c>.github/actions/</c>, outside <c>.claude/</c> and <c>.planning/</c>.
    /// </summary>
    /// <param name="relativePath">The repository-relative path, with forward slashes.</param>
    /// <returns><see langword="true"/> when the scan reads the file.</returns>
    internal static bool IsScanned(string relativePath)
    {
        bool skipped = relativePath.StartsWith(value: ".claude/", comparisonType: StringComparison.Ordinal)
                || relativePath.StartsWith(value: ".planning/", comparisonType: StringComparison.Ordinal);
        return !skipped && KindOf(relativePath: relativePath) != SuppressionFileKind.Other;
    }

    /// <summary>Finds every suppression in one file.</summary>
    /// <param name="relativePath">The repository-relative path, with forward slashes.</param>
    /// <param name="content">The file text.</param>
    /// <returns>The hits, file-name hits first, then in file order.</returns>
    internal static IReadOnlyList<SuppressionHit> Scan(string relativePath, string content)
    {
        SuppressionFileKind kind = KindOf(relativePath: relativePath);
        var hits = new List<SuppressionHit>();
        if (kind == SuppressionFileKind.CSharp)
        {
            hits.AddRange(collection: FileNameHits(relativePath: relativePath));
        }

        hits.AddRange(collection: kind switch
        {
            SuppressionFileKind.CSharp => CSharpSuppressions.Scan(relativePath: relativePath, content: content),
            SuppressionFileKind.MsBuild => MsBuildSuppressions.Scan(relativePath: relativePath, content: content),
            SuppressionFileKind.ResponseFile =>
                    MsBuildSuppressions.ScanResponseFile(relativePath: relativePath, content: content),
            SuppressionFileKind.Config => ConfigSuppressions.Scan(relativePath: relativePath, content: content),
            SuppressionFileKind.Workflow => WorkflowSuppressions.Scan(relativePath: relativePath, content: content),
            _ => [],
        });
        return hits;
    }

    /// <summary>
    /// Tells whether an exemption row covers a hit: the path matches the row's glob, and the row's text equals the
    /// hit's subject exactly. A second suppression on the same line, or a suppression hidden in a trailing comment,
    /// has a subject of its own and is not covered.
    /// </summary>
    /// <param name="hit">The hit.</param>
    /// <param name="exemptions">The exemption rows of the rule matrix.</param>
    /// <returns><see langword="true"/> when a row covers the hit.</returns>
    internal static bool IsExempt(SuppressionHit hit, IReadOnlyList<MatrixExemption> exemptions)
    {
        return exemptions.Any(predicate: exemption => MatchesGlob(relativePath: hit.Path, glob: exemption.PathGlob)
                && string.Equals(a: hit.Subject, b: exemption.Text, comparisonType: StringComparison.Ordinal));
    }

    /// <summary>
    /// Matches a repository-relative path against an exemption glob: <c>*</c> within one folder, <c>**</c> across
    /// folders, <c>?</c> for one character and <c>{a,b}</c> for either alternative.
    /// </summary>
    /// <param name="relativePath">The repository-relative path, with forward slashes.</param>
    /// <param name="glob">The glob.</param>
    /// <returns><see langword="true"/> when the whole path matches.</returns>
    internal static bool MatchesGlob(string relativePath, string glob)
    {
        return Regex.IsMatch(
                input: relativePath,
                pattern: GlobToRegex(glob: glob),
                options: RegexOptions.CultureInvariant,
                matchTimeout: _regexTimeout);
    }

    private static readonly TimeSpan _regexTimeout = TimeSpan.FromSeconds(seconds: 10);

    private static readonly string[] _msBuildExtensions = [".csproj", ".props", ".targets"];

    private static readonly string[] _workflowExtensions = [".yml", ".yaml"];

    private static readonly string[] _workflowFolders = [".github/workflows/", ".github/actions/"];

    [GeneratedRegex(
            pattern: @"(\.g|\.g\.i|\.designer|\.generated)\.cs$|^TemporaryGeneratedFile_|GlobalSuppressions",
            options: RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex GeneratedFileNamePattern();

    private static IEnumerable<SuppressionHit> FileNameHits(string relativePath)
    {
        string name = Path.GetFileName(path: relativePath);
        return GeneratedFileNamePattern()
                .Matches(input: name)
                .Select(selector: match => new SuppressionHit(
                        path: relativePath,
                        lineNumber: 0,
                        text: name,
                        subject: match.Value,
                        pattern: match.Value.StartsWith(
                                value: "GlobalSuppressions",
                                comparisonType: StringComparison.OrdinalIgnoreCase)
                                ? "GlobalSuppressions file"
                                : "generated file name"));
    }

    private static SuppressionFileKind KindOf(string relativePath)
    {
        string name = Path.GetFileName(path: relativePath);
        string extension = Path.GetExtension(path: relativePath);
        if (string.Equals(a: extension, b: ".cs", comparisonType: StringComparison.OrdinalIgnoreCase))
        {
            return SuppressionFileKind.CSharp;
        }

        if (_msBuildExtensions.Contains(value: extension, comparer: StringComparer.OrdinalIgnoreCase))
        {
            return SuppressionFileKind.MsBuild;
        }

        if (string.Equals(a: extension, b: ".rsp", comparisonType: StringComparison.OrdinalIgnoreCase))
        {
            return SuppressionFileKind.ResponseFile;
        }

        if (string.Equals(a: name, b: ".editorconfig", comparisonType: StringComparison.OrdinalIgnoreCase)
                || string.Equals(a: extension, b: ".globalconfig", comparisonType: StringComparison.OrdinalIgnoreCase))
        {
            return SuppressionFileKind.Config;
        }

        bool inGitHubFolder = _workflowFolders.Any(predicate: folder => relativePath.StartsWith(
                value: folder,
                comparisonType: StringComparison.Ordinal));
        bool isWorkflow = inGitHubFolder
                && _workflowExtensions.Contains(value: extension, comparer: StringComparer.OrdinalIgnoreCase);
        return isWorkflow ? SuppressionFileKind.Workflow : SuppressionFileKind.Other;
    }

    private static string GlobToRegex(string glob)
    {
        var pattern = new StringBuilder(value: "^");
        for (int index = 0; index < glob.Length; index++)
        {
            char character = glob[index];
            bool doubleStar = character == '*' && index + 1 < glob.Length && glob[index + 1] == '*';
            if (doubleStar && index + 2 < glob.Length && glob[index + 2] == '/')
            {
                pattern.Append(value: "(.*/)?");
                index += 2;
            }
            else if (doubleStar)
            {
                pattern.Append(value: ".*");
                index++;
            }
            else
            {
                pattern.Append(value: character switch
                {
                    '*' => "[^/]*",
                    '?' => "[^/]",
                    '{' => "(",
                    '}' => ")",
                    ',' => "|",
                    _ => Regex.Escape(str: new string(c: character, count: 1)),
                });
            }
        }

        return pattern.Append(value: '$').ToString();
    }
}
