namespace LangProject.Core.ArchitectureTests.Types.Fixtures;

/// <summary>
/// Options-class shapes for the options rule (D-38): one valid class and one bad-on-purpose shape per violation.
/// They compile under every house rule; only the ArchitectureTests rule rejects the bad ones.
/// </summary>
internal static class OptionsFixtures
{
    /// <summary>Valid: every setter is private, so only a binder with BindNonPublicProperties fills it.</summary>
    internal sealed class ValidOptions
    {
        public bool Enabled { get; private set; }

        public string Endpoint { get; private set; } = string.Empty;
    }

    /// <summary>Bad: a public setter.</summary>
    internal sealed class PublicSetterOptions
    {
        public bool Enabled { get; private set; }

        public string Endpoint { get; set; } = string.Empty;
    }

    /// <summary>Bad: an <c>init</c> setter.</summary>
    internal sealed class InitSetterOptions
    {
        public bool Enabled { get; private set; }

        public string Endpoint { get; init; } = string.Empty;
    }
}
