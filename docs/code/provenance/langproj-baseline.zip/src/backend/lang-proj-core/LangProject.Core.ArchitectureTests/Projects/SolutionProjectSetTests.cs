using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Xml.Linq;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Projects;

/// <summary>
/// Solution-level checks: the exact project set (SPEC R2), the single analyzer-only edge in
/// <c>Directory.Build.targets</c> (D-46) and the Roslyn pin that keeps the analyzer loadable (RESEARCH Pitfall 1).
/// </summary>
public sealed class SolutionProjectSetTests
{
    /// <summary>The solution file lists exactly the 15 projects named in code-architecture.md.</summary>
    [Fact]
    public void Solution_ProjectList_ContainsExactlyTheSpecProjectSet()
    {
        string solutionXml = File.ReadAllText(path: RepositoryLayout.SolutionFilePath);

        SolutionFile.ReadProjectPaths(solutionXml: solutionXml)
                .ShouldBe(expected: _specProjectPaths.Order(comparer: StringComparer.Ordinal));
    }

    /// <summary>
    /// <c>Directory.Build.targets</c> holds exactly one ProjectReference: the analyzer, as an analyzer only, and
    /// excluded from the analyzer's own build.
    /// </summary>
    [Fact]
    public void AnalyzerEdge_DirectoryBuildTargets_IsOneAnalyzerOnlyReference()
    {
        string targetsXml = File.ReadAllText(path: DirectoryBuildTargetsPath);

        IReadOnlyList<string> violations = CheckAnalyzerEdge(targetsXml: targetsXml);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>An analyzer edge that also references the analyzer's output assembly is reported.</summary>
    [Fact]
    public void AnalyzerEdge_SyntheticOutputReference_IsReported()
    {
        IReadOnlyList<string> violations = CheckAnalyzerEdge(targetsXml: """
                <Project>
                  <ItemGroup Condition="'$(MSBuildProjectName)' != 'Sebreiro.CodeRules.Analyzers'">
                    <ProjectReference
                        Include="packages/Sebreiro.CodeRules.Analyzers/Sebreiro.CodeRules.Analyzers.csproj"
                        OutputItemType="Analyzer" />
                  </ItemGroup>
                </Project>
                """);

        violations.ShouldHaveSingleItem().ShouldContain(expected: "ReferenceOutputAssembly");
    }

    /// <summary>
    /// The central <c>Microsoft.CodeAnalysis.CSharp</c> version is not newer than the compiler of the running SDK,
    /// so the analyzer loads instead of failing with CS9057.
    /// </summary>
    /// <returns>A task that completes when the check has run.</returns>
    [Fact]
    public async Task RoslynPin_CentralVersion_IsNotNewerThanTheSdkCompiler()
    {
        Version pin = ReadRoslynPin();
        string sdkVersion = (await RunDotnetAsync(arguments: "--version")).Trim();
        string sdkList = await RunDotnetAsync(arguments: "--list-sdks");

        Version compiler = ReadCompilerVersion(sdkVersion: sdkVersion, sdkList: sdkList);

        pin.ShouldBeLessThanOrEqualTo(
                expected: compiler,
                customMessage: $"Microsoft.CodeAnalysis.CSharp {pin} is newer than SDK {sdkVersion}'s compiler.");
    }

    /// <summary>
    /// A <c>dotnet</c> query that runs past its limit is killed and reported as a timeout, so a stuck SDK prompt
    /// cannot hang the test run.
    /// </summary>
    /// <returns>A task that completes when the check has run.</returns>
    [Fact]
    public async Task DotnetQuery_PastItsLimit_ThrowsTimeout()
    {
        Func<Task> query = () => DotnetQuery.RunAsync(
                arguments: ["--info"],
                workingDirectory: RepositoryLayout.RepositoryRoot,
                timeout: TimeSpan.FromMilliseconds(milliseconds: 1),
                cancellationToken: TestContext.Current.CancellationToken);

        await query.ShouldThrowAsync<TimeoutException>();
    }

    private const string AnalyzerName = "Sebreiro.CodeRules.Analyzers";

    private const string AnalyzerProjectPath =
            "packages/Sebreiro.CodeRules.Analyzers/Sebreiro.CodeRules.Analyzers.csproj";

    private const string SelfExclusion = "'$(MSBuildProjectName)' != '" + AnalyzerName + "'";

    private static readonly string[] _specProjectPaths =
    [
        "LangProject.Core.API/LangProject.Core.API.csproj",
        "LangProject.Core.API.Abstractions/LangProject.Core.API.Abstractions.csproj",
        "LangProject.Core.Application/LangProject.Core.Application.csproj",
        "LangProject.Core.Application.Abstractions/LangProject.Core.Application.Abstractions.csproj",
        "LangProject.Core.ArchitectureTests/LangProject.Core.ArchitectureTests.csproj",
        "LangProject.Core.CompositionRoot/LangProject.Core.CompositionRoot.csproj",
        "LangProject.Core.DAL/LangProject.Core.DAL.csproj",
        "LangProject.Core.DAL.Abstractions/LangProject.Core.DAL.Abstractions.csproj",
        "LangProject.Core.Domain/LangProject.Core.Domain.csproj",
        "LangProject.Core.Integration.Abstractions/LangProject.Core.Integration.Abstractions.csproj",
        "LangProject.Core.IntegrationTests/LangProject.Core.IntegrationTests.csproj",
        AnalyzerProjectPath,
        "packages/Sebreiro.CodeRules.Analyzers.Tests/Sebreiro.CodeRules.Analyzers.Tests.csproj",
        "packages/Sebreiro.UnitOfWork.Abstractions/Sebreiro.UnitOfWork.Abstractions.csproj",
        "packages/Sebreiro.UnitOfWork.EntityFrameworkCore/Sebreiro.UnitOfWork.EntityFrameworkCore.csproj",
    ];

    private static readonly TimeSpan _dotnetTimeout = TimeSpan.FromMinutes(minutes: 1);

    private static string DirectoryBuildTargetsPath =>
            Path.Combine(path1: RepositoryLayout.SolutionRoot, path2: "Directory.Build.targets");

    private static List<string> CheckAnalyzerEdge(string targetsXml)
    {
        List<XElement> references =
        [
            .. XmlText.Parse(xml: targetsXml).Descendants()
                    .Where(predicate: element => IsNamed(element: element, localName: "ProjectReference")),
        ];
        if (references.Count != 1)
        {
            return [$"Directory.Build.targets has {references.Count} ProjectReference items; expected exactly 1."];
        }

        XElement edge = references[0];
        List<string> violations = [];
        string include = ((string?)edge.Attribute(name: "Include") ?? string.Empty)
                .Replace(oldChar: '\\', newChar: '/');
        AddIfDifferent(
                violations: violations,
                name: "Include",
                actual: include.EndsWith(value: AnalyzerProjectPath, comparisonType: StringComparison.Ordinal)
                        ? AnalyzerProjectPath
                        : include,
                expected: AnalyzerProjectPath);
        AddIfDifferent(
                violations: violations,
                name: "OutputItemType",
                actual: (string?)edge.Attribute(name: "OutputItemType"),
                expected: "Analyzer");
        AddIfDifferent(
                violations: violations,
                name: "ReferenceOutputAssembly",
                actual: (string?)edge.Attribute(name: "ReferenceOutputAssembly"),
                expected: "false");
        AddIfDifferent(
                violations: violations,
                name: "ItemGroup Condition",
                actual: (string?)edge.Parent?.Attribute(name: "Condition"),
                expected: SelfExclusion);
        return violations;
    }

    private static void AddIfDifferent(List<string> violations, string name, string? actual, string? expected)
    {
        if (!string.Equals(a: actual, b: expected, comparisonType: StringComparison.Ordinal))
        {
            violations.Add(item: $"Analyzer edge {name} is '{actual}'; expected '{expected}'.");
        }
    }

    private static Version ReadRoslynPin()
    {
        string propsPath = Path.Combine(path1: RepositoryLayout.SolutionRoot, path2: "Directory.Packages.props");
        XElement pin = XmlText.Parse(xml: File.ReadAllText(path: propsPath)).Descendants()
                .Where(predicate: element => IsNamed(element: element, localName: "PackageVersion"))
                .Single(predicate: element => string.Equals(
                        a: (string?)element.Attribute(name: "Include"),
                        b: "Microsoft.CodeAnalysis.CSharp",
                        comparisonType: StringComparison.Ordinal));
        return Version.Parse(input: (string?)pin.Attribute(name: "Version") ?? string.Empty);
    }

    private static Version ReadCompilerVersion(string sdkVersion, string sdkList)
    {
        string prefix = sdkVersion + " [";
        string line = sdkList.Split(separator: '\n')
                .Select(selector: entry => entry.Trim())
                .Single(predicate: entry => entry.StartsWith(value: prefix, comparisonType: StringComparison.Ordinal));
        string sdkRoot = line[prefix.Length..^1];
        string compilerPath = Path.Combine(
                sdkRoot,
                sdkVersion,
                "Roslyn",
                "bincore",
                "Microsoft.CodeAnalysis.CSharp.dll");
        return AssemblyName.GetAssemblyName(assemblyFile: compilerPath).Version
                ?? throw new InvalidOperationException(message: $"{compilerPath} has no assembly version.");
    }

    private static async Task<string> RunDotnetAsync(string arguments)
    {
        ProcessResult result = await DotnetQuery.RunAsync(
                arguments: [arguments],
                workingDirectory: RepositoryLayout.RepositoryRoot,
                timeout: _dotnetTimeout,
                cancellationToken: TestContext.Current.CancellationToken);
        result.ExitCode.ShouldBe(expected: 0, customMessage: $"dotnet {arguments} failed: {result.Output}");
        return result.StandardOutput;
    }

    private static bool IsNamed(XElement element, string localName)
    {
        return string.Equals(a: element.Name.LocalName, b: localName, comparisonType: StringComparison.Ordinal);
    }
}
