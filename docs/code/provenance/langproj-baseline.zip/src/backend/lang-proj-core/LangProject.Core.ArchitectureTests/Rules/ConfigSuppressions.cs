using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// The <c>.editorconfig</c> and <c>.globalconfig</c> part of the suppression scan. Each line is parsed with the
/// patterns of Roslyn's <c>AnalyzerConfig</c>: a section header may end in a <c>#</c> or <c>;</c> comment, a
/// setting splits on the first <c>=</c> or <c>:</c>, and a trailing comment is stripped from the value. The subject
/// of a hit is the setting as <c>[section] key = value</c>, or <c>key = value</c> before the first section.
/// </summary>
/// <remarks>
/// Hits: a <c>.severity</c> key (one diagnostic, a category or all analyzers) set to <c>none</c>, <c>silent</c>,
/// <c>refactoring</c>, <c>suggestion</c>, <c>default</c>, <c>hidden</c> or <c>info</c>; an option value whose
/// severity suffix is one of these; and <c>generated_code = true</c>.
/// </remarks>
internal static partial class ConfigSuppressions
{
    /// <summary>Finds every suppression in one <c>.editorconfig</c> or <c>.globalconfig</c> file.</summary>
    /// <param name="relativePath">The repository-relative path, with forward slashes.</param>
    /// <param name="content">The file text.</param>
    /// <returns>The hits, in file order.</returns>
    internal static IReadOnlyList<SuppressionHit> Scan(string relativePath, string content)
    {
        var hits = new List<SuppressionHit>();
        string section = string.Empty;
        string[] lines = content.Split(separator: '\n');
        for (int index = 0; index < lines.Length; index++)
        {
            string line = lines[index].Trim();
            if (IsComment(line: line))
            {
                continue;
            }

            Match header = SectionPattern().Match(input: line);
            Match setting = PropertyPattern().Match(input: line);
            if (header.Success)
            {
                section = "[" + header.Groups["section"].Value + "]";
            }
            else if (setting.Success)
            {
                string key = setting.Groups["key"].Value;
                string value = setting.Groups["value"].Value;
                string? pattern = SettingPattern(key: key, value: value);
                if (pattern is not null)
                {
                    string subject = section.Length == 0 ? $"{key} = {value}" : $"{section} {key} = {value}";
                    hits.Add(item: new SuppressionHit(
                            path: relativePath,
                            lineNumber: index + 1,
                            text: line,
                            subject: subject,
                            pattern: pattern));
                }
            }
        }

        return hits;
    }

    private static readonly string[] _weakSeverities =
            ["none", "silent", "refactoring", "suggestion", "default", "hidden", "info"];

    [GeneratedRegex(
            pattern: @"^\s*\[(?<section>(([^#;]|\\#|\\;)+))\]\s*([#;].*)?$",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex SectionPattern();

    [GeneratedRegex(
            pattern: @"^\s*(?<key>[\w\.\-_]+)\s*[=:]\s*(?<value>.*?)\s*([#;].*)?$",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex PropertyPattern();

    private static bool IsComment(string line)
    {
        return line.StartsWith(value: '#') || line.StartsWith(value: ';');
    }

    private static string? SettingPattern(string key, string value)
    {
        bool isSeverity = key.EndsWith(value: ".severity", comparisonType: StringComparison.OrdinalIgnoreCase);
        if (isSeverity && IsWeak(severity: value))
        {
            return "severity downgrade";
        }

        int colon = value.LastIndexOf(value: ':');
        if (colon >= 0 && IsWeak(severity: value[(colon + 1)..].Trim()))
        {
            return "option severity downgrade";
        }

        bool generated = string.Equals(a: key, b: "generated_code", comparisonType: StringComparison.OrdinalIgnoreCase)
                && string.Equals(a: value, b: "true", comparisonType: StringComparison.OrdinalIgnoreCase);
        return generated ? "generated_code = true" : null;
    }

    private static bool IsWeak(string severity)
    {
        return _weakSeverities.Contains(value: severity, comparer: StringComparer.OrdinalIgnoreCase);
    }
}
