using System;
using System.Collections.Generic;
using System.Linq;
using LangProject.Core.API.Abstractions;
using LangProject.Core.ArchitectureTests.Projects;
using LangProject.Core.ArchitectureTests.Types.Fixtures;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Types;

/// <summary>
/// Tests of the D-40/D-41 type rules: <c>.Abstractions</c> projects hold only interfaces, DTOs, enums and
/// constants-only static classes, and an implementation project's only public type is its registration class.
/// Also proves that every reflection rule fails on an empty selector (SPEC R6).
/// </summary>
public sealed class AbstractionsRuleTests
{
    /// <summary>
    /// Every type in every <c>.Abstractions</c> assembly, product and <c>Sebreiro.UnitOfWork</c>, is an allowed kind.
    /// </summary>
    [Fact]
    public void Abstractions_Production_HoldOnlyAllowedKinds()
    {
        IReadOnlyList<Type> types = ProductionTypes.TypesOf(filter: IsAbstractionsProject);

        types.ShouldContain(expected: typeof(ApiRoutes));
        types.Select(selector: type => ProductionTypes.NameOf(assembly: type.Assembly))
                .Distinct(comparer: StringComparer.Ordinal)
                .Order(comparer: StringComparer.Ordinal)
                .ShouldBe(expected:
                [
                    AllowedEdges.ApiAbstractions,
                    AllowedEdges.ApplicationAbstractions,
                    AllowedEdges.DalAbstractions,
                    AllowedEdges.IntegrationAbstractions,
                    AllowedEdges.UnitOfWorkAbstractions,
                ]);
        IReadOnlyList<string> violations = TypeConventionRules.CheckAbstractionsContent(types: types);
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>An interface, an enum, a constants-only static class and a DTO are all accepted.</summary>
    [Fact]
    public void Abstractions_AllowedKinds_AreAccepted()
    {
        IReadOnlyList<string> violations = TypeConventionRules.CheckAbstractionsContent(
                types:
                [
                    typeof(AbstractionFixtures.ISampleContract),
                    typeof(AbstractionFixtures.SampleKind),
                    typeof(AbstractionFixtures.SampleRoutes),
                    typeof(AbstractionFixtures.SampleDto),
                ]);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>A non-DTO class in an abstractions project is reported.</summary>
    [Fact]
    public void Abstractions_ServiceClass_IsReported()
    {
        IReadOnlyList<string> violations = TypeConventionRules.CheckAbstractionsContent(
                types: [typeof(AbstractionFixtures.ISampleContract), typeof(AbstractionFixtures.SampleService)]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: nameof(AbstractionFixtures.SampleService));
    }

    /// <summary>A static class with a method, not only constants, is reported.</summary>
    [Fact]
    public void Abstractions_StaticClassWithMethod_IsReported()
    {
        IReadOnlyList<string> violations = TypeConventionRules.CheckAbstractionsContent(
                types: [typeof(AbstractionFixtures.SampleHelpers)]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: nameof(AbstractionFixtures.SampleHelpers));
    }

    /// <summary>
    /// API, Application, DAL and Sebreiro.UnitOfWork.EntityFrameworkCore each expose exactly one public type, their
    /// registration class. DAL's generated EF migration types, which are public, are the one listed exclusion.
    /// </summary>
    [Fact]
    public void Implementations_Production_ExposeOnlyRegistration()
    {
        IReadOnlyList<Type> types = ProductionTypes.TypesOf(filter: AllowedEdges.IsImplementation);

        types.Select(selector: type => ProductionTypes.NameOf(assembly: type.Assembly))
                .Distinct(comparer: StringComparer.Ordinal)
                .Order(comparer: StringComparer.Ordinal)
                .ShouldBe(expected:
                [
                    AllowedEdges.Api,
                    AllowedEdges.Application,
                    AllowedEdges.Dal,
                    AllowedEdges.UnitOfWorkEntityFrameworkCore,
                ]);
        IReadOnlyList<string> violations = TypeConventionRules.CheckImplementationVisibility(types: types);
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>A registration class beside internal types passes, so the rule does not over-report.</summary>
    [Fact]
    public void Implementations_RegistrationOnly_IsAccepted()
    {
        IReadOnlyList<string> violations = TypeConventionRules.CheckImplementationVisibility(
                types:
                [
                    typeof(AbstractionFixtures.SampleRegistration),
                    typeof(AbstractionFixtures.SampleInternalService),
                ]);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>A second public type beside the registration class is reported.</summary>
    [Fact]
    public void Implementations_ExtraPublicType_IsReported()
    {
        IReadOnlyList<string> violations = TypeConventionRules.CheckImplementationVisibility(
                types:
                [
                    typeof(AbstractionFixtures.SampleRegistration),
                    typeof(AbstractionFixtures.SamplePublicService),
                    typeof(AbstractionFixtures.SampleInternalService),
                ]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: nameof(AbstractionFixtures.SamplePublicService));
    }

    /// <summary>An implementation project with no public registration class is reported.</summary>
    [Fact]
    public void Implementations_MissingRegistration_IsReported()
    {
        IReadOnlyList<string> violations = TypeConventionRules.CheckImplementationVisibility(
                types: [typeof(AbstractionFixtures.SampleInternalService)]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: "registration class");
    }

    /// <summary>
    /// Every reflection type rule, given an empty type set, reports that its selector matched zero types.
    /// </summary>
    /// <param name="rule">The name of the rule function.</param>
    [Theory]
    [InlineData(nameof(TypeConventionRules.CheckEntities))]
    [InlineData(nameof(TypeConventionRules.CheckDtos))]
    [InlineData(nameof(TypeConventionRules.CheckNaming))]
    [InlineData(nameof(TypeConventionRules.CheckAbstractionsContent))]
    [InlineData(nameof(TypeConventionRules.CheckImplementationVisibility))]
    public void EveryTypeRule_EmptySelector_Fails(string rule)
    {
        IReadOnlyList<string> violations = RunRule(rule: rule, types: []);

        violations.ShouldHaveSingleItem().ShouldBe(expected: TypeConventionRules.EmptySelector);
    }

    private static bool IsAbstractionsProject(string projectName)
    {
        return projectName.EndsWith(value: ".Abstractions", comparisonType: StringComparison.Ordinal);
    }

    private static IReadOnlyList<string> RunRule(string rule, IReadOnlyCollection<Type> types)
    {
        return rule switch
        {
            nameof(TypeConventionRules.CheckEntities) => TypeConventionRules.CheckEntities(entities: types),
            nameof(TypeConventionRules.CheckDtos) => TypeConventionRules.CheckDtos(dtos: types),
            nameof(TypeConventionRules.CheckNaming) => TypeConventionRules.CheckNaming(types: types),
            nameof(TypeConventionRules.CheckAbstractionsContent) =>
                    TypeConventionRules.CheckAbstractionsContent(types: types),
            nameof(TypeConventionRules.CheckImplementationVisibility) =>
                    TypeConventionRules.CheckImplementationVisibility(types: types),
            _ => throw new ArgumentOutOfRangeException(paramName: nameof(rule), message: "Unknown rule: " + rule),
        };
    }
}
