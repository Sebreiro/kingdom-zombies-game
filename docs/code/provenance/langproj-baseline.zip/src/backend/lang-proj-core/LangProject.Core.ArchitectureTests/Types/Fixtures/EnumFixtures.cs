using System.Text.Json.Serialization;

namespace LangProject.Core.ArchitectureTests.Types.Fixtures;

/// <summary>
/// Enum shapes for the enum rule (D-52): one valid shape and one bad-on-purpose shape per violation. They compile
/// under every house rule; only the ArchitectureTests enum rule rejects the bad ones.
/// </summary>
internal static class EnumFixtures
{
    /// <summary>
    /// A valid enum: <c>Unknown = 0</c> and every member pinned with a unique name. <c>Running</c> is pinned as
    /// <c>Active</c>, as after a rename of the C# member.
    /// </summary>
    internal enum ValidStatus
    {
        [JsonStringEnumMemberName("Unknown")]
        Unknown = 0,

        [JsonStringEnumMemberName("Active")]
        Running = 1,

        [JsonStringEnumMemberName("Stopped")]
        Stopped = 2,
    }

    /// <summary>Bad: no member named <c>Unknown</c>.</summary>
    internal enum MissingUnknownStatus
    {
        [JsonStringEnumMemberName("None")]
        None = 0,

        [JsonStringEnumMemberName("Active")]
        Active = 1,
    }

    /// <summary>Bad: <c>Unknown</c> is not the zero value.</summary>
    internal enum UnknownNotZeroStatus
    {
        [JsonStringEnumMemberName("Active")]
        Active = 0,

        [JsonStringEnumMemberName("Unknown")]
        Unknown = 1,
    }

    /// <summary>Bad: a member without <c>[JsonStringEnumMemberName]</c>.</summary>
    internal enum UnpinnedMemberStatus
    {
        [JsonStringEnumMemberName("Unknown")]
        Unknown = 0,

        [JsonStringEnumMemberName("Active")]
        Active = 1,

        NotPinned = 2,
    }

    /// <summary>Bad: two members share a pinned name.</summary>
    internal enum DuplicatePinnedNameStatus
    {
        [JsonStringEnumMemberName("Unknown")]
        Unknown = 0,

        [JsonStringEnumMemberName("Same")]
        First = 1,

        [JsonStringEnumMemberName("Same")]
        Second = 2,
    }
}
