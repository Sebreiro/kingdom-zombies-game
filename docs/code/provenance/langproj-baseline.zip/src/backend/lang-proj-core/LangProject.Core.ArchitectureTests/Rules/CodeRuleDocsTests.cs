using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// The code-rule docs do not drift from the solution (SPEC R20, QUAL-04): no old <c>Sebreiro.LangProject</c> names,
/// no sentence saying that violations are warnings only, exactly the solution's projects in the project tree, and the
/// body-length rule stated as "more than 60 lines fails, 40 advised".
/// </summary>
public sealed class CodeRuleDocsTests
{
    /// <summary><c>code-style.md</c> and <c>code-architecture.md</c> have no drift.</summary>
    [Fact]
    public void CodeRuleDocs_CurrentText_HasNoDrift()
    {
        string codeArchitecture = ReadDoc(name: "code-architecture.md");
        IReadOnlyList<string> solutionProjects = SolutionProjectNames();

        IReadOnlyList<string> drift = RuleDocument.FindDrift(
                codeStyle: ReadDoc(name: "code-style.md"),
                codeArchitecture: codeArchitecture,
                solutionProjects: [.. solutionProjects]);

        RuleDocument.ListedProjects(codeArchitecture: codeArchitecture).ShouldBe(expected: solutionProjects);
        drift.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: drift));
    }

    /// <summary>
    /// Docs with an old product name, a warning-only sentence, a project list that misses a project and an
    /// "ideally under 40 lines" rule are reported once for each.
    /// </summary>
    [Fact]
    public void CodeRuleDocs_DriftedText_IsReported()
    {
        const string CodeStyle = """
                # Code Style Guidelines

                Analyzer default severity is warning, so violations don't break the build.

                ### Member body length

                Methods are ideally under 40 lines.

                """;
        const string CodeArchitecture = """
                # Code Architecture Guidelines

                ```
                lang-proj-core/
                    Sebreiro.LangProject.Core.API/
                    LangProject.Core.Domain/
                ```

                """;

        IReadOnlyList<string> drift = RuleDocument.FindDrift(
                codeStyle: CodeStyle,
                codeArchitecture: CodeArchitecture,
                solutionProjects: ["LangProject.Core.API", "LangProject.Core.Domain"]);

        drift.Count.ShouldBe(expected: 4, customMessage: string.Join(separator: "\n", values: drift));
        drift.ShouldContain(elementPredicate: message => message.Contains(
                value: "Sebreiro.LangProject",
                comparisonType: StringComparison.Ordinal));
        drift.ShouldContain(elementPredicate: message => message.Contains(
                value: "warning",
                comparisonType: StringComparison.Ordinal));
        drift.ShouldContain(elementPredicate: message => message.Contains(
                value: "LangProject.Core.API",
                comparisonType: StringComparison.Ordinal));
        drift.ShouldContain(elementPredicate: message => message.Contains(
                value: "60",
                comparisonType: StringComparison.Ordinal));
    }

    /// <summary>
    /// GitHub anchors keep letters, digits, <c>-</c> and <c>_</c>, drop other punctuation, and use dashes.
    /// </summary>
    /// <param name="heading">The heading text.</param>
    /// <param name="expected">The anchor GitHub gives it.</param>
    [Theory]
    [InlineData("UTF-8 encoding", "utf-8-encoding")]
    [InlineData("Spaces only, no tab characters", "spaces-only-no-tab-characters")]
    [InlineData("Private fields use _camelCase", "private-fields-use-_camelcase")]
    [InlineData("Test method names use Method_State_Expected", "test-method-names-use-method_state_expected")]
    [InlineData("ConfigureAwait in Sebreiro packages", "configureawait-in-sebreiro-packages")]
    public void Heading_Slug_MatchesGitHubAnchor(string heading, string expected)
    {
        RuleDocument.Slug(headingText: heading).ShouldBe(expected: expected);
    }

    /// <summary>
    /// A heading's <c>Enforcement:</c> line is the first non-blank line after it; a heading inside a fenced code
    /// block is not a heading.
    /// </summary>
    [Fact]
    public void Headings_EnforcementLine_IsParsed()
    {
        const string Markdown = """
                ## Files

                ### Final newline

                Enforcement: [R-03](../rule-matrix.md#r-03), [R-04](../rule-matrix.md#r-04)

                Every file ends with a newline.

                ### No link

                Text.

                ```
                ### Not a heading
                ```

                """;

        IReadOnlyList<RuleHeading> headings = RuleDocument.Headings(markdown: Markdown);

        headings.Select(selector: heading => heading.Text).ShouldBe(expected: ["Files", "Final newline", "No link"]);
        headings[1].EnforcementIds.ShouldBe(expected: ["R-03", "R-04"]);
        headings[1].Slug.ShouldBe(expected: "final-newline");
        headings[2].EnforcementIds.ShouldBeEmpty();
    }

    private static string ReadDoc(string name)
    {
        return File.ReadAllText(
                path: Path.Combine(path1: RepositoryLayout.BackendDocs, path2: "CodeRules", path3: name));
    }

    private static List<string> SolutionProjectNames()
    {
        string solutionXml = File.ReadAllText(path: RepositoryLayout.SolutionFilePath);
        return
        [
            .. SolutionFile.ReadProjectPaths(solutionXml: solutionXml)
                    .Select(selector: path => Path.GetFileNameWithoutExtension(path: path))
                    .Order(comparer: StringComparer.Ordinal),
        ];
    }
}
