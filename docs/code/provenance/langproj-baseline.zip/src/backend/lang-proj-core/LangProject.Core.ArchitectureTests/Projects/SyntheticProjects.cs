using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace LangProject.Core.ArchitectureTests.Projects;

/// <summary>
/// Builds in-memory <see cref="EvaluatedProject"/> values for the bad-on-purpose proofs, as MSBuild would evaluate a
/// well-formed project in the solution: transitive references disabled, a library named after the project, the
/// solution-root <c>Directory.Build.*</c> files, the analyzer-only edge, and table edges written in the csproj itself.
/// </summary>
internal static class SyntheticProjects
{
    /// <summary>Gets the solution-relative csproj path of a product project, such as <c>X/X.csproj</c>.</summary>
    /// <param name="projectName">The project name.</param>
    /// <returns>The path.</returns>
    internal static string PathOf(string projectName)
    {
        return projectName.StartsWith(value: "Sebreiro.", comparisonType: StringComparison.Ordinal)
                ? $"{ProjectGraphRules.PackagesFolder}{projectName}/{projectName}.csproj"
                : $"{projectName}/{projectName}.csproj";
    }

    /// <summary>Builds a well-formed project that references the given projects from its own csproj.</summary>
    /// <param name="projectName">The project name.</param>
    /// <param name="references">The names of the projects it references.</param>
    /// <returns>The evaluated project.</returns>
    internal static EvaluatedProject Library(string projectName, params string[] references)
    {
        return Build(
                relativePath: PathOf(projectName: projectName),
                references: references.Select(selector: PathOf),
                properties: new Dictionary<string, string>(comparer: StringComparer.Ordinal));
    }

    /// <summary>Builds a project with explicit reference paths and property overrides.</summary>
    /// <param name="relativePath">The project's solution-relative csproj path.</param>
    /// <param name="references">The solution-relative paths of the projects it references from its csproj.</param>
    /// <param name="properties">Evaluated properties that replace the well-formed defaults.</param>
    /// <returns>The evaluated project.</returns>
    internal static EvaluatedProject Build(
            string relativePath,
            IEnumerable<string> references,
            IReadOnlyDictionary<string, string> properties)
    {
        var values = new Dictionary<string, string>(
                collection: _defaults,
                comparer: StringComparer.OrdinalIgnoreCase);
        foreach (KeyValuePair<string, string> property in properties)
        {
            values[property.Key] = property.Value;
        }

        values.TryAdd(
                key: ProjectEvaluator.AssemblyNameProperty,
                value: Path.GetFileNameWithoutExtension(path: relativePath));

        List<EvaluatedReference> items =
        [
            .. references.Select(selector: reference => new EvaluatedReference(
                    relativePath: reference,
                    definedIn: relativePath,
                    isAnalyzerOnly: false)),
            AnalyzerEdge(),
        ];
        return new EvaluatedProject(
                relativePath: relativePath,
                properties: values,
                projectReferences: items,
                packageReferences: []);
    }

    /// <summary>Builds the analyzer-only edge as the solution <c>Directory.Build.targets</c> adds it.</summary>
    /// <returns>The analyzer-only reference.</returns>
    internal static EvaluatedReference AnalyzerEdge()
    {
        return new EvaluatedReference(
                relativePath: PathOf(projectName: AllowedEdges.Analyzers),
                definedIn: ProjectGraphRules.SolutionTargetsPath,
                isAnalyzerOnly: true);
    }

    private static readonly Dictionary<string, string> _defaults = new(comparer: StringComparer.OrdinalIgnoreCase)
    {
        [ProjectEvaluator.TransitiveProperty] = "true",
        [ProjectEvaluator.OutputTypeProperty] = "Library",
        [ProjectEvaluator.IsTestProjectProperty] = string.Empty,
        [ProjectEvaluator.ImportPropsProperty] = "true",
        [ProjectEvaluator.ImportTargetsProperty] = "true",
        [ProjectEvaluator.PropsPathProperty] = ProjectGraphRules.SolutionPropsPath,
        [ProjectEvaluator.TargetsPathProperty] = ProjectGraphRules.SolutionTargetsPath,
    };
}
