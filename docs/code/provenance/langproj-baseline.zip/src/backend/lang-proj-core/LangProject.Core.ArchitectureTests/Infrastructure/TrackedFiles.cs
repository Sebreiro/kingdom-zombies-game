using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace LangProject.Core.ArchitectureTests.Infrastructure;

/// <summary>Lists the files git tracks in the repository, so repository scans read exactly the committed set.</summary>
internal static class TrackedFiles
{
    /// <summary>Runs <c>git ls-files -z</c> at the repository root.</summary>
    /// <param name="cancellationToken">Stops the run when the test run is cancelled.</param>
    /// <returns>Repository-relative paths with forward slashes, in git's order.</returns>
    /// <exception cref="InvalidOperationException">git exited with a non-zero exit code.</exception>
    internal static async Task<IReadOnlyList<string>> ListAsync(CancellationToken cancellationToken)
    {
        var startInfo = new ProcessStartInfo(fileName: "git")
        {
            WorkingDirectory = RepositoryLayout.RepositoryRoot,
        };
        startInfo.ArgumentList.Add(item: "ls-files");
        startInfo.ArgumentList.Add(item: "-z");

        ProcessResult result = await ProcessRunner.RunAsync(
                startInfo: startInfo,
                timeout: _gitTimeout,
                cancellationToken: cancellationToken);

        return ParsePaths(result: result);
    }

    /// <summary>
    /// Reads the paths from a finished <c>git ls-files -z</c> run. Only the standard output holds paths; a warning git
    /// writes to the standard error is never glued to the last path.
    /// </summary>
    /// <param name="result">The finished run.</param>
    /// <returns>The NUL-separated paths of the standard output.</returns>
    /// <exception cref="InvalidOperationException">git exited with a non-zero exit code.</exception>
    internal static IReadOnlyList<string> ParsePaths(ProcessResult result)
    {
        if (result.ExitCode != 0)
        {
            throw new InvalidOperationException(message: $"git ls-files failed: {result.Output}");
        }

        return result.StandardOutput.Split(separator: '\0', options: StringSplitOptions.RemoveEmptyEntries);
    }

    private static readonly TimeSpan _gitTimeout = TimeSpan.FromMinutes(minutes: 1);
}
