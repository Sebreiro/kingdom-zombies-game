using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using LangProject.Core.Domain.Languages;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace LangProject.Core.ArchitectureTests.Types.Fixtures;

/// <summary>
/// Type shapes for the layer-purity rules: one clean control and one bad-on-purpose dependency per rule. They compile
/// under every house rule; only the ArchitectureTests purity rules reject the bad ones.
/// </summary>
internal static class PurityFixtures
{
    /// <summary>The control: depends only on <c>System</c> types, so no purity rule reports it.</summary>
    internal sealed class CleanType
    {
        public CleanType(string name, DateOnly created)
        {
            Name = name;
            Created = created;
        }

        public string Name { get; }

        public DateOnly Created { get; }
    }

    /// <summary>Bad in Domain: holds a <see cref="ILogger"/>, a non-<c>System</c> type.</summary>
    internal sealed class DomainWithLogger
    {
        public DomainWithLogger(ILogger logger)
        {
            Logger = logger;
        }

        public ILogger Logger { get; }
    }

    /// <summary>Bad in Application: holds an <see cref="HttpClient"/>.</summary>
    internal sealed class ApplicationWithHttpClient
    {
        public ApplicationWithHttpClient(HttpClient httpClient)
        {
            HttpClient = httpClient;
        }

        public HttpClient HttpClient { get; }
    }

    /// <summary>Bad in Application: holds an EF Core <see cref="DbContext"/>.</summary>
    internal sealed class ApplicationWithDbContext
    {
        public ApplicationWithDbContext(DbContext dbContext)
        {
            DbContext = dbContext;
        }

        public DbContext DbContext { get; }
    }

    /// <summary>Bad outside CompositionRoot: takes an <see cref="IServiceProvider"/> constructor parameter.</summary>
    internal sealed class ServiceLocatorUser
    {
        public ServiceLocatorUser(IServiceProvider serviceProvider)
        {
            ServiceProvider = serviceProvider;
        }

        public IServiceProvider ServiceProvider { get; }
    }

    /// <summary>Bad in Domain: names <see cref="ILogger"/> only inside a lambda body.</summary>
    internal static class DomainLoggerInLambda
    {
        public static int CountLoggers(IEnumerable<object> items)
        {
            return items.Count(predicate: item => item is ILogger);
        }
    }

    /// <summary>Bad in Domain: names <see cref="ILogger"/> only inside an <c>async</c> method body.</summary>
    internal static class DomainLoggerInAsyncMethod
    {
        public static async Task<bool> IsLoggerAsync(object item)
        {
            await Task.Yield();
            return item is ILogger;
        }
    }

    /// <summary>Bad in Domain: names <see cref="ILogger"/> only inside an iterator body.</summary>
    internal static class DomainLoggerInIterator
    {
        public static IEnumerable<bool> AreLoggers(IEnumerable<object> items)
        {
            foreach (object item in items)
            {
                yield return item is ILogger;
            }
        }
    }

    /// <summary>Bad in Application: names an EF Core <see cref="DbContext"/> only in an <c>async</c> body.</summary>
    internal static class ApplicationDbContextInAsyncMethod
    {
        public static async Task<bool> IsContextAsync(object item)
        {
            await Task.Yield();
            return item is DbContext;
        }
    }

    /// <summary>Bad outside CompositionRoot: a factory lambda that resolves through the service provider.</summary>
    internal static class ServiceProviderInFactoryLambda
    {
        public static Func<object, object?> Factory()
        {
            return provider => ((IServiceProvider)provider).GetService(serviceType: typeof(CleanType));
        }
    }

    /// <summary>Bad outside CompositionRoot: takes an <see cref="IServiceScopeFactory"/>.</summary>
    internal sealed class ScopeFactoryUser
    {
        public ScopeFactoryUser(IServiceScopeFactory scopeFactory)
        {
            ScopeFactory = scopeFactory;
        }

        public IServiceScopeFactory ScopeFactory { get; }
    }

    /// <summary>Bad outside CompositionRoot: takes an <see cref="IServiceScope"/>.</summary>
    internal sealed class ScopeUser
    {
        public ScopeUser(IServiceScope scope)
        {
            Scope = scope;
        }

        public IServiceScope Scope { get; }
    }

    /// <summary>Bad outside CompositionRoot: takes an <see cref="IKeyedServiceProvider"/>.</summary>
    internal sealed class KeyedProviderUser
    {
        public KeyedProviderUser(IKeyedServiceProvider provider)
        {
            Provider = provider;
        }

        public IKeyedServiceProvider Provider { get; }
    }

    /// <summary>Bad outside CompositionRoot: builds an object through <see cref="ActivatorUtilities"/>.</summary>
    internal static class ActivatorUser
    {
        public static object Create(object provider)
        {
            return ActivatorUtilities.CreateInstance<CleanType>(provider: (IServiceProvider)provider, "name");
        }
    }

    /// <summary>Bad in an outward contract: a DTO exposing the <see cref="Language"/> entity (D-42).</summary>
    internal sealed class ContractWithEntityDto
    {
        public ContractWithEntityDto(Language language)
        {
            Language = language;
        }

        public Language Language { get; private set; }
    }
}
