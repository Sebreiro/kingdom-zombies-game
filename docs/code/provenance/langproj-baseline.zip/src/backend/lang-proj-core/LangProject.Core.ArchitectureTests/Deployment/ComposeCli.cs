using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;

namespace LangProject.Core.ArchitectureTests.Deployment;

/// <summary>
/// Runs <c>docker compose config</c> on <c>deploy/compose.yaml</c> with a given env file. Rendering the model needs
/// the Docker CLI with the Compose plugin, but no Docker daemon, so it runs in the fast CI job.
/// </summary>
/// <remarks>
/// Compose takes a variable from the process environment before the env file, so the child's environment drops every
/// variable that <c>deploy/.env.example</c> names, <c>SOURCE_REVISION_ID</c> and every <c>COMPOSE_*</c> variable.
/// The env file and the rendered JSON live in a temporary folder, never in <c>deploy/</c>.
/// </remarks>
internal static class ComposeCli
{
    /// <summary>Gets the path of <c>deploy/compose.yaml</c>.</summary>
    internal static string ComposeFile => Path.Combine(
            path1: RepositoryLayout.RepositoryRoot,
            path2: "deploy",
            path3: "compose.yaml");

    /// <summary>Gets the path of <c>deploy/.env.example</c>.</summary>
    internal static string EnvExampleFile => Path.Combine(
            path1: RepositoryLayout.RepositoryRoot,
            path2: "deploy",
            path3: ".env.example");

    /// <summary>Reads <c>deploy/.env.example</c>.</summary>
    /// <returns>The file's text.</returns>
    internal static string ReadEnvExample()
    {
        return File.ReadAllText(path: EnvExampleFile);
    }

    /// <summary>Lists the variable names that an env file assigns, in file order.</summary>
    /// <param name="envFileText">The text of an env file.</param>
    /// <returns>The names before the first <c>=</c> of every line that is not blank or a comment.</returns>
    internal static IReadOnlyList<string> VariableNames(string envFileText)
    {
        return
        [
            .. envFileText.Split(separator: '\n')
                    .Select(selector: line => line.Trim())
                    .Where(predicate: line => line.Length > 0 && !line.StartsWith(value: '#'))
                    .Where(predicate: line => line.Contains(value: '=', comparisonType: StringComparison.Ordinal))
                    .Select(selector: line => line[..line.IndexOf(
                            value: '=',
                            comparisonType: StringComparison.Ordinal)]),
        ];
    }

    /// <summary>Removes the line that assigns <paramref name="name"/> from an env file.</summary>
    /// <param name="envFileText">The text of an env file.</param>
    /// <param name="name">The variable to drop.</param>
    /// <returns>The env file without that variable.</returns>
    internal static string WithoutVariable(string envFileText, string name)
    {
        IEnumerable<string> kept = envFileText.Split(separator: '\n')
                .Where(predicate: line => !line.StartsWith(
                        value: name + "=",
                        comparisonType: StringComparison.Ordinal));
        return string.Join(separator: "\n", values: kept);
    }

    /// <summary>
    /// Runs <c>docker compose -f deploy/compose.yaml --env-file &lt;file&gt; config --format json</c> and keeps the
    /// rendered model.
    /// </summary>
    /// <param name="envFileText">The text of the env file to use.</param>
    /// <param name="cancellationToken">Stops the run when the test run is cancelled.</param>
    /// <returns>The exit code, the console output and the rendered JSON.</returns>
    internal static async Task<ComposeConfigResult> ConfigAsync(string envFileText, CancellationToken cancellationToken)
    {
        using var folder = new TemporaryDirectory(prefix: "compose-config");
        string envFile = Path.Combine(path1: folder.FullPath, path2: "test.env");
        string jsonFile = Path.Combine(path1: folder.FullPath, path2: "config.json");
        await File.WriteAllTextAsync(path: envFile, contents: envFileText, cancellationToken: cancellationToken);

        ProcessStartInfo startInfo = CreateStartInfo(envFile: envFile, jsonFile: jsonFile);
        ProcessResult result = await ProcessRunner.RunAsync(
                startInfo: startInfo,
                timeout: _timeout,
                cancellationToken: cancellationToken);

        string json = File.Exists(path: jsonFile)
                ? await File.ReadAllTextAsync(path: jsonFile, cancellationToken: cancellationToken)
                : string.Empty;
        return new ComposeConfigResult(exitCode: result.ExitCode, output: result.Output, json: json);
    }

    private static readonly TimeSpan _timeout = TimeSpan.FromMinutes(minutes: 1);

    private static ProcessStartInfo CreateStartInfo(string envFile, string jsonFile)
    {
        var startInfo = new ProcessStartInfo(fileName: "docker") { WorkingDirectory = RepositoryLayout.RepositoryRoot };
        string[] arguments =
        [
            "compose", "-f", ComposeFile, "--env-file", envFile, "config", "--format", "json", "--output", jsonFile,
        ];
        foreach (string argument in arguments)
        {
            startInfo.ArgumentList.Add(item: argument);
        }

        HashSet<string> removed = [.. VariableNames(envFileText: ReadEnvExample()), "SOURCE_REVISION_ID"];
        List<string> inherited =
        [
            .. startInfo.Environment.Keys.Where(predicate: key => removed.Contains(item: key)
                    || key.StartsWith(value: "COMPOSE_", comparisonType: StringComparison.Ordinal)),
        ];
        foreach (string key in inherited)
        {
            startInfo.Environment.Remove(key: key);
        }

        return startInfo;
    }
}
