using System;
using System.Collections.Generic;
using System.Linq;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Documentation;

/// <summary>
/// Every backend project documents itself (SPEC R18, DOCS-01): a <c>docs/</c> folder beside its csproj with a
/// Markdown file, a <c>docs/README.md</c> with the sections <c>## Responsibility</c>, <c>## Allowed dependencies</c>
/// and <c>## Rules</c>, and a dependency list that names exactly the csproj's <c>ProjectReference</c> projects. Each
/// rule runs on every project in <c>LangProject.Core.slnx</c> and on synthetic docs.
/// </summary>
public sealed class ProjectDocsTests
{
    /// <summary>Every project in the solution has a <c>docs/</c> folder with at least one <c>.md</c> file.</summary>
    [Fact]
    public void ProjectDocs_EveryProject_HasDocsFolderWithMarkdown()
    {
        IReadOnlyList<ProjectDocs> projects = LoadSolutionDocs();

        projects.ShouldNotBeEmpty();
        IReadOnlyList<string> violations = ProjectDocsRules.CheckDocsFolders(projects: projects);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>Every project's <c>docs/README.md</c> has the three required headings.</summary>
    [Fact]
    public void ProjectDocs_EveryReadme_HasTheThreeSections()
    {
        IReadOnlyList<ProjectDocs> projects = LoadSolutionDocs();

        projects.ShouldNotBeEmpty();
        IReadOnlyList<string> violations = ProjectDocsRules.CheckSections(projects: projects);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// Every project's <c>## Allowed dependencies</c> list names exactly the projects its csproj references, or is
    /// the single bullet <c>None</c>.
    /// </summary>
    [Fact]
    public void ProjectDocs_AllowedDependencies_MatchProjectReferences()
    {
        IReadOnlyList<ProjectDocs> projects = LoadSolutionDocs();

        projects.ShouldNotBeEmpty();
        IReadOnlyList<string> violations = ProjectDocsRules.CheckDependencyLists(projects: projects);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>A project without a <c>docs/</c> folder is reported by name.</summary>
    [Fact]
    public void ProjectDocs_MissingFolder_IsReported()
    {
        ProjectDocs project = Synthetic(markdownFiles: null, readme: null, references: []);

        IReadOnlyList<string> violations = ProjectDocsRules.CheckDocsFolders(projects: [project]);

        string violation = violations.ShouldHaveSingleItem();
        violation.ShouldContain(expected: SampleProject);
        violation.ShouldContain(expected: "docs/");
    }

    /// <summary>A <c>docs/</c> folder that holds no <c>.md</c> file is reported.</summary>
    [Fact]
    public void ProjectDocs_FolderWithoutMarkdown_IsReported()
    {
        ProjectDocs project = Synthetic(markdownFiles: [], readme: null, references: []);

        IReadOnlyList<string> violations = ProjectDocsRules.CheckDocsFolders(projects: [project]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: ".md");
    }

    /// <summary>A <c>docs/</c> folder with Markdown files but no <c>README.md</c> is reported.</summary>
    [Fact]
    public void ProjectDocs_MissingReadme_IsReported()
    {
        ProjectDocs project = Synthetic(markdownFiles: ["notes.md"], readme: null, references: []);

        IReadOnlyList<string> violations = ProjectDocsRules.CheckSections(projects: [project]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: "README.md");
    }

    /// <summary>A README that lacks one of the three headings is reported once, naming that heading.</summary>
    /// <param name="heading">The heading the synthetic README lacks.</param>
    [Theory]
    [InlineData("## Responsibility")]
    [InlineData("## Allowed dependencies")]
    [InlineData("## Rules")]
    public void ProjectDocs_MissingSection_IsReported(string heading)
    {
        string readme = ValidReadme.Replace(
                oldValue: heading + "\n",
                newValue: "## Other\n",
                comparisonType: StringComparison.Ordinal);
        ProjectDocs project = Synthetic(markdownFiles: ["README.md"], readme: readme, references: []);

        IReadOnlyList<string> violations = ProjectDocsRules.CheckSections(projects: [project]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: heading);
    }

    /// <summary>
    /// A dependency list that misses a referenced project and names one the csproj does not reference is reported
    /// once, naming both.
    /// </summary>
    [Fact]
    public void ProjectDocs_MismatchedDependencyList_IsReported()
    {
        ProjectDocs project = Synthetic(
                markdownFiles: ["README.md"],
                readme: ValidReadme,
                references: [Domain, DalAbstractions]);

        IReadOnlyList<string> violations = ProjectDocsRules.CheckDependencyLists(projects: [project]);

        string violation = violations.ShouldHaveSingleItem();
        violation.ShouldContain(expected: SampleProject);
        violation.ShouldContain(expected: DalAbstractions);
        violation.ShouldContain(expected: UnitOfWorkAbstractions);
    }

    /// <summary>The single bullet <c>None</c> for a csproj that references a project is reported.</summary>
    [Fact]
    public void ProjectDocs_NoneWithReferences_IsReported()
    {
        ProjectDocs project = Synthetic(markdownFiles: ["README.md"], readme: NoneReadme, references: [Domain]);

        IReadOnlyList<string> violations = ProjectDocsRules.CheckDependencyLists(projects: [project]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: Domain);
    }

    /// <summary>A dependency section with no bullet list is reported; <c>None</c> must be written out.</summary>
    [Fact]
    public void ProjectDocs_EmptyDependencyList_IsReported()
    {
        string readme = NoneReadme.Replace(
                oldValue: "- None\n",
                newValue: "Nothing.\n",
                comparisonType: StringComparison.Ordinal);
        ProjectDocs project = Synthetic(markdownFiles: ["README.md"], readme: readme, references: []);

        IReadOnlyList<string> violations = ProjectDocsRules.CheckDependencyLists(projects: [project]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: NoneBulletText);
    }

    /// <summary><c>None</c> next to a project name, or a project named twice, is reported.</summary>
    /// <param name="bullets">The bullets of the synthetic dependency list.</param>
    [Theory]
    [InlineData("- None\n- `LangProject.Core.Domain`\n")]
    [InlineData("- `LangProject.Core.Domain`\n- `LangProject.Core.Domain`\n")]
    public void ProjectDocs_InvalidBulletList_IsReported(string bullets)
    {
        string readme = NoneReadme.Replace(
                oldValue: "- None\n",
                newValue: bullets,
                comparisonType: StringComparison.Ordinal);
        ProjectDocs project = Synthetic(markdownFiles: ["README.md"], readme: readme, references: [Domain]);

        IReadOnlyList<string> violations = ProjectDocsRules.CheckDependencyLists(projects: [project]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: SampleProject);
    }

    /// <summary>Complete docs, with a project list or with <c>None</c>, pass every rule.</summary>
    [Fact]
    public void ProjectDocs_CompleteDocs_AreAccepted()
    {
        ProjectDocs listed = Synthetic(
                markdownFiles: ["README.md"],
                readme: ValidReadme,
                references: [Domain, UnitOfWorkAbstractions]);
        ProjectDocs none = Synthetic(markdownFiles: ["README.md", "usage.md"], readme: NoneReadme, references: []);
        IReadOnlyList<ProjectDocs> projects = [listed, none];

        ProjectDocsRules.CheckDocsFolders(projects: projects).ShouldBeEmpty();
        ProjectDocsRules.CheckSections(projects: projects).ShouldBeEmpty();
        ProjectDocsRules.CheckDependencyLists(projects: projects).ShouldBeEmpty();
    }

    /// <summary>
    /// Only the top-level bullets of the dependency section are read: a code span names the project, nested
    /// bullets, fenced code, prose and the bullets of other sections are skipped.
    /// </summary>
    [Fact]
    public void DependencyList_MixedMarkdown_ReadsOnlyTopLevelBullets()
    {
        const string Readme = """
                # LangProject.Core.Sample

                ## Allowed dependencies

                The project references these projects:

                - `LangProject.Core.Domain`: the entities it stores.
                  - `LangProject.Core.Nested`
                - Sebreiro.UnitOfWork.Abstractions

                It also gets `Sebreiro.CodeRules.Analyzers` as an analyzer only.

                ```text
                - `LangProject.Core.InFence`
                ## Rules
                ```

                ## Rules

                - `LangProject.Core.InRules`

                """;

        IReadOnlyList<string>? names = ProjectDocsRules.ReadDependencyList(readme: Readme);

        names.ShouldBe(expected: [Domain, UnitOfWorkAbstractions]);
    }

    /// <summary>A README without the dependency section has no list.</summary>
    [Fact]
    public void DependencyList_MissingSection_IsNull()
    {
        IReadOnlyList<string>? names = ProjectDocsRules.ReadDependencyList(readme: "# Title\n\n## Rules\n\n- Rule.\n");

        names.ShouldBeNull();
    }

    private const string SampleProject = "LangProject.Core.Sample";
    private const string Domain = "LangProject.Core.Domain";
    private const string DalAbstractions = "LangProject.Core.DAL.Abstractions";
    private const string UnitOfWorkAbstractions = "Sebreiro.UnitOfWork.Abstractions";
    private const string NoneBulletText = "- None";

    private const string ValidReadme = """
            # LangProject.Core.Sample

            ## Responsibility

            Holds the sample.

            ## Allowed dependencies

            - `LangProject.Core.Domain`: the entities it stores.
            - `Sebreiro.UnitOfWork.Abstractions`

            ## Rules

            - Every house rule applies.

            """;

    private const string NoneReadme = """
            # LangProject.Core.Sample

            ## Responsibility

            Holds the sample.

            ## Allowed dependencies

            - None

            ## Rules

            - Every house rule applies.

            """;

    private static List<ProjectDocs> LoadSolutionDocs()
    {
        return [.. SolutionFile.LoadProjects().Select(selector: ProjectDocs.Load)];
    }

    private static ProjectDocs Synthetic(
            IReadOnlyList<string>? markdownFiles,
            string? readme,
            IReadOnlyList<string> references)
    {
        return new ProjectDocs(
                projectName: SampleProject,
                projectReferences: references.ToHashSet(comparer: StringComparer.Ordinal),
                markdownFiles: markdownFiles,
                readme: readme);
    }
}
