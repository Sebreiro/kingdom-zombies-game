using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace LangProject.Core.ArchitectureTests.Infrastructure;

/// <summary>
/// The outcome of a finished child process: its exit code and its standard output followed by its standard error.
/// For build tools it also lists the diagnostic IDs found in MSBuild's canonical
/// <c>file(line,col): error ID: message</c> format: any ID that starts with a letter and ends with at least three
/// digits, such as <c>CS0246</c>, <c>xUnit1004</c> or <c>MSB4181</c>, plus <see cref="NoId"/> for a diagnostic
/// without an ID.
/// </summary>
internal sealed partial class ProcessResult
{
    /// <summary>
    /// The entry that stands for a diagnostic reported without an ID, such as MSBuild's <c>file : error : text</c>.
    /// </summary>
    internal const string NoId = "<no-id>";

    /// <summary>
    /// Initializes a new instance of the <see cref="ProcessResult"/> class from output that was never split, such as
    /// a placeholder for a step that has not run; it is all treated as standard output.
    /// </summary>
    /// <param name="exitCode">The exit code of the process.</param>
    /// <param name="output">The combined output.</param>
    internal ProcessResult(int exitCode, string output)
            : this(exitCode: exitCode, standardOutput: output, standardError: string.Empty)
    {
    }

    /// <summary>Initializes a new instance of the <see cref="ProcessResult"/> class.</summary>
    /// <param name="exitCode">The exit code of the process.</param>
    /// <param name="standardOutput">Everything the process wrote to its standard output.</param>
    /// <param name="standardError">Everything the process wrote to its standard error.</param>
    internal ProcessResult(int exitCode, string standardOutput, string standardError)
    {
        ExitCode = exitCode;
        StandardOutput = standardOutput;
        StandardError = standardError;
        Output = standardOutput + standardError;
    }

    /// <summary>Gets the exit code of the process.</summary>
    internal int ExitCode { get; }

    /// <summary>Gets the standard output alone, for callers that parse it, such as a NUL-separated file list.</summary>
    internal string StandardOutput { get; }

    /// <summary>Gets the standard error alone.</summary>
    internal string StandardError { get; }

    /// <summary>Gets the standard output followed by the standard error, for messages and diagnostics.</summary>
    internal string Output { get; }

    /// <summary>
    /// Gets the distinct IDs of every reported error, such as <c>CS0246</c> or <c>xUnit1004</c>, in ordinal order. An
    /// error without an ID is listed as <see cref="NoId"/>, so an exact comparison sees it.
    /// </summary>
    internal IReadOnlyList<string> ErrorIds => DiagnosticIds(severity: "error");

    /// <summary>
    /// Gets the distinct IDs of every reported warning, such as <c>NU1903</c>, in ordinal order; a warning without an
    /// ID is listed as <see cref="NoId"/>.
    /// </summary>
    internal IReadOnlyList<string> WarningIds => DiagnosticIds(severity: "warning");

    /// <summary>
    /// Gets the distinct IDs of the errors reported in one source file, in ordinal order. The file is matched by
    /// its path ending, so <c>ProofRules/BracesProof.cs</c> finds the errors MSBuild reports with a full path.
    /// </summary>
    /// <param name="pathEnding">The end of the file's path, with forward slashes.</param>
    /// <returns>The error IDs reported in that file.</returns>
    internal IReadOnlyList<string> ErrorIdsInFile(string pathEnding)
    {
        return
        [
            .. FileDiagnostics()
                    .Where(predicate: diagnostic => diagnostic.Path.EndsWith(
                            value: "/" + pathEnding,
                            comparisonType: StringComparison.Ordinal))
                    .Select(selector: diagnostic => diagnostic.Id)
                    .Distinct(comparer: StringComparer.Ordinal)
                    .Order(comparer: StringComparer.Ordinal),
        ];
    }

    /// <summary>Gets the distinct paths of every source file with a reported error, in ordinal order.</summary>
    /// <returns>The full paths, with forward slashes.</returns>
    internal IReadOnlyList<string> FilesWithErrors()
    {
        return
        [
            .. FileDiagnostics()
                    .Select(selector: diagnostic => diagnostic.Path)
                    .Distinct(comparer: StringComparer.Ordinal)
                    .Order(comparer: StringComparer.Ordinal),
        ];
    }

    [GeneratedRegex(
            pattern: @"\b(?<severity>error|warning) (?<id>[A-Za-z][A-Za-z0-9]*[0-9]{3,})\s*:",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex DiagnosticPattern();

    [GeneratedRegex(
            pattern: @"(^|:)[ \t]*(?<severity>error|warning)[ \t]*:",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant | RegexOptions.Multiline,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex NoIdDiagnosticPattern();

    [GeneratedRegex(
            pattern: @"^\s*(?<path>[^\s(][^(\r\n]*)\([0-9]+,[0-9]+(,[0-9]+,[0-9]+)?\): "
                    + @"error( (?<id>[A-Za-z][A-Za-z0-9]*[0-9]{3,}))?[ \t]*:",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant | RegexOptions.Multiline,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex FileErrorPattern();

    private IEnumerable<(string Path, string Id)> FileDiagnostics()
    {
        return FileErrorPattern()
                .Matches(input: Output)
                .Select(selector: match => (
                        Path: match.Groups["path"].Value.Replace(oldChar: '\\', newChar: '/'),
                        Id: match.Groups["id"].Success ? match.Groups["id"].Value : NoId));
    }

    private List<string> DiagnosticIds(string severity)
    {
        IEnumerable<string> withId = DiagnosticPattern()
                .Matches(input: Output)
                .Where(predicate: match => IsSeverity(match: match, severity: severity))
                .Select(selector: match => match.Groups["id"].Value);
        IEnumerable<string> withoutId = NoIdDiagnosticPattern()
                .Matches(input: Output)
                .Where(predicate: match => IsSeverity(match: match, severity: severity))
                .Select(selector: _ => NoId);
        return
        [
            .. withId.Concat(second: withoutId)
                    .Distinct(comparer: StringComparer.Ordinal)
                    .Order(comparer: StringComparer.Ordinal),
        ];
    }

    private static bool IsSeverity(Match match, string severity)
    {
        return string.Equals(a: match.Groups["severity"].Value, b: severity, comparisonType: StringComparison.Ordinal);
    }
}
