using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using LangProject.Core.API;
using LangProject.Core.API.Abstractions;
using LangProject.Core.Application;
using LangProject.Core.Application.Abstractions.Languages;
using LangProject.Core.ArchitectureTests.Infrastructure;
using LangProject.Core.ArchitectureTests.Projects;
using LangProject.Core.DAL;
using LangProject.Core.DAL.Abstractions.Languages;
using LangProject.Core.Domain.Languages;
using LangProject.Core.Integration.Abstractions;
using Sebreiro.UnitOfWork.Abstractions;
using Sebreiro.UnitOfWork.EntityFrameworkCore;
using Architecture = ArchUnitNET.Domain.Architecture;
using ArchLoader = ArchUnitNET.Loader.ArchLoader;

namespace LangProject.Core.ArchitectureTests.Types;

/// <summary>
/// The production assemblies under test: every non-test project of <c>LangProject.Core.slnx</c> except the analyzer,
/// that is every <c>LangProject.Core.*</c> product assembly and the <c>Sebreiro.UnitOfWork.*</c> packages. They are
/// loaded once, by name from the solution's project list, as an ArchUnitNET <see cref="Architecture"/> for the
/// dependency rules and as <see cref="Type"/> sets for the reflection rules.
/// </summary>
internal static class ProductionTypes
{
    /// <summary>Gets the Domain assembly, which holds the entities.</summary>
    internal static Assembly Domain => typeof(Language).Assembly;

    /// <summary>Gets the Application assembly.</summary>
    internal static Assembly Application => typeof(ApplicationRegistration).Assembly;

    /// <summary>Gets the Application.Abstractions assembly, an outward contract without Domain (D-42).</summary>
    internal static Assembly ApplicationAbstractions => typeof(LanguageDto).Assembly;

    /// <summary>Gets the API.Abstractions assembly, the HTTP contracts that never see Domain (D-42, D-44).</summary>
    internal static Assembly ApiAbstractions => typeof(ApiRoutes).Assembly;

    /// <summary>Gets the CompositionRoot assembly, the only user of <see cref="IServiceProvider"/>.</summary>
    internal static Assembly CompositionRoot => typeof(Program).Assembly;

    /// <summary>
    /// Gets every production assembly, ordered by name: one per non-test project in <c>LangProject.Core.slnx</c>
    /// except the analyzer, loaded by name, so a project added to the solution is a subject without any edit here.
    /// </summary>
    internal static IReadOnlyList<Assembly> Assemblies { get; } = LoadSolutionAssemblies();

    /// <summary>
    /// Gets one type from each production assembly the tests name directly. Each must be the same assembly that
    /// <see cref="Assemblies"/> loads by name.
    /// </summary>
    internal static IReadOnlyList<Type> Anchors { get; } =
    [
        typeof(ApiRegistration),
        typeof(ApiRoutes),
        typeof(ApplicationRegistration),
        typeof(LanguageDto),
        typeof(Program),
        typeof(DalRegistration),
        typeof(ILanguageRepository),
        typeof(Language),
        typeof(IProviderClient),
        typeof(IUnitOfWork),
        typeof(UnitOfWorkRegistration),
    ];

    /// <summary>Gets the production assemblies loaded into ArchUnitNET, built on first use.</summary>
    internal static Architecture Architecture => _architecture.Value;

    /// <summary>
    /// Lists the production project names in a solution file: every project except the three test projects and the
    /// analyzer, which is loaded as an analyzer, never as a library.
    /// </summary>
    /// <param name="solutionXml">The XML text of an <c>.slnx</c> file.</param>
    /// <returns>The project names, in ordinal order.</returns>
    internal static IReadOnlyList<string> ProductionProjectNames(string solutionXml)
    {
        return
        [
            .. SolutionFile.ReadProjectPaths(solutionXml: solutionXml)
                    .Select(selector: path => Path.GetFileNameWithoutExtension(path: path))
                    .Where(predicate: name => !AllowedEdges.IsTest(projectName: name))
                    .Where(predicate: name => !string.Equals(
                            a: name,
                            b: AllowedEdges.Analyzers,
                            comparisonType: StringComparison.Ordinal))
                    .Order(comparer: StringComparer.Ordinal),
        ];
    }

    /// <summary>Gets the simple name of an assembly, which equals its project name.</summary>
    /// <param name="assembly">The assembly.</param>
    /// <returns>The simple name, for example <c>LangProject.Core.Domain</c>.</returns>
    internal static string NameOf(Assembly assembly)
    {
        return assembly.GetName().Name ?? string.Empty;
    }

    /// <summary>
    /// Gets the types declared in source in an assembly, nested types included. Compiler-generated types (closures,
    /// state machines, embedded attributes, <c>&lt;PrivateImplementationDetails&gt;</c>) and the types nested in
    /// them are left out.
    /// </summary>
    /// <param name="assembly">The assembly to read.</param>
    /// <returns>The declared types, ordered by full name.</returns>
    internal static IReadOnlyList<Type> TypesOf(Assembly assembly)
    {
        return
        [
            .. assembly.GetTypes()
                    .Where(predicate: IsDeclaredInSource)
                    .OrderBy(keySelector: type => type.FullName, comparer: StringComparer.Ordinal),
        ];
    }

    /// <summary>Gets the declared types of every production assembly that matches a filter.</summary>
    /// <param name="filter">Selects the assemblies by name.</param>
    /// <returns>The declared types of the matching assemblies.</returns>
    internal static IReadOnlyList<Type> TypesOf(Func<string, bool> filter)
    {
        return
        [
            .. Assemblies
                    .Where(predicate: assembly => filter(arg: NameOf(assembly: assembly)))
                    .SelectMany(selector: TypesOf),
        ];
    }

    private static readonly Lazy<Architecture> _architecture = new(valueFactory: BuildArchitecture);

    private static List<Assembly> LoadSolutionAssemblies()
    {
        string solutionXml = File.ReadAllText(path: RepositoryLayout.SolutionFilePath);
        return
        [
            .. ProductionProjectNames(solutionXml: solutionXml)
                    .Select(selector: name => Assembly.Load(assemblyRef: new AssemblyName(assemblyName: name))),
        ];
    }

    private static Architecture BuildArchitecture()
    {
        return new ArchLoader().LoadAssemblies(assemblies: [.. Assemblies]).Build();
    }

    private static bool IsDeclaredInSource(Type type)
    {
        for (Type? current = type; current is not null; current = current.DeclaringType)
        {
            if (current.IsDefined(attributeType: typeof(CompilerGeneratedAttribute), inherit: false)
                    || current.Name.StartsWith(value: '<'))
            {
                return false;
            }
        }

        return true;
    }
}
