using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Projects;

/// <summary>
/// Real MSBuild evaluations of bad-on-purpose projects in a throwaway folder. Each case passed the old csproj-text
/// rules; evaluated, it is reported: a semicolon list of references, a reference added by
/// <c>Directory.Build.props</c>, a transitive-reference value other than true, a nested props file that drops the
/// solution settings, and an SDK that makes the project an executable.
/// </summary>
public sealed class ProjectEvaluationProofTests
{
    /// <summary>
    /// One <c>Include</c> with two semicolon-separated projects adds both edges, so the forbidden DAL edge from API is
    /// reported; the text parser also splits the list now.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Evaluation_SemicolonProjectReference_ReportsEveryEdge()
    {
        string items = SemicolonReference(
                AllowedEdges.Dal,
                AllowedEdges.ApiAbstractions,
                AllowedEdges.ApplicationAbstractions);
        string csproj = Project(sdk: "Microsoft.NET.Sdk", body: ItemGroup(items: items));
        using TemporaryDirectory root = NewRoot();
        Write(root: root, relativePath: ApiPath, content: csproj);

        EvaluatedProject api = await EvaluateAsync(root: root, relativePath: ApiPath);

        api.ReferencedProjects.Order(comparer: StringComparer.Ordinal).ShouldBe(expected:
        [
            AllowedEdges.ApiAbstractions,
            AllowedEdges.ApplicationAbstractions,
            AllowedEdges.Dal,
        ]);
        ProjectGraphRules.CheckAllowedEdges(projects: [api]).ShouldHaveSingleItem()
                .ShouldContain(expected: $"references {AllowedEdges.Dal}, which");
        ProjectGraphRules.CheckImplementationReferences(projects: [api]).ShouldHaveSingleItem()
                .ShouldContain(expected: AllowedEdges.Dal);
        ProjectFile.Parse(relativePath: ApiPath, xml: csproj).ProjectReferences
                .Contains(item: AllowedEdges.Dal)
                .ShouldBeTrue();
    }

    /// <summary>
    /// A ProjectReference that the root <c>Directory.Build.props</c> adds to every project counts as an edge of each
    /// project, and is reported as written outside the csproj.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Evaluation_ReferenceFromDirectoryBuildProps_IsReported()
    {
        using TemporaryDirectory root = NewRoot();
        string dalPath = "$(MSBuildThisFileDirectory)" + PathOf(name: AllowedEdges.Dal);
        string dalItem = $"""<ProjectReference Include="{dalPath}" />""";
        Write(
                root: root,
                relativePath: ProjectGraphRules.SolutionPropsPath,
                content: Project(sdk: null, body: TransitiveOff + ItemGroup(items: dalItem)));
        string apiItems = References(
                AllowedEdges.ApiAbstractions,
                AllowedEdges.ApplicationAbstractions);
        Write(
                root: root,
                relativePath: ApiPath,
                content: Project(sdk: "Microsoft.NET.Sdk", body: ItemGroup(items: apiItems)));

        EvaluatedProject api = await EvaluateAsync(root: root, relativePath: ApiPath);

        ProjectGraphRules.CheckAllowedEdges(projects: [api]).ShouldHaveSingleItem()
                .ShouldContain(expected: AllowedEdges.Dal);
        ProjectGraphRules.CheckReferenceSources(projects: [api])
                .ShouldContain(elementPredicate: violation => violation.Contains(
                        value: $"comes from {ProjectGraphRules.SolutionPropsPath}",
                        comparisonType: StringComparison.Ordinal));
    }

    /// <summary>
    /// A csproj that sets <c>DisableTransitiveProjectReferences</c> to a value other than true, after the root props
    /// set it to true, evaluates to that value and is reported.
    /// </summary>
    /// <param name="value">The csproj's value.</param>
    /// <returns>A task that completes when the test has run.</returns>
    [Theory]
    [InlineData("")]
    [InlineData("0")]
    [InlineData("no")]
    [InlineData("false")]
    public async Task Evaluation_TransitiveValueNotTrue_IsReported(string value)
    {
        using TemporaryDirectory root = NewRoot();
        string body = $"""
                <PropertyGroup>
                  <{ProjectGraphRules.TransitiveProperty}>{value}</{ProjectGraphRules.TransitiveProperty}>
                </PropertyGroup>
                """;
        Write(root: root, relativePath: ApiPath, content: Project(sdk: "Microsoft.NET.Sdk", body: body));

        EvaluatedProject api = await EvaluateAsync(root: root, relativePath: ApiPath);

        ProjectGraphRules.CheckTransitiveReferencesDisabled(projects: [api]).ShouldHaveSingleItem()
                .ShouldContain(expected: $"'{value}'");
    }

    /// <summary>
    /// A nested <c>Directory.Build.props</c> that does not import the solution one drops its settings: the project
    /// evaluates transitive references back on and imports a nearer props file, and both are reported.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Evaluation_NestedPropsWithoutParent_IsReported()
    {
        using TemporaryDirectory root = NewRoot();
        Write(root: root, relativePath: "LangProject.Core.API/Directory.Build.props", content: "<Project />\n");
        Write(root: root, relativePath: ApiPath, content: Project(sdk: "Microsoft.NET.Sdk", body: string.Empty));

        EvaluatedProject api = await EvaluateAsync(root: root, relativePath: ApiPath);

        ProjectGraphRules.CheckTransitiveReferencesDisabled(projects: [api]).ShouldHaveSingleItem();
        ProjectGraphRules.CheckBuildImports(projects: [api]).ShouldHaveSingleItem()
                .ShouldContain(expected: ProjectEvaluator.PropsPathProperty);
    }

    /// <summary>
    /// A project on the Worker SDK sets no <c>OutputType</c> itself, yet evaluates to <c>Exe</c>, and is reported
    /// as a second host.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Evaluation_WorkerSdkProject_IsReportedAsExecutable()
    {
        using TemporaryDirectory root = NewRoot();
        Write(
                root: root,
                relativePath: ApiPath,
                content: Project(sdk: "Microsoft.NET.Sdk.Worker", body: string.Empty));

        EvaluatedProject api = await EvaluateAsync(root: root, relativePath: ApiPath);

        api.GetProperty(name: ProjectEvaluator.OutputTypeProperty).ShouldBe(expected: "Exe");
        ProjectGraphRules.CheckExecutables(projects: [api]).ShouldHaveSingleItem()
                .ShouldContain(expected: AllowedEdges.Api);
    }

    private const string ApiPath = "LangProject.Core.API/LangProject.Core.API.csproj";

    private const string TransitiveOff = """
            <PropertyGroup>
              <DisableTransitiveProjectReferences>true</DisableTransitiveProjectReferences>
            </PropertyGroup>
            """;

    private static readonly UTF8Encoding _utf8 = new(encoderShouldEmitUTF8Identifier: false);

    private static TemporaryDirectory NewRoot()
    {
        var root = new TemporaryDirectory(prefix: "langproject-evaluation");
        File.Copy(
                sourceFileName: Path.Combine(path1: RepositoryLayout.RepositoryRoot, path2: "global.json"),
                destFileName: Path.Combine(path1: root.FullPath, path2: "global.json"));
        Write(
                root: root,
                relativePath: ProjectGraphRules.SolutionPropsPath,
                content: Project(sdk: null, body: TransitiveOff));
        Write(root: root, relativePath: ProjectGraphRules.SolutionTargetsPath, content: "<Project />\n");
        return root;
    }

    private static void Write(TemporaryDirectory root, string relativePath, string content)
    {
        string path = Path.Combine(path1: root.FullPath, path2: relativePath);
        Directory.CreateDirectory(path: Path.GetDirectoryName(path: path) ?? root.FullPath);
        File.WriteAllText(path: path, contents: content, encoding: _utf8);
    }

    private static string Project(string? sdk, string body)
    {
        string sdkAttribute = sdk is null ? string.Empty : $" Sdk=\"{sdk}\"";
        return $"<Project{sdkAttribute}>\n{body}\n</Project>\n";
    }

    private static string PathOf(string name)
    {
        return $"{name}/{name}.csproj";
    }

    private static string SemicolonReference(params string[] names)
    {
        string paths = string.Join(separator: ";", values: names.Select(selector: name => "../" + PathOf(name: name)));
        return $"""<ProjectReference Include="{paths}" />""";
    }

    private static string References(params string[] names)
    {
        return string.Join(
                separator: "\n",
                values: names.Select(selector: name => $"""<ProjectReference Include="../{PathOf(name: name)}" />"""));
    }

    private static string ItemGroup(string items)
    {
        return $"<ItemGroup>\n{items}\n</ItemGroup>\n";
    }

    private static async Task<EvaluatedProject> EvaluateAsync(TemporaryDirectory root, string relativePath)
    {
        IReadOnlyList<EvaluatedProject> projects = await ProjectEvaluator.EvaluateAsync(
                solutionRoot: root.FullPath,
                relativePaths: [relativePath],
                cancellationToken: TestContext.Current.CancellationToken);
        return projects.ShouldHaveSingleItem();
    }
}
