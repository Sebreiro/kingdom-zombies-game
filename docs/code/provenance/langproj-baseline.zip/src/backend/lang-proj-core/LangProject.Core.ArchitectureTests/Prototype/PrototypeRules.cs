using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

namespace LangProject.Core.ArchitectureTests.Prototype;

/// <summary>
/// The HTML prototype rules (Phase 2 SPEC R1 to R3, D-14): no prototype file loads a remote resource, every page
/// declares UTF-8, stress marks are encoded as U+0301 directly after a Cyrillic vowel, and the prototype index links
/// every state of the state table to a page that holds it. Each rule is a pure function over file text.
/// </summary>
internal static partial class PrototypeRules
{
    /// <summary>The prototype folder, relative to the repository root, with a trailing slash.</summary>
    internal const string PrototypeFolder = "src/frontend/prototype/";

    /// <summary>The prototype index page, relative to <see cref="PrototypeFolder"/>.</summary>
    internal const string IndexPage = "index.html";

    /// <summary>The combining acute accent, the only allowed stress mark.</summary>
    internal const char StressMark = '́';

    /// <summary>The combining diaeresis, which must never follow <c>е</c>: the letter <c>ё</c> is U+0451.</summary>
    internal const char Diaeresis = '̈';

    /// <summary>The Russian vowels, lower and upper case: the only letters a stress mark may follow.</summary>
    internal const string CyrillicVowels = "аеёиоуыэюяАЕЁИОУЫЭЮЯ";

    /// <summary>
    /// Gets the state table, the SPEC R2 checklist of 65 states over 9 screens: each screen page, relative to
    /// <see cref="PrototypeFolder"/>, with the ids of the state sections it holds and the index links to them.
    /// </summary>
    internal static IReadOnlyDictionary<string, IReadOnlyList<string>> ExpectedStates { get; } =
            new Dictionary<string, IReadOnlyList<string>>(comparer: StringComparer.Ordinal)
            {
                ["lookup.html"] =
                [
                    "initial",
                    "no-provider-enabled",
                    "signed-out",
                    "panel-expanded",
                    "panel-collapsed",
                    "long-input",
                ],
                ["word-result.html"] =
                [
                    "status-loading",
                    "status-result",
                    "status-no-result",
                    "status-failed",
                    "status-timed-out",
                    "status-not-supported",
                    "mixed-statuses",
                    "group-collapsed",
                    "group-expanded",
                    "in-lists",
                    "save-to-list",
                    "long-word",
                ],
                ["sentence-result.html"] =
                [
                    "translation-and-words",
                    "save-word-to-list",
                    "status-loading",
                    "status-no-result",
                    "status-failed",
                    "status-timed-out",
                    "status-not-supported",
                    "mixed-statuses",
                ],
                ["settings.html"] =
                [
                    "providers-some-enabled",
                    "providers-none-enabled",
                    "loading",
                    "save-failed",
                    "load-failed",
                ],
                ["sign-up.html"] = ["empty", "field-errors", "email-taken", "submitting"],
                ["sign-in.html"] = ["empty", "wrong-credentials", "submitting", "signed-in-panel"],
                ["history.html"] =
                [
                    "filled",
                    "filtered",
                    "no-match",
                    "empty",
                    "confirm-delete-item",
                    "confirm-clear-all",
                    "loading",
                    "load-failed",
                ],
                ["word-lists.html"] =
                [
                    "filled",
                    "no-lists",
                    "create",
                    "rename",
                    "name-taken",
                    "confirm-delete",
                    "loading",
                    "load-failed",
                ],
                ["word-list-detail.html"] =
                [
                    "filled-with-notes",
                    "sorted",
                    "search",
                    "no-match",
                    "empty",
                    "save-to-lists",
                    "duplicate-prevented",
                    "remove-word",
                    "loading",
                    "load-failed",
                ],
            };

    /// <summary>
    /// Finds every remote reference in a <c>src</c>, <c>href</c>, <c>@import</c> or <c>url()</c>: a URL that starts
    /// with <c>http://</c>, <c>https://</c> or the protocol-relative <c>//</c>, quoted or not, in any letter case.
    /// </summary>
    /// <param name="text">The text of an HTML, CSS or other prototype file.</param>
    /// <returns>One entry per remote reference; empty when the text loads only local resources.</returns>
    internal static IReadOnlyList<string> FindRemoteReferences(string text)
    {
        return [.. RemoteReferencePattern().Matches(input: text).Select(selector: match => match.Groups["url"].Value)];
    }

    /// <summary>Tells whether an HTML page declares its character encoding as UTF-8 in a meta element.</summary>
    /// <param name="html">The text of an HTML page.</param>
    /// <returns><see langword="true"/> when the page has a meta element with a UTF-8 charset.</returns>
    internal static bool HasUtf8Charset(string html)
    {
        return Utf8CharsetPattern().IsMatch(input: html);
    }

    /// <summary>
    /// Finds every stress mark that is not U+0301 directly after a Cyrillic vowel: a U+0301 after any other
    /// character, a U+0308 after <c>е</c> instead of the letter <c>ё</c> (U+0451), and an apostrophe used as a stress
    /// mark between a Cyrillic vowel and a Cyrillic letter.
    /// </summary>
    /// <param name="text">The text of a prototype file.</param>
    /// <returns>One message per problem, with its line number; empty when every stress mark is well encoded.</returns>
    internal static IReadOnlyList<string> FindStressMarkProblems(string text)
    {
        var problems = new List<string>();
        for (int index = 0; index < text.Length; index++)
        {
            char previous = index > 0 ? text[index - 1] : '\0';
            if (text[index] == StressMark && !CyrillicVowels.Contains(value: previous))
            {
                problems.Add(item: $"line {LineOf(text: text, index: index)}: U+0301 follows {Describe(ch: previous)}, "
                        + "not a Cyrillic vowel");
            }
            else if (text[index] == Diaeresis && previous is 'е' or 'Е')
            {
                problems.Add(item: $"line {LineOf(text: text, index: index)}: е is followed by U+0308; "
                        + "write ё as U+0451");
            }
        }

        problems.AddRange(collection: ApostropheStressPattern().Matches(input: text).Select(selector: match =>
                $"line {LineOf(text: text, index: match.Index)}: '{match.Value}' uses an apostrophe as a stress mark; "
                        + "use U+0301 after the vowel"));
        return problems;
    }

    /// <summary>
    /// Checks the state table against the index and the pages: every expected state has an index link of the form
    /// <c>page.html#state</c>, and every such index link points at an existing page with a section of that id.
    /// </summary>
    /// <param name="indexHtml">The text of the prototype index page.</param>
    /// <param name="pages">The text of every prototype page, keyed by its path in the prototype folder.</param>
    /// <param name="expectedStates">The state table: each page with the ids of its state sections.</param>
    /// <returns>One message per missing link, missing page or missing section; empty when all agree.</returns>
    internal static IReadOnlyList<string> FindStateProblems(
            string indexHtml,
            IReadOnlyDictionary<string, string> pages,
            IReadOnlyDictionary<string, IReadOnlyList<string>> expectedStates)
    {
        List<string> links =
        [
            .. IndexLinkPattern().Matches(input: indexHtml)
                    .Select(selector: match => match.Groups["page"].Value + "#" + match.Groups["state"].Value)
                    .Distinct(comparer: StringComparer.Ordinal),
        ];
        var problems = new List<string>();
        foreach ((string page, IReadOnlyList<string> states) in expectedStates)
        {
            problems.AddRange(collection: states
                    .Select(selector: state => page + "#" + state)
                    .Where(predicate: link => !links.Contains(value: link, comparer: StringComparer.Ordinal))
                    .Select(selector: link => $"{IndexPage} has no link to {link}"));
        }

        foreach (string link in links)
        {
            string page = link[..link.IndexOf(value: '#', comparisonType: StringComparison.Ordinal)];
            string state = link[(page.Length + 1)..];
            if (!pages.TryGetValue(key: page, value: out string? html))
            {
                problems.Add(item: $"{IndexPage} links {link}, but {page} does not exist");
            }
            else if (!SectionIds(html: html).Contains(value: state, comparer: StringComparer.Ordinal))
            {
                problems.Add(item: $"{IndexPage} links {link}, but {page} has no section with id \"{state}\"");
            }
        }

        return problems;
    }

    [GeneratedRegex(
            pattern: @"(\b(src|href)\s*=\s*[""']?|@import\s+[""']?|\burl\(\s*[""']?)(?<url>(https?:)?//[^\s""'()<>]*)",
            options: RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex RemoteReferencePattern();

    [GeneratedRegex(
            pattern: @"<meta\b[^>]*?\bcharset\s*=\s*[""']?utf-8\b",
            options: RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex Utf8CharsetPattern();

    [GeneratedRegex(
            pattern: @"[аеёиоуыэюя]['’][а-яё]",
            options: RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex ApostropheStressPattern();

    [GeneratedRegex(
            pattern: @"\bhref\s*=\s*[""']?(?<page>[A-Za-z0-9._/-]+\.html)#(?<state>[A-Za-z0-9_-]+)",
            options: RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex IndexLinkPattern();

    [GeneratedRegex(
            pattern: @"<section\b[^>]*?\bid\s*=\s*[""']?(?<id>[A-Za-z0-9_-]+)",
            options: RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex SectionIdPattern();

    private static IEnumerable<string> SectionIds(string html)
    {
        return SectionIdPattern().Matches(input: html).Select(selector: match => match.Groups["id"].Value);
    }

    private static string LineOf(string text, int index)
    {
        int line = text.AsSpan(start: 0, length: index).Count(value: '\n') + 1;
        return line.ToString(provider: CultureInfo.InvariantCulture);
    }

    private static string Describe(char ch)
    {
        if (ch == '\0')
        {
            return "the start of the text";
        }

        string codePoint = ((int)ch).ToString(format: "X4", provider: CultureInfo.InvariantCulture);
        return $"'{ch}' (U+{codePoint})";
    }
}
