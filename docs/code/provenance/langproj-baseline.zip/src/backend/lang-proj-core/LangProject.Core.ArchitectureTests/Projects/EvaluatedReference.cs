using System.IO;

namespace LangProject.Core.ArchitectureTests.Projects;

/// <summary>
/// One <c>ProjectReference</c> item after MSBuild evaluation: a semicolon list or a wildcard is already split into
/// one item per project, the path is resolved against the folder of the file that added it, and the file that added
/// it is known, whether that is the csproj, a <c>Directory.Build.*</c> file or an imported file.
/// </summary>
internal sealed class EvaluatedReference
{
    /// <summary>Initializes a new instance of the <see cref="EvaluatedReference"/> class.</summary>
    /// <param name="relativePath">The referenced project's path relative to the solution root, forward slashes.</param>
    /// <param name="definedIn">The solution-relative path of the file that adds the item.</param>
    /// <param name="isAnalyzerOnly">
    /// Whether the item sets both <c>OutputItemType=Analyzer</c> and <c>ReferenceOutputAssembly=false</c>.
    /// </param>
    internal EvaluatedReference(string relativePath, string definedIn, bool isAnalyzerOnly)
    {
        RelativePath = relativePath;
        DefinedIn = definedIn;
        IsAnalyzerOnly = isAnalyzerOnly;
        Name = Path.GetFileNameWithoutExtension(path: relativePath);
    }

    /// <summary>Gets the referenced project's file name without its extension, which is its project name.</summary>
    internal string Name { get; }

    /// <summary>
    /// Gets the referenced project's path relative to the solution root, with forward slashes; a project outside the
    /// solution root starts with <c>../</c>.
    /// </summary>
    internal string RelativePath { get; }

    /// <summary>Gets the solution-relative path of the file whose XML adds this item.</summary>
    internal string DefinedIn { get; }

    /// <summary>
    /// Gets a value indicating whether the item is an analyzer-only edge, which loads the project as an analyzer and
    /// never references its assembly.
    /// </summary>
    internal bool IsAnalyzerOnly { get; }
}
