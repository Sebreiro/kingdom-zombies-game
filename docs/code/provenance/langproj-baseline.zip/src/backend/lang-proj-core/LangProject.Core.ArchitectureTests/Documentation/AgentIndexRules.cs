using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace LangProject.Core.ArchitectureTests.Documentation;

/// <summary>
/// The docs index rules (SPEC R17, R19, DOCS-02 to DOCS-04): each <c>CLAUDE.md</c> is exactly <c>@AGENTS.md</c>
/// beside its <c>AGENTS.md</c>, no other agent memory file is tracked, no <c>AGENTS.md</c> holds an <c>@</c>
/// import, the root index links every other
/// index, the index tree links exactly one GSD workflow doc, that doc is short and has no generated markers, and the
/// backend decision records exist, are linked from the backend index and are complete. Each rule is a pure function
/// over <see cref="RepositoryDocs"/> values.
/// </summary>
internal static partial class AgentIndexRules
{
    /// <summary>The file name of an agent entry file, which only points at its <c>AGENTS.md</c>.</summary>
    internal const string ClaudeFileName = "CLAUDE.md";

    /// <summary>The file name of an index of short instructions and plain links.</summary>
    internal const string AgentsFileName = "AGENTS.md";

    /// <summary>The whole text of every <c>CLAUDE.md</c>: one line and a final newline.</summary>
    internal const string ClaudeFileContent = "@AGENTS.md\n";

    /// <summary>The path of the one GSD workflow doc.</summary>
    internal const string GsdDocPath = "docs/workflow/gsd.md";

    /// <summary>The most lines the GSD workflow doc may have (D-12).</summary>
    internal const int MaxGsdDocLines = 150;

    /// <summary>The start of every section marker that GSD's generator writes and later rewrites (D-10).</summary>
    internal const string GsdMarker = "<!-- GSD:";

    /// <summary>The path of the backend index, which links every decision record.</summary>
    internal const string BackendIndexPath = "src/backend/AGENTS.md";

    /// <summary>The folder of the backend decision records, with a trailing slash.</summary>
    internal const string DecisionRecordsFolder = "src/backend/docs/decisions/";

    /// <summary>The start of the line that gives a decision record's status.</summary>
    internal const string StatusPrefix = "Status: ";

    /// <summary>Gets the folders that each hold a <c>CLAUDE.md</c> and <c>AGENTS.md</c> pair, root first.</summary>
    internal static IReadOnlyList<string> IndexFolders { get; } = [string.Empty, "src/backend/", "src/frontend/"];

    /// <summary>Gets the decision records that SPEC R19 requires.</summary>
    internal static IReadOnlyList<string> RequiredDecisionRecords { get; } =
    [
        DecisionRecordsFolder + "0001-layer-graph.md",
        DecisionRecordsFolder + "0002-provider-abstraction.md",
        DecisionRecordsFolder + "0003-enforcement-approach.md",
    ];

    /// <summary>Gets the headings every decision record has.</summary>
    internal static IReadOnlyList<string> DecisionRecordHeadings { get; } =
            ["## Context", "## Decision", "## Consequences"];

    /// <summary>
    /// Reports a missing <c>CLAUDE.md</c> in an index folder, and every tracked agent memory file (a file named
    /// <c>CLAUDE.md</c> or <c>CLAUDE.local.md</c> in any case, anywhere, <c>.claude/</c> included) that is not a
    /// <c>CLAUDE.md</c> of exactly <c>@AGENTS.md</c> and a final newline with an <c>AGENTS.md</c> beside it.
    /// </summary>
    /// <param name="docs">The repository's docs.</param>
    /// <returns>One message per violation; empty when every file complies.</returns>
    internal static IReadOnlyList<string> CheckClaudeFiles(RepositoryDocs docs)
    {
        var violations = new List<string>();
        violations.AddRange(collection: MissingIndexFiles(docs: docs, fileName: ClaudeFileName));
        foreach (string path in MemoryFiles(docs: docs))
        {
            string? text = docs.Text(path: path);
            string name = Path.GetFileName(path: path);
            if (!string.Equals(a: name, b: ClaudeFileName, comparisonType: StringComparison.Ordinal))
            {
                violations.Add(item: $"{path}: an agent memory file other than {ClaudeFileName}; remove it");
                continue;
            }

            if (text is null)
            {
                violations.Add(item: $"{path}: an agent memory file in a folder the docs checks skip; remove it");
                continue;
            }

            if (!string.Equals(a: text, b: ClaudeFileContent, comparisonType: StringComparison.Ordinal))
            {
                violations.Add(item: $"{path}: must be exactly the line '@AGENTS.md' and a final newline");
            }

            if (!docs.TrackedPaths.Contains(item: FolderOf(path: path) + AgentsFileName))
            {
                violations.Add(item: $"{path}: no {AgentsFileName} beside it");
            }
        }

        return violations;
    }

    /// <summary>
    /// Reports a missing <c>AGENTS.md</c> in an index folder, and every <c>AGENTS.md</c> line, outside fenced code
    /// and code spans, that starts with <c>@</c> or holds an <c>@path</c> token after a space, which an agent would
    /// load as an import.
    /// </summary>
    /// <param name="docs">The repository's docs.</param>
    /// <returns>One message per violation; empty when every file complies.</returns>
    internal static IReadOnlyList<string> CheckAtImports(RepositoryDocs docs)
    {
        var violations = new List<string>();
        violations.AddRange(collection: MissingIndexFiles(docs: docs, fileName: AgentsFileName));
        foreach (string path in DocumentsNamed(docs: docs, fileName: AgentsFileName))
        {
            foreach (KeyValuePair<int, string> line in MarkdownFences.ContentLines(markdown: docs.Documents[path]))
            {
                string text = MarkdownFences.WithoutCodeSpans(line: line.Value);
                if (text.TrimStart().StartsWith(value: '@') || InlineImportPattern().IsMatch(input: text))
                {
                    violations.Add(item: $"{path}:{line.Key + 1}: holds an '@' import; use a plain Markdown link");
                }
            }
        }

        return violations;
    }

    /// <summary>Reports every <c>AGENTS.md</c> that the root <c>AGENTS.md</c> does not link.</summary>
    /// <param name="docs">The repository's docs.</param>
    /// <returns>One message per unlinked index; empty when the root links every index.</returns>
    internal static IReadOnlyList<string> CheckSubIndexesLinked(RepositoryDocs docs)
    {
        HashSet<string> linked = LinkTargets(docs: docs, documentPath: AgentsFileName);
        return
        [
            .. DocumentsNamed(docs: docs, fileName: AgentsFileName)
                    .Where(predicate: path => !string.Equals(
                            a: path,
                            b: AgentsFileName,
                            comparisonType: StringComparison.Ordinal))
                    .Where(predicate: path => !linked.Contains(item: path))
                    .Select(selector: path => $"{AgentsFileName} does not link the index {path}"),
        ];
    }

    /// <summary>
    /// Reports when the <c>AGENTS.md</c> files do not link <c>docs/workflow/gsd.md</c> exactly once, or link
    /// another GSD workflow doc: any document whose file name contains <c>gsd</c>, in any case.
    /// </summary>
    /// <param name="docs">The repository's docs.</param>
    /// <returns>One message per violation; empty when exactly one link to the one GSD doc exists.</returns>
    internal static IReadOnlyList<string> CheckGsdDocLinks(RepositoryDocs docs)
    {
        List<(string Path, MarkdownLink Link)> gsdLinks =
        [
            .. DocumentsNamed(docs: docs, fileName: AgentsFileName)
                    .SelectMany(selector: path => MarkdownLinks
                            .ReadLinks(documentPath: path, markdown: docs.Documents[path])
                            .Select(selector: link => (Path: path, Link: link)))
                    .Where(predicate: pair => pair.Link.Target is not null && IsGsdDoc(target: pair.Link.Target)),
        ];
        var violations = new List<string>();
        foreach ((string path, MarkdownLink link) in gsdLinks.Where(predicate: pair => !string.Equals(
                a: pair.Link.Target,
                b: GsdDocPath,
                comparisonType: StringComparison.Ordinal)))
        {
            violations.Add(item: $"{path}:{link.Line}: links '{link.Target}', a second GSD workflow doc; "
                    + $"link only {GsdDocPath}");
        }

        int count = gsdLinks.Count - violations.Count;
        if (count != 1)
        {
            violations.Add(item: $"the {AgentsFileName} files link {GsdDocPath} {count} times; link it exactly once");
        }

        return violations;
    }

    /// <summary>
    /// Reports a missing GSD workflow doc, one with more than <see cref="MaxGsdDocLines"/> lines, and one that
    /// holds a generated section marker.
    /// </summary>
    /// <param name="text">The doc's text, or <see langword="null"/> when it does not exist.</param>
    /// <returns>One message per violation; empty when the doc complies.</returns>
    internal static IReadOnlyList<string> CheckGsdDoc(string? text)
    {
        if (text is null)
        {
            return [$"{GsdDocPath} does not exist"];
        }

        var violations = new List<string>();
        int lines = CountLines(text: text);
        if (lines > MaxGsdDocLines)
        {
            violations.Add(item: $"{GsdDocPath} has {lines} lines; at most {MaxGsdDocLines} are allowed");
        }

        if (text.Contains(value: GsdMarker, comparisonType: StringComparison.Ordinal))
        {
            violations.Add(item: $"{GsdDocPath} holds the generated section marker '{GsdMarker}'");
        }

        return violations;
    }

    /// <summary>
    /// Counts a text's lines: every newline ends a line, and text after the last newline is one more line.
    /// </summary>
    /// <param name="text">The text.</param>
    /// <returns>The number of lines; 0 for the empty text.</returns>
    internal static int CountLines(string text)
    {
        int newlines = text.Count(predicate: character => character == '\n');
        return text.Length == 0 || text.EndsWith(value: '\n') ? newlines : newlines + 1;
    }

    /// <summary>
    /// Reports every required decision record that does not exist, and every record under
    /// <see cref="DecisionRecordsFolder"/> that the backend index does not link, or that lacks a required heading
    /// or the status line.
    /// </summary>
    /// <param name="docs">The repository's docs.</param>
    /// <returns>One message per violation; empty when every record complies.</returns>
    internal static IReadOnlyList<string> CheckDecisionRecords(RepositoryDocs docs)
    {
        var violations = new List<string>();
        violations.AddRange(collection: RequiredDecisionRecords
                .Where(predicate: path => docs.Text(path: path) is null)
                .Select(selector: path => $"{path} does not exist (SPEC R19)"));
        HashSet<string> linked = LinkTargets(docs: docs, documentPath: BackendIndexPath);
        foreach (string path in docs.Documents.Keys
                .Where(predicate: path => path.StartsWith(
                        value: DecisionRecordsFolder,
                        comparisonType: StringComparison.Ordinal))
                .Order(comparer: StringComparer.Ordinal))
        {
            List<string> lines = ContentLines(text: docs.Documents[path]);
            if (!linked.Contains(item: path))
            {
                violations.Add(item: $"{path}: not linked from {BackendIndexPath}");
            }

            violations.AddRange(collection: DecisionRecordHeadings
                    .Where(predicate: heading => !lines.Contains(value: heading, comparer: StringComparer.Ordinal))
                    .Select(selector: heading => $"{path}: no '{heading}' heading"));
            if (!lines.Any(predicate: line => line.StartsWith(
                    value: StatusPrefix,
                    comparisonType: StringComparison.Ordinal)))
            {
                violations.Add(item: $"{path}: no '{StatusPrefix}...' line");
            }
        }

        return violations;
    }

    private static readonly string[] _memoryFileNames = [ClaudeFileName, "CLAUDE.local.md"];

    [GeneratedRegex(
            pattern: @"(^|\s)@[\w~.\-]*[./][\w~./\-]+",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex InlineImportPattern();

    private static IEnumerable<string> MemoryFiles(RepositoryDocs docs)
    {
        return docs.TrackedPaths
                .Where(predicate: path => _memoryFileNames.Contains(
                        value: Path.GetFileName(path: path),
                        comparer: StringComparer.OrdinalIgnoreCase))
                .Order(comparer: StringComparer.Ordinal);
    }

    private static IEnumerable<string> MissingIndexFiles(RepositoryDocs docs, string fileName)
    {
        return IndexFolders
                .Select(selector: folder => folder + fileName)
                .Where(predicate: path => docs.Text(path: path) is null)
                .Select(selector: path => $"{path} does not exist");
    }

    private static IEnumerable<string> DocumentsNamed(RepositoryDocs docs, string fileName)
    {
        return docs.Documents.Keys
                .Where(predicate: path => string.Equals(
                        a: Path.GetFileName(path: path),
                        b: fileName,
                        comparisonType: StringComparison.Ordinal))
                .Order(comparer: StringComparer.Ordinal);
    }

    private static HashSet<string> LinkTargets(RepositoryDocs docs, string documentPath)
    {
        string? text = docs.Text(path: documentPath);
        if (text is null)
        {
            return new HashSet<string>(comparer: StringComparer.Ordinal);
        }

        return MarkdownLinks.ReadLinks(documentPath: documentPath, markdown: text)
                .Select(selector: link => link.Target)
                .OfType<string>()
                .ToHashSet(comparer: StringComparer.Ordinal);
    }

    private static string FolderOf(string path)
    {
        int slash = path.LastIndexOf(value: '/');
        return slash < 0 ? string.Empty : path[..(slash + 1)];
    }

    private static bool IsGsdDoc(string target)
    {
        return Path.GetFileName(path: target)
                .Contains(value: "gsd", comparisonType: StringComparison.OrdinalIgnoreCase);
    }

    private static List<string> ContentLines(string text)
    {
        return [.. MarkdownFences.ContentLines(markdown: text).Select(selector: line => line.Value)];
    }
}
