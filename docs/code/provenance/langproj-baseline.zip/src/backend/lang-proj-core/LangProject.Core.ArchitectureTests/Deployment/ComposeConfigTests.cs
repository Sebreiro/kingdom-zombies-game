using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Deployment;

/// <summary>
/// Checks of <c>deploy/compose.yaml</c> through <c>docker compose config</c> with <c>deploy/.env.example</c>: only
/// the API port and PostgreSQL on <c>127.0.0.1:5432</c> are published (P2), the services start in the gated order
/// (D-64), a missing required variable stops Compose and names it (D-62), the database roles and images are the
/// intended ones (D-21, D-65, D-69) and there is no telemetry collector (SPEC R15).
/// </summary>
public sealed class ComposeConfigTests
{
    /// <summary>
    /// PostgreSQL is published only on <c>127.0.0.1:5432</c>, the API only on its port on the bind address, all
    /// interfaces by default, and no other service publishes a port (P2, D-68).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Compose_PublishedPorts_PostgresOnLoopbackOnly()
    {
        JsonElement config = await RenderExampleAsync();

        ComposeModel.PublishedPorts(config: config)
                .ShouldBe(expected: ["api 0.0.0.0:8080->8080", "postgres 127.0.0.1:5432->5432"]);
    }

    /// <summary>
    /// <c>API_BIND_ADDRESS</c> moves only the API port, for example to <c>127.0.0.1</c> behind a host proxy; without
    /// the variable the API stays on all interfaces (D-68), and PostgreSQL stays on loopback either way.
    /// </summary>
    /// <param name="bindLine">The <c>API_BIND_ADDRESS</c> line of the env file, or empty for none.</param>
    /// <param name="expectedApi">The expected API port entry.</param>
    /// <returns>A task that completes when the test has run.</returns>
    [Theory]
    [InlineData("API_BIND_ADDRESS=127.0.0.1", "api 127.0.0.1:8080->8080")]
    [InlineData("", "api 0.0.0.0:8080->8080")]
    public async Task Compose_ApiBindAddress_MovesOnlyTheApiPort(string bindLine, string expectedApi)
    {
        string envFile = ComposeCli.WithoutVariable(
                envFileText: ComposeCli.ReadEnvExample(),
                name: "API_BIND_ADDRESS") + "\n" + bindLine + "\n";

        ComposeConfigResult result = await ComposeCli.ConfigAsync(
                envFileText: envFile,
                cancellationToken: TestContext.Current.CancellationToken);
        result.ExitCode.ShouldBe(expected: 0, customMessage: result.Output);
        using var document = JsonDocument.Parse(json: result.Json);

        ComposeModel.PublishedPorts(config: document.RootElement)
                .ShouldBe(expected: [expectedApi, "postgres 127.0.0.1:5432->5432"]);
    }

    /// <summary>
    /// The port reader shows the host of every published port, so a port on all interfaces or on <c>0.0.0.0</c> is
    /// never hidden.
    /// </summary>
    [Fact]
    public void PublishedPorts_SyntheticModel_ShowTheHostOfEveryPort()
    {
        using var document = JsonDocument.Parse(json: """
                {
                  "services": {
                    "postgres": { "ports": [ { "host_ip": "0.0.0.0", "target": 5432, "published": "5432" } ] },
                    "watcher": { "ports": [ { "target": 80, "published": "8081" } ] },
                    "migrator": {}
                  }
                }
                """);

        ComposeModel.PublishedPorts(config: document.RootElement)
                .ShouldBe(expected: ["postgres 0.0.0.0:5432->5432", "watcher *:8081->80"]);
    }

    /// <summary>
    /// Every service logs through the local driver with rotation at 10 MB per file and five files, so container logs
    /// cannot fill the disk of a long-running host.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Compose_EveryService_HasBoundedLogs()
    {
        JsonElement config = await RenderExampleAsync();

        ComposeModel.Logging(config: config).ShouldBe(expected:
        [
            "api local 10m 5",
            "db-roles local 10m 5",
            "migrator local 10m 5",
            "postgres local 10m 5",
            "watcher local 10m 5",
        ]);
    }

    /// <summary>
    /// The log reader shows a service without a <c>logging</c> block and a driver without rotation options, so an
    /// unbounded log is never hidden.
    /// </summary>
    [Fact]
    public void Logging_SyntheticModel_ShowsUnboundedServices()
    {
        using var document = JsonDocument.Parse(json: """
                {
                  "services": {
                    "api": { "logging": { "driver": "json-file" } },
                    "postgres": {},
                    "watcher": { "logging": { "driver": "local", "options": { "max-size": "10m" } } }
                  }
                }
                """);

        ComposeModel.Logging(config: document.RootElement)
                .ShouldBe(expected: ["api json-file - -", "postgres none", "watcher local 10m -"]);
    }

    /// <summary>
    /// No service sets <c>network_mode</c>, so every service is on the project network and its published ports are
    /// exactly the <c>ports</c> entries checked above (P2, D-68).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Compose_NetworkModes_AreNotSet()
    {
        JsonElement config = await RenderExampleAsync();

        ComposeModel.NetworkModes(config: config).ShouldBeEmpty();
    }

    /// <summary>
    /// A host network mode and a mode that shares another service's network are each reported, although neither adds
    /// a <c>ports</c> entry.
    /// </summary>
    [Fact]
    public void NetworkModes_SyntheticModel_AreReported()
    {
        using var document = JsonDocument.Parse(json: """
                {
                  "services": {
                    "postgres": { "network_mode": "host", "ports": [] },
                    "watcher": { "network_mode": "service:api" },
                    "api": {}
                  }
                }
                """);

        ComposeModel.NetworkModes(config: document.RootElement)
                .ShouldBe(expected: ["postgres host", "watcher service:api"]);
    }

    /// <summary>
    /// With an env file that lacks one required variable, <c>docker compose config</c> exits with a non-zero code
    /// and its output names the variable (SPEC R13 empty edge, D-62).
    /// </summary>
    /// <param name="variable">The required variable left out of the env file.</param>
    /// <returns>A task that completes when the test has run.</returns>
    [Theory]
    [InlineData("POSTGRES_APP_PASSWORD")]
    [InlineData("REDACTION_HMAC_KEY")]
    [InlineData("POSTGRES_PASSWORD")]
    [InlineData("POSTGRES_USER")]
    [InlineData("POSTGRES_DB")]
    [InlineData("POSTGRES_APP_USER")]
    public async Task Compose_MissingRequiredVariable_FailsNamingIt(string variable)
    {
        string envFile = ComposeCli.WithoutVariable(envFileText: ComposeCli.ReadEnvExample(), name: variable);

        ComposeConfigResult result = await ComposeCli.ConfigAsync(
                envFileText: envFile,
                cancellationToken: TestContext.Current.CancellationToken);

        result.ExitCode.ShouldNotBe(expected: 0, customMessage: result.Output);
        result.Output.ShouldContain(expected: $"required variable {variable} is missing a value");
        result.Output.ShouldContain(expected: $"{variable} is required");
    }

    /// <summary>
    /// A required variable that is present but empty stops Compose too, and the output names it (D-62).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Compose_EmptyRequiredVariable_FailsNamingIt()
    {
        string envFile = ComposeCli.WithoutVariable(
                envFileText: ComposeCli.ReadEnvExample(),
                name: "REDACTION_HMAC_KEY") + "\nREDACTION_HMAC_KEY=\n";

        ComposeConfigResult result = await ComposeCli.ConfigAsync(
                envFileText: envFile,
                cancellationToken: TestContext.Current.CancellationToken);

        result.ExitCode.ShouldNotBe(expected: 0, customMessage: result.Output);
        result.Output.ShouldContain(expected: "required variable REDACTION_HMAC_KEY is missing a value");
    }

    /// <summary>
    /// db-roles waits for PostgreSQL to be healthy, the migrator for db-roles to complete, the API for the migrator
    /// to complete, and the watcher for the API to start (D-64, D-67, RD-6).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Compose_StartupOrder_IsGated()
    {
        JsonElement config = await RenderExampleAsync();

        ComposeModel.Dependencies(config: config).ShouldBe(expected:
        [
            "api -> migrator: service_completed_successfully",
            "db-roles -> postgres: service_healthy",
            "migrator -> db-roles: service_completed_successfully",
            "watcher -> api: service_started",
        ]);
    }

    /// <summary>
    /// The postgres and db-roles services use the same image, pinned to an exact
    /// <c>postgres:&lt;major&gt;.&lt;minor&gt;</c> tag (D-69).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Compose_PostgresImages_ArePinnedAndEqual()
    {
        JsonElement config = await RenderExampleAsync();

        List<string> postgresImages =
        [
            .. ComposeModel.Images(config: config)
                    .Where(predicate: entry => IsService(entry: entry, service: "postgres")
                            || IsService(entry: entry, service: "db-roles"))
                    .Select(selector: entry => entry[(entry.IndexOf(value: ' ') + 1)..]),
        ];

        postgresImages.Count.ShouldBe(expected: 2);
        postgresImages.Distinct(comparer: StringComparer.Ordinal).ShouldHaveSingleItem()
                .ShouldMatch(regexPattern: @"^postgres:[0-9]+\.[0-9]+$");
    }

    /// <summary>
    /// The stack has exactly the five services and their pinned or locally built images, so no OpenTelemetry
    /// collector or dashboard runs in it; the OTLP endpoint is empty by default (SPEC R15).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Compose_ServiceSet_HasNoTelemetryCollector()
    {
        JsonElement config = await RenderExampleAsync();

        ComposeModel.ServiceNames(config: config)
                .ShouldBe(expected: ["api", "db-roles", "migrator", "postgres", "watcher"]);
        ComposeModel.Images(config: config).ShouldBe(expected:
        [
            "api langproject-core",
            "db-roles postgres:18.6",
            "migrator langproject-core-migrator",
            "postgres postgres:18.6",
            "watcher curlimages/curl:8.23.0",
        ]);
        ComposeModel.ServiceEnvironment(config: config, service: "api")["Telemetry__OtlpEndpoint"].ShouldBeEmpty();
    }

    /// <summary>
    /// The API and the migrator are built from the backend Dockerfile's <c>api</c> and <c>migrator</c> targets, never
    /// pulled and never rebuilt by a plain <c>up</c> (<c>pull_policy: never</c>), so only <c>up --build</c> changes
    /// the image and its version; the API runs in Production with the HMAC key from the env file (D-20, D-21, D-62,
    /// SPEC R14).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Compose_ApiService_RunsBuiltImageInProduction()
    {
        JsonElement config = await RenderExampleAsync();
        Dictionary<string, string> example = ExampleValues();

        ComposeModel.Builds(config: config).ShouldBe(expected:
        [
            "api src/backend/lang-proj-core api never",
            "migrator src/backend/lang-proj-core migrator never",
        ]);
        IReadOnlyDictionary<string, string> api = ComposeModel.ServiceEnvironment(config: config, service: "api");
        api["ASPNETCORE_ENVIRONMENT"].ShouldBe(expected: "Production");
        api["Redaction__HmacKey"].ShouldBe(expected: example["REDACTION_HMAC_KEY"]);
    }

    /// <summary>
    /// The API connects as the DML-only app role, the migrator and db-roles as the owner role, and db-roles gets
    /// the app role's name and password to sync (D-64, D-65).
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Compose_DatabaseRoles_ApiUsesAppRoleAndMigratorOwner()
    {
        JsonElement config = await RenderExampleAsync();
        Dictionary<string, string> example = ExampleValues();

        ComposeModel.ServiceEnvironment(config: config, service: "api")["ConnectionStrings__Database"]
                .ShouldBe(expected: ConnectionString(
                        example: example,
                        user: "POSTGRES_APP_USER",
                        password: "POSTGRES_APP_PASSWORD"));
        ComposeModel.ServiceEnvironment(config: config, service: "migrator")["LANGPROJECT_MIGRATOR_CONNECTION"]
                .ShouldBe(expected: ConnectionString(
                        example: example,
                        user: "POSTGRES_USER",
                        password: "POSTGRES_PASSWORD"));
        IReadOnlyDictionary<string, string> roles = ComposeModel.ServiceEnvironment(
                config: config,
                service: "db-roles");
        roles["PGHOST"].ShouldBe(expected: "postgres");
        roles["PGUSER"].ShouldBe(expected: example["POSTGRES_USER"]);
        roles["PGPASSWORD"].ShouldBe(expected: example["POSTGRES_PASSWORD"]);
        roles["POSTGRES_APP_USER"].ShouldBe(expected: example["POSTGRES_APP_USER"]);
        roles["POSTGRES_APP_PASSWORD"].ShouldBe(expected: example["POSTGRES_APP_PASSWORD"]);
        string.Equals(
                a: example["POSTGRES_APP_USER"],
                b: example["POSTGRES_USER"],
                comparisonType: StringComparison.Ordinal).ShouldBeFalse();
    }

    /// <summary>
    /// The PostgreSQL data lives in the named volume <c>pgdata</c> at <c>/var/lib/postgresql</c>, where the
    /// postgres 18 image declares its volume (RD-7, SPEC R13). db-roles gets the role script and a tmpfs over that
    /// path, so its container leaves no anonymous volume behind.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Compose_PostgresVolume_IsNamedAtVarLibPostgresql()
    {
        JsonElement config = await RenderExampleAsync();
        string script = RepositoryLayout.RepositoryRoot.Replace(oldChar: '\\', newChar: '/') + "/deploy/db-roles.sql";

        ComposeModel.Mounts(config: config).ShouldBe(expected:
        [
            $"db-roles bind {script}:/db-roles.sql",
            "db-roles tmpfs /var/lib/postgresql",
            "postgres volume pgdata:/var/lib/postgresql",
        ]);
    }

    private static async Task<JsonElement> RenderExampleAsync()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        ComposeConfigResult result = await ComposeCli.ConfigAsync(
                envFileText: ComposeCli.ReadEnvExample(),
                cancellationToken: cancellationToken);
        result.ExitCode.ShouldBe(expected: 0, customMessage: result.Output);

        using var document = JsonDocument.Parse(json: result.Json);
        return document.RootElement.Clone();
    }

    private static Dictionary<string, string> ExampleValues()
    {
        return ComposeCli.ReadEnvExample()
                .Split(separator: '\n')
                .Where(predicate: line => line.Length > 0 && !line.StartsWith(value: '#'))
                .Select(selector: line => line.Split(separator: '=', count: 2))
                .ToDictionary(
                        keySelector: parts => parts[0],
                        elementSelector: parts => parts[1],
                        comparer: StringComparer.Ordinal);
    }

    private static string ConnectionString(Dictionary<string, string> example, string user, string password)
    {
        return $"Host=postgres;Port=5432;Database={example["POSTGRES_DB"]};Username={example[user]};"
                + $"Password={example[password]};Gss Encryption Mode=Disable";
    }

    private static bool IsService(string entry, string service)
    {
        return entry.StartsWith(value: service + " ", comparisonType: StringComparison.Ordinal);
    }
}
