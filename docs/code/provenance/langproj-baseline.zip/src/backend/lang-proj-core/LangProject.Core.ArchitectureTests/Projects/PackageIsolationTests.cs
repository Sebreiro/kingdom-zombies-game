using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Projects;

/// <summary>
/// Tests that the reusable projects under <c>packages/</c> stay product-agnostic: no ProjectReference or package item
/// whose path or ID contains <c>LangProject</c> (SPEC R3, ARCH-04).
/// </summary>
public sealed class PackageIsolationTests
{
    /// <summary>
    /// No package project, as MSBuild evaluates it, references a project or package whose path or ID contains
    /// LangProject, wherever the item is written.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Packages_InSolution_HaveNoProductReferences()
    {
        IReadOnlyList<EvaluatedProject> projects = await ProjectEvaluator.LoadWorkingTreeAsync();

        ProjectGraphRules.SelectPackageProjects(projects: projects).ShouldNotBeEmpty();
        IReadOnlyList<string> violations = ProjectGraphRules.CheckPackageIsolation(projects: projects);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>A synthetic package csproj with a ProjectReference to a product project is reported.</summary>
    [Fact]
    public void Packages_SyntheticProjectReference_IsReported()
    {
        EvaluatedProject package = SyntheticProjects.Build(
                relativePath: BadPackagePath,
                references: [DomainProjectPath],
                properties: new Dictionary<string, string>(comparer: StringComparer.Ordinal));

        IReadOnlyList<string> violations = ProjectGraphRules.CheckPackageIsolation(projects: [package]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: "LangProject.Core.Domain");
    }

    /// <summary>A synthetic package csproj with a PackageReference whose ID contains LangProject is reported.</summary>
    /// <param name="packageId">The offending package ID, in different casings.</param>
    [Theory]
    [InlineData("LangProject.Shared")]
    [InlineData("langproject.shared")]
    [InlineData("Contoso.LANGPROJECT.Client")]
    public void Packages_SyntheticPackageReference_IsReported(string packageId)
    {
        var package = new EvaluatedProject(
                relativePath: BadPackagePath,
                properties: new Dictionary<string, string>(comparer: StringComparer.Ordinal),
                projectReferences: [SyntheticProjects.AnalyzerEdge()],
                packageReferences: ["Shouldly", packageId]);

        IReadOnlyList<string> violations = ProjectGraphRules.CheckPackageIsolation(projects: [package]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: packageId);
    }

    /// <summary>
    /// The rule covers every csproj under <c>packages/</c>, packable or not: a non-packable test project there with
    /// a product reference is reported, and the rule's production input is every package csproj on disk.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Packages_AnalyzersTestsProject_IsCoveredByTheSameRule()
    {
        EvaluatedProject analyzerTests = SyntheticProjects.Build(
                relativePath: AnalyzersTestsPath,
                references: [SyntheticProjects.PathOf(projectName: AllowedEdges.Analyzers), DomainProjectPath],
                properties: new Dictionary<string, string>(comparer: StringComparer.Ordinal)
                {
                    [ProjectEvaluator.OutputTypeProperty] = "Exe",
                    [ProjectEvaluator.IsTestProjectProperty] = "true",
                });
        EvaluatedProject outsidePackages = SyntheticProjects.Build(
                relativePath: "LangProject.Core.Application/LangProject.Core.Application.csproj",
                references: [DomainProjectPath],
                properties: new Dictionary<string, string>(comparer: StringComparer.Ordinal));

        IReadOnlyList<string> violations =
                ProjectGraphRules.CheckPackageIsolation(projects: [analyzerTests, outsidePackages]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: AllowedEdges.AnalyzersTests);
        ProjectGraphRules.SelectPackageProjects(projects: await ProjectEvaluator.LoadWorkingTreeAsync())
                .Select(selector: project => project.RelativePath)
                .Order(comparer: StringComparer.Ordinal)
                .ShouldBe(expected: PackageCsprojFilesOnDisk());
    }

    private const string BadPackagePath = "packages/Sebreiro.Bad/Sebreiro.Bad.csproj";

    private const string AnalyzersTestsPath =
            "packages/Sebreiro.CodeRules.Analyzers.Tests/Sebreiro.CodeRules.Analyzers.Tests.csproj";

    private const string DomainProjectPath = "LangProject.Core.Domain/LangProject.Core.Domain.csproj";

    private static List<string> PackageCsprojFilesOnDisk()
    {
        IEnumerable<string> csprojFiles = RepositoryLayout.FindBuildFiles(root: RepositoryLayout.PackagesDirectory)
                .Where(predicate: path => string.Equals(
                        a: Path.GetExtension(path: path),
                        b: ".csproj",
                        comparisonType: StringComparison.OrdinalIgnoreCase))
                .Select(selector: RepositoryLayout.ToSolutionRelative)
                .Order(comparer: StringComparer.Ordinal);
        return [.. csprojFiles];
    }
}
