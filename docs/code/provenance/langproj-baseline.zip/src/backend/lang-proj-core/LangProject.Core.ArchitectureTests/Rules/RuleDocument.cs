using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using LangProject.Core.ArchitectureTests.Documentation;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// Reads the code-rule docs (<c>code-style.md</c> and <c>code-architecture.md</c>): their headings with the
/// rule-matrix rows each links to, and the drift checks of SPEC R20. Pure functions over text, so proofs can feed
/// synthetic docs.
/// </summary>
internal static partial class RuleDocument
{
    /// <summary>
    /// Lists the <c>##</c> and <c>###</c> headings of a Markdown document, outside fenced code blocks.
    /// </summary>
    /// <param name="markdown">The document text.</param>
    /// <returns>The headings in document order.</returns>
    internal static IReadOnlyList<RuleHeading> Headings(string markdown)
    {
        string[] lines = markdown.Split(separator: '\n');
        IReadOnlyList<bool> content = MarkdownFences.ContentMask(lines: lines);
        var headings = new List<RuleHeading>();
        for (int index = 0; index < lines.Length; index++)
        {
            Match heading = HeadingPattern().Match(input: lines[index].TrimEnd());
            if (content[index] && heading.Success)
            {
                string text = heading.Groups["text"].Value.Trim();
                headings.Add(item: new RuleHeading(
                        level: heading.Groups["hashes"].Value.Length,
                        text: text,
                        slug: Slug(headingText: text),
                        enforcementIds: EnforcementIds(lines: lines, headingIndex: index)));
            }
        }

        return headings;
    }

    /// <summary>
    /// Computes the anchor GitHub gives a heading: lower case, punctuation other than <c>-</c> and <c>_</c> removed,
    /// spaces turned into <c>-</c>.
    /// </summary>
    /// <param name="headingText">The heading text without the leading hashes.</param>
    /// <returns>The anchor, without <c>#</c>.</returns>
    internal static string Slug(string headingText)
    {
        var slug = new StringBuilder(capacity: headingText.Length);
        foreach (char character in headingText.Trim())
        {
            if (char.IsLetterOrDigit(c: character) || character is '_' or '-')
            {
                slug.Append(value: char.ToLowerInvariant(c: character));
            }
            else if (character == ' ')
            {
                slug.Append(value: '-');
            }
        }

        return slug.ToString();
    }

    /// <summary>
    /// Lists the projects named in the solution tree of <c>code-architecture.md</c>: every
    /// <c>LangProject.Core.*</c> or <c>Sebreiro.*</c> folder name in a fenced block.
    /// </summary>
    /// <param name="codeArchitecture">The text of <c>code-architecture.md</c>.</param>
    /// <returns>The project names, in ordinal order.</returns>
    internal static IReadOnlyList<string> ListedProjects(string codeArchitecture)
    {
        var projects = new List<string>();
        string[] lines = codeArchitecture.Split(separator: '\n');
        IReadOnlyList<bool> content = MarkdownFences.ContentMask(lines: lines);
        for (int index = 0; index < lines.Length; index++)
        {
            Match folder = ProjectFolderPattern().Match(input: lines[index]);
            if (!content[index] && folder.Success)
            {
                projects.Add(item: folder.Groups["name"].Value);
            }
        }

        return [.. projects.Distinct(comparer: StringComparer.Ordinal).Order(comparer: StringComparer.Ordinal)];
    }

    /// <summary>
    /// Finds drift from the SPEC R20 doc rules: an old <c>Sebreiro.LangProject</c> product name, a sentence saying
    /// that violations are warnings only, a project list that differs from the solution, or a body-length rule that
    /// does not say that more than 60 lines fail with 40 advised.
    /// </summary>
    /// <param name="codeStyle">The text of <c>code-style.md</c>.</param>
    /// <param name="codeArchitecture">The text of <c>code-architecture.md</c>.</param>
    /// <param name="solutionProjects">The project names in the solution file.</param>
    /// <returns>One message per drift; empty when the docs follow every rule.</returns>
    internal static IReadOnlyList<string> FindDrift(
            string codeStyle,
            string codeArchitecture,
            IReadOnlyCollection<string> solutionProjects)
    {
        var drift = new List<string>();
        drift.AddRange(collection: WordingDrift(name: "code-style.md", text: codeStyle));
        drift.AddRange(collection: WordingDrift(name: "code-architecture.md", text: codeArchitecture));

        IReadOnlyList<string> listed = ListedProjects(codeArchitecture: codeArchitecture);
        string missing = string.Join(
                separator: ", ",
                values: solutionProjects.Except(second: listed, comparer: StringComparer.Ordinal));
        string extra = string.Join(
                separator: ", ",
                values: listed.Except(second: solutionProjects, comparer: StringComparer.Ordinal));
        if (missing.Length > 0 || extra.Length > 0)
        {
            drift.Add(item: $"code-architecture.md lists other projects than the solution: missing [{missing}], "
                    + $"extra [{extra}]");
        }

        if (!codeStyle.Contains(value: BodyLimitSentence, comparisonType: StringComparison.Ordinal))
        {
            drift.Add(item: $"code-style.md does not say '{BodyLimitSentence}' (60 lines fail, 40 advised)");
        }

        return drift;
    }

    private const string OldProductPrefix = "Sebreiro.LangProject";
    private const string BodyLimitSentence = "more than 60 lines fails the build; 40 lines is the advised length";

    [GeneratedRegex(
            pattern: "^(?<hashes>#{2,3}) (?<text>.+)$",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex HeadingPattern();

    [GeneratedRegex(
            pattern: @"\[R-(?<number>[0-9]{2})\]\(\.\./rule-matrix\.md#r-(?<anchor>[0-9]{2})\)",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex EnforcementLinkPattern();

    [GeneratedRegex(
            pattern: @"^\s+(?<name>(LangProject\.Core|Sebreiro)\.[A-Za-z.]+)/",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex ProjectFolderPattern();

    [GeneratedRegex(
            pattern: @"((don't|do not|doesn't|does not|won't|will not)\s+break\s+the\s+build|warnings?[ -]only"
                    + @"|default\s+severity\s+is\s+warning)",
            options: RegexOptions.IgnoreCase | RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex WarningOnlyPattern();

    private static List<string> WordingDrift(string name, string text)
    {
        var drift = new List<string>();
        if (text.Contains(value: OldProductPrefix, comparisonType: StringComparison.Ordinal))
        {
            drift.Add(item: $"{name} still names the old {OldProductPrefix}.* projects");
        }

        Match warningOnly = WarningOnlyPattern().Match(input: text);
        if (warningOnly.Success)
        {
            drift.Add(item: $"{name} says violations are warnings only: '{warningOnly.Value}'");
        }

        return drift;
    }

    private static List<string> EnforcementIds(string[] lines, int headingIndex)
    {
        string? firstLine = lines
                .Skip(count: headingIndex + 1)
                .Select(selector: line => line.Trim())
                .FirstOrDefault(predicate: line => line.Length > 0);
        if (firstLine is null || !firstLine.StartsWith(value: "Enforcement:", comparisonType: StringComparison.Ordinal))
        {
            return [];
        }

        return
        [
            .. EnforcementLinkPattern()
                    .Matches(input: firstLine)
                    .Where(predicate: link => string.Equals(
                            a: link.Groups["number"].Value,
                            b: link.Groups["anchor"].Value,
                            comparisonType: StringComparison.Ordinal))
                    .Select(selector: link => "R-" + link.Groups["number"].Value),
        ];
    }
}
