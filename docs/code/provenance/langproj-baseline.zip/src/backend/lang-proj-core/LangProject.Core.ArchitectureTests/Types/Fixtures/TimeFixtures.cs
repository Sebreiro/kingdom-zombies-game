using System;
using System.Collections.Generic;

namespace LangProject.Core.ArchitectureTests.Types.Fixtures;

/// <summary>
/// DTO shapes for the time rule (D-55): one valid shape and one bad-on-purpose shape per violation. They compile
/// under every house rule; only the ArchitectureTests time rule rejects the bad ones.
/// </summary>
internal static class TimeFixtures
{
    /// <summary>Valid: a <see cref="DateTimeOffset"/> time, an optional one and a duration with a unit.</summary>
    internal sealed class ValidTimesDto
    {
        public ValidTimesDto(DateTimeOffset createdAt, DateTimeOffset? finishedAt, double durationMs)
        {
            CreatedAt = createdAt;
            FinishedAt = finishedAt;
            DurationMs = durationMs;
        }

        public DateTimeOffset CreatedAt { get; }

        public DateTimeOffset? FinishedAt { get; }

        public double DurationMs { get; }
    }

    /// <summary>Bad: a <see cref="DateTime"/> property, which carries no offset.</summary>
    internal sealed class DateTimePropertyDto
    {
        public DateTimePropertyDto(DateTime? createdAt)
        {
            CreatedAt = createdAt;
        }

        public DateTime? CreatedAt { get; }
    }

    /// <summary>Bad: a <see cref="TimeSpan"/> property, which goes on the wire as a string.</summary>
    internal sealed class TimeSpanPropertyDto
    {
        public TimeSpan Elapsed { get; }
    }

    /// <summary>Bad: a duration without a unit suffix.</summary>
    internal sealed class DurationWithoutUnitDto
    {
        public double TotalDuration { get; }
    }

    /// <summary>Bad: a list of <see cref="DateTime"/> values.</summary>
    internal sealed class DateTimeListDto
    {
        public DateTimeListDto(IReadOnlyList<DateTime> timestamps)
        {
            Timestamps = timestamps;
        }

        public IReadOnlyList<DateTime> Timestamps { get; }
    }

    /// <summary>Bad: an array of <see cref="DateTime"/> values.</summary>
    internal sealed class DateTimeArrayDto
    {
        public DateTimeArrayDto(DateTime[] days)
        {
            Days = days;
        }

        public IReadOnlyCollection<DateTime[]> Batches => [Days];

        private DateTime[] Days { get; }
    }

    /// <summary>Bad: a dictionary whose values are <see cref="TimeSpan"/> values.</summary>
    internal sealed class TimeSpanDictionaryDto
    {
        public TimeSpanDictionaryDto(IReadOnlyDictionary<string, TimeSpan> timings)
        {
            Timings = timings;
        }

        public IReadOnlyDictionary<string, TimeSpan> Timings { get; }
    }

    /// <summary>Bad: an entity that keeps its time in a <see cref="DateTime"/> field.</summary>
    internal sealed class DateTimeFieldEntity
    {
        public DateTimeFieldEntity(DateTime createdAt)
        {
            _createdAt = createdAt;
        }

        public DateTimeOffset CreatedAtUtc()
        {
            return new DateTimeOffset(dateTime: _createdAt);
        }

        private readonly DateTime _createdAt;
    }
}
