namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// One row of the rule matrix's "Exemptions" table: a scoped exemption, the files it covers, the exact subject of
/// the suppression the scan meets there, why it exists and the rule it belongs to.
/// </summary>
internal sealed class MatrixExemption
{
    /// <summary>Initializes a new instance of the <see cref="MatrixExemption"/> class.</summary>
    /// <param name="id">The row ID, for example <c>EX-01</c>.</param>
    /// <param name="anchor">The HTML anchor ID in the ID cell, for example <c>ex-01</c>; empty when missing.</param>
    /// <param name="pathGlob">The repository-relative path glob of the files the exemption covers.</param>
    /// <param name="text">
    /// The exact subject of the suppression the scan meets in those files, or the text a rule function encodes.
    /// </param>
    /// <param name="reason">Why the exemption exists.</param>
    /// <param name="ruleId">The rule row the exemption belongs to, for example <c>R-36</c>.</param>
    internal MatrixExemption(string id, string anchor, string pathGlob, string text, string reason, string ruleId)
    {
        Id = id;
        Anchor = anchor;
        PathGlob = pathGlob;
        Text = text;
        Reason = reason;
        RuleId = ruleId;
    }

    /// <summary>Gets the row ID, for example <c>EX-01</c>.</summary>
    internal string Id { get; }

    /// <summary>Gets the HTML anchor ID in the ID cell; empty when the cell has none.</summary>
    internal string Anchor { get; }

    /// <summary>Gets the repository-relative path glob, without backticks.</summary>
    internal string PathGlob { get; }

    /// <summary>Gets the exact text, without backticks.</summary>
    internal string Text { get; }

    /// <summary>Gets the reason cell.</summary>
    internal string Reason { get; }

    /// <summary>Gets the ID of the rule row the exemption belongs to.</summary>
    internal string RuleId { get; }
}
