using System;
using System.Diagnostics;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LangProject.Core.ArchitectureTests.Infrastructure;

/// <summary>
/// Runs a child process with redirected output and a time limit. Output is read, never written to the console;
/// a process that runs past the limit is killed with its whole process tree.
/// </summary>
internal static class ProcessRunner
{
    /// <summary>Starts the process, waits for it to exit, and returns its exit code and combined output.</summary>
    /// <param name="startInfo">The program, arguments, working directory and environment to run.</param>
    /// <param name="timeout">How long the process may run before it is killed.</param>
    /// <param name="cancellationToken">Stops the wait and kills the process when the test run is cancelled.</param>
    /// <returns>The exit code, the standard output and the standard error, kept apart.</returns>
    /// <exception cref="TimeoutException">The process ran longer than <paramref name="timeout"/>.</exception>
    internal static async Task<ProcessResult> RunAsync(
            ProcessStartInfo startInfo,
            TimeSpan timeout,
            CancellationToken cancellationToken)
    {
        startInfo.UseShellExecute = false;
        startInfo.RedirectStandardInput = true;
        startInfo.RedirectStandardOutput = true;
        startInfo.RedirectStandardError = true;
        startInfo.StandardOutputEncoding = Encoding.UTF8;
        startInfo.StandardErrorEncoding = Encoding.UTF8;

        using var limit = CancellationTokenSource.CreateLinkedTokenSource(token: cancellationToken);
        limit.CancelAfter(delay: timeout);
        using Process process = Process.Start(startInfo: startInfo)
                ?? throw new InvalidOperationException(message: $"Could not start {startInfo.FileName}.");
        process.StandardInput.Close();
        Task<string> standardOutput = process.StandardOutput.ReadToEndAsync(cancellationToken: limit.Token);
        Task<string> standardError = process.StandardError.ReadToEndAsync(cancellationToken: limit.Token);
        try
        {
            await process.WaitForExitAsync(cancellationToken: limit.Token);
            string[] texts = await Task.WhenAll(standardOutput, standardError);
            return new ProcessResult(exitCode: process.ExitCode, standardOutput: texts[0], standardError: texts[1]);
        }
        catch (OperationCanceledException exception) when (!cancellationToken.IsCancellationRequested)
        {
            process.Kill(entireProcessTree: true);
            throw new TimeoutException(
                    message: $"{startInfo.FileName} {string.Join(separator: " ", values: startInfo.ArgumentList)} "
                            + $"ran longer than {timeout}.",
                    innerException: exception);
        }
        catch (OperationCanceledException)
        {
            process.Kill(entireProcessTree: true);
            throw;
        }
    }
}
