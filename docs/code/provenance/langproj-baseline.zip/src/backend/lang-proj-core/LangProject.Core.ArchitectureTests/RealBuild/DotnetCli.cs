using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;

namespace LangProject.Core.ArchitectureTests.RealBuild;

/// <summary>
/// Runs the <c>dotnet</c> CLI for the real-build proofs, with redirected output and a time limit, never through the
/// console.
/// </summary>
/// <remarks>
/// The child gets a clean environment: MSBuild and profiler variables inherited from the test host are removed, and
/// MSBuild node reuse, the MSBuild server, the shared compiler and the Razor server are switched off. A build server
/// left running would hold the redirected output open, and an inherited <c>MSBuildSDKsPath</c> or coverage profiler
/// would change how the child builds.
/// </remarks>
internal static class DotnetCli
{
    /// <summary>The switch that turns NuGet audit off for a proof build that does not test auditing.</summary>
    internal const string NoAudit = "-p:NuGetAudit=false";

    /// <summary>Runs <c>dotnet</c> with <paramref name="arguments"/> in <paramref name="workingDirectory"/>.</summary>
    /// <param name="arguments">The arguments, one item per argument; no shell quoting is applied.</param>
    /// <param name="workingDirectory">The folder to run in; <c>global.json</c> above it selects the SDK.</param>
    /// <param name="cancellationToken">Cancels the run and kills the process.</param>
    /// <returns>The exit code and the standard output followed by the standard error.</returns>
    internal static Task<ProcessResult> RunAsync(
            IReadOnlyList<string> arguments,
            string workingDirectory,
            CancellationToken cancellationToken)
    {
        var startInfo = new ProcessStartInfo(fileName: "dotnet") { WorkingDirectory = workingDirectory };
        foreach (string argument in arguments)
        {
            startInfo.ArgumentList.Add(item: argument);
        }

        List<string> inherited = [.. startInfo.Environment.Keys.Where(predicate: IsRemovedVariable)];
        foreach (string key in inherited)
        {
            startInfo.Environment.Remove(key: key);
        }

        foreach (KeyValuePair<string, string> variable in _childVariables)
        {
            startInfo.Environment[variable.Key] = variable.Value;
        }

        return ProcessRunner.RunAsync(startInfo: startInfo, timeout: _timeout, cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Runs <c>dotnet build</c> on one project or solution, with build servers disabled and the classic console
    /// logger, so every diagnostic appears in MSBuild's canonical format. NuGet audit is off
    /// (<see cref="NoAudit"/>): only the audit proof, <see cref="BuildWithAuditAsync"/>, needs advisory data.
    /// </summary>
    /// <param name="target">The project or solution path, relative to <paramref name="workingDirectory"/>.</param>
    /// <param name="workingDirectory">The folder to run in.</param>
    /// <param name="cancellationToken">Cancels the run and kills the process.</param>
    /// <returns>The exit code and the combined output.</returns>
    internal static Task<ProcessResult> BuildAsync(
            string target,
            string workingDirectory,
            CancellationToken cancellationToken)
    {
        return RunAsync(
                arguments: ["build", target, "--disable-build-servers", "-tl:off", "-nologo", NoAudit],
                workingDirectory: workingDirectory,
                cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Runs <c>dotnet build</c> like <see cref="BuildAsync"/>, but with NuGet audit on and NuGet's HTTP cache
    /// bypassed, so restore reads the copy's audit source afresh.
    /// </summary>
    /// <param name="target">The project or solution path, relative to <paramref name="workingDirectory"/>.</param>
    /// <param name="workingDirectory">The folder to run in.</param>
    /// <param name="cancellationToken">Cancels the run and kills the process.</param>
    /// <returns>The exit code and the combined output.</returns>
    internal static Task<ProcessResult> BuildWithAuditAsync(
            string target,
            string workingDirectory,
            CancellationToken cancellationToken)
    {
        return RunAsync(
                arguments:
                [
                    "build",
                    target,
                    "--disable-build-servers",
                    "-tl:off",
                    "-nologo",
                    "-p:NuGetAudit=true",
                    "-p:RestoreNoHttpCache=true",
                ],
                workingDirectory: workingDirectory,
                cancellationToken: cancellationToken);
    }

    /// <summary>
    /// Explains a failed run for an assertion message: the output, preceded by a note when restore could not
    /// reach a package source, because the proofs need nuget.org only for a package that is missing from the
    /// NuGet global packages folder.
    /// </summary>
    /// <param name="result">The finished run.</param>
    /// <returns>The message.</returns>
    internal static string Explain(ProcessResult result)
    {
        bool offline = _networkCodes.Any(predicate: code => result.Output.Contains(
                value: code,
                comparisonType: StringComparison.Ordinal));
        return offline ? NetworkNote + result.Output : result.Output;
    }

    private const string NetworkNote = "Restore could not reach a package source. The real-build proofs need "
            + "nuget.org only for a package or tool missing from the NuGet global packages folder: run "
            + "`dotnet restore` and `dotnet tool restore` for the solution once while online.\n";

    private static readonly TimeSpan _timeout = TimeSpan.FromMinutes(minutes: 10);

    private static readonly string[] _networkCodes = ["NU1301", "NU1101", "NU1102", "NU1900"];

    private static readonly string[] _removedVariablePrefixes =
    [
        "MSBuild",
        "CORECLR_",
        "COR_",
        "MicrosoftInstrumentationEngine_",
        "DOTNET_STARTUP_HOOKS",
    ];

    private static readonly Dictionary<string, string> _childVariables = new(comparer: StringComparer.Ordinal)
    {
        ["MSBUILDDISABLENODEREUSE"] = "1",
        ["DOTNET_CLI_USE_MSBUILD_SERVER"] = "0",
        ["UseSharedCompilation"] = "false",
        ["UseRazorBuildServer"] = "false",
        ["DOTNET_CLI_TELEMETRY_OPTOUT"] = "1",
        ["DOTNET_NOLOGO"] = "1",
        ["DOTNET_SKIP_FIRST_TIME_EXPERIENCE"] = "1",
        ["DOTNET_CLI_UI_LANGUAGE"] = "en",
    };

    private static bool IsRemovedVariable(string key)
    {
        return _removedVariablePrefixes.Any(predicate: prefix => key.StartsWith(
                value: prefix,
                comparisonType: StringComparison.OrdinalIgnoreCase));
    }
}
