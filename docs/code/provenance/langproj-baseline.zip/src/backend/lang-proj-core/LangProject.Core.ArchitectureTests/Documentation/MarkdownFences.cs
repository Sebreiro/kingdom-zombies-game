using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace LangProject.Core.ArchitectureTests.Documentation;

/// <summary>
/// Finds the fenced code blocks of a Markdown document the way CommonMark does, for every docs check that skips
/// code: a fence opens with a run of three or more backticks or tildes, indented by at most three spaces, and a
/// backtick fence's info string holds no backtick (so <c>```dotnet build``` is the command</c> is a code span, not a
/// fence). It closes only with a run of the same character at least as long, followed by nothing but spaces, and
/// an unclosed fence runs to the end of the document. It also removes code spans from a line.
/// </summary>
internal static partial class MarkdownFences
{
    /// <summary>Tells, for each line, whether it is content: outside every fenced block and not a fence line.</summary>
    /// <param name="lines">The document's lines.</param>
    /// <returns>One flag per line, <see langword="true"/> for a content line.</returns>
    internal static IReadOnlyList<bool> ContentMask(IReadOnlyList<string> lines)
    {
        bool[] content = new bool[lines.Count];
        char fenceCharacter = '\0';
        int fenceLength = 0;
        for (int index = 0; index < lines.Count; index++)
        {
            Match fence = FencePattern().Match(input: lines[index]);
            string run = fence.Groups["run"].Value;
            string info = fence.Groups["info"].Value;
            if (fenceLength == 0)
            {
                bool opens = fence.Success && !(run[0] == '`' && info.Contains(value: '`'));
                content[index] = !opens;
                fenceCharacter = opens ? run[0] : '\0';
                fenceLength = opens ? run.Length : 0;
            }
            else if (fence.Success
                    && run[0] == fenceCharacter
                    && run.Length >= fenceLength
                    && info.Trim().Length == 0)
            {
                fenceLength = 0;
            }
        }

        return content;
    }

    /// <summary>Lists the content lines of a document, with their 0-based indexes.</summary>
    /// <param name="markdown">The document's text.</param>
    /// <returns>The lines outside every fenced block, in order.</returns>
    internal static IReadOnlyList<KeyValuePair<int, string>> ContentLines(string markdown)
    {
        string[] lines = markdown.Split(separator: '\n');
        IReadOnlyList<bool> mask = ContentMask(lines: lines);
        var content = new List<KeyValuePair<int, string>>();
        for (int index = 0; index < lines.Length; index++)
        {
            if (mask[index])
            {
                content.Add(item: new KeyValuePair<int, string>(key: index, value: lines[index]));
            }
        }

        return content;
    }

    /// <summary>Removes the code spans of one line, so text inside backticks is not read as Markdown.</summary>
    /// <param name="line">The line.</param>
    /// <returns>The line without its code spans.</returns>
    internal static string WithoutCodeSpans(string line)
    {
        return CodeSpanPattern().Replace(input: line, replacement: string.Empty);
    }

    [GeneratedRegex(
            pattern: @"^ {0,3}(?<run>`{3,}|~{3,})(?<info>[^\r]*)\r?$",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex FencePattern();

    [GeneratedRegex(pattern: "`[^`]*`", options: RegexOptions.CultureInvariant, matchTimeoutMilliseconds: 10000)]
    private static partial Regex CodeSpanPattern();
}
