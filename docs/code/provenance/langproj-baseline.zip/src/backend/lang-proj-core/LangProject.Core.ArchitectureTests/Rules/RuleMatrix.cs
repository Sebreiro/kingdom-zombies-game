using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// The rule matrix, <c>src/backend/docs/rule-matrix.md</c>, parsed from its "Rules" and "Exemptions" tables, with
/// the row checks of SPEC R7. Parsing and checking are pure functions over text, so proofs can feed synthetic
/// matrices (D-12: docs checks are .NET tests).
/// </summary>
internal sealed partial class RuleMatrix
{
    /// <summary>Initializes a new instance of the <see cref="RuleMatrix"/> class.</summary>
    /// <param name="rules">The rows of the "Rules" table.</param>
    /// <param name="exemptions">The rows of the "Exemptions" table.</param>
    /// <param name="malformedRows">The table lines whose cell count does not fit their table.</param>
    internal RuleMatrix(
            IReadOnlyList<MatrixRule> rules,
            IReadOnlyList<MatrixExemption> exemptions,
            IReadOnlyList<string> malformedRows)
    {
        Rules = rules;
        Exemptions = exemptions;
        MalformedRows = malformedRows;
    }

    /// <summary>Gets the rows of the "Rules" table, in document order.</summary>
    internal IReadOnlyList<MatrixRule> Rules { get; }

    /// <summary>Gets the rows of the "Exemptions" table, in document order.</summary>
    internal IReadOnlyList<MatrixExemption> Exemptions { get; }

    /// <summary>Gets the table lines whose cell count does not fit their table.</summary>
    internal IReadOnlyList<string> MalformedRows { get; }

    /// <summary>Parses the "Rules" and "Exemptions" tables of a matrix document.</summary>
    /// <param name="markdown">The matrix document text.</param>
    /// <returns>The parsed matrix; a table that is missing gives no rows.</returns>
    internal static RuleMatrix Parse(string markdown)
    {
        string[] lines = markdown.Split(separator: '\n');
        var malformed = new List<string>();
        var rules = new List<MatrixRule>();
        foreach (List<string> cells in TableRows(
                lines: lines,
                heading: "## Rules",
                cellCount: 6,
                malformed: malformed))
        {
            rules.Add(item: new MatrixRule(
                    id: IdText(cell: cells[0]),
                    anchor: Anchor(cell: cells[0]),
                    rule: cells[1],
                    mechanisms: cells[2],
                    scope: cells[3],
                    proof: cells[4],
                    level: cells[5]));
        }

        var exemptions = new List<MatrixExemption>();
        foreach (List<string> cells in TableRows(
                lines: lines,
                heading: "## Exemptions",
                cellCount: 5,
                malformed: malformed))
        {
            exemptions.Add(item: new MatrixExemption(
                    id: IdText(cell: cells[0]),
                    anchor: Anchor(cell: cells[0]),
                    pathGlob: Unquote(cell: cells[1]),
                    text: Unquote(cell: cells[2]),
                    reason: cells[3],
                    ruleId: RuleIdPattern().Match(input: cells[4]).Value));
        }

        return new RuleMatrix(rules: rules, exemptions: exemptions, malformedRows: malformed);
    }

    /// <summary>
    /// Checks every row: a well-formed ID with a matching anchor, no empty cell, at least one proof test, known
    /// levels, unique IDs, and exemption and rule references that exist.
    /// </summary>
    /// <param name="matrix">The parsed matrix.</param>
    /// <returns>One message per problem; empty when every row is complete.</returns>
    internal static IReadOnlyList<string> CheckRows(RuleMatrix matrix)
    {
        var ruleIds = matrix.Rules.Select(selector: rule => rule.Id).ToHashSet(comparer: StringComparer.Ordinal);
        var exemptionIds = matrix.Exemptions
                .Select(selector: exemption => exemption.Id)
                .ToHashSet(comparer: StringComparer.Ordinal);
        List<string> violations =
        [
            .. matrix.MalformedRows.Select(selector: row => $"Malformed table row: {row}"),
            .. DuplicateIds(ids: matrix.Rules.Select(selector: rule => rule.Id)),
            .. DuplicateIds(ids: matrix.Exemptions.Select(selector: exemption => exemption.Id)),
            .. matrix.Rules.SelectMany(selector: rule => CheckRule(rule: rule, exemptionIds: exemptionIds)),
            .. matrix.Exemptions.SelectMany(selector: exemption => CheckExemption(
                    exemption: exemption,
                    ruleIds: ruleIds)),
        ];
        return violations;
    }

    /// <summary>Lists the diagnostic IDs in a cell, such as <c>IDE0055</c>, <c>SCR0001</c> or <c>RS0030</c>.</summary>
    /// <param name="cell">The cell text.</param>
    /// <returns>The distinct IDs, in order of appearance.</returns>
    internal static IReadOnlyList<string> DiagnosticIds(string cell)
    {
        return Values(pattern: DiagnosticIdPattern(), text: cell, group: "id");
    }

    /// <summary>
    /// Lists the proof tests in a cell: backticked fully qualified names that start with <c>LangProject.</c> or
    /// <c>Sebreiro.</c>.
    /// </summary>
    /// <param name="cell">The cell text.</param>
    /// <returns>The names, in order of appearance.</returns>
    internal static IReadOnlyList<string> ProofTests(string cell)
    {
        return Values(pattern: ProofTestPattern(), text: cell, group: "name");
    }

    /// <summary>
    /// Lists the banned-symbol documentation IDs in a cell: backticked entries such as <c>P:System.DateTime.Now</c>.
    /// An entry with a generic arity, such as <c>P:System.Threading.Tasks.Task`1.Result</c>, sits in double backticks.
    /// </summary>
    /// <param name="cell">The cell text.</param>
    /// <returns>The entries, in order of appearance.</returns>
    internal static IReadOnlyList<string> BannedSymbols(string cell)
    {
        return Values(pattern: BannedSymbolPattern(), text: cell, group: "entry");
    }

    /// <summary>Lists the links from a cell to the code-rule docs, as document path and anchor.</summary>
    /// <param name="cell">The cell text, for example a rule cell.</param>
    /// <returns>The links, for example <c>(CodeRules/code-style.md, utf-8-encoding)</c>.</returns>
    internal static IReadOnlyList<KeyValuePair<string, string>> DocLinks(string cell)
    {
        return
        [
            .. DocLinkPattern()
                    .Matches(input: cell)
                    .Select(selector: link => new KeyValuePair<string, string>(
                            key: link.Groups["document"].Value,
                            value: link.Groups["anchor"].Value)),
        ];
    }

    /// <summary>Lists the exemption IDs (<c>EX-NN</c>) named in a text.</summary>
    /// <param name="text">The text, for example a scope cell.</param>
    /// <returns>The distinct IDs, in order of appearance.</returns>
    internal static IReadOnlyList<string> ExemptionIds(string text)
    {
        return Values(pattern: ExemptionIdPattern(), text: text, group: "id");
    }

    private static readonly HashSet<string> _levels = new(
            collection: ["analyzer test", "ArchitectureTests", "real build", "IntegrationTests", "CI", "PR review"],
            comparer: StringComparer.Ordinal);

    [GeneratedRegex(
            pattern: @"\b(?<id>(SCR|IDE|CA|MA|RCS|RS|CS)[0-9]{4})\b",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex DiagnosticIdPattern();

    [GeneratedRegex(
            pattern: @"`(?<name>(LangProject|Sebreiro)(\.[A-Za-z_][A-Za-z0-9_]*)+)`",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex ProofTestPattern();

    [GeneratedRegex(
            pattern: "`{1,2} ?(?<entry>[TMPFE]:([^`\\s]|`[0-9])+)",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex BannedSymbolPattern();

    [GeneratedRegex(
            pattern: @"\]\((?<document>CodeRules/[A-Za-z-]+\.md)#(?<anchor>[^)\s]+)\)",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex DocLinkPattern();

    [GeneratedRegex(
            pattern: @"\b(?<id>EX-[0-9]{2})\b",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex ExemptionIdPattern();

    [GeneratedRegex(
            pattern: @"\bR-[0-9]{2}\b",
            options: RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex RuleIdPattern();

    [GeneratedRegex(
            pattern: "^(?<prefix>R|EX)-(?<number>[0-9]{2})$",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex RowIdPattern();

    [GeneratedRegex(
            pattern: @"<a id=""(?<anchor>[^""]*)""></a>",
            options: RegexOptions.ExplicitCapture | RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex AnchorPattern();

    [GeneratedRegex(
            pattern: @"(?<!\\)\|",
            options: RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex CellSeparatorPattern();

    private static IEnumerable<List<string>> TableRows(
            string[] lines,
            string heading,
            int cellCount,
            List<string> malformed)
    {
        int start = Array.FindIndex(array: lines, match: line => string.Equals(
                a: line.TrimEnd(),
                b: heading,
                comparisonType: StringComparison.Ordinal));
        if (start < 0)
        {
            yield break;
        }

        IEnumerable<string> tableLines = lines
                .Skip(count: start + 1)
                .TakeWhile(predicate: line => !line.StartsWith(value: "## ", comparisonType: StringComparison.Ordinal))
                .Select(selector: line => line.Trim())
                .Where(predicate: line => line.StartsWith(value: '|'))
                .Skip(count: 2);
        foreach (string line in tableLines)
        {
            List<string> cells = SplitCells(line: line);
            if (cells.Count == cellCount)
            {
                yield return cells;
            }
            else
            {
                malformed.Add(item: line);
            }
        }
    }

    private static List<string> SplitCells(string line)
    {
        string inner = line.Trim().TrimStart(trimChar: '|');
        if (inner.EndsWith(value: '|') && !inner.EndsWith(value: "\\|", comparisonType: StringComparison.Ordinal))
        {
            inner = inner[..^1];
        }

        return
        [
            .. CellSeparatorPattern()
                    .Split(input: inner)
                    .Select(selector: cell => cell.Replace(
                            oldValue: "\\|",
                            newValue: "|",
                            comparisonType: StringComparison.Ordinal).Trim()),
        ];
    }

    private static string IdText(string cell)
    {
        return AnchorPattern().Replace(input: cell, replacement: string.Empty).Trim();
    }

    private static string Anchor(string cell)
    {
        return AnchorPattern().Match(input: cell).Groups["anchor"].Value;
    }

    private static string Unquote(string cell)
    {
        return cell.Length >= 2 && cell.StartsWith(value: '`') && cell.EndsWith(value: '`') ? cell[1..^1] : cell;
    }

    private static List<string> Values(Regex pattern, string text, string group)
    {
        return
        [
            .. pattern
                    .Matches(input: text)
                    .Select(selector: match => match.Groups[group].Value)
                    .Distinct(comparer: StringComparer.Ordinal),
        ];
    }

    private static IEnumerable<string> DuplicateIds(IEnumerable<string> ids)
    {
        return ids
                .GroupBy(keySelector: id => id, comparer: StringComparer.Ordinal)
                .Where(predicate: group => group.Count() > 1)
                .Select(selector: group => $"{group.Key} is used by more than one row");
    }

    private static List<string> CheckRule(MatrixRule rule, HashSet<string> exemptionIds)
    {
        var violations = new List<string>();
        violations.AddRange(collection: CheckId(id: rule.Id, anchor: rule.Anchor, prefix: "R"));
        violations.AddRange(collection: EmptyCells(
                id: rule.Id,
                cells: [("rule", rule.Rule), ("mechanism", rule.Mechanisms), ("scope", rule.Scope)]));
        if (ProofTests(cell: rule.Proof).Count == 0)
        {
            violations.Add(item: $"{rule.Id}: the proof cell names no proof test");
        }

        violations.AddRange(collection: rule.Level
                .Split(separator: ',')
                .Select(selector: level => level.Trim())
                .Where(predicate: level => !_levels.Contains(item: level))
                .Select(selector: level => $"{rule.Id}: unknown level '{level}'"));
        violations.AddRange(collection: ExemptionIds(text: rule.Scope)
                .Where(predicate: id => !exemptionIds.Contains(item: id))
                .Select(selector: id => $"{rule.Id}: names {id}, which has no exemption row"));
        return violations;
    }

    private static List<string> CheckExemption(MatrixExemption exemption, HashSet<string> ruleIds)
    {
        var violations = new List<string>();
        violations.AddRange(collection: CheckId(id: exemption.Id, anchor: exemption.Anchor, prefix: "EX"));
        violations.AddRange(collection: EmptyCells(
                id: exemption.Id,
                cells: [("path glob", exemption.PathGlob), ("text", exemption.Text), ("reason", exemption.Reason)]));
        if (!ruleIds.Contains(item: exemption.RuleId))
        {
            violations.Add(item: $"{exemption.Id}: belongs to rule '{exemption.RuleId}', which has no row");
        }

        if (string.Equals(a: exemption.Text.Trim(), b: "*", comparisonType: StringComparison.Ordinal))
        {
            violations.Add(item: $"{exemption.Id}: '*' exempts nothing; give the exact subject of one suppression");
        }

        return violations;
    }

    private static List<string> CheckId(string id, string anchor, string prefix)
    {
        Match match = RowIdPattern().Match(input: id);
        if (!match.Success || !string.Equals(
                a: match.Groups["prefix"].Value,
                b: prefix,
                comparisonType: StringComparison.Ordinal))
        {
            return [$"'{id}' is not a {prefix}-NN row ID"];
        }

        string expected = (string.Equals(a: prefix, b: "R", comparisonType: StringComparison.Ordinal) ? "r-" : "ex-")
                + match.Groups["number"].Value;
        if (!string.Equals(a: anchor, b: expected, comparisonType: StringComparison.Ordinal))
        {
            return [$"{id}: the ID cell needs the anchor <a id=\"{expected}\"></a>"];
        }

        return [];
    }

    private static IEnumerable<string> EmptyCells(string id, (string Name, string Value)[] cells)
    {
        return cells
                .Where(predicate: cell => string.IsNullOrWhiteSpace(value: cell.Value))
                .Select(selector: cell => $"{id}: the {cell.Name} cell is empty");
    }
}
