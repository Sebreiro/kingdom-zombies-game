using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Files;
using LangProject.Core.ArchitectureTests.Infrastructure;
using LangProject.Core.ArchitectureTests.Rules;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.RealBuild;

/// <summary>
/// Real <c>dotnet ef migrations add</c> runs in a throwaway copy of the solution: the generated migration builds
/// clean without hand edits, after a model change and with no model change (SPEC R8). The migration and designer
/// files must exist, and they and the model snapshot must pass the scans R-50 relies on as they are: the
/// suppression scan with the rule matrix's exemptions, and the D-84 format rule. The copy keeps the tool manifest,
/// so the pinned <c>dotnet-ef</c> runs. DAL is built first, because <c>dotnet ef</c> reads the project's restore
/// output before it would build it.
/// </summary>
public sealed class MigrationProofTests
{
    /// <summary>
    /// Changing the language name's maximum length from 64 to 65, then <c>dotnet ef migrations add</c>, writes a
    /// migration and designer file that pass the scans, and a build of the whole solution then exits with code 0.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Migrations_AddAfterModelChange_BuildsClean()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        using SolutionCopy copy = await SolutionCopy.CreateAsync(
                cancellationToken: cancellationToken);
        copy.ReplaceInFile(
                relativePath: "LangProject.Core.DAL/Languages/LanguageConfiguration.cs",
                oldValue: "maxLength: 64",
                newValue: "maxLength: 65");

        await AddMigrationAsync(copy: copy, name: "ProofModelChange", cancellationToken: cancellationToken);
        copy.ReadFile(relativePath: MigrationsFolder + SnapshotFile).ShouldContain(expected: "HasMaxLength(65)");
        ProcessResult build = await DotnetCli.BuildAsync(
                target: SolutionFile,
                workingDirectory: copy.SolutionRoot,
                cancellationToken: cancellationToken);

        ShouldBuildClean(build: build);
    }

    /// <summary>
    /// <c>dotnet ef migrations add</c> with no model change writes an empty migration and its designer file, which
    /// pass the scans, and a build of the whole solution then exits with code 0.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Migrations_AddWithoutModelChange_BuildsClean()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        using SolutionCopy copy = await SolutionCopy.CreateAsync(
                cancellationToken: cancellationToken);

        ProcessResult add = await AddMigrationAsync(
                copy: copy,
                name: "ProofEmpty",
                cancellationToken: cancellationToken);
        add.Output.ShouldContain(expected: "Done.", customMessage: add.Output);
        ProcessResult build = await DotnetCli.BuildAsync(
                target: SolutionFile,
                workingDirectory: copy.SolutionRoot,
                cancellationToken: cancellationToken);

        ShouldBuildClean(build: build);
    }

    private const string SolutionFile = "LangProject.Core.slnx";
    private const string MigrationsFolder = "LangProject.Core.DAL/Migrations/";
    private const string DalProject = "LangProject.Core.DAL/LangProject.Core.DAL.csproj";
    private const string SnapshotFile = "LangDbContextModelSnapshot.cs";
    private const string SolutionFolder = "src/backend/lang-proj-core/";

    private static async Task<ProcessResult> AddMigrationAsync(
            SolutionCopy copy,
            string name,
            CancellationToken cancellationToken)
    {
        ProcessResult restore = await DotnetCli.RunAsync(
                arguments: ["tool", "restore"],
                workingDirectory: copy.SolutionRoot,
                cancellationToken: cancellationToken);
        restore.ExitCode.ShouldBe(expected: 0, customMessage: DotnetCli.Explain(result: restore));
        ProcessResult build = await DotnetCli.BuildAsync(
                target: DalProject,
                workingDirectory: copy.SolutionRoot,
                cancellationToken: cancellationToken);
        build.ExitCode.ShouldBe(expected: 0, customMessage: DotnetCli.Explain(result: build));

        ProcessResult add = await DotnetCli.RunAsync(
                arguments: ["ef", "migrations", "add", name, "--project", DalProject, "--no-build"],
                workingDirectory: copy.SolutionRoot,
                cancellationToken: cancellationToken);
        add.ExitCode.ShouldBe(expected: 0, customMessage: add.Output);
        ShouldPassScans(copy: copy, name: name);
        return add;
    }

    private static void ShouldPassScans(SolutionCopy copy, string name)
    {
        string folder = Path.Combine(path1: copy.SolutionRoot, path2: MigrationsFolder);
        List<string> generated =
        [
            .. Directory.EnumerateFiles(path: folder, searchPattern: $"*_{name}*.cs")
                    .Select(selector: path => Path.GetFileName(path: path))
                    .Order(comparer: StringComparer.Ordinal),
        ];
        generated.Count.ShouldBe(expected: 2, customMessage: string.Join(separator: ", ", values: generated));
        generated.ShouldContain(elementPredicate: file => file.EndsWith(
                value: $"_{name}.Designer.cs",
                comparisonType: StringComparison.Ordinal));

        IReadOnlyList<MatrixExemption> exemptions = RuleMatrix.Parse(markdown: File.ReadAllText(
                path: Path.Combine(path1: RepositoryLayout.BackendDocs, path2: "rule-matrix.md"))).Exemptions;
        var violations = new List<string>();
        foreach (string file in generated.Append(element: SnapshotFile))
        {
            string relativePath = SolutionFolder + MigrationsFolder + file;
            byte[] bytes = File.ReadAllBytes(path: Path.Combine(path1: folder, path2: file));
            string text = File.ReadAllText(path: Path.Combine(path1: folder, path2: file));
            violations.AddRange(collection: SuppressionScanner.Scan(relativePath: relativePath, content: text)
                    .Where(predicate: hit => !SuppressionScanner.IsExempt(hit: hit, exemptions: exemptions))
                    .Select(selector: hit => hit.ToString()));
            violations.AddRange(collection: SourceFileFormat.Check(relativePath: relativePath, content: bytes));
        }

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    private static void ShouldBuildClean(ProcessResult build)
    {
        build.ExitCode.ShouldBe(expected: 0, customMessage: build.Output);
        build.ErrorIds.ShouldBeEmpty(customMessage: build.Output);
    }
}
