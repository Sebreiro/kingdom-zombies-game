using System;
using System.Collections.Generic;
using System.Linq;

namespace LangProject.Core.ArchitectureTests.Files;

/// <summary>
/// An <c>.editorconfig</c> file read as INI sections, every setting kept in file order with its section, so tests can
/// ask for the value that takes effect (the last one in a section) and find any section that sets a key to another
/// value.
/// </summary>
internal sealed class EditorConfigFile
{
    /// <summary>The section name used for the settings before the first header, such as <c>root = true</c>.</summary>
    internal const string Preamble = "";

    /// <summary>
    /// Gets every setting in file order; keys are lowercase, as editorconfig keys are case-insensitive.
    /// </summary>
    internal IReadOnlyList<(string Section, string Key, string Value)> Settings { get; }

    /// <summary>
    /// Parses the text of an <c>.editorconfig</c> file. Blank lines and <c>#</c> or <c>;</c> comments are skipped.
    /// </summary>
    /// <param name="text">The file text.</param>
    /// <returns>The parsed file.</returns>
    internal static EditorConfigFile Parse(string text)
    {
        var settings = new List<(string Section, string Key, string Value)>();
        string section = Preamble;
        foreach (string rawLine in text.Split(separator: '\n'))
        {
            string line = rawLine.Trim();
            if (line.Length == 0 || line.StartsWith(value: '#') || line.StartsWith(value: ';'))
            {
                continue;
            }

            if (line.StartsWith(value: '[') && line.EndsWith(value: ']'))
            {
                section = line[1..^1];
                continue;
            }

            int separator = line.IndexOf(value: '=', comparisonType: StringComparison.Ordinal);
            if (separator > 0)
            {
                settings.Add(item: (
                        Section: section,
                        Key: line[..separator].Trim().ToLowerInvariant(),
                        Value: line[(separator + 1)..].Trim()));
            }
        }

        return new EditorConfigFile(settings: settings);
    }

    /// <summary>
    /// Checks the value that takes effect in one section: for each expected key, the last value the section sets,
    /// across repeated headers, must equal the expected value, ignoring case.
    /// </summary>
    /// <param name="section">The section header without brackets, or <see cref="Preamble"/>.</param>
    /// <param name="expected">The expected values by key.</param>
    /// <returns>One violation per key that is missing or ends with another value.</returns>
    internal IReadOnlyList<string> CheckEffective(string section, IReadOnlyDictionary<string, string> expected)
    {
        List<string> violations = [];
        foreach (KeyValuePair<string, string> setting in expected)
        {
            string? actual = Settings
                    .LastOrDefault(predicate: entry => IsSame(left: entry.Section, right: section)
                            && IsSame(left: entry.Key, right: setting.Key))
                    .Value;
            if (!string.Equals(a: actual, b: setting.Value, comparisonType: StringComparison.OrdinalIgnoreCase))
            {
                violations.Add(item: $"[{section}] {setting.Key} takes effect as '{actual ?? "(unset)"}'; "
                        + $"expected '{setting.Value}'");
            }
        }

        return violations;
    }

    /// <summary>
    /// Finds every setting, in any section, that gives one of the expected keys another value, so a later or more
    /// specific section cannot override the expected value.
    /// </summary>
    /// <param name="expected">The expected values by key.</param>
    /// <returns>One violation per conflicting setting.</returns>
    internal IReadOnlyList<string> FindConflicts(IReadOnlyDictionary<string, string> expected)
    {
        return
        [
            .. Settings
                    .Where(predicate: entry => expected.TryGetValue(key: entry.Key, value: out string? value)
                            && !string.Equals(
                                    a: entry.Value,
                                    b: value,
                                    comparisonType: StringComparison.OrdinalIgnoreCase))
                    .Select(selector: entry => $"[{entry.Section}] sets {entry.Key} = {entry.Value}; every section "
                            + $"keeps {entry.Key} = {expected[entry.Key]}"),
        ];
    }

    /// <summary>Tells whether any section, or the preamble, sets a key.</summary>
    /// <param name="key">The key, matched case-insensitively.</param>
    /// <returns><see langword="true"/> when the key is set anywhere.</returns>
    internal bool Sets(string key)
    {
        return Settings.Any(predicate: entry => IsSame(left: entry.Key, right: key.ToLowerInvariant()));
    }

    private EditorConfigFile(IReadOnlyList<(string Section, string Key, string Value)> settings)
    {
        Settings = settings;
    }

    private static bool IsSame(string left, string right)
    {
        return string.Equals(a: left, b: right, comparisonType: StringComparison.Ordinal);
    }
}
