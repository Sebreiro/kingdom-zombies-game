using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using Mono.Cecil;
using Mono.Cecil.Cil;

namespace LangProject.Core.ArchitectureTests.Types;

/// <summary>
/// Lists the types that the compiler-generated code of a source type uses. A lambda, an <c>async</c> method or an
/// iterator is compiled into a nested generated type (a closure, a <c>&lt;&gt;c</c> lambda holder or a state
/// machine). ArchUnitNET does not load those types and does not credit every one of them to the source type (an
/// <c>async</c> state machine, in particular), so the purity rules also read their IL here, with Mono.Cecil.
/// </summary>
internal static class GeneratedCodeScanner
{
    /// <summary>
    /// Finds every type that the generated nested types of each subject use: their field types and base types, and
    /// the types of every local, type operand, member operand and signature in their method bodies.
    /// </summary>
    /// <param name="subjects">The source-declared types whose generated code is read.</param>
    /// <returns>One entry per use; the same used type can appear more than once.</returns>
    internal static IReadOnlyList<GeneratedDependency> FindDependencies(IEnumerable<Type> subjects)
    {
        return [.. subjects.SelectMany(selector: FindDependencies)];
    }

    private static readonly ConcurrentDictionary<string, ModuleDefinition> _modules =
            new(comparer: StringComparer.Ordinal);

    private static IEnumerable<GeneratedDependency> FindDependencies(Type subject)
    {
        ModuleDefinition module = _modules.GetOrAdd(
                key: subject.Assembly.Location,
                valueFactory: path => ModuleDefinition.ReadModule(
                        fileName: path,
                        parameters: new ReaderParameters { InMemory = true }));
        TypeDefinition? definition = module.GetType(fullName: subject.FullName?.Replace(oldChar: '+', newChar: '/'));
        if (definition is null)
        {
            return [];
        }

        string ownTopLevel = TopLevel(type: definition).FullName;
        return GeneratedNested(type: definition)
                .SelectMany(selector: generated => UsedTypes(type: generated)
                        .Where(predicate: used => !IsCompilerOnly(type: used))
                        .Where(predicate: used => !string.Equals(
                                a: TopLevel(type: used).FullName,
                                b: ownTopLevel,
                                comparisonType: StringComparison.Ordinal))
                        .Select(selector: used => new GeneratedDependency(
                                subject: subject,
                                generatedType: generated.Name,
                                usedNamespace: TopLevel(type: used).Namespace,
                                usedFullName: used.FullName.Replace(oldChar: '/', newChar: '+'))));
    }

    private static IEnumerable<TypeDefinition> GeneratedNested(TypeDefinition type)
    {
        return type.NestedTypes
                .Where(predicate: IsGenerated)
                .SelectMany(selector: nested => GeneratedNested(type: nested).Prepend(element: nested))
                .Concat(second: type.NestedTypes
                        .Where(predicate: nested => !IsGenerated(type: nested))
                        .SelectMany(selector: GeneratedNested));
    }

    private static IEnumerable<TypeReference> UsedTypes(TypeDefinition type)
    {
        IEnumerable<TypeReference> declared = type.Fields.Select(selector: field => field.FieldType)
                .Concat(second: type.Interfaces.Select(selector: implementation => implementation.InterfaceType))
                .Append(element: type.BaseType)
                .OfType<TypeReference>();
        IEnumerable<TypeReference> bodies = type.Methods
                .Where(predicate: method => method.HasBody)
                .SelectMany(selector: method => method.Body.Variables
                        .Select(selector: variable => variable.VariableType)
                        .Concat(second: method.Body.Instructions.SelectMany(selector: OperandTypes)));
        return declared.Concat(second: bodies).SelectMany(selector: Flatten);
    }

    private static IEnumerable<TypeReference> OperandTypes(Instruction instruction)
    {
        return instruction.Operand switch
        {
            TypeReference type => [type],
            MethodReference method => method.Parameters
                    .Select(selector: parameter => parameter.ParameterType)
                    .Prepend(element: method.ReturnType)
                    .Prepend(element: method.DeclaringType),
            FieldReference field => [field.DeclaringType, field.FieldType],
            _ => [],
        };
    }

    private static IEnumerable<TypeReference> Flatten(TypeReference type)
    {
        if (type is GenericInstanceType generic)
        {
            return Flatten(type: generic.ElementType)
                    .Concat(second: generic.GenericArguments.SelectMany(selector: Flatten));
        }

        if (type is TypeSpecification specification)
        {
            return Flatten(type: specification.ElementType);
        }

        return type is GenericParameter ? [] : [type];
    }

    private static TypeReference TopLevel(TypeReference type)
    {
        TypeReference current = type;
        while (current.DeclaringType is not null)
        {
            current = current.DeclaringType;
        }

        return current;
    }

    private static bool IsGenerated(TypeDefinition type)
    {
        return type.Name.StartsWith(value: '<')
                || type.CustomAttributes.Any(predicate: attribute => string.Equals(
                        a: attribute.AttributeType.FullName,
                        b: typeof(CompilerGeneratedAttribute).FullName,
                        comparisonType: StringComparison.Ordinal));
    }

    private static bool IsCompilerOnly(TypeReference type)
    {
        return TopLevel(type: type).Name.StartsWith(value: '<');
    }
}
