using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace LangProject.Core.ArchitectureTests.Infrastructure;

/// <summary>
/// Reads the project list from <c>LangProject.Core.slnx</c>. The solution file, never a csproj file glob, is the
/// source of the project set, so proof fixtures outside the solution are excluded by construction.
/// </summary>
internal static class SolutionFile
{
    /// <summary>Reads the <c>Path</c> of every <c>Project</c> element, under any <c>Folder</c>.</summary>
    /// <param name="solutionXml">The XML text of an <c>.slnx</c> file.</param>
    /// <returns>Solution-relative project paths with forward slashes, in ordinal order.</returns>
    internal static IReadOnlyList<string> ReadProjectPaths(string solutionXml)
    {
        XDocument document = XmlText.Parse(xml: solutionXml);
        return document.Descendants()
                .Where(predicate: element => string.Equals(
                        a: element.Name.LocalName,
                        b: "Project",
                        comparisonType: StringComparison.Ordinal))
                .Select(selector: ReadPath)
                .Order(comparer: StringComparer.Ordinal)
                .ToList();
    }

    /// <summary>Loads every project listed in the production solution file.</summary>
    /// <returns>The parsed projects, in ordinal path order.</returns>
    internal static IReadOnlyList<ProjectFile> LoadProjects()
    {
        string solutionXml = File.ReadAllText(path: RepositoryLayout.SolutionFilePath);
        return ReadProjectPaths(solutionXml: solutionXml)
                .Select(selector: LoadFromSolutionRoot)
                .ToList();
    }

    private static ProjectFile LoadFromSolutionRoot(string relativePath)
    {
        return ProjectFile.Load(solutionRoot: RepositoryLayout.SolutionRoot, relativePath: relativePath);
    }

    private static string ReadPath(XElement project)
    {
        string path = (string?)project.Attribute(name: "Path")
                ?? throw new InvalidOperationException(message: $"A solution Project element has no Path: {project}");
        return path.Replace(oldChar: '\\', newChar: '/');
    }
}
