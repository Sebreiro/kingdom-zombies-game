using System;
using System.Collections.Generic;
using LangProject.Core.API.Abstractions.Health;
using LangProject.Core.Application.Abstractions.Languages;
using LangProject.Core.ArchitectureTests.Types.Fixtures;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Types;

/// <summary>
/// Tests of the DTO rule (SPEC R6, D-37): a DTO is a class, not a record, with private non-<c>init</c> setters and
/// every public property set through its constructor; and of the D-37 naming rule. Each rule runs on production
/// and on bad-on-purpose fixtures.
/// </summary>
public sealed class DtoRuleTests
{
    /// <summary>
    /// Every production type whose name ends in Dto passes; the selector matches <see cref="LanguageDto"/>.
    /// </summary>
    [Fact]
    public void Dtos_Production_FollowDtoRules()
    {
        IReadOnlyList<Type> dtos = TypeConventionRules.SelectDtos(
                types: ProductionTypes.TypesOf(filter: static _ => true));

        dtos.ShouldContain(expected: typeof(LanguageDto));
        IReadOnlyList<string> violations = TypeConventionRules.CheckDtos(dtos: dtos);
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>The valid fixture passes, so the rule does not over-report.</summary>
    [Fact]
    public void Dtos_ValidFixture_IsAccepted()
    {
        IReadOnlyList<string> violations = TypeConventionRules.CheckDtos(dtos: [typeof(DtoFixtures.ValidDto)]);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>A <c>record class</c> DTO is reported.</summary>
    [Fact]
    public void Dtos_RecordClass_IsReported()
    {
        string violation = SingleViolation(dto: typeof(DtoFixtures.RecordClassDto));

        violation.ShouldContain(expected: nameof(DtoFixtures.RecordClassDto));
        violation.ShouldContain(expected: "record class");
    }

    /// <summary>A <c>record struct</c> DTO is reported.</summary>
    [Fact]
    public void Dtos_RecordStruct_IsReported()
    {
        string violation = SingleViolation(dto: typeof(DtoFixtures.RecordStructDto));

        violation.ShouldContain(expected: nameof(DtoFixtures.RecordStructDto));
        violation.ShouldContain(expected: "record struct");
    }

    /// <summary>A public setter on a DTO is reported.</summary>
    [Fact]
    public void Dtos_PublicSetter_IsReported()
    {
        string violation = SingleViolation(dto: typeof(DtoFixtures.PublicSetterDto));

        violation.ShouldContain(expected: nameof(DtoFixtures.PublicSetterDto));
        violation.ShouldContain(expected: "public setter");
    }

    /// <summary>An <c>init</c> setter on a DTO is reported.</summary>
    [Fact]
    public void Dtos_InitSetter_IsReported()
    {
        string violation = SingleViolation(dto: typeof(DtoFixtures.InitSetterDto));

        violation.ShouldContain(expected: nameof(DtoFixtures.InitSetterDto));
        violation.ShouldContain(expected: "init setter");
    }

    /// <summary>A public property without a matching constructor parameter is reported.</summary>
    [Fact]
    public void Dtos_PropertyNotSetByConstructor_IsReported()
    {
        string violation = SingleViolation(dto: typeof(DtoFixtures.PropertyNotSetByConstructorDto));

        violation.ShouldContain(expected: nameof(DtoFixtures.PropertyNotSetByConstructorDto));
        violation.ShouldContain(expected: "Name");
        violation.ShouldContain(expected: "constructor parameter");
    }

    /// <summary>
    /// <c>SampleRequest</c> and <c>SampleResponse</c> are reported; <c>SampleResponseDto</c> is not (D-37).
    /// </summary>
    [Fact]
    public void Naming_PlainRequestOrResponseSuffix_IsReported()
    {
        IReadOnlyList<string> violations = TypeConventionRules.CheckNaming(
                types:
                [
                    typeof(DtoFixtures.SampleRequest),
                    typeof(DtoFixtures.SampleResponse),
                    typeof(DtoFixtures.SampleResponseDto),
                ]);

        violations.Count.ShouldBe(expected: 2, customMessage: string.Join(separator: "\n", values: violations));
        violations.ShouldContain(elementPredicate: violation => violation.Contains(
                value: nameof(DtoFixtures.SampleRequest) + " ",
                comparisonType: StringComparison.Ordinal));
        violations.ShouldContain(elementPredicate: violation => violation.Contains(
                value: nameof(DtoFixtures.SampleResponse) + " ",
                comparisonType: StringComparison.Ordinal));
        violations.ShouldNotContain(elementPredicate: violation => violation.Contains(
                value: nameof(DtoFixtures.SampleResponseDto),
                comparisonType: StringComparison.Ordinal));
    }

    /// <summary>No production <c>LangProject.*</c> type ends in plain Request or Response.</summary>
    [Fact]
    public void Naming_Production_HasNoPlainRequestOrResponseSuffix()
    {
        IReadOnlyList<Type> productTypes = ProductionTypes.TypesOf(
                filter: static name => name.StartsWith(
                        value: "LangProject.",
                        comparisonType: StringComparison.Ordinal));

        productTypes.ShouldContain(expected: typeof(LanguageDto));
        IReadOnlyList<string> violations = TypeConventionRules.CheckNaming(types: productTypes);
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// An HTTP DTO that ends in plain Dto, <c>FooEntryDto</c>, is reported; <c>FooEntryResponseDto</c> and
    /// <c>FooRequestDto</c> are not (D-37).
    /// </summary>
    [Fact]
    public void HttpDtoNames_PlainDtoSuffix_IsReported()
    {
        IReadOnlyList<string> violations = TypeConventionRules.CheckHttpDtoNames(
                httpContractTypes:
                [
                    typeof(DtoFixtures.FooEntryDto),
                    typeof(DtoFixtures.FooEntryResponseDto),
                    typeof(DtoFixtures.FooRequestDto),
                ]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: nameof(DtoFixtures.FooEntryDto) + " ");
    }

    /// <summary>HTTP DTOs that end in RequestDto or ResponseDto pass.</summary>
    [Fact]
    public void HttpDtoNames_RequestOrResponseDtoSuffix_IsAccepted()
    {
        IReadOnlyList<string> violations = TypeConventionRules.CheckHttpDtoNames(
                httpContractTypes: [typeof(DtoFixtures.FooEntryResponseDto), typeof(DtoFixtures.FooRequestDto)]);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>A type list with no DTO fails, so the rule never passes vacuously.</summary>
    [Fact]
    public void HttpDtoNames_EmptySelector_Fails()
    {
        TypeConventionRules.CheckHttpDtoNames(httpContractTypes: [typeof(DtoFixtures.SampleRequest)])
                .ShouldBe(expected: [TypeConventionRules.EmptySelector]);
    }

    /// <summary>
    /// Every DTO in the HTTP contract project, API.Abstractions, ends in RequestDto or ResponseDto; the selector
    /// matches <see cref="HealthResponseDto"/>.
    /// </summary>
    [Fact]
    public void HttpDtoNames_Production_EndInRequestDtoOrResponseDto()
    {
        IReadOnlyList<Type> httpContractTypes = ProductionTypes.TypesOf(assembly: ProductionTypes.ApiAbstractions);

        httpContractTypes.ShouldContain(expected: typeof(HealthResponseDto));
        IReadOnlyList<string> violations = TypeConventionRules.CheckHttpDtoNames(httpContractTypes: httpContractTypes);
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    private static string SingleViolation(Type dto)
    {
        return TypeConventionRules.CheckDtos(dtos: [dto]).ShouldHaveSingleItem();
    }
}
