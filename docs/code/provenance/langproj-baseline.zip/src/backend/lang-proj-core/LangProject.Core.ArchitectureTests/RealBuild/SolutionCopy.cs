using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using LangProject.Core.ArchitectureTests.Infrastructure;

namespace LangProject.Core.ArchitectureTests.RealBuild;

/// <summary>
/// A throwaway copy of the backend solution, made for one proof and deleted on dispose. It holds the files git
/// tracks under <c>src/backend/lang-proj-core/</c>, as they are in the working tree, plus the repository-root
/// <c>global.json</c> and <c>.editorconfig</c>, in the same relative layout. The real props, targets, central
/// versions, <c>.editorconfig</c> files, banned-symbol lists, lock files and tool manifest therefore apply, an
/// untracked or ignored file never does, and a proof can change the copy without touching the working tree.
/// </summary>
/// <remarks>
/// The copy sits in its own folder under <see cref="ProofRoot"/>, which is private to the user. Its root also holds
/// two guard files, so nothing above the copy changes its builds: an empty <c>Directory.Build.rsp</c>, which ends
/// MSBuild's search for a response file, and a <c>NuGet.Config</c> that clears every package source from the
/// configuration files above and from the user's own and adds only nuget.org.
/// </remarks>
internal sealed class SolutionCopy : IDisposable
{
    /// <summary>Deletes the copy.</summary>
    public void Dispose()
    {
        if (Directory.Exists(path: CopyRoot))
        {
            Directory.Delete(path: CopyRoot, recursive: true);
        }
    }

    /// <summary>Gets the copy's root, the counterpart of the repository root.</summary>
    internal string CopyRoot { get; }

    /// <summary>Gets the copy's solution root, the counterpart of <c>src/backend/lang-proj-core</c>.</summary>
    internal string SolutionRoot { get; }

    /// <summary>Lists the files git tracks and copies the solution into a new private folder.</summary>
    /// <param name="cancellationToken">Stops the listing when the test run is cancelled.</param>
    /// <returns>The new copy.</returns>
    internal static async Task<SolutionCopy> CreateAsync(CancellationToken cancellationToken)
    {
        IReadOnlyList<string> trackedFiles = await TrackedFiles.ListAsync(cancellationToken: cancellationToken);
        return new SolutionCopy(trackedFiles: trackedFiles);
    }

    /// <summary>
    /// Selects the repository-relative paths a copy holds: every tracked file under
    /// <c>src/backend/lang-proj-core/</c>, and the repository-root <c>global.json</c> and <c>.editorconfig</c>.
    /// </summary>
    /// <param name="trackedFiles">The files git tracks, with forward slashes.</param>
    /// <returns>The selected paths, in the order given.</returns>
    internal static IReadOnlyList<string> CopiedFiles(IReadOnlyList<string> trackedFiles)
    {
        return
        [
            .. trackedFiles.Where(predicate: path => path.StartsWith(
                    value: SolutionFolder,
                    comparisonType: StringComparison.Ordinal)
                    || _repositoryRootFiles.Contains(value: path, comparer: StringComparer.Ordinal)),
        ];
    }

    /// <summary>Writes a file in the copy as UTF-8 without a BOM, creating its folder when needed.</summary>
    /// <param name="relativePath">The path relative to <see cref="SolutionRoot"/>, with forward slashes.</param>
    /// <param name="content">The file content.</param>
    internal void WriteFile(string relativePath, string content)
    {
        string path = FullPathOf(relativePath: relativePath);
        string folder = Path.GetDirectoryName(path: path)
                ?? throw new InvalidOperationException(message: $"{path} has no folder.");
        Directory.CreateDirectory(path: folder);
        File.WriteAllText(path: path, contents: content, encoding: _utf8WithoutBom);
    }

    /// <summary>Reads a file of the copy.</summary>
    /// <param name="relativePath">The path relative to <see cref="SolutionRoot"/>, with forward slashes.</param>
    /// <returns>The file content.</returns>
    internal string ReadFile(string relativePath)
    {
        return File.ReadAllText(path: FullPathOf(relativePath: relativePath));
    }

    /// <summary>Replaces every occurrence of a text in a file of the copy.</summary>
    /// <param name="relativePath">The path relative to <see cref="SolutionRoot"/>, with forward slashes.</param>
    /// <param name="oldValue">The text to replace; it must occur in the file.</param>
    /// <param name="newValue">The replacement.</param>
    /// <exception cref="InvalidOperationException">The file does not contain <paramref name="oldValue"/>.</exception>
    internal void ReplaceInFile(string relativePath, string oldValue, string newValue)
    {
        string text = ReadFile(relativePath: relativePath);
        if (!text.Contains(value: oldValue, comparisonType: StringComparison.Ordinal))
        {
            throw new InvalidOperationException(message: $"{relativePath} does not contain '{oldValue}'.");
        }

        string replaced = text.Replace(
                oldValue: oldValue,
                newValue: newValue,
                comparisonType: StringComparison.Ordinal);
        WriteFile(relativePath: relativePath, content: replaced);
    }

    /// <summary>
    /// Makes a NuGet vulnerability feed the copy's only audit source, so restore audits against it alone and never
    /// against the package sources.
    /// </summary>
    /// <param name="serviceIndex">The feed's service index.</param>
    internal void UseAuditSource(Uri serviceIndex)
    {
        string auditSources = AuditSources.Replace(
                oldValue: "{source}",
                newValue: serviceIndex.AbsoluteUri,
                comparisonType: StringComparison.Ordinal);
        string config = GuardNuGetConfig.Replace(
                oldValue: "</configuration>\n",
                newValue: auditSources + "\n",
                comparisonType: StringComparison.Ordinal);
        WriteRootFile(name: NuGetConfigFile, content: config);
    }

    /// <summary>Adds a central <c>PackageVersion</c> to the copy's <c>Directory.Packages.props</c>.</summary>
    /// <param name="packageId">The package ID.</param>
    /// <param name="version">The version.</param>
    internal void AddPackageVersion(string packageId, string version)
    {
        XDocument document = XmlText.Parse(xml: ReadFile(relativePath: PackagesPropsFile));
        XElement root = document.Root
                ?? throw new InvalidOperationException(message: $"{PackagesPropsFile} has no root element.");
        root.Add(content: new XElement(
                name: "ItemGroup",
                content: new XElement(
                        name: "PackageVersion",
                        new XAttribute(name: "Include", value: packageId),
                        new XAttribute(name: "Version", value: version))));
        WriteFile(relativePath: PackagesPropsFile, content: document.ToString() + "\n");
    }

    private const string PackagesPropsFile = "Directory.Packages.props";
    private const string SolutionFolder = "src/backend/lang-proj-core/";
    private const string NuGetConfigFile = "NuGet.Config";
    private const string GuardResponseFile = "# Ends MSBuild's search for Directory.Build.rsp above the copy.\n";
    private const string GuardNuGetConfig = """
            <?xml version="1.0" encoding="utf-8"?>
            <configuration>
              <packageSources>
                <clear />
                <add key="nuget.org" value="https://api.nuget.org/v3/index.json" protocolVersion="3" />
              </packageSources>
            </configuration>

            """;
    private const string AuditSources = """
              <auditSources>
                <clear />
                <add key="proof-advisories" value="{source}" allowInsecureConnections="true" />
              </auditSources>
            </configuration>
            """;

    private static readonly string[] _repositoryRootFiles = ["global.json", ".editorconfig"];
    private static readonly UTF8Encoding _utf8WithoutBom = new(encoderShouldEmitUTF8Identifier: false);

    private SolutionCopy(IReadOnlyList<string> trackedFiles)
    {
        CopyRoot = ProofRoot.CreateCopyFolder();
        SolutionRoot = Path.Combine(path1: CopyRoot, path2: "src", path3: "backend", path4: "lang-proj-core");
        try
        {
            foreach (string relativePath in CopiedFiles(trackedFiles: trackedFiles))
            {
                CopyTrackedFile(relativePath: relativePath);
            }

            WriteRootFile(name: "Directory.Build.rsp", content: GuardResponseFile);
            WriteRootFile(name: NuGetConfigFile, content: GuardNuGetConfig);
        }
        catch
        {
            Dispose();
            throw;
        }
    }

    private void CopyTrackedFile(string relativePath)
    {
        string source = Path.Combine(
                path1: RepositoryLayout.RepositoryRoot,
                path2: relativePath.Replace(oldChar: '/', newChar: Path.DirectorySeparatorChar));
        if (!File.Exists(path: source))
        {
            return;
        }

        string target = Path.Combine(
                path1: CopyRoot,
                path2: relativePath.Replace(oldChar: '/', newChar: Path.DirectorySeparatorChar));
        string folder = Path.GetDirectoryName(path: target)
                ?? throw new InvalidOperationException(message: $"{target} has no folder.");
        Directory.CreateDirectory(path: folder);
        File.Copy(sourceFileName: source, destFileName: target);
    }

    private void WriteRootFile(string name, string content)
    {
        File.WriteAllText(
                path: Path.Combine(path1: CopyRoot, path2: name),
                contents: content,
                encoding: _utf8WithoutBom);
    }

    private string FullPathOf(string relativePath)
    {
        return Path.Combine(
                path1: SolutionRoot,
                path2: relativePath.Replace(oldChar: '/', newChar: Path.DirectorySeparatorChar));
    }
}
