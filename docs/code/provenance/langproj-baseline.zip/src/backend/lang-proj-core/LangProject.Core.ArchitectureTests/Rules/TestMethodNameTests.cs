using System.Collections.Generic;
using System.Linq;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// Test methods in the three test projects follow <c>Method_State_Expected</c> (D-33): exactly three parts.
/// </summary>
public sealed class TestMethodNameTests
{
    /// <summary>
    /// Every <c>[Fact]</c> and <c>[Theory]</c> method in the three test projects follows the naming rule.
    /// </summary>
    [Fact]
    public void TestMethods_InEveryTestProject_FollowMethodStateExpected()
    {
        IReadOnlyList<string> testMethods = TestSourceIndex.ProductionTestMethods();

        List<string> violations =
        [
            .. testMethods.Where(predicate: name => !TestSourceIndex.FollowsMethodStateExpected(
                    methodName: name[(name.LastIndexOf(value: '.') + 1)..])),
        ];

        testMethods.Count.ShouldBeGreaterThan(expected: 100);
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>Three upper-case parts joined by underscores pass; any other shape is reported.</summary>
    /// <param name="methodName">The method name.</param>
    /// <param name="expected">Whether the name follows the rule.</param>
    [Theory]
    [InlineData("GetAll_SeededDatabase_ReturnsThreeLanguages", true)]
    [InlineData("GeneratedCode_IsSkipped", false)]
    [InlineData("Line_120Characters_Passes", true)]
    [InlineData("GetAll", false)]
    [InlineData("getAll_Seeded_Returns", false)]
    [InlineData("GetAll_seeded_Returns", false)]
    [InlineData("Get_All_Seeded_Returns", false)]
    [InlineData("GetAll__Returns", false)]
    public void TestMethodName_Shape_IsChecked(string methodName, bool expected)
    {
        TestSourceIndex.FollowsMethodStateExpected(methodName: methodName).ShouldBe(expected: expected);
    }

    /// <summary>
    /// The index finds <c>[Fact]</c> and <c>[Theory]</c> methods, async or not and with further attributes,
    /// qualified with the file's namespace and class; other methods are not test methods.
    /// </summary>
    [Fact]
    public void TestMethods_SampleSource_FindsFactAndTheoryMethods()
    {
        const string Source = """
                using Xunit;

                namespace Sample.Tests;

                /// <summary>Sample.</summary>
                public sealed class SampleTests
                {
                    /// <summary>A fact.</summary>
                    [Fact]
                    public void First_Case_Passes()
                    {
                    }

                    /// <summary>A theory.</summary>
                    [Theory]
                    [InlineData(1)]
                    public async Task Second_Case_Passes(int value)
                    {
                        await Task.Yield();
                    }

                    private static void Helper()
                    {
                    }
                }

                """;

        TestSourceIndex.TestMethods(content: Source).ShouldBe(
                expected:
                [
                    "Sample.Tests.SampleTests.First_Case_Passes",
                    "Sample.Tests.SampleTests.Second_Case_Passes",
                ]);
    }

    /// <summary>
    /// The index also finds a wrapped attribute, a qualified or suffixed attribute name, a custom attribute whose
    /// name ends in <c>Fact</c> or <c>Theory</c>, a static method, a generic method and a method of a nested class,
    /// and does not read a test inside a string literal.
    /// </summary>
    [Fact]
    public void TestMethods_UnusualDeclarations_AreIndexed()
    {
        const string Source = """
                namespace Sample.Tests;

                internal sealed class Helper
                {
                }

                public sealed class OddTests
                {
                    [Theory(
                            DisplayName = "wrapped")]
                    public void Wrapped() { }

                    [Xunit.Fact]
                    public void Qualified() { }

                    [FactAttribute]
                    public void Suffixed() { }

                    [RetryFact]
                    public void Custom() { }

                    [Fact]
                    public static void Static() { }

                    [Fact]
                    public void Generic<T>() { }

                    private const string Sample = "[Fact] public void InString() { }";

                    public sealed class Nested
                    {
                        [Trait("a", "b"), Fact]
                        internal Task Inner() => Task.CompletedTask;
                    }
                }

                """;

        TestSourceIndex.TestMethods(content: Source).ShouldBe(
                expected:
                [
                    "Sample.Tests.OddTests.Wrapped",
                    "Sample.Tests.OddTests.Qualified",
                    "Sample.Tests.OddTests.Suffixed",
                    "Sample.Tests.OddTests.Custom",
                    "Sample.Tests.OddTests.Static",
                    "Sample.Tests.OddTests.Generic",
                    "Sample.Tests.OddTests.Nested.Inner",
                ]);
    }
}
