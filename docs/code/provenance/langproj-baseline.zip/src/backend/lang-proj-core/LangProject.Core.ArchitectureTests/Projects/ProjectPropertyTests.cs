using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Projects;

/// <summary>
/// Tests of csproj and props properties: transitive project references stay disabled and every project imports the
/// solution-root build files (SPEC R6), the version is set only once (D-22), CompositionRoot is the only non-test
/// executable (SPEC R2, RD-10), and no mapping library is referenced (D-43). The transitive, import and executable
/// rules read what MSBuild evaluates, so SDK defaults and imported files count.
/// </summary>
public sealed class ProjectPropertyTests
{
    /// <summary>
    /// No csproj, props or targets file on disk sets <c>DisableTransitiveProjectReferences</c>,
    /// <c>ImportDirectoryBuildProps</c> or <c>ImportDirectoryBuildTargets</c> to anything but true, and the solution's
    /// <c>Directory.Build.props</c> sets transitive references off.
    /// </summary>
    [Fact]
    public void TransitiveReferences_NeverDisabledFalse_InAnyBuildFile()
    {
        IReadOnlyList<ProjectFile> buildFiles = ProjectFile.LoadBuildFiles();

        buildFiles.ShouldNotBeEmpty();
        IReadOnlyList<string> violations =
                ProjectGraphRules.CheckTransitiveReferencesNotDisabled(buildFiles: buildFiles);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
        SolutionProps().GetProperty(name: "DisableTransitiveProjectReferences").ShouldBe(expected: "true");
    }

    /// <summary>
    /// A synthetic build file that sets <c>DisableTransitiveProjectReferences</c> to any value but true, or switches
    /// off a <c>Directory.Build.*</c> import, is reported: MSBuild turns transitive references back on for every
    /// value other than true.
    /// </summary>
    /// <param name="name">The property.</param>
    /// <param name="value">The value, which is not true.</param>
    [Theory]
    [InlineData("DisableTransitiveProjectReferences", "false")]
    [InlineData("DisableTransitiveProjectReferences", "False")]
    [InlineData("DisableTransitiveProjectReferences", " false ")]
    [InlineData("DisableTransitiveProjectReferences", "")]
    [InlineData("DisableTransitiveProjectReferences", "0")]
    [InlineData("DisableTransitiveProjectReferences", "no")]
    [InlineData("DisableTransitiveProjectReferences", "$(Unset)")]
    [InlineData("ImportDirectoryBuildProps", "false")]
    [InlineData("ImportDirectoryBuildTargets", "false")]
    public void TransitiveReferences_SyntheticNotTrue_IsReported(string name, string value)
    {
        ProjectFile bad = WithProperty(name: name, value: value);

        IReadOnlyList<string> violations = ProjectGraphRules.CheckTransitiveReferencesNotDisabled(buildFiles: [bad]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: BadProjectPath);
    }

    /// <summary>Every evaluated project ends up with <c>DisableTransitiveProjectReferences</c> set to true.</summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task TransitiveReferences_EveryProject_EvaluatesTrue()
    {
        IReadOnlyList<EvaluatedProject> projects = await ProjectEvaluator.LoadWorkingTreeAsync();

        projects.ShouldNotBeEmpty();
        IReadOnlyList<string> violations = ProjectGraphRules.CheckTransitiveReferencesDisabled(projects: projects);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>An evaluated value other than true, such as empty or <c>0</c>, is reported.</summary>
    /// <param name="value">The evaluated value.</param>
    [Theory]
    [InlineData("")]
    [InlineData("0")]
    [InlineData("false")]
    public void TransitiveReferences_EvaluatedNotTrue_IsReported(string value)
    {
        EvaluatedProject bad = WithEvaluated(name: ProjectEvaluator.TransitiveProperty, value: value);

        ProjectGraphRules.CheckTransitiveReferencesDisabled(projects: [bad])
                .ShouldHaveSingleItem()
                .ShouldContain(expected: AllowedEdges.Domain);
    }

    /// <summary>
    /// Every evaluated project imports the solution-root <c>Directory.Build.props</c> and
    /// <c>Directory.Build.targets</c>, and no nearer one.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task BuildImports_EveryProject_UsesSolutionRootFiles()
    {
        IReadOnlyList<EvaluatedProject> projects = await ProjectEvaluator.LoadWorkingTreeAsync();

        projects.ShouldNotBeEmpty();
        IReadOnlyList<string> violations = ProjectGraphRules.CheckBuildImports(projects: projects);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>A nearer <c>Directory.Build.props</c> or a switched-off import is reported.</summary>
    /// <param name="name">The evaluated property.</param>
    /// <param name="value">Its bad value.</param>
    [Theory]
    [InlineData("DirectoryBuildPropsPath", "LangProject.Core.Domain/Directory.Build.props")]
    [InlineData("DirectoryBuildTargetsPath", "LangProject.Core.Domain/Directory.Build.targets")]
    [InlineData("ImportDirectoryBuildProps", "false")]
    [InlineData("ImportDirectoryBuildTargets", "")]
    public void BuildImports_NearerFileOrSwitchedOff_IsReported(string name, string value)
    {
        EvaluatedProject bad = WithEvaluated(name: name, value: value);

        ProjectGraphRules.CheckBuildImports(projects: [bad])
                .ShouldHaveSingleItem()
                .ShouldContain(expected: name);
    }

    /// <summary>
    /// No build file other than <c>src/backend/lang-proj-core/Directory.Build.props</c> sets a version property,
    /// and that file sets <c>VersionPrefix</c>.
    /// </summary>
    [Fact]
    public void VersionProperties_InAnyBuildFile_AreOnlyInSolutionProps()
    {
        IReadOnlyList<ProjectFile> buildFiles = ProjectFile.LoadBuildFiles();

        buildFiles.ShouldNotBeEmpty();
        IReadOnlyList<string> violations = ProjectGraphRules.CheckVersionProperties(
                buildFiles: buildFiles,
                allowedRelativePath: SolutionPropsPath());

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
        SolutionProps().GetProperty(name: "VersionPrefix").ShouldNotBeNullOrWhiteSpace();
    }

    /// <summary>A synthetic csproj setting any version property is reported; the solution props may set it.</summary>
    /// <param name="propertyName">The version property, in different casings.</param>
    [Theory]
    [InlineData("Version")]
    [InlineData("VersionPrefix")]
    [InlineData("VersionSuffix")]
    [InlineData("AssemblyVersion")]
    [InlineData("FileVersion")]
    [InlineData("version")]
    public void VersionProperties_SyntheticVersion_IsReported(string propertyName)
    {
        ProjectFile bad = WithProperty(name: propertyName, value: "1.2.3");
        var allowed = ProjectFile.Parse(
                relativePath: SolutionPropsPath(),
                xml: $"<Project><PropertyGroup><{propertyName}>1.2.3</{propertyName}></PropertyGroup></Project>");

        IReadOnlyList<string> violations = ProjectGraphRules.CheckVersionProperties(
                buildFiles: [bad, allowed],
                allowedRelativePath: SolutionPropsPath());

        violations.ShouldHaveSingleItem().ShouldContain(expected: BadProjectPath);
    }

    /// <summary>
    /// Every evaluated project builds an assembly named after the project, so the type rules can load each one by
    /// its project name.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task AssemblyNames_EveryProject_MatchProjectName()
    {
        IReadOnlyList<EvaluatedProject> projects = await ProjectEvaluator.LoadWorkingTreeAsync();

        projects.ShouldNotBeEmpty();
        IReadOnlyList<string> violations = ProjectGraphRules.CheckAssemblyNames(projects: projects);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>A project whose assembly has another name is reported.</summary>
    [Fact]
    public void AssemblyNames_RenamedAssembly_IsReported()
    {
        EvaluatedProject bad = WithEvaluated(name: ProjectEvaluator.AssemblyNameProperty, value: "Contoso.Domain");

        ProjectGraphRules.CheckAssemblyNames(projects: [bad])
                .ShouldHaveSingleItem()
                .ShouldContain(expected: "Contoso.Domain");
    }

    /// <summary>
    /// Among the evaluated executables, CompositionRoot is the only non-test project; the others are the xUnit v3 test
    /// projects.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task Executables_NonTestProjects_AreOnlyCompositionRoot()
    {
        IReadOnlyList<EvaluatedProject> projects = await ProjectEvaluator.LoadWorkingTreeAsync();

        IReadOnlyList<EvaluatedProject> executables = ProjectGraphRules.SelectExecutables(projects: projects);
        IReadOnlyList<string> violations = ProjectGraphRules.CheckExecutables(projects: projects);

        executables.Select(selector: project => project.Name)
                .Contains(value: AllowedEdges.CompositionRoot, comparer: StringComparer.Ordinal)
                .ShouldBeTrue();
        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>
    /// A non-test project that evaluates to an executable output is reported, whatever casing MSBuild returns, and
    /// so is a test-named project that is not a test project.
    /// </summary>
    /// <param name="projectName">The project name.</param>
    /// <param name="outputType">The evaluated <c>OutputType</c>.</param>
    [Theory]
    [InlineData("LangProject.Core.Domain", "Exe")]
    [InlineData("LangProject.Core.Domain", "WinExe")]
    [InlineData("LangProject.Core.Domain", "exe")]
    [InlineData("LangProject.Core.ArchitectureTests", "Exe")]
    public void Executables_SyntheticNonTestExe_IsReported(string projectName, string outputType)
    {
        EvaluatedProject bad = SyntheticProjects.Build(
                relativePath: SyntheticProjects.PathOf(projectName: projectName),
                references: [],
                properties: new Dictionary<string, string>(comparer: StringComparer.Ordinal)
                {
                    [ProjectEvaluator.OutputTypeProperty] = outputType,
                });

        IReadOnlyList<string> violations = ProjectGraphRules.CheckExecutables(projects: [bad]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: projectName);
    }

    /// <summary>No csproj, props or central package file references AutoMapper, Mapster or Mapperly.</summary>
    [Fact]
    public void MappingLibraries_InAnyBuildFile_AreNotReferenced()
    {
        IReadOnlyList<ProjectFile> buildFiles = ProjectFile.LoadBuildFiles();

        buildFiles.ShouldContain(elementPredicate: file => file.PackageIds.Count > 0);
        IReadOnlyList<string> violations = ProjectGraphRules.CheckMappingLibraries(buildFiles: buildFiles);

        violations.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: violations));
    }

    /// <summary>A synthetic reference to a mapping library, through any package item, is reported.</summary>
    /// <param name="itemName">The package item kind.</param>
    /// <param name="packageId">The mapping library's package ID.</param>
    [Theory]
    [InlineData("PackageReference", "AutoMapper")]
    [InlineData("PackageReference", "AutoMapper.Extensions.Microsoft.DependencyInjection")]
    [InlineData("PackageVersion", "Mapster")]
    [InlineData("PackageReference", "mapster.dependencyinjection")]
    [InlineData("GlobalPackageReference", "Riok.Mapperly")]
    public void MappingLibraries_SyntheticReference_IsReported(string itemName, string packageId)
    {
        var bad = ProjectFile.Parse(relativePath: BadProjectPath, xml: $"""
                <Project>
                  <ItemGroup>
                    <{itemName} Include="{packageId}" />
                    <PackageReference Include="Shouldly" />
                  </ItemGroup>
                </Project>
                """);

        IReadOnlyList<string> violations = ProjectGraphRules.CheckMappingLibraries(buildFiles: [bad]);

        violations.ShouldHaveSingleItem().ShouldContain(expected: packageId);
    }

    private const string BadProjectPath = "LangProject.Core.Bad/LangProject.Core.Bad.csproj";

    private static ProjectFile WithProperty(string name, string value)
    {
        return ProjectFile.Parse(relativePath: BadProjectPath, xml: $"""
                <Project Sdk="Microsoft.NET.Sdk">
                  <PropertyGroup>
                    <{name}>{value}</{name}>
                  </PropertyGroup>
                </Project>
                """);
    }

    private static EvaluatedProject WithEvaluated(string name, string value)
    {
        return SyntheticProjects.Build(
                relativePath: SyntheticProjects.PathOf(projectName: AllowedEdges.Domain),
                references: [],
                properties: new Dictionary<string, string>(comparer: StringComparer.Ordinal) { [name] = value });
    }

    private static string SolutionPropsPath()
    {
        return RepositoryLayout.ToSolutionRelative(fullPath: RepositoryLayout.DirectoryBuildProps);
    }

    private static ProjectFile SolutionProps()
    {
        return ProjectFile.Load(solutionRoot: RepositoryLayout.SolutionRoot, relativePath: SolutionPropsPath());
    }
}
