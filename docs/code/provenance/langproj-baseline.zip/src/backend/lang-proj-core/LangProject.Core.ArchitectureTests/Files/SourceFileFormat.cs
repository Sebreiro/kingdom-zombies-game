using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace LangProject.Core.ArchitectureTests.Files;

/// <summary>
/// The D-84 text-format rules for one tracked file: valid UTF-8 without a BOM, LF line endings only, a final newline,
/// no tab character and no trailing whitespace. A pure function of the path and the bytes, so proofs can feed
/// synthetic content.
/// </summary>
/// <remarks>
/// Two scoped exemptions, each with a rule-matrix row: files under <see cref="MigrationsFolder"/> may start with a
/// UTF-8 BOM, because <c>dotnet ef</c> writes one (SPEC R8, generated code); files named
/// <see cref="LockFileName"/> may lack the final newline, because NuGet writes them without one. Every other rule
/// still applies to both.
/// </remarks>
internal static class SourceFileFormat
{
    /// <summary>The folder whose files may start with a UTF-8 BOM, relative to the repository root.</summary>
    internal const string MigrationsFolder = "src/backend/lang-proj-core/LangProject.Core.DAL/Migrations/";

    /// <summary>The NuGet lock-file name; such files may lack the final newline.</summary>
    internal const string LockFileName = "packages.lock.json";

    /// <summary>How many leading bytes <see cref="IsText"/> looks at for a NUL byte, as git does.</summary>
    internal const int TextProbeLength = 8000;

    /// <summary>
    /// Tells whether the scan reads a tracked path: any path outside the agent folder <c>.claude/</c> and the
    /// planning folder <c>.planning/</c> whose extension is not on the binary deny-list. Text is then told from
    /// binary by content (<see cref="IsText"/>), so a new text file type is checked without any edit here.
    /// </summary>
    /// <param name="relativePath">The repository-relative path, with forward slashes.</param>
    /// <returns><see langword="true"/> when the scan reads the file.</returns>
    internal static bool IsChecked(string relativePath)
    {
        if (_skippedFolders.Any(predicate: folder => relativePath.StartsWith(
                value: folder,
                comparisonType: StringComparison.Ordinal)))
        {
            return false;
        }

        string extension = Path.GetExtension(path: relativePath);
        return !_binaryExtensions.Contains(value: extension, comparer: StringComparer.OrdinalIgnoreCase);
    }

    /// <summary>
    /// Tells text from binary content the way git does: a file with a NUL byte in its first 8000 bytes is binary.
    /// </summary>
    /// <param name="content">The file's bytes.</param>
    /// <returns><see langword="true"/> for text.</returns>
    internal static bool IsText(byte[] content)
    {
        int length = Math.Min(val1: content.Length, val2: TextProbeLength);
        ReadOnlySpan<byte> head = content.AsSpan(start: 0, length: length);
        return !head.Contains(value: (byte)0);
    }

    /// <summary>
    /// Checks one tracked path. A selected path with no regular file in the working tree is a violation, so a
    /// deleted file, a submodule entry or a mangled path can never be skipped without a message.
    /// </summary>
    /// <param name="relativePath">The repository-relative path, with forward slashes.</param>
    /// <param name="content">The file's bytes, or <see langword="null"/> when no regular file exists there.</param>
    /// <returns>
    /// One message per broken rule; empty when the path is not selected, the content is binary or the file is clean.
    /// </returns>
    internal static IReadOnlyList<string> CheckTracked(string relativePath, byte[]? content)
    {
        if (!IsChecked(relativePath: relativePath))
        {
            return [];
        }

        if (content is null)
        {
            return [$"{relativePath}: is tracked but is not a regular file in the working tree"];
        }

        return IsText(content: content) ? Check(relativePath: relativePath, content: content) : [];
    }

    /// <summary>Checks the bytes of one file against every format rule.</summary>
    /// <param name="relativePath">The repository-relative path, with forward slashes.</param>
    /// <param name="content">The file's bytes.</param>
    /// <returns>
    /// One message per broken rule, each starting with the path; empty when the file follows every rule.
    /// </returns>
    internal static IReadOnlyList<string> Check(string relativePath, byte[] content)
    {
        var violations = new List<string>();
        ReadOnlySpan<byte> bytes = content;
        if (bytes.StartsWith(value: _bom))
        {
            if (!relativePath.StartsWith(value: MigrationsFolder, comparisonType: StringComparison.Ordinal))
            {
                violations.Add(item: $"{relativePath}: starts with a UTF-8 BOM");
            }

            bytes = bytes[_bom.Length..];
        }

        if (!IsValidUtf8(bytes: bytes))
        {
            violations.Add(item: $"{relativePath}: is not valid UTF-8");
        }

        if (bytes.Contains(value: (byte)'\r'))
        {
            violations.Add(item: $"{relativePath}: contains a CR character (CRLF or CR line ending)");
        }

        if (bytes.Contains(value: (byte)'\t'))
        {
            violations.Add(item: $"{relativePath}: contains a tab character");
        }

        if (HasTrailingWhitespace(bytes: bytes))
        {
            violations.Add(item: $"{relativePath}: has a line that ends with whitespace");
        }

        if (!bytes.IsEmpty && bytes[^1] != (byte)'\n' && !IsLockFile(relativePath: relativePath))
        {
            violations.Add(item: $"{relativePath}: does not end with a newline");
        }

        return violations;
    }

    private static readonly string[] _skippedFolders = [".claude/", ".planning/"];

    private static readonly string[] _binaryExtensions =
    [
        ".png",
        ".jpg",
        ".jpeg",
        ".gif",
        ".bmp",
        ".ico",
        ".webp",
        ".pdf",
        ".zip",
        ".gz",
        ".tgz",
        ".7z",
        ".jar",
        ".dll",
        ".exe",
        ".so",
        ".dylib",
        ".nupkg",
        ".snupkg",
        ".snk",
        ".pfx",
        ".woff",
        ".woff2",
        ".ttf",
        ".otf",
        ".eot",
        ".mp3",
        ".mp4",
        ".wav",
    ];

    private static readonly byte[] _bom = [0xEF, 0xBB, 0xBF];

    private static readonly UTF8Encoding _strictUtf8 = new(
            encoderShouldEmitUTF8Identifier: false,
            throwOnInvalidBytes: true);

    private static bool IsValidUtf8(ReadOnlySpan<byte> bytes)
    {
        try
        {
            _strictUtf8.GetCharCount(bytes: bytes);
            return true;
        }
        catch (DecoderFallbackException)
        {
            return false;
        }
    }

    private static bool HasTrailingWhitespace(ReadOnlySpan<byte> bytes)
    {
        for (int index = 1; index < bytes.Length; index++)
        {
            bool endsLine = bytes[index] == (byte)'\n';
            if (endsLine && bytes[index - 1] is (byte)' ' or (byte)'\t')
            {
                return true;
            }
        }

        return !bytes.IsEmpty && bytes[^1] is (byte)' ' or (byte)'\t';
    }

    private static bool IsLockFile(string relativePath)
    {
        return string.Equals(
                a: Path.GetFileName(path: relativePath),
                b: LockFileName,
                comparisonType: StringComparison.Ordinal);
    }
}
