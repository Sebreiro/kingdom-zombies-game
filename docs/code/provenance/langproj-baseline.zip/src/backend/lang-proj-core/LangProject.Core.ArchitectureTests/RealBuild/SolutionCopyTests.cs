using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.RealBuild;

/// <summary>
/// The throwaway solution copy the real-build proofs run in (D-34) is isolated: it sits in a folder private to the
/// user, holds only the files git tracks, and has guard files that stop MSBuild and NuGet from reading
/// configuration above it.
/// </summary>
public sealed class SolutionCopyTests
{
    /// <summary>
    /// A new copy sits directly under the private proof root, which has mode 0700 on Unix, holds exactly the
    /// tracked solution files, <c>global.json</c>, <c>.editorconfig</c> and the two guard files, and is deleted on
    /// dispose.
    /// </summary>
    /// <returns>A task that completes when the test has run.</returns>
    [Fact]
    public async Task SolutionCopy_Create_HoldsOnlyTrackedFilesInPrivateRoot()
    {
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;
        IReadOnlyList<string> trackedFiles = await TrackedFiles.ListAsync(cancellationToken: cancellationToken);
        List<string> expected =
        [
            .. SolutionCopy.CopiedFiles(trackedFiles: trackedFiles)
                    .Where(predicate: path => File.Exists(path: Path.Combine(
                            path1: RepositoryLayout.RepositoryRoot,
                            path2: path)))
                    .Concat(second: _guardFiles)
                    .Order(comparer: StringComparer.Ordinal),
        ];

        string copyRoot;
        List<string> copied;
        string nuGetConfig;
        using (SolutionCopy copy = await SolutionCopy.CreateAsync(cancellationToken: cancellationToken))
        {
            copyRoot = copy.CopyRoot;
            copied = ListFiles(root: copy.CopyRoot);
            nuGetConfig = await File.ReadAllTextAsync(
                    path: Path.Combine(path1: copy.CopyRoot, path2: "NuGet.Config"),
                    cancellationToken: cancellationToken);
        }

        copied.ShouldBe(expected: expected);
        copied.ShouldContain(elementPredicate: path => string.Equals(
                a: path,
                b: "src/backend/lang-proj-core/LangProject.Core.slnx",
                comparisonType: StringComparison.Ordinal));
        Path.GetDirectoryName(path: copyRoot).ShouldBe(expected: ProofRoot.PrivateRoot());
        nuGetConfig.ShouldContain(expected: "<clear />");
        Directory.Exists(path: copyRoot).ShouldBeFalse();
        if (!OperatingSystem.IsWindows())
        {
            File.GetUnixFileMode(path: ProofRoot.PrivateRoot()).ShouldBe(
                    expected: UnixFileMode.UserRead | UnixFileMode.UserWrite | UnixFileMode.UserExecute);
        }
    }

    private static readonly string[] _guardFiles = ["Directory.Build.rsp", "NuGet.Config"];

    private static List<string> ListFiles(string root)
    {
        return
        [
            .. Directory.EnumerateFiles(path: root, searchPattern: "*", searchOption: SearchOption.AllDirectories)
                    .Select(selector: path => Path.GetRelativePath(relativeTo: root, path: path)
                            .Replace(oldChar: '\\', newChar: '/'))
                    .Order(comparer: StringComparer.Ordinal),
        ];
    }
}
