using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using LangProject.Core.ArchitectureTests.Infrastructure;
using Shouldly;
using Xunit;

namespace LangProject.Core.ArchitectureTests.Rules;

/// <summary>
/// The CI settings that enforce a rule rather than run a test, read from the split backend workflow files: the entry
/// workflow <c>backend.yml</c> keeps the triggers, the concurrency rule and the three caller jobs; the analyzer
/// coverage gate in the <c>fast</c> job of <c>backend-fast.yml</c> and the production coverage gate in the
/// <c>integration</c> job of <c>backend-integration.yml</c> run the <c>coverage-gate</c> composite action (line 90%,
/// branch 80%, scoped by the caller's inputs); and the <c>deploy</c> job of <c>backend-deploy.yml</c> runs the Compose
/// smoke. The frontend entry workflow <c>frontend.yml</c> keeps the same concurrency rule, runs only when a file it
/// reaches changes, and calls <c>frontend-static.yml</c>, <c>frontend-component.yml</c> and <c>frontend-e2e.yml</c>,
/// which set up the pinned toolchain through the <c>setup-frontend</c> composite action and run the app's package
/// scripts. Every workflow and composite action file is hardened: read-only permissions, a timeout and the pinned
/// runner on every called job, every action pinned by commit SHA or an existing local action, <c>shell</c> on every
/// composite <c>run</c> step and no <c>inputs</c> expression inside a <c>run</c> script.
/// </summary>
public sealed partial class CiWorkflowTests
{
    /// <summary>
    /// The <c>fast</c> job collects Cobertura coverage from the analyzer tests and fails below 90% line or 80% branch
    /// coverage of the analyzer assembly.
    /// </summary>
    /// <returns>A task that completes when the check has run.</returns>
    [Fact]
    public async Task AnalyzerCoverageGate_FastJob_RequiresLine90AndBranch80()
    {
        IReadOnlyList<string> findings = FindAnalyzerGateProblems(set: await LoadSetAsync());

        findings.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: findings));
    }

    /// <summary>
    /// Removing the fast job's gate, commenting it out, switching it off with <c>if: false</c>, weakening a threshold,
    /// commenting a threshold out inside the command, or dropping coverage from the analyzer tests are each reported.
    /// </summary>
    /// <param name="mutation">The key of the change to the real files in the mutation table.</param>
    /// <returns>A task that completes when the check has run.</returns>
    [Theory]
    [InlineData("fast-gate-renamed")]
    [InlineData("fast-gate-commented-out")]
    [InlineData("fast-gate-if-false")]
    [InlineData("fast-gate-line-10")]
    [InlineData("fast-gate-threshold-commented")]
    [InlineData("fast-tests-without-coverage")]
    public async Task AnalyzerCoverageGate_ChangedWorkflow_IsReported(string mutation)
    {
        IReadOnlyList<string> findings = FindAnalyzerGateProblems(set: await MutatedSetAsync(mutation: mutation));

        findings.ShouldNotBeEmpty();
    }

    /// <summary>
    /// The <c>integration</c> job collects Cobertura coverage from the default-order IntegrationTests run and fails
    /// below 90% line or 80% branch coverage of the production assemblies, with test projects and generated
    /// migrations excluded (D-76).
    /// </summary>
    /// <returns>A task that completes when the check has run.</returns>
    [Fact]
    public async Task IntegrationCoverageGate_IntegrationJob_RequiresLine90AndBranch80()
    {
        IReadOnlyList<string> findings = FindIntegrationGateProblems(set: await LoadSetAsync());

        findings.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: findings));
    }

    /// <summary>
    /// Switching the integration gate off with <c>if: false</c>, weakening its branch threshold or removing the
    /// migrations filter is reported; the fast job's gate does not stand in for it.
    /// </summary>
    /// <param name="mutation">The key of the change to the real files in the mutation table.</param>
    /// <returns>A task that completes when the check has run.</returns>
    [Theory]
    [InlineData("integration-gate-if-false")]
    [InlineData("integration-gate-branch-8")]
    [InlineData("integration-gate-no-migrations-filter")]
    public async Task IntegrationCoverageGate_ChangedWorkflow_IsReported(string mutation)
    {
        IReadOnlyList<string> findings = FindIntegrationGateProblems(set: await MutatedSetAsync(mutation: mutation));

        findings.ShouldNotBeEmpty();
    }

    /// <summary>
    /// The <c>deploy</c> job builds the images and starts the Compose stack from <c>deploy/</c> with an env file
    /// copied from <c>.env.example</c> and the commit as <c>SOURCE_REVISION_ID</c>, waits for it, checks that the
    /// migrator exited with 0 and that <c>/health</c> reports the database Healthy, and always removes the stack
    /// with its volumes.
    /// </summary>
    /// <returns>A task that completes when the check has run.</returns>
    [Fact]
    public async Task DeployJob_ComposeSmoke_IsComplete()
    {
        IReadOnlyList<string> findings = FindDeployJobProblems(set: await LoadSetAsync());

        findings.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: findings));
    }

    /// <summary>
    /// Dropping the health check, switching the stack start off, building without <c>--build</c> or removing the
    /// cleanup is each reported.
    /// </summary>
    /// <param name="mutation">The key of the change to the real files in the mutation table.</param>
    /// <returns>A task that completes when the check has run.</returns>
    [Theory]
    [InlineData("deploy-no-health-check")]
    [InlineData("deploy-start-if-false")]
    [InlineData("deploy-without-build")]
    [InlineData("deploy-down-keeps-volumes")]
    public async Task DeployJob_ChangedWorkflow_IsReported(string mutation)
    {
        IReadOnlyList<string> findings = FindDeployJobProblems(set: await MutatedSetAsync(mutation: mutation));

        findings.ShouldNotBeEmpty();
    }

    /// <summary>
    /// <c>backend.yml</c> runs on a push to <c>main</c> and <c>dev</c> and on every pull request, with no path filter;
    /// it keeps the concurrency group and cancels only pull request runs; and its jobs are exactly <c>fast</c>,
    /// <c>integration</c> and <c>deploy</c>, each calling <c>./.github/workflows/backend-&lt;id&gt;.yml</c>.
    /// </summary>
    /// <returns>A task that completes when the check has run.</returns>
    [Fact]
    public async Task Entry_BackendWorkflow_KeepsTriggersConcurrencyAndJobs()
    {
        IReadOnlyList<string> findings = FindEntryProblems(set: await LoadSetAsync());

        findings.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: findings));
    }

    /// <summary>
    /// A path filter on the entry workflow, cancelling every run in progress, or a renamed caller job is each
    /// reported.
    /// </summary>
    /// <param name="mutation">The key of the change to the real files in the mutation table.</param>
    /// <returns>A task that completes when the check has run.</returns>
    [Theory]
    [InlineData("entry-path-filter")]
    [InlineData("entry-cancel-in-progress-true")]
    [InlineData("entry-jobs-renamed")]
    public async Task Entry_ChangedWorkflow_IsReported(string mutation)
    {
        IReadOnlyList<string> findings = FindEntryProblems(set: await MutatedSetAsync(mutation: mutation));

        findings.ShouldNotBeEmpty();
    }

    /// <summary>
    /// Every workflow and composite action file is hardened: read-only permissions, a timeout and
    /// <c>ubuntu-24.04</c> on every called job, every action pinned to a full commit SHA or an existing local action,
    /// <c>shell</c> on every composite <c>run</c> step and no <c>inputs</c> expression inside a <c>run</c> script.
    /// </summary>
    /// <returns>A task that completes when the check has run.</returns>
    [Fact]
    public async Task Workflow_EveryJob_HasTimeoutReadOnlyPermissionsAndPinnedActions()
    {
        CiWorkflowSet set = await LoadSetAsync();

        IReadOnlyList<string> findings = FindHardeningProblems(set: set);

        set.FileAt(relativePath: EntryWorkflow).ShouldNotBeNull();
        findings.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: findings));
    }

    /// <summary>
    /// An action pinned to a tag, in a workflow or in a composite action, a called job without a timeout, write
    /// permissions, a caller job or a step pointing at a missing local file, a composite <c>run</c> step without
    /// <c>shell</c> and an <c>inputs</c> expression inside a composite <c>run</c> script are each reported.
    /// </summary>
    /// <param name="mutation">The key of the change to the real files in the mutation table.</param>
    /// <returns>A task that completes when the check has run.</returns>
    [Theory]
    [InlineData("action-pinned-to-tag")]
    [InlineData("deploy-without-timeout")]
    [InlineData("deploy-write-permission")]
    [InlineData("called-job-without-timeout")]
    [InlineData("composite-action-pinned-to-tag")]
    [InlineData("caller-job-missing-workflow")]
    [InlineData("local-action-missing")]
    [InlineData("composite-run-without-shell")]
    [InlineData("composite-run-inputs-expression")]
    [InlineData("frontend-job-without-timeout")]
    public async Task Hardening_ChangedWorkflow_IsReported(string mutation)
    {
        IReadOnlyList<string> findings = FindHardeningProblems(set: await MutatedSetAsync(mutation: mutation));

        findings.ShouldNotBeEmpty();
    }

    /// <summary>
    /// <c>frontend.yml</c> runs on a push to <c>main</c> and <c>dev</c> and on pull requests, each with a path filter;
    /// it keeps the backend workflow's concurrency group and cancel rule, so a newer push to a pull request cancels the
    /// older frontend run; and it reads the repository with read-only permissions.
    /// </summary>
    /// <returns>A task that completes when the check has run.</returns>
    [Fact]
    public async Task Entry_FrontendWorkflow_KeepsConcurrencyAndReadOnlyPermissions()
    {
        IReadOnlyList<string> findings = FindFrontendEntryProblems(set: await LoadSetAsync());

        findings.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: findings));
    }

    /// <summary>Removing the concurrency block of <c>frontend.yml</c> is reported.</summary>
    /// <param name="mutation">The key of the change to the real files in the mutation table.</param>
    /// <returns>A task that completes when the check has run.</returns>
    [Theory]
    [InlineData("frontend-concurrency-removed")]
    public async Task Entry_FrontendChangedWorkflow_IsReported(string mutation)
    {
        IReadOnlyList<string> findings = FindFrontendEntryProblems(set: await MutatedSetAsync(mutation: mutation));

        findings.ShouldNotBeEmpty();
    }

    /// <summary>
    /// Every file <c>frontend.yml</c> reaches through local reusable workflows and composite actions, and
    /// <c>frontend.yml</c> itself, matches a path filter glob of both the push and the pull request trigger; both list
    /// <c>src/frontend/user-app/**</c>; and no glob matches a tracked file under <c>src/backend/</c> or
    /// <c>deploy/</c> or a Markdown file outside the app.
    /// </summary>
    /// <returns>A task that completes when the check has run.</returns>
    [Fact]
    public async Task Entry_FrontendWorkflow_PathFilterCoversEveryReachedFile()
    {
        IReadOnlyList<string> findings = FindFrontendPathFilterProblems(
                set: await LoadSetAsync(),
                trackedFiles: await TrackedFilesAsync());

        findings.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: findings));
    }

    /// <summary>
    /// Dropping the <c>setup-frontend</c> or the <c>upload-results</c> action from the path filter, or adding a glob
    /// for the backend files or for Markdown outside the app, is each reported.
    /// </summary>
    /// <param name="mutation">The key of the change to the real files in the mutation table.</param>
    /// <returns>A task that completes when the check has run.</returns>
    [Theory]
    [InlineData("frontend-filter-without-setup-frontend")]
    [InlineData("frontend-filter-without-upload-results")]
    [InlineData("frontend-filter-backend-files")]
    [InlineData("frontend-filter-markdown-outside-app")]
    public async Task FrontendPathFilter_ChangedWorkflow_IsReported(string mutation)
    {
        IReadOnlyList<string> findings = FindFrontendPathFilterProblems(
                set: await MutatedSetAsync(mutation: mutation),
                trackedFiles: await TrackedFilesAsync());

        findings.ShouldNotBeEmpty();
    }

    /// <summary>
    /// <c>frontend.yml</c> calls exactly the <c>static</c>, <c>component</c> and <c>e2e</c> jobs. Each called job sets
    /// up the toolchain through <c>setup-frontend</c> and then runs its package script in the app folder:
    /// <c>pnpm run check:static</c>, <c>pnpm run test:component</c>, and <c>pnpm run test:e2e</c> with
    /// <c>--project</c>, on Chromium, Firefox and WebKit with fail-fast off. <c>setup-frontend</c> installs pnpm from
    /// <c>packageManager</c>, then Node from <c>.node-version</c> with no literal <c>node-version</c>, then runs
    /// <c>pnpm install --frozen-lockfile</c>.
    /// </summary>
    /// <returns>A task that completes when the check has run.</returns>
    [Fact]
    public async Task FrontendWorkflow_Jobs_RunEveryCheckThroughPackageScripts()
    {
        IReadOnlyList<string> findings = FindFrontendJobProblems(set: await LoadSetAsync());

        findings.ShouldBeEmpty(customMessage: string.Join(separator: "\n", values: findings));
    }

    /// <summary>
    /// Turning fail-fast on, dropping an engine from the e2e matrix, replacing <c>node-version-file</c> with a literal
    /// <c>node-version</c>, or installing without <c>--frozen-lockfile</c> is each reported.
    /// </summary>
    /// <param name="mutation">The key of the change to the real files in the mutation table.</param>
    /// <returns>A task that completes when the check has run.</returns>
    [Theory]
    [InlineData("frontend-e2e-fail-fast-true")]
    [InlineData("frontend-e2e-engine-dropped")]
    [InlineData("frontend-literal-node-version")]
    [InlineData("frontend-install-not-frozen")]
    public async Task FrontendWorkflow_ChangedJob_IsReported(string mutation)
    {
        IReadOnlyList<string> findings = FindFrontendJobProblems(set: await MutatedSetAsync(mutation: mutation));

        findings.ShouldNotBeEmpty();
    }

    /// <summary>
    /// The parser keeps a <c>#</c> inside a folded <c>run</c> block as shell text, which the shell words then drop
    /// with the rest of the line, and drops YAML comment lines.
    /// </summary>
    [Fact]
    public void CiWorkflow_SyntheticText_FlattensStepsAndShellComments()
    {
        const string Text = "jobs:\n  a:\n    # timeout-minutes: 5\n    steps:\n      - name: One\n"
                + "        if: always()\n        run: >-\n          tool\n          # \"x=1\"\n          \"y=2\"\n"
                + "      - name: Two\n        with:\n          path: p # trailing\n        run: |\n"
                + "          echo a # note\n          echo b\n";

        var workflow = CiWorkflow.Parse(text: Text);
        IReadOnlyList<IReadOnlyDictionary<string, string>> steps = workflow.Steps(jobId: "a");

        workflow.JobIds.ShouldBe(expected: ["a"]);
        workflow.JobSettings(jobId: "a").ShouldBeEmpty();
        steps.Count.ShouldBe(expected: 2);
        steps[0]["if"].ShouldBe(expected: "always()");
        CiWorkflow.ShellWords(run: steps[0]["run"]).ShouldBe(expected: ["tool"]);
        steps[1]["with.path"].ShouldBe(expected: "p");
        CiWorkflow.ShellWords(run: steps[1]["run"]).ShouldBe(expected: ["echo", "a", "echo", "b"]);
    }

    /// <summary>
    /// A step that uses a local composite action expands to the action's steps, with the caller's <c>with:</c> value,
    /// else the input's default, standing in for each variable set from an <c>inputs</c> expression; other variables
    /// stay as written, and a step that uses no existing local action does not expand.
    /// </summary>
    [Fact]
    public void CiWorkflowSet_LocalActionStep_ExpandsWithCallerInputs()
    {
        const string Action = "inputs:\n  a:\n    required: true\n  b:\n    default: \"two\"\nruns:\n"
                + "  using: composite\n  steps:\n    - name: Use\n      shell: bash\n      env:\n"
                + "        A: ${{ inputs.a }}\n        B: ${{inputs.b}}\n        C: plain\n"
                + "      run: tool \"$A\" \"${B}\" \"$C\" \"$ABC\"\n";
        var set = CiWorkflowSet.Parse(texts: new Dictionary<string, string>(comparer: StringComparer.Ordinal)
        {
            [".github/actions/tool/action.yml"] = Action,
        });

        IReadOnlyList<IReadOnlyDictionary<string, string>>? expanded = set.Expand(
                step: new Dictionary<string, string>(comparer: StringComparer.Ordinal)
                {
                    ["uses"] = "./.github/actions/tool",
                    ["with.a"] = "one",
                });
        IReadOnlyList<IReadOnlyDictionary<string, string>>? missing = set.Expand(
                step: new Dictionary<string, string>(comparer: StringComparer.Ordinal)
                {
                    ["uses"] = "./.github/actions/other",
                });

        expanded.ShouldNotBeNull();
        expanded.Count.ShouldBe(expected: 1);
        expanded[0]["run"].ShouldBe(expected: "tool \"one\" \"two\" \"$C\" \"$ABC\"");
        missing.ShouldBeNull();
    }

    /// <summary>Finds what weakens the analyzer coverage gate in the <c>fast</c> job.</summary>
    /// <param name="set">The parsed workflow and action files.</param>
    /// <returns>One message per problem.</returns>
    internal static IReadOnlyList<string> FindAnalyzerGateProblems(CiWorkflowSet set)
    {
        return FindGateProblems(set: set, gate: _analyzerGate);
    }

    /// <summary>Finds what weakens the production coverage gate in the <c>integration</c> job.</summary>
    /// <param name="set">The parsed workflow and action files.</param>
    /// <returns>One message per problem.</returns>
    internal static IReadOnlyList<string> FindIntegrationGateProblems(CiWorkflowSet set)
    {
        return FindGateProblems(set: set, gate: _integrationGate);
    }

    /// <summary>Finds what is missing from the <c>deploy</c> job's Compose smoke.</summary>
    /// <param name="set">The parsed workflow and action files.</param>
    /// <returns>One message per problem.</returns>
    internal static IReadOnlyList<string> FindDeployJobProblems(CiWorkflowSet set)
    {
        CiWorkflow workflow = WorkflowAt(set: set, path: DeployWorkflow);
        List<string> findings = [.. UnconditionalJob(workflow: workflow, jobId: DeployJob)];
        IReadOnlyList<IReadOnlyDictionary<string, string>> steps = workflow.Steps(jobId: DeployJob);
        string commands = string.Join(
                separator: "\n",
                values: steps
                        .Where(predicate: step => !step.ContainsKey(key: "if"))
                        .Select(selector: step => DeployCommand(step: step)));
        foreach (string expected in _deployCommands)
        {
            if (!commands.Contains(value: expected, comparisonType: StringComparison.Ordinal))
            {
                findings.Add(item: $"The deploy job runs no unconditional step with '{expected}'");
            }
        }

        bool cleanup = steps.Any(predicate: step => step.TryGetValue(key: "if", value: out string? condition)
                && string.Equals(a: condition, b: "always()", comparisonType: StringComparison.Ordinal)
                && DeployCommand(step: step).Contains(
                        value: "docker compose down --volumes",
                        comparisonType: StringComparison.Ordinal));
        if (!cleanup)
        {
            findings.Add(item: "The deploy job has no 'if: always()' step that runs 'docker compose down --volumes'");
        }

        return findings;
    }

    /// <summary>Finds what changes the triggers, the concurrency or the caller jobs of <c>backend.yml</c>.</summary>
    /// <param name="set">The parsed workflow and action files.</param>
    /// <returns>One message per problem.</returns>
    internal static IReadOnlyList<string> FindEntryProblems(CiWorkflowSet set)
    {
        CiWorkflow? entry = set.FileAt(relativePath: EntryWorkflow);
        if (entry is null)
        {
            return [$"There is no {EntryWorkflow}"];
        }

        List<string> findings =
        [
            .. TriggerProblems(entry: entry, path: EntryWorkflow, expected: _entryTriggers),
            .. EntrySettingProblems(entry: entry, path: EntryWorkflow),
        ];
        if (!entry.JobIds.SequenceEqual(second: _entryJobs, comparer: StringComparer.Ordinal))
        {
            findings.Add(item: $"{EntryWorkflow} has the jobs {string.Join(separator: ", ", values: entry.JobIds)}");
        }

        findings.AddRange(collection: entry.JobIds.SelectMany(selector: jobId => CallerJobProblems(
                entry: entry,
                jobId: jobId)));
        return findings;
    }

    /// <summary>
    /// Finds, in every workflow and composite action file, every permission other than read, every called job without
    /// a timeout or the pinned runner, every caller job whose reusable workflow is missing, every action neither pinned
    /// to a full commit SHA nor an existing local action, every composite <c>run</c> step without <c>shell</c>, and
    /// every <c>inputs</c> expression inside a <c>run</c> script.
    /// </summary>
    /// <param name="set">The parsed workflow and action files.</param>
    /// <returns>One message per problem.</returns>
    internal static IReadOnlyList<string> FindHardeningProblems(CiWorkflowSet set)
    {
        List<string> findings = [];
        foreach (string path in set.Paths)
        {
            CiWorkflow file = WorkflowAt(set: set, path: path);
            IEnumerable<string> problems = CiWorkflowSet.IsActionPath(relativePath: path)
                    ? ActionHardeningProblems(set: set, action: file)
                    : WorkflowHardeningProblems(set: set, workflow: file);
            findings.AddRange(collection: problems.Select(selector: problem => $"{path}: {problem}"));
        }

        return findings;
    }

    /// <summary>
    /// Finds what changes the triggers, the concurrency or the permissions of <c>frontend.yml</c>: a push to
    /// <c>main</c> and <c>dev</c> and pull requests, each with a path filter, the concurrency group and cancel rule of
    /// <c>backend.yml</c>, and read-only permissions.
    /// </summary>
    /// <param name="set">The parsed workflow and action files.</param>
    /// <returns>One message per problem.</returns>
    internal static IReadOnlyList<string> FindFrontendEntryProblems(CiWorkflowSet set)
    {
        CiWorkflow? entry = set.FileAt(relativePath: FrontendEntryWorkflow);
        if (entry is null)
        {
            return [$"There is no {FrontendEntryWorkflow}"];
        }

        return
        [
            .. TriggerProblems(entry: entry, path: FrontendEntryWorkflow, expected: _frontendTriggers),
            .. EntrySettingProblems(entry: entry, path: FrontendEntryWorkflow),
        ];
    }

    /// <summary>
    /// Finds every file that <c>frontend.yml</c> reaches, itself included, that a path filter of the push or the pull
    /// request trigger does not cover; a trigger whose filter lacks <c>src/frontend/user-app/**</c>; and every glob
    /// that matches a tracked file under <c>src/backend/</c> or <c>deploy/</c> or a Markdown file outside the app.
    /// </summary>
    /// <param name="set">The parsed workflow and action files.</param>
    /// <param name="trackedFiles">The repository-relative paths of the tracked files.</param>
    /// <returns>One message per problem.</returns>
    internal static IReadOnlyList<string> FindFrontendPathFilterProblems(
            CiWorkflowSet set,
            IReadOnlyList<string> trackedFiles)
    {
        CiWorkflow? entry = set.FileAt(relativePath: FrontendEntryWorkflow);
        if (entry is null)
        {
            return [$"There is no {FrontendEntryWorkflow}"];
        }

        List<string> reached = ReachedFiles(set: set, start: FrontendEntryWorkflow);
        List<string> outside = [.. trackedFiles.Where(predicate: path => IsOutsideFrontendFilter(relativePath: path))];
        if (outside.Count == 0)
        {
            return ["No tracked backend, deploy or Markdown file is there to check the path filter against"];
        }

        return
        [
            .. _filteredEvents.SelectMany(selector: trigger => PathFilterProblems(
                    trigger: trigger,
                    globs: entry.ListValues(path: $"on.{trigger}.paths"),
                    reached: reached,
                    outside: outside)),
        ];
    }

    /// <summary>
    /// Finds what changes the frontend jobs: the caller jobs of <c>frontend.yml</c>, the package script each called
    /// job runs after <c>setup-frontend</c>, the e2e engines and fail-fast setting, and the pinned toolchain and
    /// frozen install of <c>setup-frontend</c>.
    /// </summary>
    /// <param name="set">The parsed workflow and action files.</param>
    /// <returns>One message per problem.</returns>
    internal static IReadOnlyList<string> FindFrontendJobProblems(CiWorkflowSet set)
    {
        CiWorkflow? entry = set.FileAt(relativePath: FrontendEntryWorkflow);
        if (entry is null)
        {
            return [$"There is no {FrontendEntryWorkflow}"];
        }

        List<string> findings = [];
        IEnumerable<string> jobIds = _frontendJobs.Select(selector: job => job.JobId);
        if (!entry.JobIds.SequenceEqual(second: jobIds, comparer: StringComparer.Ordinal))
        {
            findings.Add(item: $"{FrontendEntryWorkflow} has the jobs "
                    + $"{string.Join(separator: ", ", values: entry.JobIds)}, not exactly static, component and e2e");
        }

        foreach ((string jobId, string[] script, string? option) in _frontendJobs)
        {
            findings.AddRange(collection: FrontendCallerProblems(entry: entry, jobId: jobId));
            findings.AddRange(collection: FrontendScriptProblems(
                    set: set,
                    jobId: jobId,
                    script: script,
                    option: option));
        }

        findings.AddRange(collection: E2eMatrixProblems(entry: entry));
        findings.AddRange(collection: SetupFrontendProblems(set: set));
        return findings;
    }

    private const string EntryWorkflow = ".github/workflows/backend.yml";
    private const string DeployWorkflow = ".github/workflows/backend-deploy.yml";
    private const string DeployJob = "deploy";
    private const string CoverageGateAction = "./.github/actions/coverage-gate";
    private const string Runner = "ubuntu-24.04";
    private const string FrontendEntryWorkflow = ".github/workflows/frontend.yml";
    private const string SetupFrontendAction = "./.github/actions/setup-frontend";
    private const string SetupFrontendFile = ".github/actions/setup-frontend/action.yml";
    private const string AppFolder = "src/frontend/user-app";
    private const string AppGlob = "src/frontend/user-app/**";
    private const string MatrixBrowser = "${{ matrix.browser }}";

    private static readonly string[] _entryJobs = ["fast", "integration", "deploy"];

    private static readonly string[] _filteredEvents = ["push", "pull_request"];

    private static readonly string[] _engines = ["chromium", "firefox", "webkit"];

    private static readonly string[] _frontendTriggers =
    [
        "on",
        "on.push",
        "on.push.branches",
        "on.push.branches[0]",
        "on.push.branches[1]",
        "on.push.paths",
        "on.pull_request",
        "on.pull_request.paths",
    ];

    private static readonly (string JobId, string[] Script, string? Option)[] _frontendJobs =
    [
        ("static", ["pnpm", "run", "check:static"], null),
        ("component", ["pnpm", "run", "test:component"], null),
        ("e2e", ["pnpm", "run", "test:e2e"], "--project="),
    ];

    private static readonly string[] _entryTriggers =
    [
        "on",
        "on.push",
        "on.push.branches",
        "on.push.branches[0]",
        "on.push.branches[1]",
        "on.pull_request",
    ];

    private static readonly (string Path, string Value)[] _entrySettings =
    [
        ("on.push.branches[0]", "main"),
        ("on.push.branches[1]", "dev"),
        ("permissions.contents", "read"),
        ("concurrency.group", "ci-${{ github.workflow }}-${{ github.event.pull_request.number || github.sha }}"),
        ("concurrency.cancel-in-progress", "${{ github.event_name == 'pull_request' }}"),
    ];

    private static readonly CoverageGate _analyzerGate = new(
            workflowPath: ".github/workflows/backend-fast.yml",
            jobId: "fast",
            testStepName: "Analyzer tests",
            gateStepName: "Analyzer coverage gate (line 90%, branch 80%)",
            resultsDirectory: "${{runner.temp}}/analyzer-results",
            gateWords:
            [
                "\"-reports:${{runner.temp}}/analyzer-results/**/*.cobertura.xml\"",
                "\"-assemblyfilters:+Sebreiro.CodeRules.Analyzers\"",
            ]);

    private static readonly CoverageGate _integrationGate = new(
            workflowPath: ".github/workflows/backend-integration.yml",
            jobId: "integration",
            testStepName: "Integration tests",
            gateStepName: "Integration coverage gate (line 90%, branch 80%)",
            resultsDirectory: "${{runner.temp}}/integration-results",
            gateWords:
            [
                "\"-reports:${{runner.temp}}/integration-results/**/*.cobertura.xml\"",
                "\"-assemblyfilters:+LangProject.Core.*;+Sebreiro.UnitOfWork.*;-*Tests\"",
                "\"-filefilters:-**/Migrations/**\"",
            ]);

    private static readonly string[] _thresholdWords =
    [
        "\"minimumCoverageThresholds:lineCoverage=90\"",
        "\"minimumCoverageThresholds:branchCoverage=80\"",
    ];

    private static readonly string[] _deployCommands =
    [
        "deploy$ cp .env.example .env",
        "SOURCE_REVISION_ID=${{ github.sha }}",
        "deploy$ docker compose up --detach --build --wait",
        "deploy$ test \"$(docker compose ps --all --format '{{.ExitCode}}' migrator)\" = \"0\"",
        "deploy$ curl --fail --silent --show-error http://127.0.0.1:8080/health | tee health.json",
        "deploy$ jq --exit-status '.checks.database.status == \"Healthy\"' health.json",
    ];

    private static readonly Dictionary<string, (string Original, string Replacement)> _mutations =
            new(comparer: StringComparer.Ordinal)
            {
                ["fast-gate-renamed"] = (
                        "      - name: Analyzer coverage gate (line 90%, branch 80%)\n",
                        "      - name: Analyzer gate\n"),
                ["fast-gate-commented-out"] = (
                        "      - name: Analyzer coverage gate", "      # - name: Analyzer coverage gate"),
                ["fast-gate-if-false"] = (
                        "      - name: Analyzer coverage gate (line 90%, branch 80%)\n",
                        "      - name: Analyzer coverage gate (line 90%, branch 80%)\n        if: false\n"),
                ["fast-gate-line-10"] = (
                        "\"minimumCoverageThresholds:lineCoverage=90\"",
                        "\"minimumCoverageThresholds:lineCoverage=10\""),
                ["fast-gate-threshold-commented"] = (
                        "          \"minimumCoverageThresholds:lineCoverage=90\"\n",
                        "          # \"minimumCoverageThresholds:lineCoverage=90\"\n"),
                ["fast-tests-without-coverage"] = (
                        "          --coverage --coverage-output-format cobertura\n"
                                + "          --results-directory ${{ runner.temp }}/analyzer",
                        "          --results-directory ${{ runner.temp }}/analyzer"),
                ["integration-gate-if-false"] = (
                        "      - name: Integration coverage gate (line 90%, branch 80%)\n",
                        "      - name: Integration coverage gate (line 90%, branch 80%)\n        if: false\n"),
                ["integration-gate-branch-8"] = (
                        "\"minimumCoverageThresholds:branchCoverage=80\"",
                        "\"minimumCoverageThresholds:branchCoverage=8\""),
                ["integration-gate-no-migrations-filter"] = (
                        "          file-filters: \"-**/Migrations/**\"\n", string.Empty),
                ["deploy-no-health-check"] = (
                        "          jq --exit-status '.checks.database.status == \"Healthy\"' health.json\n",
                        string.Empty),
                ["deploy-start-if-false"] = (
                        "      - name: Build and start the stack\n",
                        "      - name: Build and start the stack\n        if: false\n"),
                ["deploy-without-build"] = (
                        "docker compose up --detach --build --wait", "docker compose up --detach --wait"),
                ["deploy-down-keeps-volumes"] = (
                        "        run: docker compose down --volumes\n", "        run: docker compose down\n"),
                ["entry-path-filter"] = (
                        "  pull_request:\n\npermissions:",
                        "  pull_request:\n    paths:\n      - src/backend/**\n\npermissions:"),
                ["entry-cancel-in-progress-true"] = (
                        "cancel-in-progress: ${{ github.event_name == 'pull_request' }}\n\njobs:\n  fast:",
                        "cancel-in-progress: true\n\njobs:\n  fast:"),
                ["entry-jobs-renamed"] = (
                        "  fast:\n    name: fast\n    uses:", "  quick:\n    name: quick\n    uses:"),
                ["action-pinned-to-tag"] = (
                        "actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1 # v7.0.1\n\n"
                                + "      - name: Create the env file",
                        "actions/checkout@v7 # v7.0.1\n\n      - name: Create the env file"),
                ["deploy-without-timeout"] = (
                        "    timeout-minutes: 30\n", string.Empty),
                ["deploy-write-permission"] = (
                        "    timeout-minutes: 30\n    permissions:\n      contents: read\n",
                        "    timeout-minutes: 30\n    permissions:\n      contents: write\n"),
                ["called-job-without-timeout"] = (
                        "    timeout-minutes: 25\n", string.Empty),
                ["composite-action-pinned-to-tag"] = (
                        "actions/setup-dotnet@a98b56852c35b8e3190ac28c8c2271da59106c68", "actions/setup-dotnet@v6"),
                ["caller-job-missing-workflow"] = (
                        "uses: ./.github/workflows/backend-deploy.yml", "uses: ./.github/workflows/backend-smoke.yml"),
                ["local-action-missing"] = (
                        "        uses: ./.github/actions/upload-results\n        with:\n"
                                + "          name: integration-results",
                        "        uses: ./.github/actions/upload-test-results\n        with:\n"
                                + "          name: integration-results"),
                ["composite-run-without-shell"] = (
                        "    - name: Restore (locked)\n      shell: bash\n", "    - name: Restore (locked)\n"),
                ["composite-run-inputs-expression"] = (
                        "\"-reports:$REPORTS\"", "\"-reports:${{ inputs.reports }}\""),
                ["frontend-job-without-timeout"] = (
                        "    timeout-minutes: 15\n", string.Empty),
                ["frontend-concurrency-removed"] = (
                        "concurrency:\n  group: ci-${{ github.workflow }}-"
                                + "${{ github.event.pull_request.number || github.sha }}\n"
                                + "  cancel-in-progress: ${{ github.event_name == 'pull_request' }}\n\n"
                                + "jobs:\n  static:",
                        "jobs:\n  static:"),
                ["frontend-filter-without-setup-frontend"] = (
                        "      - .github/actions/setup-frontend/**\n", string.Empty),
                ["frontend-filter-without-upload-results"] = (
                        "      - .github/actions/upload-results/**\n", string.Empty),
                ["frontend-filter-backend-files"] = (
                        "      - src/frontend/user-app/**\n",
                        "      - src/frontend/user-app/**\n      - src/backend/**\n"),
                ["frontend-filter-markdown-outside-app"] = (
                        "      - src/frontend/user-app/**\n",
                        "      - src/frontend/user-app/**\n      - \"**/*.md\"\n"),
                ["frontend-e2e-fail-fast-true"] = (
                        "      fail-fast: false\n", "      fail-fast: true\n"),
                ["frontend-e2e-engine-dropped"] = (
                        "          - webkit\n", string.Empty),
                ["frontend-literal-node-version"] = (
                        "        node-version-file: src/frontend/user-app/.node-version\n",
                        "        node-version: \"24\"\n"),
                ["frontend-install-not-frozen"] = (
                        "run: pnpm install --frozen-lockfile", "run: pnpm install"),
            };

    private static async Task<CiWorkflowSet> LoadSetAsync()
    {
        return await CiWorkflowSet.LoadAsync(cancellationToken: TestContext.Current.CancellationToken);
    }

    private static async Task<CiWorkflowSet> MutatedSetAsync(string mutation)
    {
        (string original, string replacement) = _mutations[mutation];
        CiWorkflowSet set = await LoadSetAsync();
        IReadOnlyList<string> holders = set.PathsContaining(text: original);

        holders.Count.ShouldBe(
                expected: 1,
                customMessage: $"'{mutation}' must change exactly one file, but its text is in "
                        + string.Join(separator: ", ", values: holders));
        return set.Replace(relativePath: holders[0], original: original, replacement: replacement);
    }

    private static async Task<IReadOnlyList<string>> TrackedFilesAsync()
    {
        return await TrackedFiles.ListAsync(cancellationToken: TestContext.Current.CancellationToken);
    }

    private static CiWorkflow WorkflowAt(CiWorkflowSet set, string path)
    {
        return set.FileAt(relativePath: path) ?? CiWorkflow.Parse(text: string.Empty);
    }

    private static List<string> WorkflowHardeningProblems(CiWorkflowSet set, CiWorkflow workflow)
    {
        List<string> findings = [];
        if (!string.Equals(
                a: workflow.Value(path: "permissions.contents"),
                b: "read",
                comparisonType: StringComparison.Ordinal))
        {
            findings.Add(item: "The workflow's permissions are not 'contents: read'");
        }

        findings.AddRange(collection: WritePermissions(
                owner: "The workflow",
                settings: workflow.ValuesUnder(prefix: "permissions")));
        foreach (string jobId in workflow.JobIds)
        {
            IReadOnlyDictionary<string, string> settings = workflow.JobSettings(jobId: jobId);
            findings.AddRange(collection: WritePermissions(owner: $"Job {jobId}", settings: settings));
            if (settings.TryGetValue(key: "uses", value: out string? called))
            {
                if (set.LocalWorkflow(uses: called) is null)
                {
                    findings.Add(item: $"Job {jobId} calls {called}, which is not an existing local workflow");
                }

                continue;
            }

            if (!settings.ContainsKey(key: "timeout-minutes"))
            {
                findings.Add(item: $"Job {jobId} has no timeout-minutes");
            }

            if (!string.Equals(
                    a: settings.GetValueOrDefault(key: "runs-on"),
                    b: Runner,
                    comparisonType: StringComparison.Ordinal))
            {
                findings.Add(item: $"Job {jobId} does not run on {Runner}");
            }

            findings.AddRange(collection: StepProblems(
                    set: set,
                    steps: workflow.Steps(jobId: jobId),
                    owner: $"Job {jobId}",
                    requireShell: false));
        }

        return findings;
    }

    private static List<string> ActionHardeningProblems(CiWorkflowSet set, CiWorkflow action)
    {
        List<string> findings = [];
        if (!string.Equals(
                a: action.Value(path: "runs.using"),
                b: "composite",
                comparisonType: StringComparison.Ordinal))
        {
            findings.Add(item: "The action is not a composite action");
        }

        findings.AddRange(collection: StepProblems(
                set: set,
                steps: action.ActionSteps(),
                owner: "The action",
                requireShell: true));
        return findings;
    }

    private static IEnumerable<string> WritePermissions(string owner, IReadOnlyDictionary<string, string> settings)
    {
        return settings
                .Where(predicate: pair => pair.Key.StartsWith(
                        value: "permissions",
                        comparisonType: StringComparison.Ordinal)
                        && !string.Equals(a: pair.Value, b: "read", comparisonType: StringComparison.Ordinal))
                .Select(selector: pair => $"{owner} sets {pair.Key}: {pair.Value}");
    }

    private static IEnumerable<string> StepProblems(
            CiWorkflowSet set,
            IReadOnlyList<IReadOnlyDictionary<string, string>> steps,
            string owner,
            bool requireShell)
    {
        foreach (IReadOnlyDictionary<string, string> step in steps)
        {
            string name = step.GetValueOrDefault(key: "name") ?? "(unnamed)";
            if (step.TryGetValue(key: "uses", value: out string? uses)
                    && !PinnedAction().IsMatch(input: uses)
                    && set.LocalAction(uses: uses) is null)
            {
                yield return $"{owner} uses {uses}, which is neither pinned to a commit SHA nor a local action";
            }

            if (step.TryGetValue(key: "run", value: out string? run))
            {
                if (requireShell && !step.ContainsKey(key: "shell"))
                {
                    yield return $"{owner} runs '{name}' without a shell";
                }

                if (InputsExpression().IsMatch(input: run))
                {
                    yield return $"{owner} puts an inputs expression inside the run script of '{name}'";
                }
            }
        }
    }

    private static IEnumerable<string> CallerJobProblems(CiWorkflow entry, string jobId)
    {
        var expected = new Dictionary<string, string>(comparer: StringComparer.Ordinal)
        {
            ["name"] = jobId,
            ["uses"] = $"./.github/workflows/backend-{jobId}.yml",
        };
        IReadOnlyDictionary<string, string> settings = entry.JobSettings(jobId: jobId);
        if (settings.Count != expected.Count
                || expected.Any(predicate: pair => !string.Equals(
                        a: settings.GetValueOrDefault(key: pair.Key),
                        b: pair.Value,
                        comparisonType: StringComparison.Ordinal)))
        {
            yield return $"Job {jobId} of {EntryWorkflow} is not exactly 'name: {jobId}' and "
                    + $"'uses: {expected["uses"]}'";
        }
    }

    private static IEnumerable<string> TriggerProblems(CiWorkflow entry, string path, IReadOnlyList<string> expected)
    {
        var triggers = new HashSet<string>(
                collection: entry.Paths.Where(predicate: key => (string.Equals(
                        a: key,
                        b: "on",
                        comparisonType: StringComparison.Ordinal)
                        || key.StartsWith(value: "on.", comparisonType: StringComparison.Ordinal))
                        && !key.Contains(value: ".paths[", comparisonType: StringComparison.Ordinal)),
                comparer: StringComparer.Ordinal);
        if (!triggers.SetEquals(other: expected))
        {
            yield return $"{path} triggers on "
                    + string.Join(separator: ", ", values: triggers.Order(comparer: StringComparer.Ordinal))
                    + ", not exactly " + string.Join(separator: ", ", values: expected);
        }
    }

    private static IEnumerable<string> EntrySettingProblems(CiWorkflow entry, string path)
    {
        foreach ((string key, string expected) in _entrySettings)
        {
            string? actual = entry.Value(path: key);
            if (!string.Equals(a: actual, b: expected, comparisonType: StringComparison.Ordinal))
            {
                yield return $"{path} sets {key} to '{actual}', not '{expected}'";
            }
        }
    }

    private static List<string> ReachedFiles(CiWorkflowSet set, string start)
    {
        List<string> reached = [start];
        for (int index = 0; index < reached.Count; index++)
        {
            string path = reached[index];
            CiWorkflow? file = set.FileAt(relativePath: path);
            if (file is null)
            {
                continue;
            }

            IEnumerable<string?> targets = CiWorkflowSet.IsActionPath(relativePath: path)
                    ? file.ActionSteps().Select(selector: step => set.LocalAction(uses: UsesOf(step: step)))
                    : file.JobIds.SelectMany(selector: jobId => LocalTargets(set: set, workflow: file, jobId: jobId));
            foreach (string target in targets.OfType<string>())
            {
                if (!reached.Contains(value: target, comparer: StringComparer.Ordinal))
                {
                    reached.Add(item: target);
                }
            }
        }

        return reached;
    }

    private static IEnumerable<string?> LocalTargets(CiWorkflowSet set, CiWorkflow workflow, string jobId)
    {
        IEnumerable<string?> actions = workflow.Steps(jobId: jobId)
                .Select(selector: step => set.LocalAction(uses: UsesOf(step: step)));
        return actions.Prepend(element: set.LocalWorkflow(uses: UsesOf(step: workflow.JobSettings(jobId: jobId))));
    }

    private static string UsesOf(IReadOnlyDictionary<string, string> step)
    {
        return step.GetValueOrDefault(key: "uses") ?? string.Empty;
    }

    private static IEnumerable<string> PathFilterProblems(
            string trigger,
            IReadOnlyList<string> globs,
            IReadOnlyList<string> reached,
            IReadOnlyList<string> outside)
    {
        string owner = $"on.{trigger}.paths of {FrontendEntryWorkflow}";
        if (!globs.Contains(value: AppGlob, comparer: StringComparer.Ordinal))
        {
            yield return $"{owner} does not list {AppGlob}";
        }

        foreach (string file in reached.Where(predicate: path => !globs.Any(predicate: glob => SuppressionScanner
                .MatchesGlob(relativePath: path, glob: glob))))
        {
            yield return $"{owner} does not cover {file}, which the frontend workflow reaches";
        }

        foreach (string glob in globs)
        {
            string? match = outside.FirstOrDefault(predicate: file => SuppressionScanner.MatchesGlob(
                    relativePath: file,
                    glob: glob));
            if (match is not null)
            {
                yield return $"{owner} has the glob '{glob}', which matches {match} outside the frontend";
            }
        }
    }

    private static bool IsOutsideFrontendFilter(string relativePath)
    {
        bool isMarkdown = relativePath.EndsWith(value: ".md", comparisonType: StringComparison.OrdinalIgnoreCase);
        bool inApp = relativePath.StartsWith(value: AppFolder + "/", comparisonType: StringComparison.Ordinal);
        return relativePath.StartsWith(value: "src/backend/", comparisonType: StringComparison.Ordinal)
                || relativePath.StartsWith(value: "deploy/", comparisonType: StringComparison.Ordinal)
                || (isMarkdown && !inApp);
    }

    private static IEnumerable<string> FrontendCallerProblems(CiWorkflow entry, string jobId)
    {
        IReadOnlyDictionary<string, string> settings = entry.JobSettings(jobId: jobId);
        string expected = $"./.github/workflows/frontend-{jobId}.yml";
        if (!string.Equals(a: UsesOf(step: settings), b: expected, comparisonType: StringComparison.Ordinal))
        {
            yield return $"Job {jobId} of {FrontendEntryWorkflow} does not call {expected}";
        }

        if (settings.ContainsKey(key: "if") || settings.ContainsKey(key: "continue-on-error"))
        {
            yield return $"Job {jobId} of {FrontendEntryWorkflow} has a condition or continue-on-error";
        }
    }

    private static List<string> FrontendScriptProblems(CiWorkflowSet set, string jobId, string[] script, string? option)
    {
        string path = $".github/workflows/frontend-{jobId}.yml";
        CiWorkflow? workflow = set.FileAt(relativePath: path);
        if (workflow is null)
        {
            return [$"There is no {path}"];
        }

        List<string> findings = [.. UnconditionalJob(workflow: workflow, jobId: jobId)];
        IReadOnlyList<IReadOnlyDictionary<string, string>> steps = workflow.Steps(jobId: jobId);
        int setupIndex = IndexOfStepWhere(steps: steps, predicate: step => string.Equals(
                a: UsesOf(step: step),
                b: SetupFrontendAction,
                comparisonType: StringComparison.Ordinal));
        int scriptIndex = IndexOfStepWhere(
                steps: steps,
                predicate: step => ContainsSequence(words: RunWords(step: step), sequence: script));
        string command = string.Join(separator: " ", values: script);
        if (setupIndex < 0 || scriptIndex < setupIndex)
        {
            findings.Add(item: $"Job {jobId} of {path} does not use {SetupFrontendAction} and then run '{command}'");
            return findings;
        }

        findings.AddRange(collection: UnconditionalStep(step: steps[setupIndex], jobId: jobId));
        findings.AddRange(collection: UnconditionalStep(step: steps[scriptIndex], jobId: jobId));
        findings.AddRange(collection: StepSettingProblems(
                step: steps[scriptIndex],
                owner: $"'{command}' in job {jobId}",
                key: "working-directory",
                expected: AppFolder));
        if (option is not null && !RunWords(step: steps[scriptIndex]).Any(predicate: word => word.StartsWith(
                value: option,
                comparisonType: StringComparison.Ordinal)))
        {
            findings.Add(item: $"'{command}' in job {jobId} does not pass {option}");
        }

        return findings;
    }

    private static IEnumerable<string> E2eMatrixProblems(CiWorkflow entry)
    {
        IReadOnlyDictionary<string, string> settings = entry.JobSettings(jobId: "e2e");
        if (!string.Equals(
                a: settings.GetValueOrDefault(key: "strategy.fail-fast"),
                b: "false",
                comparisonType: StringComparison.Ordinal))
        {
            yield return $"Job e2e of {FrontendEntryWorkflow} does not set strategy.fail-fast to false";
        }

        IReadOnlyList<string> browsers = entry.ListValues(path: "jobs.e2e.strategy.matrix.browser");
        if (!browsers.SequenceEqual(second: _engines, comparer: StringComparer.Ordinal))
        {
            yield return $"Job e2e of {FrontendEntryWorkflow} runs on "
                    + $"{string.Join(separator: ", ", values: browsers)}, not exactly chromium, firefox and webkit";
        }

        if (!string.Equals(
                a: settings.GetValueOrDefault(key: "with.browser"),
                b: MatrixBrowser,
                comparisonType: StringComparison.Ordinal))
        {
            yield return $"Job e2e of {FrontendEntryWorkflow} does not pass browser: {MatrixBrowser}";
        }
    }

    private static List<string> SetupFrontendProblems(CiWorkflowSet set)
    {
        CiWorkflow? action = set.FileAt(relativePath: SetupFrontendFile);
        if (action is null)
        {
            return [$"There is no {SetupFrontendFile}"];
        }

        IReadOnlyList<IReadOnlyDictionary<string, string>> steps = action.ActionSteps();
        int pnpmIndex = IndexOfStepWhere(steps: steps, predicate: step => UsesOf(step: step).StartsWith(
                value: "pnpm/action-setup@",
                comparisonType: StringComparison.Ordinal));
        int nodeIndex = IndexOfStepWhere(steps: steps, predicate: step => UsesOf(step: step).StartsWith(
                value: "actions/setup-node@",
                comparisonType: StringComparison.Ordinal));
        int installIndex = IndexOfStepWhere(steps: steps, predicate: step => ContainsSequence(
                words: RunWords(step: step),
                sequence: ["pnpm", "install", "--frozen-lockfile"]));
        if (pnpmIndex < 0 || nodeIndex < pnpmIndex || installIndex < nodeIndex)
        {
            return [$"{SetupFrontendFile} does not set up pnpm, then Node, then run 'pnpm install --frozen-lockfile'"];
        }

        List<string> findings =
        [
            .. StepSettingProblems(
                    step: steps[pnpmIndex],
                    owner: "pnpm/action-setup",
                    key: "with.package_json_file",
                    expected: AppFolder + "/package.json"),
            .. StepSettingProblems(
                    step: steps[nodeIndex],
                    owner: "actions/setup-node",
                    key: "with.node-version-file",
                    expected: AppFolder + "/.node-version"),
            .. StepSettingProblems(
                    step: steps[nodeIndex],
                    owner: "actions/setup-node",
                    key: "with.cache",
                    expected: "pnpm"),
            .. StepSettingProblems(
                    step: steps[installIndex],
                    owner: "pnpm install",
                    key: "working-directory",
                    expected: AppFolder),
            .. steps.SelectMany(selector: step => UnconditionalStep(step: step, jobId: "setup-frontend")),
        ];
        if (steps.Any(predicate: step => step.ContainsKey(key: "with.node-version")))
        {
            findings.Add(item: $"{SetupFrontendFile} sets a literal node-version instead of reading .node-version");
        }

        return findings;
    }

    private static IEnumerable<string> StepSettingProblems(
            IReadOnlyDictionary<string, string> step,
            string owner,
            string key,
            string expected)
    {
        string? actual = step.GetValueOrDefault(key: key);
        if (!string.Equals(a: actual, b: expected, comparisonType: StringComparison.Ordinal))
        {
            yield return $"{owner} sets {key} to '{actual}', not '{expected}'";
        }
    }

    private static List<string> FindGateProblems(CiWorkflowSet set, CoverageGate gate)
    {
        CiWorkflow? workflow = set.FileAt(relativePath: gate.WorkflowPath);
        if (workflow is null)
        {
            return [$"There is no {gate.WorkflowPath}"];
        }

        List<string> findings = [.. UnconditionalJob(workflow: workflow, jobId: gate.JobId)];
        IReadOnlyList<IReadOnlyDictionary<string, string>> steps = workflow.Steps(jobId: gate.JobId);
        int testIndex = IndexOfStep(steps: steps, name: gate.TestStepName);
        int gateIndex = IndexOfStep(steps: steps, name: gate.GateStepName);
        if (testIndex < 0 || gateIndex < 0 || gateIndex < testIndex)
        {
            findings.Add(item: $"Job {gate.JobId} lacks '{gate.TestStepName}' followed by '{gate.GateStepName}'");
            return findings;
        }

        findings.AddRange(collection: UnconditionalStep(step: steps[testIndex], jobId: gate.JobId));
        findings.AddRange(collection: UnconditionalStep(step: steps[gateIndex], jobId: gate.JobId));
        IReadOnlyList<string> testWords = RunWords(step: steps[testIndex]);
        if (!ContainsSequence(words: testWords, sequence: ["--coverage", "--coverage-output-format", "cobertura"])
                || !ContainsSequence(words: testWords, sequence: ["--results-directory", gate.ResultsDirectory]))
        {
            findings.Add(item: $"'{gate.TestStepName}' does not write Cobertura coverage to {gate.ResultsDirectory}");
        }

        findings.AddRange(collection: GateActionProblems(set: set, gateStep: steps[gateIndex], gate: gate));
        return findings;
    }

    private static List<string> GateActionProblems(
            CiWorkflowSet set,
            IReadOnlyDictionary<string, string> gateStep,
            CoverageGate gate)
    {
        if (!string.Equals(
                a: gateStep.GetValueOrDefault(key: "uses"),
                b: CoverageGateAction,
                comparisonType: StringComparison.Ordinal))
        {
            return [$"'{gate.GateStepName}' does not use {CoverageGateAction}"];
        }

        IReadOnlyDictionary<string, string>? reportStep = (set.Expand(step: gateStep) ?? [])
                .FirstOrDefault(predicate: step => RunWords(step: step).Contains(
                        value: "reportgenerator",
                        comparer: StringComparer.Ordinal));
        if (reportStep is null)
        {
            return [$"{CoverageGateAction} has no step that runs reportgenerator"];
        }

        List<string> findings = [.. UnconditionalStep(step: reportStep, jobId: gate.JobId)];
        IReadOnlyList<string> gateWords = RunWords(step: reportStep);
        findings.AddRange(collection: gate.GateWords.Concat(second: _thresholdWords)
                .Where(predicate: word => !gateWords.Contains(value: word, comparer: StringComparer.Ordinal))
                .Select(selector: word => $"'{gate.GateStepName}' does not pass {word}"));
        findings.AddRange(collection: gateWords
                .Where(predicate: word => word.Contains(
                        value: "minimumCoverageThresholds",
                        comparisonType: StringComparison.Ordinal)
                        && !_thresholdWords.Contains(value: word, comparer: StringComparer.Ordinal))
                .Select(selector: word => $"'{gate.GateStepName}' passes the other threshold {word}"));
        return findings;
    }

    private static IEnumerable<string> UnconditionalJob(CiWorkflow workflow, string jobId)
    {
        if (!workflow.JobIds.Contains(value: jobId, comparer: StringComparer.Ordinal))
        {
            yield return $"The workflow has no {jobId} job";
            yield break;
        }

        IReadOnlyDictionary<string, string> settings = workflow.JobSettings(jobId: jobId);
        if (settings.ContainsKey(key: "if") || settings.ContainsKey(key: "continue-on-error"))
        {
            yield return $"Job {jobId} has a condition or continue-on-error";
        }
    }

    private static IEnumerable<string> UnconditionalStep(IReadOnlyDictionary<string, string> step, string jobId)
    {
        if (step.ContainsKey(key: "if") || step.ContainsKey(key: "continue-on-error"))
        {
            yield return $"Step '{step.GetValueOrDefault(key: "name")}' of job {jobId} has a condition or "
                    + "continue-on-error";
        }
    }

    private static int IndexOfStep(IReadOnlyList<IReadOnlyDictionary<string, string>> steps, string name)
    {
        return IndexOfStepWhere(steps: steps, predicate: step => string.Equals(
                a: step.GetValueOrDefault(key: "name"),
                b: name,
                comparisonType: StringComparison.Ordinal));
    }

    private static int IndexOfStepWhere(
            IReadOnlyList<IReadOnlyDictionary<string, string>> steps,
            Func<IReadOnlyDictionary<string, string>, bool> predicate)
    {
        for (int index = 0; index < steps.Count; index++)
        {
            if (predicate(steps[index]))
            {
                return index;
            }
        }

        return -1;
    }

    private static IReadOnlyList<string> RunWords(IReadOnlyDictionary<string, string> step)
    {
        return CiWorkflow.ShellWords(run: step.GetValueOrDefault(key: "run") ?? string.Empty);
    }

    private static bool ContainsSequence(IReadOnlyList<string> words, string[] sequence)
    {
        for (int start = 0; start + sequence.Length <= words.Count; start++)
        {
            if (sequence.Select(selector: (word, offset) => (word, offset))
                    .All(predicate: pair => string.Equals(
                            a: words[start + pair.offset],
                            b: pair.word,
                            comparisonType: StringComparison.Ordinal)))
            {
                return true;
            }
        }

        return false;
    }

    private static string DeployCommand(IReadOnlyDictionary<string, string> step)
    {
        string folder = step.GetValueOrDefault(key: "working-directory") ?? ".";
        IEnumerable<string> environment = step
                .Where(predicate: pair => pair.Key.StartsWith(value: "env.", comparisonType: StringComparison.Ordinal))
                .Select(selector: pair => $"{pair.Key["env.".Length..]}={pair.Value}");
        IEnumerable<string> lines = (step.GetValueOrDefault(key: "run") ?? string.Empty)
                .Split(separator: '\n')
                .Select(selector: line => string.Join(separator: " ", values: CiWorkflow.ShellWords(run: line)))
                .Where(predicate: line => line.Length > 0)
                .Select(selector: line => $"{folder}$ {line}");
        return string.Join(separator: "\n", values: environment.Concat(second: lines));
    }

    [GeneratedRegex(
            pattern: "^[A-Za-z0-9_.-]+/[A-Za-z0-9_./-]+@[0-9a-f]{40}$",
            options: RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex PinnedAction();

    [GeneratedRegex(
            pattern: @"\$\{\{\s*inputs\.",
            options: RegexOptions.CultureInvariant,
            matchTimeoutMilliseconds: 10000)]
    private static partial Regex InputsExpression();

    private sealed class CoverageGate
    {
        internal CoverageGate(
                string workflowPath,
                string jobId,
                string testStepName,
                string gateStepName,
                string resultsDirectory,
                IReadOnlyList<string> gateWords)
        {
            WorkflowPath = workflowPath;
            JobId = jobId;
            TestStepName = testStepName;
            GateStepName = gateStepName;
            ResultsDirectory = resultsDirectory;
            GateWords = gateWords;
        }

        internal string WorkflowPath { get; }

        internal string JobId { get; }

        internal string TestStepName { get; }

        internal string GateStepName { get; }

        internal string ResultsDirectory { get; }

        internal IReadOnlyList<string> GateWords { get; }
    }
}
