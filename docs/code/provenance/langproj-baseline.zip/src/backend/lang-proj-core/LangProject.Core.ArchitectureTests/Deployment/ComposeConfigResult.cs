namespace LangProject.Core.ArchitectureTests.Deployment;

/// <summary>
/// The outcome of one <c>docker compose config --format json</c> run: its exit code, its console output and the
/// rendered model.
/// </summary>
internal sealed class ComposeConfigResult
{
    /// <summary>Initializes a new instance of the <see cref="ComposeConfigResult"/> class.</summary>
    /// <param name="exitCode">The exit code of <c>docker compose</c>.</param>
    /// <param name="output">The standard output followed by the standard error.</param>
    /// <param name="json">The rendered model as JSON; empty when Compose wrote none.</param>
    internal ComposeConfigResult(int exitCode, string output, string json)
    {
        ExitCode = exitCode;
        Output = output;
        Json = json;
    }

    /// <summary>Gets the exit code of <c>docker compose</c>.</summary>
    internal int ExitCode { get; }

    /// <summary>Gets the standard output followed by the standard error.</summary>
    internal string Output { get; }

    /// <summary>Gets the rendered model as JSON; empty when Compose wrote none.</summary>
    internal string Json { get; }
}
