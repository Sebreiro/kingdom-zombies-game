using System;
using System.Collections.Generic;
using System.Linq;
using ArchUnitNET.Fluent.Syntax.Elements.Types;
using Architecture = ArchUnitNET.Domain.Architecture;

namespace LangProject.Core.ArchitectureTests.Types;

/// <summary>
/// One layer-purity rule in two parts: the ArchUnitNET dependency rule over the source-declared subjects, and the
/// same ban applied to the compiler-generated code of those subjects (<see cref="GeneratedCodeScanner"/>), which
/// ArchUnitNET does not always credit to them.
/// </summary>
internal sealed class PurityRule
{
    /// <summary>Initializes a new instance of the <see cref="PurityRule"/> class.</summary>
    /// <param name="rule">The ArchUnitNET rule over <paramref name="subjects"/>.</param>
    /// <param name="subjects">The source-declared subject types.</param>
    /// <param name="isForbidden">Tells whether a type used by generated code breaks the rule.</param>
    internal PurityRule(
            TypesShouldConjunction rule,
            IReadOnlyCollection<Type> subjects,
            Func<GeneratedDependency, bool> isForbidden)
    {
        Rule = rule;
        _subjects = subjects;
        _isForbidden = isForbidden;
    }

    /// <summary>Gets the ArchUnitNET part of the rule.</summary>
    internal TypesShouldConjunction Rule { get; }

    /// <summary>Evaluates both parts.</summary>
    /// <param name="architecture">The loaded assemblies that hold the subjects.</param>
    /// <returns>
    /// The ArchUnitNET failures followed by the generated-code violations; empty when the rule holds.
    /// </returns>
    internal IReadOnlyList<string> Violations(Architecture architecture)
    {
        IEnumerable<string> declared = Rule.Evaluate(architecture: architecture)
                .Where(predicate: result => !result.Passed)
                .Select(selector: result => result.Description);
        IEnumerable<string> generated = GeneratedCodeScanner.FindDependencies(subjects: _subjects)
                .Where(predicate: _isForbidden)
                .Select(selector: dependency => dependency.ToString())
                .Distinct(comparer: StringComparer.Ordinal)
                .Order(comparer: StringComparer.Ordinal);
        return [.. declared.Concat(second: generated)];
    }

    private readonly IReadOnlyCollection<Type> _subjects;

    private readonly Func<GeneratedDependency, bool> _isForbidden;
}
