using System.Threading.Tasks;
using Sebreiro.CodeRules.Analyzers.Tests.Verification;
using Xunit;

namespace Sebreiro.CodeRules.Analyzers.Tests;

/// <summary>
/// In-memory proofs of SCR0003: a primary constructor on a class or struct and a positional record class or record
/// struct fail, while a non-positional record and a class with an ordinary constructor pass.
/// </summary>
public sealed class PrimaryConstructorAnalyzerTests
{
    /// <summary>A class with a primary constructor is reported on its parameter list.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Class_PrimaryConstructor_Reports()
    {
        return VerifyAsync(source: """
                class C{|SCR0003:(int x)|}
                {
                    public int X => x;
                }
                """);
    }

    /// <summary>A class with an empty primary constructor parameter list is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Class_EmptyPrimaryConstructor_Reports()
    {
        return VerifyAsync(source: """
                class C{|SCR0003:()|}
                {
                }
                """);
    }

    /// <summary>A struct with a primary constructor is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Struct_PrimaryConstructor_Reports()
    {
        return VerifyAsync(source: """
                struct S{|SCR0003:(int x)|}
                {
                    public int X => x;
                }
                """);
    }

    /// <summary>A positional record and a positional record class are reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_PositionalRecord_Reports()
    {
        return VerifyAsync(source: """
                record R{|SCR0003:(int X)|};

                record class Q{|SCR0003:(int X)|};
                """);
    }

    /// <summary>A positional record struct is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_PositionalRecordStruct_Reports()
    {
        return VerifyAsync(source: """
                record struct P{|SCR0003:(int X)|};
                """);
    }

    /// <summary>A record with init properties and no parameter list passes.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_NonPositionalRecord_Passes()
    {
        return VerifyAsync(source: """
                record R
                {
                    public int X { get; init; }
                }

                record struct P
                {
                    public int X { get; init; }
                }
                """);
    }

    /// <summary>A class and a struct with ordinary constructors pass.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_OrdinaryConstructor_Passes()
    {
        return VerifyAsync(source: """
                class C
                {
                    private readonly int _x;

                    public C(int x)
                    {
                        _x = x;
                    }

                    public int X => _x;
                }

                struct S
                {
                    public S(int x)
                    {
                        X = x;
                    }

                    public int X { get; }
                }
                """);
    }

    /// <summary>
    /// The receiver parameter list of a C# 14 extension block is not a primary constructor and passes.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task ExtensionBlock_ReceiverParameter_Passes()
    {
        return VerifyAsync(source: """
                static class E
                {
                    extension(string s)
                    {
                        public int Doubled => s.Length * 2;
                    }
                }
                """);
    }

    private static Task VerifyAsync(string source)
    {
        return AnalyzerVerifier.VerifyAsync<PrimaryConstructorAnalyzer>(source: source);
    }
}
