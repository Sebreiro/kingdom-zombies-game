using System.Threading.Tasks;
using Microsoft.CodeAnalysis.Testing;
using Sebreiro.CodeRules.Analyzers.Tests.Verification;
using Xunit;

namespace Sebreiro.CodeRules.Analyzers.Tests;

/// <summary>
/// In-memory proofs of SCR0008: members run by access first (public, internal, protected internal, protected,
/// private protected, private), then by kind (constants, fields, constructors, properties, indexers, events,
/// methods, operators), with nested types last. The first member that breaks the order is reported, once per
/// type declaration part.
/// </summary>
public sealed class MemberOrderAnalyzerTests
{
    /// <summary>The full D-27 order passes.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_FullOrder_Passes()
    {
        return VerifyAsync(source: """
                using System;

                class C
                {
                    public const int Max = 1;
                    public int Field;
                    public C() { }
                    public int Property { get; set; }
                    public int this[int index] => index;
                    public event Action Changed;
                    public void Method() { }
                    public static C operator +(C left, C right) => left;
                    public static implicit operator int(C value) => 0;
                    internal const int InternalMax = 1;
                    internal int _internalField;
                    internal C(int value) { }
                    internal int InternalProperty { get; set; }
                    internal void InternalMethod() { }
                    protected int _protectedField;
                    protected void ProtectedMethod() { }
                    private const int PrivateMax = 1;
                    private int _privateField;
                    private C(string value) { }
                    private int PrivateProperty { get; set; }
                    private event Action PrivateChanged;
                    private void PrivateMethod() { }
                    private sealed class Nested { }
                    public enum Kind { None }
                    public delegate void Handler();
                }
                """);
    }

    /// <summary>A private field declared before a public method is reported on the method.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_PrivateFieldBeforePublicMethod_Reports()
    {
        return VerifyAsync(source: """
                class C
                {
                    private int _value;

                    public void {|SCR0008:Method|}()
                    {
                    }
                }
                """);
    }

    /// <summary>A public property after a public method is reported on the property.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_PublicPropertyAfterPublicMethod_Reports()
    {
        return VerifyAsync(source: """
                class C
                {
                    public void Method()
                    {
                    }

                    public int {|SCR0008:Property|} { get; set; }
                }
                """);
    }

    /// <summary>A constructor after a property of the same access is reported on the constructor.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task ConstructorAfterProperty_SameAccess_Reports()
    {
        return VerifyAsync(source: """
                class C
                {
                    public int Property { get; set; }

                    public {|SCR0008:C|}()
                    {
                    }
                }
                """);
    }

    /// <summary>A nested type before a member is reported on the member, whatever the access of either.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_NestedTypeBeforeMember_Reports()
    {
        return VerifyAsync(source: """
                class C
                {
                    public sealed class Nested
                    {
                    }

                    private int {|SCR0008:_value|};
                }
                """);
    }

    /// <summary>Nested types come last in any access order, and each one's own members are checked.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task NestedTypes_AnyAccessOrder_PassAndAreCheckedThemselves()
    {
        return VerifyAsync(source: """
                class C
                {
                    public void Method()
                    {
                    }

                    private sealed class First
                    {
                        private int _value;

                        public void {|SCR0008:Method|}()
                        {
                        }
                    }

                    public interface ISecond
                    {
                    }
                }
                """);
    }

    /// <summary>
    /// The six access levels run public, internal, protected internal, protected, private protected, private.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task AllSixAccessLevels_InOrder_Pass()
    {
        return VerifyAsync(source: """
                class C
                {
                    public void A()
                    {
                    }

                    internal void B()
                    {
                    }

                    protected internal void C1()
                    {
                    }

                    internal protected void C2()
                    {
                    }

                    protected void D()
                    {
                    }

                    private protected void E()
                    {
                    }

                    private void F()
                    {
                    }

                    void G()
                    {
                    }
                }
                """);
    }

    /// <summary>A protected internal member after a protected one is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_ProtectedInternalAfterProtected_Reports()
    {
        return VerifyAsync(source: """
                class C
                {
                    protected void D()
                    {
                    }

                    protected internal void {|SCR0008:C1|}()
                    {
                    }
                }
                """);
    }

    /// <summary>A protected member after a private protected one is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_ProtectedAfterPrivateProtected_Reports()
    {
        return VerifyAsync(source: """
                class C
                {
                    private protected void E()
                    {
                    }

                    protected void {|SCR0008:D|}()
                    {
                    }
                }
                """);
    }

    /// <summary>A member with no access modifier in a class is private.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_NoModifierInClass_IsPrivate()
    {
        return VerifyAsync(source: """
                class C
                {
                    void Method()
                    {
                    }

                    internal void {|SCR0008:Other|}()
                    {
                    }
                }
                """);
    }

    /// <summary>An explicit interface implementation ranks as public, so it may sit among the public methods.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_ExplicitInterfaceImplementation_RanksAsPublic()
    {
        return VerifyAsync(source: """
                using System;

                class C : IDisposable
                {
                    public void Method()
                    {
                    }

                    void IDisposable.Dispose()
                    {
                    }

                    internal void Other()
                    {
                    }
                }
                """);
    }

    /// <summary>An explicit interface implementation after an internal member is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_ExplicitInterfaceImplementationAfterInternal_Reports()
    {
        return VerifyAsync(source: """
                using System;

                class C : IDisposable
                {
                    internal void Other()
                    {
                    }

                    void IDisposable.{|SCR0008:Dispose|}()
                    {
                    }
                }
                """);
    }

    /// <summary>A member with no access modifier in an interface is public.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_InterfaceMembers_ArePublicAndChecked()
    {
        return VerifyAsync(source: """
                interface I
                {
                    void Method();

                    int {|SCR0008:Property|} { get; }
                }
                """);
    }

    /// <summary>Structs, records and record structs are checked like classes.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_StructAndRecords_AreChecked()
    {
        return VerifyAsync(source: """
                struct S
                {
                    public void Method()
                    {
                    }

                    public int {|SCR0008:Field|};
                }

                record R
                {
                    public void Method()
                    {
                    }

                    public int {|SCR0008:Property|} { get; init; }
                }

                record struct Q
                {
                    private int _value;

                    public const int {|SCR0008:Max|} = 1;
                }
                """);
    }

    /// <summary>A static constructor has no access modifier, so it ranks as a private constructor.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_StaticConstructor_RanksAsPrivateConstructor()
    {
        return VerifyAsync(source: """
                class C
                {
                    private static readonly int _value;

                    static C()
                    {
                        _value = 1;
                    }

                    public void {|SCR0008:Method|}()
                    {
                    }
                }
                """);
    }

    /// <summary>
    /// Each part of a partial type is checked on its own: two parts that are each in order pass, even though their
    /// members taken together are not.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_PartialParts_AreCheckedOnTheirOwn()
    {
        return VerifyAsync(source: """
                partial class C
                {
                    private int _value;
                }

                partial class C
                {
                    public void Method()
                    {
                    }

                    private void Other()
                    {
                    }
                }

                partial class C
                {
                    private void Third()
                    {
                    }

                    public void {|SCR0008:Fourth|}()
                    {
                    }
                }
                """);
    }

    /// <summary>Only the first member out of order is reported in a type declaration part.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_SeveralViolations_OnlyTheFirstIsReported()
    {
        return VerifyAsync(source: """
                class C
                {
                    private int _value;

                    public void {|SCR0008:Method|}()
                    {
                    }

                    private int _other;

                    public void Second()
                    {
                    }
                }
                """);
    }

    /// <summary>The message names both members and their access and kind.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_Message_NamesBothMembers()
    {
        return AnalyzerVerifier.VerifyAsync<MemberOrderAnalyzer>(
                source: """
                        class C
                        {
                            private int _value;

                            public void Method()
                            {
                            }
                        }
                        """,
                expected: new DiagnosticResult(descriptor: MemberOrderAnalyzer.Rule)
                        .WithSpan(startLine: 5, startColumn: 17, endLine: 5, endColumn: 23)
                        .WithArguments("Method", "public method", "_value", "private field"));
    }

    /// <summary>
    /// A C# 14 extension block takes no place in the order: one between a public method and a private field
    /// passes.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task ExtensionBlock_BetweenMembers_Passes()
    {
        return VerifyAsync(source: """
                static class E
                {
                    public static int Twice(int value)
                    {
                        return value * 2;
                    }

                    extension(string s)
                    {
                        public int Doubled => Twice(value: s.Length);
                    }

                    private static int _count;
                }
                """);
    }

    /// <summary>A private method before a public method inside an extension block is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task ExtensionBlock_PrivateBeforePublic_Reports()
    {
        return VerifyAsync(source: """
                static class E
                {
                    extension(string s)
                    {
                        private int Helper()
                        {
                            return s.Length;
                        }

                        public int {|SCR0008:Run|}()
                        {
                            return s.Helper();
                        }
                    }
                }
                """);
    }

    /// <summary>
    /// A member with no access modifier inside an extension block ranks as private, so an internal method after it
    /// is reported.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task ExtensionBlock_NoModifier_RanksAsPrivate()
    {
        return AnalyzerVerifier.VerifyAsync<MemberOrderAnalyzer>(
                source: """
                        static class E
                        {
                            extension(string s)
                            {
                                int Helper()
                                {
                                    return s.Length;
                                }

                                internal int Run()
                                {
                                    return s.Helper();
                                }
                            }
                        }
                        """,
                expected: new DiagnosticResult(descriptor: MemberOrderAnalyzer.Rule)
                        .WithSpan(startLine: 10, startColumn: 22, endLine: 10, endColumn: 25)
                        .WithArguments("Run", "internal method", "Helper", "private method"));
    }

    /// <summary>Code marked <c>generated_code = true</c> in an <c>.editorconfig</c> is not checked.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_GeneratedCode_IsSkipped()
    {
        return AnalyzerVerifier.VerifyAsync<MemberOrderAnalyzer>(
                source: """
                        class C
                        {
                            private int _value;

                            public void Method()
                            {
                            }
                        }
                        """,
                editorConfig: """
                        root = true

                        [*.cs]
                        generated_code = true
                        """);
    }

    private static Task VerifyAsync(string source)
    {
        return AnalyzerVerifier.VerifyAsync<MemberOrderAnalyzer>(source: source);
    }
}
