using System;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.Formatting;
using Microsoft.CodeAnalysis.Text;
using Sebreiro.CodeRules.Analyzers.Tests.Verification;
using Shouldly;
using Xunit;

namespace Sebreiro.CodeRules.Analyzers.Tests;

/// <summary>
/// In-memory proofs of SCR0009 for every continuation kind agreed in plan 01-06: the continuation line passes at
/// 8 spaces past the line it continues and fails at 4 or 12. The block layouts SCR0009 owns (block-lambda braces,
/// collection-expression brackets and elements) pass at their agreed indent and fail elsewhere. Kinds left to
/// IDE0055 or never checked are not reported at any indent. Each sample is a template: <c>~</c> stands for the
/// offset under test and <c>«</c>…<c>»</c> wraps each token that must be reported when the offset is wrong.
/// </summary>
public sealed class ContinuationIndentAnalyzerTests
{
    /// <summary>Wrapped arguments, each on its own line, pass at 8 spaces past the line holding the <c>(</c>.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task WrappedArgument_8Spaces_Passes()
    {
        return PassesAsync(template: WrappedArgument, offset: 8);
    }

    /// <summary>Wrapped arguments at 4 or 12 spaces fail, each on its first token.</summary>
    /// <param name="offset">The indent past the line holding the <c>(</c>.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task WrappedArgument_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: WrappedArgument, offset: offset);
    }

    /// <summary>A wrapped attribute argument passes at 8 spaces past the attribute's line.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task WrappedAttributeArgument_8Spaces_Passes()
    {
        return PassesAsync(template: WrappedAttributeArgument, offset: 8);
    }

    /// <summary>A wrapped attribute argument at 4 or 12 spaces fails.</summary>
    /// <param name="offset">The indent past the attribute's line.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task WrappedAttributeArgument_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: WrappedAttributeArgument, offset: offset);
    }

    /// <summary>Wrapped parameters pass at 8 spaces past the declaration's line.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task WrappedParameter_8Spaces_Passes()
    {
        return PassesAsync(template: WrappedParameter, offset: 8);
    }

    /// <summary>Wrapped parameters at 4 or 12 spaces fail.</summary>
    /// <param name="offset">The indent past the declaration's line.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task WrappedParameter_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: WrappedParameter, offset: offset);
    }

    /// <summary>Fluent-chain lines pass at 8 spaces past the line that starts the chain.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task FluentChain_8Spaces_Passes()
    {
        return PassesAsync(template: FluentChain, offset: 8);
    }

    /// <summary>Fluent-chain lines at 4 or 12 spaces fail, on their <c>.</c>.</summary>
    /// <param name="offset">The indent past the line that starts the chain.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task FluentChain_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: FluentChain, offset: offset);
    }

    /// <summary>A <c>?.</c> chain line passes at 8 spaces past the line that starts the chain.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task ConditionalAccessChain_8Spaces_Passes()
    {
        return PassesAsync(template: ConditionalAccessChain, offset: 8);
    }

    /// <summary>A <c>?.</c> chain line at 4 or 12 spaces fails, on its <c>?</c>.</summary>
    /// <param name="offset">The indent past the line that starts the chain.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task ConditionalAccessChain_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: ConditionalAccessChain, offset: offset);
    }

    /// <summary>
    /// Several <c>?.</c> and <c>?[</c> steps, each on its own line, all pass at 8 spaces past the line that starts
    /// the chain, not one more level for each step.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task ConditionalAccessSteps_8Spaces_Passes()
    {
        return PassesAsync(template: ConditionalAccessSteps, offset: 8);
    }

    /// <summary>Several <c>?.</c> and <c>?[</c> steps at 4 or 12 spaces fail, each on its <c>?</c>.</summary>
    /// <param name="offset">The indent past the line that starts the chain.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task ConditionalAccessSteps_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: ConditionalAccessSteps, offset: offset);
    }

    /// <summary>
    /// A <c>.</c> line after a <c>?.</c> line passes at 8 spaces past the line that starts the chain.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task MixedChain_8Spaces_Passes()
    {
        return PassesAsync(template: MixedChain, offset: 8);
    }

    /// <summary>A chain mixing <c>.</c> and <c>?.</c> lines at 4 or 12 spaces fails on every line.</summary>
    /// <param name="offset">The indent past the line that starts the chain.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task MixedChain_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: MixedChain, offset: offset);
    }

    /// <summary>A line starting with a binary operator passes at 8 spaces past the left operand's line.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task LeadingBinaryOperator_8Spaces_Passes()
    {
        return PassesAsync(template: LeadingBinaryOperator, offset: 8);
    }

    /// <summary>A line starting with a binary operator at 4 or 12 spaces fails.</summary>
    /// <param name="offset">The indent past the left operand's line.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task LeadingBinaryOperator_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: LeadingBinaryOperator, offset: offset);
    }

    /// <summary>The right operand after a trailing binary operator passes at 8 spaces.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task TrailingBinaryOperator_8Spaces_Passes()
    {
        return PassesAsync(template: TrailingBinaryOperator, offset: 8);
    }

    /// <summary>The right operand after a trailing binary operator at 4 or 12 spaces fails.</summary>
    /// <param name="offset">The indent past the left operand's line.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task TrailingBinaryOperator_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: TrailingBinaryOperator, offset: offset);
    }

    /// <summary>A wrapped <c>if (</c> condition passes at 8 spaces past the <c>if</c> line.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task WrappedIfCondition_8Spaces_Passes()
    {
        return PassesAsync(template: WrappedIfCondition, offset: 8);
    }

    /// <summary>A wrapped <c>if (</c> condition at 4 or 12 spaces fails.</summary>
    /// <param name="offset">The indent past the <c>if</c> line.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task WrappedIfCondition_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: WrappedIfCondition, offset: offset);
    }

    /// <summary>The <c>?</c> and <c>:</c> lines of a conditional operator pass at 8 spaces.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task ConditionalOperator_8Spaces_Passes()
    {
        return PassesAsync(template: ConditionalOperator, offset: 8);
    }

    /// <summary>The <c>?</c> and <c>:</c> lines at 4 or 12 spaces both fail.</summary>
    /// <param name="offset">The indent past the condition's line.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task ConditionalOperator_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: ConditionalOperator, offset: offset);
    }

    /// <summary>A constructor initializer passes at 8 spaces past the constructor's first line.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task ConstructorInitializer_8Spaces_Passes()
    {
        return PassesAsync(template: ConstructorInitializer, offset: 8);
    }

    /// <summary>A constructor initializer at 4 or 12 spaces fails.</summary>
    /// <param name="offset">The indent past the constructor's first line.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task ConstructorInitializer_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: ConstructorInitializer, offset: offset);
    }

    /// <summary>A <c>where</c> clause passes at 8 spaces past the declaration's first line.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task WhereClause_8Spaces_Passes()
    {
        return PassesAsync(template: WhereClause, offset: 8);
    }

    /// <summary>A <c>where</c> clause at 4 or 12 spaces fails.</summary>
    /// <param name="offset">The indent past the declaration's first line.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task WhereClause_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: WhereClause, offset: offset);
    }

    /// <summary>A value on the line after <c>=</c> in a declaration passes at 8 spaces.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task ValueAfterEquals_8Spaces_Passes()
    {
        return PassesAsync(template: ValueAfterEquals, offset: 8);
    }

    /// <summary>A value on the line after <c>=</c> in a declaration at 4 or 12 spaces fails.</summary>
    /// <param name="offset">The indent past the line holding the <c>=</c>.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task ValueAfterEquals_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: ValueAfterEquals, offset: offset);
    }

    /// <summary>A value on the line after an assignment's <c>=</c> passes at 8 spaces.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task ValueAfterAssignment_8Spaces_Passes()
    {
        return PassesAsync(template: ValueAfterAssignment, offset: 8);
    }

    /// <summary>A value on the line after an assignment's <c>=</c> at 4 or 12 spaces fails.</summary>
    /// <param name="offset">The indent past the line holding the <c>=</c>.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task ValueAfterAssignment_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: ValueAfterAssignment, offset: offset);
    }

    /// <summary>A value on the line after <c>return</c> passes at 8 spaces.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task ValueAfterReturn_8Spaces_Passes()
    {
        return PassesAsync(template: ValueAfterReturn, offset: 8);
    }

    /// <summary>A value on the line after <c>return</c> at 4 or 12 spaces fails.</summary>
    /// <param name="offset">The indent past the <c>return</c> line.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task ValueAfterReturn_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: ValueAfterReturn, offset: offset);
    }

    /// <summary>An expression-bodied member's <c>=&gt;</c> on the next line passes at 8 spaces.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task ExpressionBodyArrow_8Spaces_Passes()
    {
        return PassesAsync(template: ExpressionBodyArrow, offset: 8);
    }

    /// <summary>An expression-bodied member's <c>=&gt;</c> at 4 or 12 spaces fails.</summary>
    /// <param name="offset">The indent past the member's first line.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task ExpressionBodyArrow_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: ExpressionBodyArrow, offset: offset);
    }

    /// <summary>A base list on the next line passes at 8 spaces past the type's first line.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task BaseList_8Spaces_Passes()
    {
        return PassesAsync(template: BaseList, offset: 8);
    }

    /// <summary>A base list on the next line at 4 or 12 spaces fails.</summary>
    /// <param name="offset">The indent past the type's first line.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task BaseList_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: BaseList, offset: offset);
    }

    /// <summary>A lambda expression body on the line after <c>=&gt;</c> passes at 8 spaces.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task LambdaExpressionBody_8Spaces_Passes()
    {
        return PassesAsync(template: LambdaExpressionBody, offset: 8);
    }

    /// <summary>A lambda expression body on the line after <c>=&gt;</c> at 4 or 12 spaces fails.</summary>
    /// <param name="offset">The indent past the line holding the <c>=&gt;</c>.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(12)]
    public Task LambdaExpressionBody_4Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: LambdaExpressionBody, offset: offset);
    }

    /// <summary>Block-lambda braces pass at the indent of the line where the lambda starts.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task BlockLambdaBraces_AtLambdaLineIndent_Passes()
    {
        return PassesAsync(template: BlockLambdaBraces, offset: 0);
    }

    /// <summary>Block-lambda braces 4 or 8 spaces past the lambda's line fail, both of them.</summary>
    /// <param name="offset">The indent past the line where the lambda starts.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(8)]
    public Task BlockLambdaBraces_4Or8Spaces_Fails(int offset)
    {
        return FailsAsync(template: BlockLambdaBraces, offset: offset);
    }

    /// <summary>A collection expression's <c>[</c> on the line after <c>=</c> passes at that line's indent.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task CollectionOpenBracket_AtEqualsLineIndent_Passes()
    {
        return PassesAsync(template: CollectionOpenBracket, offset: 0);
    }

    /// <summary>A collection expression's <c>[</c> 4 or 8 spaces past the <c>=</c> line fails.</summary>
    /// <param name="offset">The indent past the line holding the <c>=</c>.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(4)]
    [InlineData(8)]
    public Task CollectionOpenBracket_4Or8Spaces_Fails(int offset)
    {
        return FailsAsync(template: CollectionOpenBracket, offset: offset);
    }

    /// <summary>
    /// A collection expression on one line after <c>=</c> has no block layout: it is a value and passes at 8 spaces.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task OneLineCollectionAfterEquals_8Spaces_Passes()
    {
        return PassesAsync(template: OneLineCollection, offset: 8);
    }

    /// <summary>A one-line collection expression after <c>=</c> at 0 or 12 spaces fails.</summary>
    /// <param name="offset">The indent past the line holding the <c>=</c>.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(0)]
    [InlineData(12)]
    public Task OneLineCollectionAfterEquals_0Or12Spaces_Fails(int offset)
    {
        return FailsAsync(template: OneLineCollection, offset: offset);
    }

    /// <summary>Collection-expression elements pass at 4 spaces past the line holding the <c>[</c>.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task CollectionElement_4Spaces_Passes()
    {
        return PassesAsync(template: CollectionElement, offset: 4);
    }

    /// <summary>A collection-expression element at 0 or 8 spaces past the <c>[</c> line fails.</summary>
    /// <param name="offset">The indent past the line holding the <c>[</c>.</param>
    /// <returns>A task that completes when the verification has run.</returns>
    [Theory]
    [InlineData(0)]
    [InlineData(8)]
    public Task CollectionElement_0Or8Spaces_Fails(int offset)
    {
        return FailsAsync(template: CollectionElement, offset: offset);
    }

    /// <summary>A collection expression's <c>]</c> passes at the indent of the line holding the <c>[</c>.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task CollectionCloseBracket_AtOpenLineIndent_Passes()
    {
        return PassesAsync(template: CollectionCloseBracket, offset: 0);
    }

    /// <summary>A collection expression's <c>]</c> 4 spaces past the <c>[</c> line fails.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task CollectionCloseBracket_4Spaces_Fails()
    {
        return FailsAsync(template: CollectionCloseBracket, offset: 4);
    }

    /// <summary>
    /// Nested continuations are measured from the line they continue: inner arguments sit 8 spaces past the line
    /// holding their own <c>(</c>, and a chain inside a lambda 8 spaces past that chain's first line.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task NestedContinuations_8SpacesPastTheirOwnLine_Pass()
    {
        return VerifyAsync(source: NestedContinuations);
    }

    /// <summary>An inner wrapped argument at the outer argument's indent fails.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task NestedArgument_AtOuterIndent_Fails()
    {
        return VerifyAsync(source: """
                class C
                {
                    int M(int first, int second)
                    {
                        return M(
                                first: M(
                                {|SCR0009:first|}: 1,
                                {|SCR0009:second|}: 2),
                                second: 3);
                    }
                }
                """);
    }

    /// <summary>Object and collection initializers and anonymous objects are left to IDE0055.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Initializers_AnyIndent_NotReported()
    {
        return VerifyAsync(source: Initializers);
    }

    /// <summary>Switch-expression braces and arms and query clauses are left to IDE0055.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task SwitchExpressionAndQuery_AnyIndent_NotReported()
    {
        return VerifyAsync(source: SwitchExpressionAndQuery);
    }

    /// <summary>Lines inside multi-line string literals, raw, verbatim and interpolated, are never checked.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task StringLiteralLines_AnyIndent_NotReported()
    {
        return VerifyAsync(source: StringLiteralLines);
    }

    /// <summary>
    /// Kinds outside the agreed list are not reported: a closing parenthesis on its own line, a member's value on
    /// the line after its <c>=&gt;</c>, wrapped type arguments and statements.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task OtherKinds_AnyIndent_NotReported()
    {
        return VerifyAsync(source: OtherKinds);
    }

    /// <summary>
    /// A file holding every agreed kind at its agreed indent is left unchanged by the Roslyn formatter, which is
    /// what IDE0055 checks, and SCR0009 reports nothing in it: the two rules never conflict.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task AgreedSamples_FormatterLeavesUnchanged_AndNotReported()
    {
        return FormatterAgreesAsync(source: AgreedSamples);
    }

    /// <summary>Code marked <c>generated_code = true</c> in an <c>.editorconfig</c> is not checked.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_GeneratedCode_IsSkipped()
    {
        return AnalyzerVerifier.VerifyAsync<ContinuationIndentAnalyzer>(
                source: Sample(template: WrappedArgument, offset: 4, marked: false),
                editorConfig: """
                        root = true

                        [*.cs]
                        generated_code = true
                        """);
    }

    private const StringComparison Ordinal = StringComparison.Ordinal;

    private const string WrappedArgument = """
        class C
        {
            int M(int first, int second)
            {
                return M(
                ~«first»: 1,
                ~«second»: 2);
            }
        }
        """;

    private const string WrappedAttributeArgument = """
        using System;

        class C
        {
            [Obsolete("Old.",
            ~«true»)]
            void M()
            {
            }
        }
        """;

    private const string WrappedParameter = """
        class C
        {
            void M(
            ~«int» first,
            ~«int» second)
            {
            }
        }
        """;

    private const string FluentChain = """
        using System.Linq;

        class C
        {
            object M(int[] items)
            {
                return items
                ~«.»Where(predicate: i => i > 0)
                ~«.»ToList();
            }
        }
        """;

    private const string ConditionalAccessChain = """
        class C
        {
            string M(object value)
            {
                return value
                ~«?».ToString();
            }
        }
        """;

    private const string ConditionalAccessSteps = """
        class C
        {
            string M(string[] items)
            {
                return items
                ~«?»[0]
                ~«?».Trim()
                ~«?».ToUpperInvariant();
            }
        }
        """;

    private const string MixedChain = """
        using System.Linq;

        class C
        {
            string M(string[] items)
            {
                return items
                ~«.»FirstOrDefault()
                ~«?».Trim()
                ~«.»ToUpperInvariant();
            }
        }
        """;

    private const string LeadingBinaryOperator = """
        class C
        {
            bool M(int a, int b)
            {
                return a > 0
                ~«&&» b > 0;
            }
        }
        """;

    private const string TrailingBinaryOperator = """
        class C
        {
            bool M(int a, int b)
            {
                return a > 0 &&
                ~«b» > 0;
            }
        }
        """;

    private const string WrappedIfCondition = """
        class C
        {
            bool M(int a, int b)
            {
                if (a > 0
                ~«||» b > 0)
                {
                    return true;
                }

                return false;
            }
        }
        """;

    private const string ConditionalOperator = """
        class C
        {
            int M(int a, int b)
            {
                return a > b
                ~«?» a
                ~«:» b;
            }
        }
        """;

    private const string ConstructorInitializer = """
        class B
        {
            public B(int value)
            {
            }
        }

        class C : B
        {
            public C(int value)
            ~«:» base(value: value)
            {
            }
        }
        """;

    private const string WhereClause = """
        class C
        {
            T Make<T>()
            ~«where» T : new()
            {
                return new T();
            }
        }
        """;

    private const string ValueAfterEquals = """
        class C
        {
            int M()
            {
                int value =
                ~«M»();
                return value;
            }
        }
        """;

    private const string ValueAfterAssignment = """
        class C
        {
            int M()
            {
                int value;
                value =
                ~«M»();
                return value;
            }
        }
        """;

    private const string ValueAfterReturn = """
        class C
        {
            int M()
            {
                return
                ~«M»();
            }
        }
        """;

    private const string ExpressionBodyArrow = """
        class C
        {
            int Value
            ~«=>» 1;
        }
        """;

    private const string BaseList = """
        using System;

        class C
        ~«:» IDisposable
        {
            public void Dispose()
            {
            }
        }
        """;

    private const string LambdaExpressionBody = """
        using System;

        class C
        {
            void M()
            {
                Func<int, int> f = v =>
                ~«v» + 1;
            }
        }
        """;

    private const string BlockLambdaBraces = """
        using System;

        class C
        {
            void M()
            {
                Func<int, int> f = v =>
                ~«{»
                ~    return v + 1;
                ~«}»;
            }
        }
        """;

    private const string CollectionOpenBracket = """
        class C
        {
            int[] M()
            {
                int[] values =
                ~«[»
                ~    1,
                ~];
                return values;
            }
        }
        """;

    private const string OneLineCollection = """
        class C
        {
            private static readonly string[] _names =
            ~«[»"a", "b"];
        }
        """;

    private const string CollectionElement = """
        class C
        {
            int[] M()
            {
                int[] values = [
                    1,
                ~«2»,
                ];
                return values;
            }
        }
        """;

    private const string CollectionCloseBracket = """
        class C
        {
            int[] M()
            {
                int[] values = [
                    1,
                ~«]»;
                return values;
            }
        }
        """;

    private const string NestedContinuations = """
        using System;
        using System.Linq;

        class C
        {
            int M(int first, int second)
            {
                return M(
                        first: M(
                                first: 1,
                                second: 2),
                        second: 3);
            }

            object N(int[] items)
            {
                Run(
                        action: () =>
                        {
                            Run(action: () => { });
                        });
                return items
                        .Select(selector: i => i
                                .ToString())
                        .Select(selector: s =>
                        {
                            return s.Length;
                        })
                        .ToList();
            }

            void Run(Action action)
            {
            }
        }
        """;

    private const string Initializers = """
        using System.Collections.Generic;

        class C
        {
            public int Value { get; set; }

            object M()
            {
                var list = new List<int>
                      {
                   1,
                         };
                var anonymous = new
                     {
                   Value = 1,
                        };
                return new C
                           {
                Value =
             2,
                };
            }
        }
        """;

    private const string SwitchExpressionAndQuery = """
        using System.Linq;

        class C
        {
            object M(int value, int[] items)
            {
                int result = value switch
                     {
                   1 => 2,
                          _ => 0,
                 };
                var query = from i in items
                   where i > result
                             select i;
                return query;
            }
        }
        """;

    private const string StringLiteralLines = """"
        class C
        {
            string M(int count)
            {
                string raw = """
                  text
                       more
                  """;
                string verbatim = @"
           verbatim
         ";
                return $"""
            {count}
                {raw
              + verbatim}
            """;
            }
        }
        """";

    private const string OtherKinds = """
        using System.Collections.Generic;

        class C
        {
            int Value =>
                       1;

            int M(int first)
            {
                Dictionary<
              int,
                     string> map = [];
                    return M(
                            first: 1
           );
            }
        }
        """;

    private const string AgreedSamples = """
        using System;
        using System.Linq;

        internal class B
        {
            public B(int value)
            {
            }
        }

        [Obsolete("Old.",
                true)]
        internal sealed class C
                : B, IDisposable
        {
            public C(
                    int value,
                    int other)
                    : base(value: value)
            {
            }

            public int Value
                    => 1;

            public static T Make<T>()
                    where T : new()
            {
                return new T();
            }

            public void Dispose()
            {
            }

            public object M(int[] items, int a, int b)
            {
                int value =
                        Compute(
                                first: a,
                                second: b);
                bool ok = a > 0
                        && b > 0;
                bool also = a > 0 &&
                        b > 0;
                int pick = a > b
                        ? a
                        : b;
                Func<int, int> f = v =>
                        v + 1;
                Func<int, int> g = v =>
                {
                    return v + 1;
                };
                int[] values =
                [
                    value,
                    pick,
                ];
                if (ok
                        || also)
                {
                    value =
                            f(value) + g(pick);
                }

                return items
                        .Where(predicate: i => i > value)
                        .Select(selector: i =>
                        {
                            return i + values.Length;
                        })
                        .ToList();
            }

            public string N(object value)
            {
                return
                        value
                                ?.ToString() ?? string.Empty;
            }

            public string O(string[] items)
            {
                return items
                        ?[0]
                        ?.Trim()
                        ?.ToUpperInvariant();
            }

            public string P(string[] items)
            {
                return items
                        .FirstOrDefault()
                        ?.Trim()
                        .ToUpperInvariant();
            }

            private static int Compute(int first, int second)
            {
                return first + second;
            }
        }
        """;

    private static Task PassesAsync(string template, int offset)
    {
        return VerifyAsync(source: Sample(template: template, offset: offset, marked: false));
    }

    private static Task FailsAsync(string template, int offset)
    {
        return VerifyAsync(source: Sample(template: template, offset: offset, marked: true));
    }

    private static string Sample(string template, int offset, bool marked)
    {
        string open = marked ? "{|SCR0009:" : string.Empty;
        string close = marked ? "|}" : string.Empty;
        return template
                .Replace(oldValue: "~", newValue: new string(c: ' ', count: offset), comparisonType: Ordinal)
                .Replace(oldValue: "«", newValue: open, comparisonType: Ordinal)
                .Replace(oldValue: "»", newValue: close, comparisonType: Ordinal);
    }

    private static async Task FormatterAgreesAsync(string source)
    {
        string formatted = await FormatAsync(source: source).ConfigureAwait(continueOnCapturedContext: false);
        formatted.ShouldBe(expected: source);
        await VerifyAsync(source: source).ConfigureAwait(continueOnCapturedContext: false);
    }

    private static async Task<string> FormatAsync(string source)
    {
        using var workspace = new AdhocWorkspace();
        Document document = workspace
                .AddProject(name: "Samples", language: LanguageNames.CSharp)
                .AddDocument(name: "Samples.cs", text: SourceText.From(text: source));
        Document formatted = await Formatter
                .FormatAsync(document: document, cancellationToken: TestContext.Current.CancellationToken)
                .ConfigureAwait(continueOnCapturedContext: false);
        SourceText text = await formatted
                .GetTextAsync(cancellationToken: TestContext.Current.CancellationToken)
                .ConfigureAwait(continueOnCapturedContext: false);
        return text.ToString();
    }

    private static Task VerifyAsync(string source)
    {
        return AnalyzerVerifier.VerifyAsync<ContinuationIndentAnalyzer>(source: source);
    }
}
