using System.Threading.Tasks;
using Microsoft.CodeAnalysis.Testing;
using Sebreiro.CodeRules.Analyzers.Tests.Verification;
using Xunit;

namespace Sebreiro.CodeRules.Analyzers.Tests;

/// <summary>
/// In-memory proofs of SCR0010: plain using directives run <c>System</c> and <c>System.*</c> first, then by
/// namespace name (ordinal, ignoring case); <c>using static</c> directives follow in the same order, and aliases
/// come last, ordered by alias name. Global usings come before the others. The first directive out of order is
/// reported, once per compilation unit and once per namespace.
/// </summary>
public sealed class UsingOrderAnalyzerTests
{
    /// <summary><c>System</c> and <c>System.*</c> first, then the other namespaces alphabetically, passes.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_SystemFirstThenAlphabetical_Passes()
    {
        return VerifyAsync(source: """
                using System;
                using System.Collections.Generic;
                using System.Text;
                using Alpha.Beta;
                using Alpha.Gamma;
                using Microsoft.Tools;
                using SystemTools;
                """ + Namespaces);
    }

    /// <summary><c>using System.Text;</c> before <c>using System;</c> is reported on <c>using System;</c>.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_SystemTextBeforeSystem_Reports()
    {
        return VerifyAsync(source: """
                using System.Text;
                {|SCR0010:using System;|}
                """ + Namespaces);
    }

    /// <summary>A <c>Microsoft.*</c> using before a <c>System.*</c> using is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_MicrosoftBeforeSystem_Reports()
    {
        return VerifyAsync(source: """
                using Microsoft.Tools;
                {|SCR0010:using System.Text;|}
                """ + Namespaces);
    }

    /// <summary><c>using Alpha.Gamma;</c> before <c>using Alpha.Beta;</c> is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_NonSystemOutOfOrder_Reports()
    {
        return VerifyAsync(source: """
                using System;
                using Alpha.Gamma;
                {|SCR0010:using Alpha.Beta;|}
                """ + Namespaces);
    }

    /// <summary>
    /// <c>SystemTools</c> is not a <c>System</c> namespace: it sorts with the others, so it may follow
    /// <c>Alpha.Beta</c>.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task SystemPrefixWithoutDot_SortsWithOthers_Passes()
    {
        return VerifyAsync(source: """
                using Alpha.Beta;
                using SystemTools;
                """ + Namespaces);
    }

    /// <summary>The comparison ignores case: <c>alpha</c> before <c>Beta</c> passes.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_CaseIgnored_Passes()
    {
        return VerifyAsync(source: """
                using alpha;
                using Beta;
                """ + LowerCaseNamespaces);
    }

    /// <summary>The comparison ignores case: <c>Beta</c> before <c>alpha</c> is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_CaseIgnored_Reports()
    {
        return VerifyAsync(source: """
                using Beta;
                {|SCR0010:using alpha;|}
                """ + LowerCaseNamespaces);
    }

    /// <summary>
    /// Plain usings, then <c>using static</c> directives, then aliases, each group in the same order, passes.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task StaticAfterPlain_AliasesLast_Passes()
    {
        return VerifyAsync(source: """
                using System;
                using Alpha.Beta;
                using static System.Math;
                using static Alpha.Beta.Helpers;
                using Builder = System.Text.StringBuilder;
                using Helpers = Alpha.Gamma.Helpers;
                """ + Namespaces);
    }

    /// <summary>A <c>using static</c> directive before a plain one is reported on the plain one.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_StaticBeforePlain_Reports()
    {
        return VerifyAsync(source: """
                using static System.Math;
                {|SCR0010:using System;|}
                """ + Namespaces);
    }

    /// <summary>An alias before a <c>using static</c> directive is reported on the static one.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_AliasBeforeStatic_Reports()
    {
        return VerifyAsync(source: """
                using System;
                using Builder = System.Text.StringBuilder;
                {|SCR0010:using static System.Math;|}
                """ + Namespaces);
    }

    /// <summary>Inside the static group, <c>System.*</c> types come first.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_StaticGroupOutOfOrder_Reports()
    {
        return VerifyAsync(source: """
                using static Alpha.Beta.Helpers;
                {|SCR0010:using static System.Math;|}
                """ + Namespaces);
    }

    /// <summary>Aliases are ordered by alias name: <c>Helpers</c> before <c>Builder</c> is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_AliasesOutOfOrder_Reports()
    {
        return VerifyAsync(source: """
                using Helpers = Alpha.Gamma.Helpers;
                {|SCR0010:using Builder = System.Text.StringBuilder;|}
                """ + Namespaces);
    }

    /// <summary>Global usings come before the others, which the compiler also requires.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_GlobalUsingsFirst_Pass()
    {
        return VerifyAsync(source: """
                global using System.Text;
                global using Alpha.Beta;
                using System;
                using Alpha.Gamma;
                """ + Namespaces);
    }

    /// <summary>Global usings are ordered among themselves.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_GlobalUsingsOutOfOrder_Report()
    {
        return VerifyAsync(source: """
                global using Alpha.Beta;
                {|SCR0010:global using System.Text;|}
                using System;
                """ + Namespaces);
    }

    /// <summary>Only the first directive out of order in a list is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_OnlyFirstViolation_Reports()
    {
        return VerifyAsync(source: """
                using Microsoft.Tools;
                {|SCR0010:using Alpha.Gamma;|}
                using Alpha.Beta;
                """ + Namespaces);
    }

    /// <summary>
    /// The usings of a namespace block are checked on their own: each list is in order, so nothing is reported even
    /// though the namespace's <c>System</c> using follows the file's <c>Alpha</c> using.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task NamespaceBlock_CheckedOnItsOwn_Passes()
    {
        return VerifyAsync(source: """
                using Alpha.Beta;

                namespace Outer
                {
                    using System;
                    using System.Text;

                    class C
                    {
                    }
                }
                """ + Namespaces);
    }

    /// <summary>A namespace block's usings out of order are reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_NamespaceBlockOutOfOrder_Reports()
    {
        return VerifyAsync(source: """
                namespace Outer
                {
                    using System.Text;
                    {|SCR0010:using System;|}

                    class C
                    {
                    }
                }
                """ + Namespaces);
    }

    /// <summary>The usings inside a file-scoped namespace are checked too.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_FileScopedNamespaceOutOfOrder_Reports()
    {
        return VerifyAsync(source: """
                namespace Outer;

                using System.Text;
                {|SCR0010:using System;|}

                class C
                {
                }
                """);
    }

    /// <summary>The message names the directive out of order and the one it must come before.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_Message_NamesBothDirectives()
    {
        return AnalyzerVerifier.VerifyAsync<UsingOrderAnalyzer>(
                source: """
                        using System.Text;
                        using System;
                        """,
                expected: new DiagnosticResult(descriptor: UsingOrderAnalyzer.Rule)
                        .WithSpan(startLine: 2, startColumn: 1, endLine: 2, endColumn: 14)
                        .WithArguments("using System;", "using System.Text;"));
    }

    /// <summary>Code marked <c>generated_code = true</c> in an <c>.editorconfig</c> is not checked.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_GeneratedCode_IsSkipped()
    {
        return AnalyzerVerifier.VerifyAsync<UsingOrderAnalyzer>(
                source: """
                        using System.Text;
                        using System;
                        """,
                editorConfig: """
                        root = true

                        [*.cs]
                        generated_code = true
                        """);
    }

    private const string Namespaces = """


            namespace Alpha.Beta
            {
                public static class Helpers
                {
                }
            }

            namespace Alpha.Gamma
            {
                public static class Helpers
                {
                }
            }

            namespace Microsoft.Tools
            {
                public static class Helpers
                {
                }
            }

            namespace SystemTools
            {
                public static class Helpers
                {
                }
            }
            """;

    private const string LowerCaseNamespaces = """


            namespace alpha
            {
                public static class Helpers
                {
                }
            }

            namespace Beta
            {
                public static class Helpers
                {
                }
            }
            """;

    private static Task VerifyAsync(string source)
    {
        return AnalyzerVerifier.VerifyAsync<UsingOrderAnalyzer>(source: source);
    }
}
