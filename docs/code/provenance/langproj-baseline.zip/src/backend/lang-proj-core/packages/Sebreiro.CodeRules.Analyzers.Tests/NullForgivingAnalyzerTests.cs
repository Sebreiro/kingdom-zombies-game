using System.Threading.Tasks;
using Sebreiro.CodeRules.Analyzers.Tests.Verification;
using Xunit;

namespace Sebreiro.CodeRules.Analyzers.Tests;

/// <summary>
/// In-memory proofs of SCR0005: the null-forgiving operator fails on a variable, before a member access and on the
/// <see langword="null"/> literal, while logical not and <c>!=</c> pass.
/// </summary>
public sealed class NullForgivingAnalyzerTests
{
    /// <summary>The null-forgiving operator on a variable is reported on the operator.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_Variable_Reports()
    {
        return VerifyAsync(source: """
                #nullable enable
                class C
                {
                    string M(string? value)
                    {
                        return value{|SCR0005:!|};
                    }
                }
                """);
    }

    /// <summary>The null-forgiving operator before a member access is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_BeforeMemberAccess_Reports()
    {
        return VerifyAsync(source: """
                #nullable enable
                class C
                {
                    int M(string? value)
                    {
                        return value{|SCR0005:!|}.Length;
                    }
                }
                """);
    }

    /// <summary>The null-forgiving operator on the <see langword="null"/> literal is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_NullLiteral_Reports()
    {
        return VerifyAsync(source: """
                #nullable enable
                class C
                {
                    public string Name { get; set; } = null{|SCR0005:!|};
                }
                """);
    }

    /// <summary>Logical not and the not-equals operator pass.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_LogicalNotAndNotEquals_Pass()
    {
        return VerifyAsync(source: """
                #nullable enable
                class C
                {
                    bool M(bool flag, int a, int b)
                    {
                        return !flag && a != b;
                    }
                }
                """);
    }

    private static Task VerifyAsync(string source)
    {
        return AnalyzerVerifier.VerifyAsync<NullForgivingAnalyzer>(source: source);
    }
}
