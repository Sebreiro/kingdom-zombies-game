using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Sebreiro.CodeRules.Analyzers.Tests.Verification;
using Xunit;

namespace Sebreiro.CodeRules.Analyzers.Tests;

/// <summary>
/// In-memory proofs of SCR0002: a <c>//</c>, <c>/* */</c> or <c>///</c> comment between a member body's braces
/// fails in every kind of body, the global statements of a file form one body, and XML docs, comments between
/// members and preprocessor directives pass.
/// </summary>
public sealed class BodyCommentAnalyzerTests
{
    /// <summary>A line comment and a block comment inside a method body are reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Method_LineAndBlockComments_Report()
    {
        return VerifyAsync(source: """
                class C
                {
                    void M()
                    {
                        {|SCR0002:// line|}
                        {|SCR0002:/* block */|}
                    }
                }
                """);
    }

    /// <summary>A comment after a statement on the same line is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Method_TrailingComment_Reports()
    {
        return VerifyAsync(source: """
                class C
                {
                    int M()
                    {
                        int x = 1; {|SCR0002:// trailing|}
                        return x {|SCR0002:/* inline */|} + 1;
                    }
                }
                """);
    }

    /// <summary>A comment inside a constructor and a destructor is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task ConstructorAndDestructor_Comments_Report()
    {
        return VerifyAsync(source: """
                class C
                {
                    C()
                    {
                        {|SCR0002:// constructor|}
                    }

                    ~C()
                    {
                        {|SCR0002:// destructor|}
                    }
                }
                """);
    }

    /// <summary>A comment inside property, indexer and event accessors and an expression body is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Accessors_Comments_Report()
    {
        return VerifyAsync(source: """
                using System;

                class C
                {
                    private int _value;

                    int Value
                    {
                        get
                        {
                            {|SCR0002:// getter|}
                            return _value;
                        }

                        set { _value = value; {|SCR0002:/* setter */|} }
                    }

                    int this[int i] => i {|SCR0002:/* indexer */|} + 1;

                    int Twice => _value {|SCR0002:/* property */|} * 2;

                    event EventHandler Changed
                    {
                        add { {|SCR0002:// add|}
                        }

                        remove { {|SCR0002:// remove|}
                        }
                    }
                }
                """);
    }

    /// <summary>A comment inside an operator and a conversion operator is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Operators_Comments_Report()
    {
        return VerifyAsync(source: """
                class C
                {
                    public static C operator +(C left, C right)
                    {
                        {|SCR0002:// operator|}
                        return left;
                    }

                    public static implicit operator int(C value)
                    {
                        {|SCR0002:// conversion|}
                        return 0;
                    }
                }
                """);
    }

    /// <summary>A comment inside a local function and inside lambdas is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task LocalFunctionAndLambda_Comments_Report()
    {
        return VerifyAsync(source: """
                using System;

                class C
                {
                    int M()
                    {
                        Func<int, int> f = x =>
                        {
                            {|SCR0002:// block lambda|}
                            return x;
                        };
                        return Local() + f(1);

                        int Local()
                        {
                            {|SCR0002:// local function|}
                            return 1;
                        }
                    }
                }
                """);
    }

    /// <summary>A comment inside a lambda in a field initializer is reported: the lambda is a body.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task FieldInitializerLambda_Comment_Reports()
    {
        return VerifyAsync(source: """
                using System;

                class C
                {
                    private static readonly Func<int, int> _block = x =>
                    {
                        {|SCR0002:// block|}
                        return x;
                    };

                    private static readonly Func<int, int> _expression = x => x {|SCR0002:/* expression */|} + 1;
                }
                """);
    }

    /// <summary>A <c>///</c> comment inside a method body is a body comment.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Method_DocumentationComment_Reports()
    {
        return VerifyAsync(source: """
                class C
                {
                    int M()
                    {
                        {|SCR0002:/// <summary>Local.</summary>|}
                        int Local()
                        {
                            return 1;
                        }

                        return Local();
                    }
                }
                """);
    }

    /// <summary>XML docs on members and comments between members, before and after bodies pass.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_CommentsOutsideBodies_Pass()
    {
        return VerifyAsync(source: """
                // File header.
                using System;

                /// <summary>A type.</summary>
                class C
                {
                    // Between members.
                    private int _value = 1; // After a field.

                    /// <summary>A method.</summary>
                    /** <remarks>Block XML doc.</remarks> */
                    int M()
                    {
                        return _value;
                    } // After the closing brace.

                    /* Between members. */
                    int P { get; set; }
                }
                """);
    }

    /// <summary>
    /// <c>#if</c>, <c>#endif</c>, <c>#region</c> and <c>#endregion</c> inside a body are not comments.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task PreprocessorDirectives_InBody_Pass()
    {
        return VerifyAsync(source: """
                class C
                {
                    int M()
                    {
                #if DEBUG
                        int x = 1;
                #else
                        int x = 2;
                #endif
                        #region Values
                        int y = x;
                        #endregion
                        return y;
                    }
                }
                """);
    }

    /// <summary>
    /// The global statements of a file are one body: comments before, between and after them report.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task GlobalStatements_Comments_Report()
    {
        return VerifyAsync(
                source: """
                        using System;

                        {|SCR0002:// Before the first statement.|}
                        int x = 1;
                        {|SCR0002:/* Between statements. */|}
                        int y = x + 1; {|SCR0002:// After the last statement.|}
                        """,
                outputKind: OutputKind.ConsoleApplication);
    }

    /// <summary>
    /// A comment after the last global statement, before a type, is outside the global-statement body.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task GlobalStatements_CommentBeforeType_Passes()
    {
        return VerifyAsync(
                source: """
                        int x = 1;

                        // Before the type.
                        class C
                        {
                        }
                        """,
                outputKind: OutputKind.ConsoleApplication);
    }

    /// <summary>Code marked <c>generated_code = true</c> in an <c>.editorconfig</c> is not checked.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_GeneratedCode_IsSkipped()
    {
        return VerifyAsync(
                source: """
                        class C
                        {
                            void M()
                            {
                                // Generated.
                            }
                        }
                        """,
                editorConfig: """
                        root = true

                        [*.cs]
                        generated_code = true
                        """);
    }

    private static Task VerifyAsync(
            string source,
            string? editorConfig = null,
            OutputKind outputKind = OutputKind.DynamicallyLinkedLibrary)
    {
        return AnalyzerVerifier.VerifyAsync<BodyCommentAnalyzer>(
                source: source,
                editorConfig: editorConfig,
                outputKind: outputKind);
    }
}
