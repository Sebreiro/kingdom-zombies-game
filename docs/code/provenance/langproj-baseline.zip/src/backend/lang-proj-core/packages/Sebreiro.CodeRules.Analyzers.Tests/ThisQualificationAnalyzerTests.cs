using System.Threading.Tasks;
using Sebreiro.CodeRules.Analyzers.Tests.Verification;
using Xunit;

namespace Sebreiro.CodeRules.Analyzers.Tests;

/// <summary>
/// In-memory proofs of SCR0011: a member access qualified with <c>this.</c> fails; every other use of the
/// <c>this</c> keyword passes.
/// </summary>
public sealed class ThisQualificationAnalyzerTests
{
    /// <summary>Assigning a field through <c>this.</c> is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_FieldAssignment_Reports()
    {
        return VerifyAsync(source: """
                class C
                {
                    private int _value;

                    public void Set(int value)
                    {
                        {|SCR0011:this._value|} = value;
                    }
                }
                """);
    }

    /// <summary>Calling a method through <c>this.</c> is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_MethodCall_Reports()
    {
        return VerifyAsync(source: """
                class C
                {
                    public void Run()
                    {
                        {|SCR0011:this.Stop|}();
                    }

                    public void Stop()
                    {
                    }
                }
                """);
    }

    /// <summary>Reading a property and raising an event through <c>this.</c> are both reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_PropertyAndEvent_Report()
    {
        return VerifyAsync(source: """
                using System;

                class C
                {
                    public event Action Changed;

                    public int Value { get; set; }

                    public int Read()
                    {
                        {|SCR0011:this.Changed|}?.Invoke();
                        return {|SCR0011:this.Value|};
                    }
                }
                """);
    }

    /// <summary>Unqualified member access passes.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_Unqualified_Passes()
    {
        return VerifyAsync(source: """
                class C
                {
                    private int _value;

                    public void Set(int value)
                    {
                        _value = value;
                        Stop();
                    }

                    public void Stop()
                    {
                    }
                }
                """);
    }

    /// <summary>Constructor chaining with <c>: this(...)</c> passes.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_ConstructorChaining_Passes()
    {
        return VerifyAsync(source: """
                class C
                {
                    public C()
                        : this(value: 0)
                    {
                    }

                    public C(int value)
                    {
                    }
                }
                """);
    }

    /// <summary>Passing <c>this</c> as an argument and returning it pass.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_ThisAsValue_Passes()
    {
        return VerifyAsync(source: """
                class C
                {
                    public C Self()
                    {
                        Use(target: this);
                        return this;
                    }

                    private static void Use(C target)
                    {
                    }
                }
                """);
    }

    /// <summary>An indexer declaration <c>this[int i]</c> and an element access <c>this[0]</c> pass.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_Indexer_Passes()
    {
        return VerifyAsync(source: """
                class C
                {
                    public int this[int index] => index;

                    public int First()
                    {
                        return this[0];
                    }
                }
                """);
    }

    /// <summary>The <c>this</c> modifier of an extension method's first parameter passes.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_ExtensionMethodParameter_Passes()
    {
        return VerifyAsync(source: """
                static class Extensions
                {
                    public static int Twice(this int value)
                    {
                        return value * 2;
                    }
                }
                """);
    }

    /// <summary>
    /// Calling an extension method on the current instance through <c>this.</c> passes: the call does not bind
    /// without it.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task ExtensionMethodCall_OnThis_Passes()
    {
        return VerifyAsync(source: """
                static class E
                {
                    public static int Twice(this C c)
                    {
                        return 2;
                    }
                }

                class C
                {
                    public int M()
                    {
                        return this.Twice();
                    }
                }
                """);
    }

    /// <summary>
    /// Using a C# 14 extension property and extension method on the current instance through <c>this.</c> passes,
    /// while a real member next to them is still reported.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task ExtensionMember_OnThis_Passes()
    {
        return VerifyAsync(source: """
                static class E
                {
                    extension(C c)
                    {
                        public int Doubled => 2;

                        public int Tripled()
                        {
                            return 3;
                        }
                    }
                }

                class C
                {
                    public int Value { get; set; }

                    public int M()
                    {
                        return this.Doubled + this.Tripled() + {|SCR0011:this.Value|};
                    }
                }
                """);
    }

    /// <summary>Code marked <c>generated_code = true</c> in an <c>.editorconfig</c> is not checked.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_GeneratedCode_IsSkipped()
    {
        return AnalyzerVerifier.VerifyAsync<ThisQualificationAnalyzer>(
                source: """
                        class C
                        {
                            private int _value;

                            public void Set(int value)
                            {
                                this._value = value;
                            }
                        }
                        """,
                editorConfig: """
                        root = true

                        [*.cs]
                        generated_code = true
                        """);
    }

    private static Task VerifyAsync(string source)
    {
        return AnalyzerVerifier.VerifyAsync<ThisQualificationAnalyzer>(source: source);
    }
}
