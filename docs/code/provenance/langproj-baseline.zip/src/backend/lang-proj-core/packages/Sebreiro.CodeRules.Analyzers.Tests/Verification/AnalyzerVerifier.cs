using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp.Testing;
using Microsoft.CodeAnalysis.Diagnostics;
using Microsoft.CodeAnalysis.Testing;
using Microsoft.CodeAnalysis.Text;
using Xunit;

namespace Sebreiro.CodeRules.Analyzers.Tests.Verification;

/// <summary>
/// Runs one analyzer over in-memory C# source against the .NET 10 reference assemblies. Expected diagnostics are
/// written as markup in the source, for example <c>{|SCR0001:1|}</c>; any other analyzer diagnostic or any
/// compiler error fails the run.
/// </summary>
internal static class AnalyzerVerifier
{
    /// <summary>
    /// Verifies that <typeparamref name="TAnalyzer"/> reports exactly the diagnostics marked up in the source.
    /// </summary>
    /// <typeparam name="TAnalyzer">The analyzer under test.</typeparam>
    /// <param name="source">The C# source with diagnostic markup.</param>
    /// <param name="editorConfig">
    /// Optional <c>.editorconfig</c> content placed at the root of the in-memory project, or <see langword="null"/>.
    /// </param>
    /// <param name="outputKind">
    /// The kind of assembly to compile; <see cref="OutputKind.ConsoleApplication"/> allows top-level statements.
    /// </param>
    /// <param name="expected">
    /// An optional diagnostic expected in addition to the markup, used to check a message, or
    /// <see langword="null"/>.
    /// </param>
    /// <returns>A task that completes when the verification has run.</returns>
    internal static Task VerifyAsync<TAnalyzer>(
            string source,
            string? editorConfig = null,
            OutputKind outputKind = OutputKind.DynamicallyLinkedLibrary,
            DiagnosticResult? expected = null)
            where TAnalyzer : DiagnosticAnalyzer, new()
    {
        var test = new CSharpAnalyzerTest<TAnalyzer, DefaultVerifier>
        {
            TestCode = source,
            ReferenceAssemblies = ReferenceAssemblies.Net.Net100,
        };
        test.TestState.OutputKind = outputKind;
        if (expected is { } diagnostic)
        {
            test.ExpectedDiagnostics.Add(item: diagnostic);
        }

        if (editorConfig is not null)
        {
            test.TestState.AnalyzerConfigFiles.Add(item: ("/.editorconfig", SourceText.From(text: editorConfig)));
        }

        return test.RunAsync(cancellationToken: TestContext.Current.CancellationToken);
    }
}
