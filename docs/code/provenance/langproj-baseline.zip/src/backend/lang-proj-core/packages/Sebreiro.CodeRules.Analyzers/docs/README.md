# Sebreiro.CodeRules.Analyzers

## Responsibility

A reusable Roslyn analyzer package with the code rules that no built-in analyzer enforces exactly as
written. It targets `netstandard2.0`, as a Roslyn analyzer must. Every other project of the solution
gets it as an analyzer only, through one item in `Directory.Build.targets`, and every rule fails the build
at `Error`. It holds no product code and knows nothing about the product.

## Allowed dependencies

- None

It does not analyze its own build: the analyzer-only edge in `Directory.Build.targets` skips this project
([EX-19](../../../../docs/rule-matrix.md#ex-19)), so a change to its source is checked by hand in a
throwaway project.

## Rules

| ID | Analyzer | Rule | Row |
|----|----------|------|-----|
| `SCR0001` | `NamedArgumentAnalyzer` | Every argument is named, except the agreed exemptions | [R-38](../../../../docs/rule-matrix.md#r-38) |
| `SCR0002` | `BodyCommentAnalyzer` | No comments inside member bodies | [R-36](../../../../docs/rule-matrix.md#r-36) |
| `SCR0003` | `PrimaryConstructorAnalyzer` | No primary constructors and no positional records | [R-23](../../../../docs/rule-matrix.md#r-23), [R-24](../../../../docs/rule-matrix.md#r-24) |
| `SCR0004` | `RegionDirectiveAnalyzer` | No `#region` directives | [R-25](../../../../docs/rule-matrix.md#r-25) |
| `SCR0005` | `NullForgivingAnalyzer` | No null-forgiving operator | [R-26](../../../../docs/rule-matrix.md#r-26) |
| `SCR0006` | `BodyLengthAnalyzer` | A member body of more than 60 lines fails | [R-37](../../../../docs/rule-matrix.md#r-37) |
| `SCR0007` | `LineLengthAnalyzer` | Lines of 120 characters or fewer | [R-10](../../../../docs/rule-matrix.md#r-10) |
| `SCR0008` | `MemberOrderAnalyzer` | Members ordered by access, then by kind | [R-33](../../../../docs/rule-matrix.md#r-33) |
| `SCR0009` | `ContinuationIndentAnalyzer` | Continuation lines indented by 8 spaces | [R-09](../../../../docs/rule-matrix.md#r-09) |
| `SCR0010` | `UsingOrderAnalyzer` | Usings in the agreed order | [R-14](../../../../docs/rule-matrix.md#r-14) |
| `SCR0011` | `ThisQualificationAnalyzer` | No `this.` qualification | [R-28](../../../../docs/rule-matrix.md#r-28) |
| `SCR0012` | `LocalNewDeclarationAnalyzer` | A local created with `new` uses `var` | [R-18](../../../../docs/rule-matrix.md#r-18) |

Rules for the code of this project:

- It is product-agnostic: no project reference or package whose path or ID contains `LangProject`, and
  it packs with `dotnet pack` ([R-62](../../../../docs/rule-matrix.md#r-62)).
- Every analyzer skips generated code. In this solution only `LangProject.Core.DAL/Migrations/` is marked
  as generated ([R-50](../../../../docs/rule-matrix.md#r-50)).
- Its tests cover at least 90% of its lines and 80% of its branches, and CI fails below either value
  ([R-49](../../../../docs/rule-matrix.md#r-49)).
- Every rule in [code-style.md](../../../../docs/CodeRules/code-style.md) and
  [code-architecture.md](../../../../docs/CodeRules/code-architecture.md) applies to its source, even
  though the build does not check its own SCR rules on it.

## Release tracking

`AnalyzerReleases.Unshipped.md` lists every rule ID with its category, severity and analyzer, and
`AnalyzerReleases.Shipped.md` lists the released ones. Both are additional files of the build, so the
release-tracking analyzer (RS2008) fails the build when a descriptor and the files disagree. A new ID goes
into `AnalyzerReleases.Unshipped.md` in the same change as its descriptor.

## Roslyn pin

`Microsoft.CodeAnalysis.CSharp` is pinned to `5.0.0` in `Directory.Packages.props`. An analyzer compiled
against a newer Roslyn than the SDK's compiler does not load, and the build then runs without the SCR
rules. A test fails when the pin is newer than the compiler of the SDK in `global.json`, so the pin is
raised only after the SDK.

## How to add a rule

1. Write the rule under its own heading in the code-rule docs, with its `Enforcement:` line.
2. Add an analyzer class here with the next free `SCRnnnn` ID, category `Sebreiro.CodeRules` and severity
   `Error`, and add the ID to `AnalyzerReleases.Unshipped.md`.
3. Add its in-memory proofs to `Sebreiro.CodeRules.Analyzers.Tests`, one test class per analyzer.
4. Add its row to the [rule matrix](../../../../docs/rule-matrix.md) with the ID and the proof tests.
5. Build the whole solution: existing code that breaks the new rule is fixed in the same change.
