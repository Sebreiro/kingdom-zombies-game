using System.Threading.Tasks;
using Sebreiro.CodeRules.Analyzers.Tests.Verification;
using Xunit;

namespace Sebreiro.CodeRules.Analyzers.Tests;

/// <summary>
/// In-memory proofs of SCR0004: a <c>#region</c> directive fails wherever it appears, while other preprocessor
/// directives pass.
/// </summary>
public sealed class RegionDirectiveAnalyzerTests
{
    /// <summary>A region inside a type is reported on its <c>#region</c> line.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_InsideType_Reports()
    {
        return VerifyAsync(source: """
                class C
                {
                    {|SCR0004:#region Fields|}
                    private int _x;
                    #endregion

                    int X => _x;
                }
                """);
    }

    /// <summary>A region inside a member body is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_InsideBody_Reports()
    {
        return VerifyAsync(source: """
                class C
                {
                    int M()
                    {
                        {|SCR0004:#region|}
                        int x = 1;
                        #endregion
                        return x;
                    }
                }
                """);
    }

    /// <summary>A region around a type at file level is reported, and so is a nested region.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_FileLevelAndNested_Report()
    {
        return VerifyAsync(source: """
                {|SCR0004:#region Types|}
                class C
                {
                    {|SCR0004:#region Inner|}
                    private int _x;
                    #endregion
                }
                #endregion
                """);
    }

    /// <summary><c>#if</c>, <c>#else</c> and <c>#endif</c> are not regions and pass.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_OtherDirectives_Pass()
    {
        return VerifyAsync(source: """
                class C
                {
                    int M()
                    {
                #if DEBUG
                        return 1;
                #else
                        return 2;
                #endif
                    }
                }
                """);
    }

    private static Task VerifyAsync(string source)
    {
        return AnalyzerVerifier.VerifyAsync<RegionDirectiveAnalyzer>(source: source);
    }
}
