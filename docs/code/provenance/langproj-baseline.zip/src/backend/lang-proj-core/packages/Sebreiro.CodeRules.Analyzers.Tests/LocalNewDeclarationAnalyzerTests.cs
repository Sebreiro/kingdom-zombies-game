using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.Testing;
using Sebreiro.CodeRules.Analyzers.Tests.Verification;
using Xunit;

namespace Sebreiro.CodeRules.Analyzers.Tests;

/// <summary>
/// In-memory proofs of SCR0012: a local declared with an explicit type and initialized with a target-typed
/// <c>new(…)</c> fails, so <c>var x = new Foo();</c> is the one accepted form. Fields, properties, arguments, return
/// values, collection expressions and locals where <c>var</c> cannot be used pass.
/// </summary>
public sealed class LocalNewDeclarationAnalyzerTests
{
    /// <summary><c>Foo x = new();</c> is reported on the declaration.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_TypedLocalWithTargetTypedNew_Reports()
    {
        return VerifyAsync(source: """
                class Foo
                {
                    public void M()
                    {
                        {|SCR0012:Foo x = new()|};
                    }
                }
                """);
    }

    /// <summary>A target-typed <c>new</c> with arguments and an object initializer is reported too.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_TargetTypedNewWithArgumentsAndInitializer_Reports()
    {
        return VerifyAsync(source: """
                class Foo
                {
                    public Foo(int start)
                    {
                    }

                    public int Value { get; set; }

                    public static void M()
                    {
                        {|SCR0012:Foo x = new(start: 1) { Value = 2 }|};
                    }
                }
                """);
    }

    /// <summary><c>var x = new Foo();</c> passes.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_VarWithNew_Passes()
    {
        return VerifyAsync(source: """
                class Foo
                {
                    public void M()
                    {
                        var x = new Foo();
                    }
                }
                """);
    }

    /// <summary>
    /// <c>Foo x = new Foo();</c> is not SCR0012's: IDE0007 reports it in the build, so SCR0012 stays silent.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_TypedLocalWithExplicitNew_IsNotReported()
    {
        return VerifyAsync(source: """
                class Foo
                {
                    public void M()
                    {
                        Foo x = new Foo();
                    }
                }
                """);
    }

    /// <summary>A field and a property initialized with target-typed <c>new()</c> pass.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_FieldAndProperty_Pass()
    {
        return VerifyAsync(source: """
                class Foo
                {
                    private readonly Foo _x = new();

                    public Foo Property { get; } = new();
                }
                """);
    }

    /// <summary>Target-typed <c>new()</c> as an argument and as a return value passes.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_ArgumentAndReturnValue_Pass()
    {
        return VerifyAsync(source: """
                class Foo
                {
                    public static Foo Create()
                    {
                        Use(value: new());
                        return new();
                    }

                    private static void Use(Foo value)
                    {
                    }
                }
                """);
    }

    /// <summary>A <c>using</c> declaration and an <c>await using</c> declaration are both reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_UsingAndAwaitUsingDeclarations_Report()
    {
        return VerifyAsync(source: """
                using System;
                using System.Threading.Tasks;

                class Resource : IDisposable, IAsyncDisposable
                {
                    public void Dispose()
                    {
                    }

                    public ValueTask DisposeAsync()
                    {
                        return default;
                    }

                    public static async Task M()
                    {
                        using {|SCR0012:Resource first = new()|};
                        await using {|SCR0012:Resource second = new()|};
                        await Task.Yield();
                    }
                }
                """);
    }

    /// <summary>A <c>for</c> initializer and a <c>using (…)</c> statement declaration are both reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_ForInitializerAndUsingStatement_Report()
    {
        return VerifyAsync(source: """
                using System;

                class Counter : IDisposable
                {
                    public int Value { get; set; }

                    public void Dispose()
                    {
                    }

                    public static void M()
                    {
                        for ({|SCR0012:Counter counter = new()|}; counter.Value < 3; counter.Value++)
                        {
                        }

                        using ({|SCR0012:Counter other = new()|})
                        {
                        }
                    }
                }
                """);
    }

    /// <summary>Several declarators in one declaration cannot use <c>var</c>, so they pass.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_SeveralDeclarators_Pass()
    {
        return VerifyAsync(source: """
                class Foo
                {
                    public void M()
                    {
                        Foo first = new(), second = new();
                        for (Foo a = new(), b = new(); a != b; a = b)
                        {
                        }
                    }
                }
                """);
    }

    /// <summary>
    /// A collection expression, an initializer that is not <c>new</c>, a local with no initializer and a
    /// <c>ref</c> local pass.
    /// </summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_OtherInitializers_Pass()
    {
        return VerifyAsync(source: """
                using System.Collections.Generic;

                class Foo
                {
                    public static void M(int[] values)
                    {
                        List<int> items = [];
                        Foo created = Create();
                        Foo later;
                        ref int first = ref values[0];
                        for (int index = 0; index < values.Length; index++)
                        {
                        }
                    }

                    private static Foo Create()
                    {
                        return new Foo();
                    }
                }
                """);
    }

    /// <summary>A top-level statement local with target-typed <c>new()</c> is reported.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_TopLevelStatement_Reports()
    {
        return AnalyzerVerifier.VerifyAsync<LocalNewDeclarationAnalyzer>(
                source: """
                        using System.Text;

                        {|SCR0012:StringBuilder builder = new()|};
                        builder.Append(value: 1);
                        """,
                outputKind: OutputKind.ConsoleApplication);
    }

    /// <summary>The message names the local and the type to write after <c>new</c>.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_Message_NamesLocalAndType()
    {
        return AnalyzerVerifier.VerifyAsync<LocalNewDeclarationAnalyzer>(
                source: """
                        class Foo
                        {
                            public void M()
                            {
                                Foo x = new();
                            }
                        }
                        """,
                expected: new DiagnosticResult(descriptor: LocalNewDeclarationAnalyzer.Rule)
                        .WithSpan(startLine: 5, startColumn: 9, endLine: 5, endColumn: 22)
                        .WithArguments("x", "Foo"));
    }

    /// <summary>Code marked <c>generated_code = true</c> in an <c>.editorconfig</c> is not checked.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_GeneratedCode_IsSkipped()
    {
        return AnalyzerVerifier.VerifyAsync<LocalNewDeclarationAnalyzer>(
                source: """
                        class Foo
                        {
                            public void M()
                            {
                                Foo x = new();
                            }
                        }
                        """,
                editorConfig: """
                        root = true

                        [*.cs]
                        generated_code = true
                        """);
    }

    private static Task VerifyAsync(string source)
    {
        return AnalyzerVerifier.VerifyAsync<LocalNewDeclarationAnalyzer>(source: source);
    }
}
