using System.Threading.Tasks;
using Sebreiro.CodeRules.Analyzers.Tests.Verification;
using Xunit;

namespace Sebreiro.CodeRules.Analyzers.Tests;

/// <summary>
/// In-memory proofs of SCR0007: a line of 120 UTF-16 characters passes and one of 121 fails, the line terminator is
/// not counted, and a Cyrillic letter counts as one character. Long lines are generated in code: a type name alone
/// on its line, so the line holds nothing but letters.
/// </summary>
public sealed class LineLengthAnalyzerTests
{
    /// <summary>A line of exactly 120 Latin letters passes.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Line_120Characters_Passes()
    {
        return VerifyAsync(source: TypeNamed(name: Letters(letter: 'A', count: 120)));
    }

    /// <summary>A line of 121 Latin letters fails, reported on the characters past the limit.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Line_121Characters_Fails()
    {
        return VerifyAsync(source: TypeNamed(name: Letters(letter: 'A', count: 120) + "{|SCR0007:A|}"));
    }

    /// <summary>A line of 120 Cyrillic letters passes: each letter is one UTF-16 character.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Line_120CyrillicLetters_Passes()
    {
        return VerifyAsync(source: TypeNamed(name: Letters(letter: 'Я', count: 120)));
    }

    /// <summary>A line of 121 Cyrillic letters fails.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Line_121CyrillicLetters_Fails()
    {
        return VerifyAsync(source: TypeNamed(name: Letters(letter: 'Я', count: 120) + "{|SCR0007:Я|}"));
    }

    /// <summary>A comment line of 121 characters fails as well: every line is checked.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task CommentLine_121Characters_Fails()
    {
        return VerifyAsync(source: "class C\n{\n}\n//" + Letters(letter: 'a', count: 118) + "{|SCR0007:a|}\n");
    }

    /// <summary>The CRLF terminator is not counted: a 120-character line ending in CRLF passes.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_CrLfTerminator_IsNotCounted()
    {
        return VerifyAsync(source: "class\r\n" + Letters(letter: 'A', count: 120) + "\r\n{\r\n}\r\n");
    }

    /// <summary>Code marked <c>generated_code = true</c> in an <c>.editorconfig</c> is not checked.</summary>
    /// <returns>A task that completes when the verification has run.</returns>
    [Fact]
    public Task Analyze_GeneratedCode_IsSkipped()
    {
        return AnalyzerVerifier.VerifyAsync<LineLengthAnalyzer>(
                source: TypeNamed(name: Letters(letter: 'A', count: 200)),
                editorConfig: """
                        root = true

                        [*.cs]
                        generated_code = true
                        """);
    }

    private static string Letters(char letter, int count)
    {
        return new string(c: letter, count: count);
    }

    private static string TypeNamed(string name)
    {
        return "class\n" + name + "\n{\n}\n";
    }

    private static Task VerifyAsync(string source)
    {
        return AnalyzerVerifier.VerifyAsync<LineLengthAnalyzer>(source: source);
    }
}
