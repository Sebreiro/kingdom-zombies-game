# Sebreiro.CodeRules.Analyzers.Tests

## Responsibility

The tests of `Sebreiro.CodeRules.Analyzers`, an xUnit v3 test executable. Each analyzer has one test class
that runs it in memory on small C# sources, through the shared `Verification/AnalyzerVerifier`, and checks
the exact diagnostics it reports, or that it reports none. The CI fast job measures the analyzer's coverage
from this run.

## Allowed dependencies

- `Sebreiro.CodeRules.Analyzers`

This is a normal project reference, so the tests can create the analyzers. The project also gets the
analyzer-only edge from `Directory.Build.targets`, like every other project; that edge is not listed
([R-54](../../../../docs/rule-matrix.md#r-54)).

## Rules

- Tests follow every production rule, use Shouldly and are named `Method_State_Expected`
  ([R-46](../../../../docs/rule-matrix.md#r-46), [R-47](../../../../docs/rule-matrix.md#r-47),
  [R-48](../../../../docs/rule-matrix.md#r-48)). A test whose name would have two parts takes the prefix
  `Analyze_`, for example `Analyze_GeneratedCode_IsSkipped`.
- Each rule has proofs that a bad sample is reported and that the agreed exemptions and a good sample pass.
- The tests cover at least 90% of the analyzer's lines and 80% of its branches
  ([R-49](../../../../docs/rule-matrix.md#r-49)).
- It is product-agnostic like every project under `packages/`: no reference whose path or ID contains
  `LangProject` ([R-62](../../../../docs/rule-matrix.md#r-62)).
- The project is an executable because xUnit v3 needs one ([EX-13](../../../../docs/rule-matrix.md#ex-13)).
- Every rule in [code-style.md](../../../../docs/CodeRules/code-style.md) and
  [code-architecture.md](../../../../docs/CodeRules/code-architecture.md) applies.

## How to run

From the repository root:

`dotnet test --project src/backend/lang-proj-core/packages/Sebreiro.CodeRules.Analyzers.Tests/Sebreiro.CodeRules.Analyzers.Tests.csproj -c Release`
