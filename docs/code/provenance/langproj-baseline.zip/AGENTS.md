# LangProject — Agent Guide

LangProject is a monorepo for a translation and dictionary service (Russian, English, Spanish):
a .NET 10 backend, PostgreSQL, and one cross-platform frontend app (Android, Linux, Windows, Web).

This file is the entry point for AI agents and the index of the repository docs. Keep it short. Do
not load every linked doc: open only the docs relevant to the current task.

## Where things are

| Need | Read |
|------|------|
| How work is planned and started (GSD workflow) | [docs/workflow/gsd.md](docs/workflow/gsd.md) |
| Branches, commits, PRs, planning files, releases, versions | [docs/workflow/git-workflow.md](docs/workflow/git-workflow.md) |
| Run, test and deploy the backend | [docs/how-to-launch.md](docs/how-to-launch.md) |
| Backend: projects, dependency rules, code rules, decision records | [src/backend/AGENTS.md](src/backend/AGENTS.md) |
| Frontend app | [src/frontend/AGENTS.md](src/frontend/AGENTS.md) |
| Project goals, scope and decisions | [.planning/PROJECT.md](.planning/PROJECT.md) |
| v1 requirements | [.planning/REQUIREMENTS.md](.planning/REQUIREMENTS.md) |
| Phases and current position | [.planning/ROADMAP.md](.planning/ROADMAP.md), [.planning/STATE.md](.planning/STATE.md) |

## Hard rules

- Start file-changing work through a GSD command, so the planning files stay in sync. The GSD
  workflow doc explains how.
- Repository docs are tool-neutral. Every repository behaviour (branches, PRs, planning files, releases,
  launch, checks, conventions) is documented in root docs or in the specific project's `docs/` as rules for
  whoever does the work. Tool docs, such as the GSD doc, describe only the tool.
- Use "versions" (v1, v2, …) in all writing — never "MVP".
- Backend code rules fail the build and the architecture tests. Read the
  [backend index](src/backend/AGENTS.md) before changing backend code.

## Docs rules

These rules apply to every tracked Markdown file outside `.claude/` and `.planning/`. The backend's
ArchitectureTests check them on every build (`DocsLinkTests`, `AgentIndexTests`).

- Every relative link points at a file or folder that git tracks. Anchors (`#...`) are not checked,
  so check them when you write the link.
- Each `CLAUDE.md` is the single line `@AGENTS.md`, beside its `AGENTS.md`. An `AGENTS.md` uses plain
  Markdown links and never an `@` import, so a reader loads only the docs it follows.
- The `AGENTS.md` files link exactly one GSD workflow doc, `docs/workflow/gsd.md`. It is written by
  hand, holds at most 150 lines and no generated section markers, and states no repository rule.
- A new focused doc is linked from the nearest `AGENTS.md` or from a doc linked there.
