import pathlib,sys,importlib.util,zipfile,json,io,hashlib,struct
root=pathlib.Path('D:/Work/Games/KingdomZombies')
spec=importlib.util.spec_from_file_location('media',root/'tools/phase4/extract-media.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);Image=m.image_module()
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda im:png(im)
def png(im):
 b=io.BytesIO();im.save(b,format='PNG',compress_level=9);return b.getvalue()
def info(im):
 return {'width':im.width,'height':im.height,'rgbaSha256':sha(im.tobytes()),'alphaBBox':list(im.getbbox()),'visiblePixels':sum(a>0 for a in im.getchannel('A').tobytes())}
def normalized(original):
 im=original.copy();im.putalpha(im.getchannel('A').point(lambda a:255 if a>=128 else 0));box=im.getbbox();im=im.crop(box);im.thumbnail((32,32),Image.Resampling.NEAREST)
 canvas=Image.new('RGBA',(32,32));canvas.paste(im,((32-im.width)//2,(32-im.height)//2))
 palette=[(38,40,39),(72,51,43),(113,75,50),(159,108,65),(204,173,119),(244,207,113),(219,105,41)]
 canvas.putdata([pixel[:3]+(255,) if pixel[3] else (0,0,0,0) for pixel in canvas.get_flattened_data()]);return canvas,box,palette
master=(root/'.phase4/04-28-original.png').read_bytes();prompt=(root/'.phase4/04-28-expanded-prompt.txt').read_bytes();original=Image.open(io.BytesIO(master)).convert('RGBA');emblem,box,palette=normalized(original)
common=json.loads((root/'src/godot-game/content/packs/common.json').read_text());donor=zipfile.ZipFile(root/'production/phase4/common-selected.zip');members={'masters/camp-crown-original.png':master,'prompts/camp-crown.txt':prompt,'outputs/emblem-32.png':png(emblem)};sources=[]
for id in ['common.texture.3','common.s0.7592','common.s0.7989']:
 row=next(x for x in common['resources'] if x['id']==id);data=donor.read(row['member']);members['donors/'+id+'.png']=data;members['donors/'+id+'.json']=(json.dumps(row,indent=2)+'\n').encode();members['donors/'+id+'.bin']=donor.read(row['source']['rawMember']);sources.append(row)
atlas=Image.new('RGBA',(256,64));atlas.paste(emblem,(0,0));atlas.paste(Image.open(io.BytesIO(members['donors/common.texture.3.png'])).convert('RGBA'),(40,0));atlas.paste(Image.open(io.BytesIO(members['donors/common.s0.7592.png'])).convert('RGBA'),(80,0));atlas_bytes=png(atlas)
sizes=[16,24,32,48,64,128,256];frames=[png(emblem.resize((s,s),Image.Resampling.NEAREST)) for s in sizes];ico=struct.pack('<HHH',0,1,len(sizes));offset=6+16*len(sizes)
for s,b in zip(sizes,frames):ico+=struct.pack('<BBBBHHII',s if s<256 else 0,s if s<256 else 0,0,0,1,32,len(b),offset);offset+=len(b)
ico+=b''.join(frames)
for s,b in zip(sizes,frames):members[f'outputs/icon-{s}.png']=b
members['outputs/identity-symbols.png']=atlas_bytes;members['outputs/kingdom-zombies.ico']=ico
recipe={'schemaVersion':1,'tool':'built-in image_gen','outputIdentity':'exec-5b4739c2-e69f-411d-8074-f0b971fd7ac5.png','references':[],'referenceDecision':'No image inputs. Original game crown/camp motif; D-13 simple low-resolution direction, no donor identity art. Donor cursor/keycap sources are separately retained and never used as game identity.','master':{'member':'masters/camp-crown-original.png','sha256':sha(master),'image':info(original)},'prompt':{'member':'prompts/camp-crown.txt','sha256':sha(prompt)},'transformations':[{'op':'alpha-threshold','value':128},{'op':'crop','box':list(box)},{'op':'fit-nearest','size':[32,32],'center':True},{'op':'preserve-sampled-rgb','alpha':'binary, transparent RGB zero'},{'op':'ico-png-frames','sizes':sizes,'resample':'nearest','planes':1,'bits':32}],'mask':'Master alpha threshold at128; no hand-painted or secret mask.','sources':[{'id':x['id'],'source':x['source'],'member':x['member'],'sha256':sha(members['donors/'+x['id']+'.png'])} for x in sources]}
members['recipes/identity.json']=(json.dumps(recipe,indent=2)+'\n').encode();members['recipes/replay.py']=pathlib.Path(__file__).read_bytes()
members['references/ui-style.json']=(json.dumps({'decision':'D-13/D-20/D-24/D-29/D-30','theme':'assets/ui/InspectionTheme.tres','kitSha256':sha((root/'src/godot-game/content/packs/ui-kit.json').read_bytes()),'fontPaths':['assets/ui/LiberationSans.ttf','assets/ui/PerfectDOSVGA437.ttf','assets/ui/Fallback.ttf'],'noEssentialLabelsInPixels':True},indent=2)+'\n').encode()
history=zipfile.ZipFile(root/'.phase4/04-28-pre-amendment-palette.zip')
for name in ['outputs/identity-symbols.png','outputs/kingdom-zombies.ico','recipes/identity.json']:members['history/palette-normalization/'+name]=history.read(name)
for file,data in [('src/godot-game/assets/ui/identity-symbols.png',atlas_bytes),('src/godot-game/assets/ui/kingdom-zombies.ico',ico)]:
 target=root/file;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
bundle=root/'production/phase4/ui-identity.zip'
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(members.items()):
  entry=zipfile.ZipInfo(name,(2026,11,17,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;z.writestr(entry,data)
manifest={'schemaVersion':1,'id':'ui-identity','version':1,'obligations':['UI-03','UI-04','UI-07','UI-08'],'shared':['FX-09','FX-10'],'sampleDataOnly':True,'atlas':{'path':'assets/ui/identity-symbols.png','sha256':sha(atlas_bytes),**info(atlas)},'regions':{'title-emblem':[0,0,32,32],'interaction-cursor':[40,0,32,32],'keycap-frame':[80,0,60,26]},'desktop':{'title':'KingdomZombies','titleMode':'native Label, Display font plus original title-emblem','icon':'assets/ui/kingdom-zombies.ico','sha256':sha(ico),'frames':sizes,'currentProjectIcon':'res://icon.svg','appliedToCurrentExport':False,'applicationOwner':'04-31','visualJudgment':'pending-04-32/04-33'},'provenance':{'bundle':'production/phase4/ui-identity.zip','sha256':sha(bundle.read_bytes()),'members':[{'member':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(members.items())],'recipe':recipe},'acceptance':{'visual':'pending-04-32/04-33','humanApproval':None,'completedObligations':[]}}
(root/'.phase4/04-28-art.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8');print(json.dumps({'master':info(original),'atlas':info(atlas),'bundleMembers':len(members),'icoBytes':len(ico)}))
