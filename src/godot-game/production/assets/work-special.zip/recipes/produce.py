import pathlib, json, io, zipfile, hashlib, importlib.util, sys
sys.dont_write_bytecode=True
root=pathlib.Path(__file__).resolve().parents[2]
s=importlib.util.spec_from_file_location('media',root/'tools/phase4/extract-media.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);Image=m.image_module()
out=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
master=(out/'work-effects-master.png').read_bytes();im=Image.open(io.BytesIO(master)).convert('RGBA');w,h=im.size
assert min(w,h)>=64 and min(im.getchannel('A').getextrema())==0
atlas=Image.new('RGBA',(128,64));components=[];retained={};recipes=[]
for row,kind,size in [(0,'spit',(8,5)),(1,'splash',(16,16)),(2,'stain',(16,5)),(3,'axe',(10,16))]:
 for col in range(4):
  box=(col*w//4,row*h//4,(col+1)*w//4,(row+1)*h//4);cell=im.crop(box);alpha=cell.getchannel('A').point(lambda a:255 if a>=128 else 0);cell.putalpha(alpha);bbox=cell.getbbox();assert bbox
  cropped=cell.crop(bbox);scale=min(size[0]/cropped.width,size[1]/cropped.height);native=cropped.resize((max(1,round(cropped.width*scale)),max(1,round(cropped.height*scale))),Image.Resampling.NEAREST)
  x=col*16+(16-native.width)//2;y=row*16+16-native.height;atlas.paste(native,(x,y));key=f'{kind}.{col}'
  record={'key':key,'atlasRect':[x,y,native.width,native.height],'pivot':[native.width//2,native.height-1] if kind=='stain' else [native.width//2,native.height//2],'source':'generated/work-effects-master.png','cell':list(box),'alphaThreshold':128,'crop':list(bbox),'nativeSize':list(native.size),'rgbaSha256':sha(native.tobytes()),'filter':'nearest','rgbRetained':True}
  components.append(record);recipes.append(record)
common=json.loads((root/'src/godot-game/content/packs/common.json').read_bytes());z=zipfile.ZipFile(root/'production/phase4/common-selected.zip')
hammer=next(r for r in common['resources'] if r['id']=='common.s0.6853');raw=z.read(hammer['member']);tool=Image.open(io.BytesIO(raw)).convert('RGBA');atlas.paste(tool,(64,0));components.append({'key':'hammer','atlasRect':[64,0,*tool.size],'pivot':[2,8],'source':'retained/common/'+hammer['member'],'rgbaSha256':sha(tool.tobytes()),'filter':'nearest','rgbRetained':True});retained['retained/common/'+hammer['member']]=raw
for id in ['common.s0.6853','common.s0.4399','common.s0.7986','common.s0.7212','common.s0.7060']:
 r=next(r for r in common['resources'] if r['id']==id);retained['retained/common/'+id+'.json']=encode(r)
 for source in [r['source'],*r.get('dependencies',[])]:
  for key in ['rawMember']:
   if key in source:retained['retained/common/'+source[key]]=z.read(source[key])
  if source.get('stream'):retained['retained/common/'+source['stream']['member']]=z.read(source['stream']['member'])
 if 'member' in r:retained['retained/common/'+r['member']]=z.read(r['member'])
for id in ['common.clip.1245','common.clip.915','common.clip.823']:
 retained['retained/common/'+id+'.json']=encode(next(c for c in common['clips'] if c['id']==id))
for family,body in [('a','CH-01'),('c','CH-06'),('b','CH-08')]:
 source=zipfile.ZipFile(root/f'production/phase4/bodies-{family}.zip')
 for name in [f'masters/{body}.png',f'prompts/{body}.txt','recipes/build-bodies.py']:
  retained[f'retained/bodies-{family}/'+name]=source.read(name)
 for path in [f'src/godot-game/content/packs/bodies-{family}.json',f'src/godot-game/assets/characters/bodies-{family}.png',f'src/godot-game/content/animation/fits-{family}.json']:
  retained['retained/'+path]=(root/path).read_bytes()
for path in ['src/godot-game/content/config/combat.json','src/godot-game/content/config/items.json','src/godot-game/content/packs/items-01-10.json','src/godot-game/assets/equipment/items-01-10.png']:
 retained['retained/'+path]=(root/path).read_bytes()
png=io.BytesIO();atlas.save(png,format='PNG');png=png.getvalue()
def clip(id,obligation,poses,loop=False,persistent=False,tool=None,event=None,body='CH-01',source=None):
 return {'id':id,'obligation':obligation,'body':body,'samples':[{'pose':p,'duration':d,'angle':a} for p,d,a in poses],'duration':sum(p[1] for p in poses),'loop':loop,'persistent':persistent,'tool':tool,'event':event,'sourceClip':source,'clothing':'fixed-fitted-anchors','inventoryMutation':False}
actions=[
 clip('Sit','AN-10',[('idle',.12,0),('sit',.28,0),('sit',.6,0)],persistent=True),
 clip('Stand','AN-10',[('sit',.1,0),('recover',.15,0),('idle',.15,0)]),
 clip('Gather','AN-11',[('gather',.2,0),('gather',.2,0),('carry',.2,0)],event={'time':.4,'sound':'AU-30'},source='common.clip.915'),
 clip('Put away','AN-11',[('carry',.12,0),('gather',.12,0),('idle',.16,0)],event={'time':.24,'sound':'AU-30'}),
 *[clip(id,'AN-12',[('windup',.25,-1.1),('strike',.25,.7),('recover',.25,.4),('idle',.25,0)],loop=True,tool='hammer',event={'time':.5,'sound':'AU-12'},source='common.clip.1245') for id in ['Build','Hammer','Repair']],
 clip('Chop','AN-12',[('windup',.25,-1.1),('strike',.2,.7),('recover',.25,.4),('idle',.3,0)],loop=True,tool='axe',event={'time':.45,'sound':'AU-13'},source='common.s0.4399'),
 clip('Pickup','AN-13',[('gather',.15,0),('carry',.15,0)],event={'time':.15,'sound':'AU-30'}),
 clip('Carry','AN-13',[('carry',.4,0)],loop=True),
 clip('Deliver','AN-13',[('carry',.12,0),('gather',.12,0),('idle',.16,0)],event={'time':.24,'sound':'AU-30'}),
 clip('Stash','AN-13',[('carry',.12,0),('gather',.12,0),('idle',.16,0)],event={'time':.24,'sound':'AU-18'}),
 clip('Equip','AN-13',[('gather',.12,0),('carry',.12,0),('idle',.16,0)],event={'time':.24,'sound':'AU-18'}),
 clip('Eat','AN-14',[('eat',.2,0),('recover',.1,0),('idle',.1,0)],event={'time':0,'sound':'AU-19'},source='common.clip.823'),
 clip('Spit','AN-15',[('windup',.3,0),('aim',.3,0),('strike',.2,0),('recover',.4,0),('idle',1.8,0)],event={'time':.6,'sound':'AU-08'},body='CH-06'),
 clip('Burst','AN-16',[('hit',.1,0),('collapse-a',.2,0),('collapse-b',.2,0),('corpse',2.5,0)],persistent=True,event={'time':.1,'sound':'AU-29'},body='CH-08')]
combat=json.loads((root/'src/godot-game/content/config/combat.json').read_bytes());spit=next(p for p in combat['projectiles'] if p['projectileId']=='spit')
pack={'schemaVersion':1,'version':1,'id':'work-special','obligations':[f'AN-{n:02}' for n in range(10,17)],'clock':'explicit-elapsed-only','atlas':{'path':'src/godot-game/assets/characters/work-special.png','sha256':sha(png),'width':128,'height':64},'components':components,'actions':actions,'spit':{**spit,'intervalSeconds':3,'releaseSeconds':.6,'pixelsPerUnit':2,'firstContactUnits':4,'mouthOffsetFromFace':[1,1],'sound':'AU-08','impactSound':'AU-08'},'burst':{'stainSeconds':1.5,'damage':0,'slowdown':0,'blocksMovement':False,'corpseIndependent':True,'lootRetained':True},'fixtures':{'transfer':['Empty','Plant','Carried','Delivered','Equipped'],'payloadItem':'IT-08','freeCapacity':False,'toolInventoryItems':False,'gameplayEvents':0},'provenance':{'generationTool':'built-in image_gen','master':'generated/work-effects-master.png','masterSha256':sha(master),'prompt':'prompts/work-effects.txt','promptSha256':sha((out/'work-effects-prompt.txt').read_bytes()),'recipe':'recipes/produce.py','sourceReview':'source-component inspection only; actual appearance/listening/acceptance pending04-32/33'}}
definition=encode(pack)
(root/'src/godot-game/content/animation/work-special.json').write_bytes(definition);(root/'src/godot-game/assets/characters/work-special.png').write_bytes(png)
retained.update({'generated/work-effects-master.png':master,'prompts/work-effects.txt':(out/'work-effects-prompt.txt').read_bytes(),'recipes/produce.py':pathlib.Path(__file__).read_bytes(),'recipes/extract-media.py':(root/'tools/phase4/extract-media.py').read_bytes(),'recipes/components.json':encode(recipes),'work-special.json':definition,'work-special.png':png})
retained['members.json']=encode([{'path':k,'bytes':len(v),'sha256':sha(v)} for k,v in sorted(retained.items())])
with zipfile.ZipFile(root/'production/phase4/work-special.zip','w',compression=zipfile.ZIP_DEFLATED) as bundle:
 for name,data in sorted(retained.items()):bundle.writestr(name,data)
print(json.dumps({'components':len(components),'actions':len(actions),'members':len(retained),'masterSize':[w,h],'atlas':[128,64]}))
