"""Adapt retained authored raster poses; no procedural body artwork."""
import sys,pathlib,json,hashlib,io,zipfile,copy,math
sys.dont_write_bytecode=True
sys.path.insert(0,'D:/Work/Games/KindomCrown/.tools/resource-python')
from PIL import Image
ROOT=pathlib.Path('D:/Work/Games/KingdomZombies');WORK=ROOT/'.phase4/04-07'
POSES=['idle','walk-near','walk-far','run','windup','strike','recover','aim','hit','collapse-a','collapse-b','corpse','sit','gather','eat','carry']
CONFIG={'b':[('CH-04','Brute',32,9,'broad-heavy-arms'),('CH-05','Armored zombie neutral body',30,5,'rigid-upright-angular-jaw'),('CH-08','Acid bloater',30,11,'fat-belly-sloping-shoulders')],'c':[('CH-06','Spitter',30,5,'long-neck-forward-mouth'),('CH-07','Zombie archer',30,5,'lean-braced-archer')]}
def sha(x):return hashlib.sha256(x).hexdigest()
def js(x):return (json.dumps(x,ensure_ascii=False,allow_nan=False,indent=2)+'\n').encode()
def png(im):
 b=io.BytesIO();im.save(b,format='PNG',compress_level=9);return b.getvalue()
def clean(im):
 im=im.convert('RGBA');im.putdata([(r,g,b,255) if a>=240 and not(r>180 and r>g*2 and r>b*2) else (0,0,0,0) for r,g,b,a in im.get_flattened_data()]);return im
def largest(im):
 p=im.load();seen=set();best=[]
 for y in range(im.height):
  for x in range(im.width):
   if (x,y) in seen or p[x,y][3]==0:continue
   q=[(x,y)];seen.add((x,y));group=[]
   while q:
    a,b=q.pop();group.append((a,b))
    for dy in [-1,0,1]:
     for dx in [-1,0,1]:
      c,d=a+dx,b+dy
      if 0<=c<im.width and 0<=d<im.height and (c,d) not in seen and p[c,d][3]:seen.add((c,d));q.append((c,d))
   if len(group)>len(best):best=group
 out=Image.new('RGBA',im.size)
 for x,y in best:out.putpixel((x,y),p[x,y])
 return out
def rows(im):
 groups=[]
 for y in range(im.height):
  if sum(a>0 for a in im.getchannel('A').crop((0,y,im.width,y+1)).tobytes())<=12:continue
  if not groups or y>groups[-1][-1]+8:groups.append([y])
  else:groups[-1].append(y)
 assert len(groups)==4,('ROW_GROUPS',[(g[0],g[-1]) for g in groups])
 return [(g[0],g[-1]+1) for g in groups]
def build(profile):
 members={};reviews=[];bodies=[];parts=[];fits=copy.deepcopy(json.loads((ROOT/'src/godot-game/content/animation/fits-a.json').read_bytes()));fits['id']='fits-'+profile;fits['bodies']=[]
 with zipfile.ZipFile(ROOT/'production/phase4/bodies-a.zip') as z:
  for name in z.namelist():
   if name.startswith('references/'):members[name]=z.read(name)
  members['references/neutral-shambler-sheet.png']=z.read('masters/CH-02.png')
 members['references/scale-pilot.json']=(ROOT/'src/godot-game/content/packs/scale-pilot.json').read_bytes()
 with zipfile.ZipFile(ROOT/'production/phase4/scale-pilot.zip') as z:members['references/scale-native-zombie.png']=z.read('native/zombie.png')
 common=json.loads((ROOT/'src/godot-game/content/packs/common.json').read_bytes())
 with zipfile.ZipFile(ROOT/'production/phase4/common-selected.zip') as z:
  for id in ['common.r.6011','common.r.6056','common.r.6095']:
   row=next(r for r in common['resources'] if r['id']==id);members['references/'+id+'.json']=js(row);members['references/'+id+'.png']=z.read(row['member']);members['references/'+id+'.bin']=z.read(row['source']['rawMember'])
   reviews.append({'source':id,'sourceIdentity':row['source'],'suitability':'K15 posture/timing reference only; clothed fantasy actor pixels excluded from neutral bodies. Actual K20 bow/arrow is separate IT-07/02 gear.'})
  for id in ['common.clip.777','common.clip.780','common.clip.783','common.clip.786','common.clip.804']:
   row=next(r for r in common['clips'] if r['id']==id);members['references/'+id+'.json']=js(row)
 reviews.append({'source':'references/neutral-shambler-sheet.png','sha256':sha(members['references/neutral-shambler-sheet.png']),'suitability':'Neutral separation and muted undead palette reference only; five distinct authored shapes, not recolored ordinary body'})
 atlas=Image.new('RGBA',(768,40*math.ceil(len(CONFIG[profile])*64/16)))
 landmarks=json.loads((WORK/'landmarks.json').read_bytes());members['recipes/landmarks.json']=js(landmarks)
 for id,name,height,width,silhouette in CONFIG[profile]:
  raw=(WORK/(id+'.png')).read_bytes();master='masters/'+id+'.png';members[master]=raw;members['prompts/'+id+'.txt']=(WORK/(id+'.txt')).read_bytes();source=Image.open(io.BytesIO(raw)).convert('RGBA');im=clean(source);bands=rows(im);first=largest(im.crop((0,bands[0][0],im.width//4,bands[0][1])));bb=first.getbbox();factor=height/(bb[3]-bb[1]);poses=[];fitposes=[]
  for pi,pose in enumerate(POSES):
   col=pi%4;row=pi//4;cell=[round(im.width*col/4),bands[row][0],round(im.width*(col+1)/4),bands[row][1]];cut=largest(im.crop(cell));bb=cut.getbbox();assert bb,('EMPTY',id,pose);crop=[cell[0]+bb[0],cell[1]+bb[1],cell[0]+bb[2],cell[1]+bb[3]];cut=largest(im.crop(crop));size=[max(1,round(cut.width*factor)),max(1,round(cut.height*factor))];assert size[0]<=46 and size[1]<=36,(id,pose,size);at=[24-size[0]//2,38-size[1]];frame=Image.new('RGBA',(48,40));frame.alpha_composite(cut.resize(size,Image.Resampling.NEAREST),at)
   anchors={k:[at[0]+round(v[0]*size[0]),at[1]+round(v[1]*size[1])] for k,v in landmarks[id][pose].items()};head=anchors['head'];hip=anchors['hips'];headbox=[max(0,head[0]-2),max(0,head[1]-2),min(48,head[0]+3),min(40,head[1]+3)];split=max(at[1]+1,min(37,hip[1]));keys={}
   for label in ['full','head','upper','lower']:
    bounds=[0,0,48,40] if label=='full' else headbox if label=='head' else [0,0,48,split] if label=='upper' else [0,split,48,40];exclude=[] if label in ['full','head'] else [headbox];layer=Image.new('RGBA',(48,40));layer.paste(frame.crop(bounds),(bounds[0],bounds[1]));
    for box in exclude:layer.paste((0,0,0,0),box)
    key=id+'.'+pose+'.'+label;data=png(layer);member='native/'+key+'.png';members[member]=data;idx=len(parts);x=idx%16*48;y=idx//16*40;atlas.alpha_composite(layer,(x,y));keys[label]=key;parts.append({'key':key,'member':member,'origin':master,'sha256':sha(data),'rgbaSha256':sha(layer.tobytes()),'atlasRect':[x,y,48,40],'pivot':[24,38],'density':1,'worldSize':[48,40],'operations':[{'op':'mask','alphaAtLeast':240,'removeRedMatte':[180,2,2]},{'op':'crop','box':crop},{'op':'largest-component','connectivity':8},{'op':'nearest','size':size},{'op':'place','canvas':[48,40],'at':at},{'op':'partition','bounds':bounds,'exclude':exclude}]})
   poses.append({'id':pose,'parts':keys,'pivot':[24,38],'head':head,'hips':hip,'sourceCell':cell,'sourceCrop':crop,'nativeSize':size,'nativePlacement':at,'duration':0 if pose=='corpse' else .12,'persistent':pose=='corpse','authored':True,'bakedEquipment':[]})
   torso=anchors['torso'];length=max(1,round(math.dist(torso,hip)));angle=round((math.atan2(hip[1]-torso[1],hip[0]-torso[0])-math.pi/2)/(math.pi/2))*math.pi/2
   fitposes.append({'id':pose,'bodyParts':keys,'anchors':anchors,'torsoLength':length,'persistent':pose=='corpse','unlinkedRotation':angle if pose in ['collapse-b','corpse','sit','gather'] else 0,'mouthRelease':anchors['face'] if id=='CH-06' else None})
   reviews.append({'source':master,'cell':pi,'pose':pose,'suitability':'Distinct complete authored neutral pose; retained RGB and nearest-only adaptation. No selectable item baked. Final physical appearance judgment pending04-32.'})
  bodies.append({'id':id,'name':name,'master':master,'masterSha256':sha(raw),'prompt':'prompts/'+id+'.txt','promptSha256':sha(members['prompts/'+id+'.txt']),'tool':'built-in image_gen','sourceCanvas':list(source.size),'sourceAlphaRange':list(source.getchannel('A').getextrema()),'logicalStandingHeight':height,'sharedScale':factor,'silhouette':silhouette,'poses':poses,'bakedEquipment':[]})
  limb=5 if id=='CH-04' else 3;componentWidths={}
  for item in fits['items']:
   for layer in item['layers']:
    comp=layer['component']
    if comp.startswith('sleeve'):componentWidths[comp]=limb
    elif comp.startswith('leg-'):componentWidths[comp]=4 if id in ['CH-04','CH-08'] else 3
    elif comp in ['waist','hem'] or item['id']=='IT-21':componentWidths[comp]=width+2
  fits['bodies'].append({'id':id,'width':width,'componentWidths':componentWidths,'poses':fitposes})
 fits['bindings'][0]={'path':'content/packs/bodies-'+profile+'.json','sha256':''};fits['sourceAdaptation']={'coordinateSpace':'48x40 registered density1; facing reflects X about24','landmarks':'recipes/landmarks.json; separately authored per body/pose from retained sources','itemSizing':'Actual24 item masters:22 wearable/held presentations; IT-01 money and IT-22 pouch remain inventory/container only, never invented worn bags','sampling':'nearest','unlinkedRotation':'corpse/collapse/task alignment follows authored torso; held item master size is unchanged'}
 fits['applicability']=[{'item':'IT-'+str(i).zfill(2),'presentation':'inventory-container-only' if i in [1,22] else 'worn-held','bodies':[b['id'] for b in bodies],'poses':[] if i in [1,22] else POSES,'facings':[] if i in [1,22] else [-1,1],'reason':'Money has no wearable slot; portable pouch contents do not create a worn bag' if i in [1,22] else 'Every legal slot and pose, including equipped persistent corpse'} for i in range(1,25)]
 pack={'schemaVersion':1,'version':1,'id':'bodies-'+profile,'logicalPixelsPerWorldPixel':1,'scaleDecision':'D-13-pilot-1','stylePrecedence':'D-13 LOW-RESOLUTION OVERRIDES older richer defaults','atlas':{'path':'res://assets/characters/bodies-'+profile+'.png','size':list(atlas.size),'sha256':sha(png(atlas))},'commonBundleSha256':sha((ROOT/'production/phase4/common-selected.zip').read_bytes()),'pilotBundleSha256':sha((ROOT/'production/phase4/scale-pilot.zip').read_bytes()),'bodies':bodies,'parts':parts,'sourceSuitability':reviews,'acceptance':{'visual':'pending','humanApproval':None,'owner':'04-32/04-33','completedObligations':[]},'recipe':{'member':'recipes/build-bodies.py','sha256':sha(pathlib.Path(__file__).read_bytes()),'Python':'3.12.14','Pillow':'13.0.0'}}
 members['recipes/build-bodies.py']=pathlib.Path(__file__).read_bytes();members['bodies-'+profile+'.png']=png(atlas);members['bodies-'+profile+'.json']=js(pack);fits['bindings'][0]['sha256']=sha(members['bodies-'+profile+'.json']);members['fits-'+profile+'.json']=js(fits);members['members.json']=js([{'path':k,'bytes':len(v),'sha256':sha(v)} for k,v in sorted(members.items())]);out=WORK/('stage-'+profile);out.mkdir(exist_ok=True)
 with zipfile.ZipFile(out/('bodies-'+profile+'.zip'),'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,data in sorted(members.items()):z.writestr(name,data)
 for name in ['bodies-'+profile+'.png','bodies-'+profile+'.json','fits-'+profile+'.json']:(out/name).write_bytes(members[name])
 board=Image.new('RGBA',(48*4,40*4*len(bodies)))
 for bi,b in enumerate(bodies):
  for pi,p in enumerate(b['poses']):board.alpha_composite(Image.open(io.BytesIO(members['native/'+p['parts']['full']+'.png'])),(pi%4*48,(bi*4+pi//4)*40))
 board.resize((board.width*4,board.height*4),Image.Resampling.NEAREST).save(out/'body-board.png');print(json.dumps({'profile':profile,'bodies':len(bodies),'poses':len(bodies)*16,'parts':len(parts),'members':len(members)}))
if __name__=='__main__':build(sys.argv[1])
