"""Selected generated pose adaptation; no procedural substitute character art."""
import pathlib,sys,json,hashlib,io,zipfile,time,math
sys.dont_write_bytecode=True
sys.path.insert(0,'D:/Work/Games/KindomCrown/.tools/resource-python')
from PIL import Image
ROOT=pathlib.Path('D:/Work/Games/KingdomZombies');WORK=ROOT/'.phase4/04-06'
POSES=['idle','walk-near','walk-far','run','windup','strike','recover','aim','hit','collapse-a','collapse-b','corpse','sit','gather','eat','carry']
def sha(b):return hashlib.sha256(b).hexdigest()
def js(x):return (json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def png(im):
 b=io.BytesIO();im.save(b,format='PNG',compress_level=9);return b.getvalue()
def clean(im):
 im=im.convert('RGBA');im.putdata([(r,g,b,255) if a>=240 and not(r>180 and r>g*2 and r>b*2) else (0,0,0,0) for r,g,b,a in im.get_flattened_data()]);return im
def rows(im):
 ys=[y for y in range(im.height) if sum(a>0 for a in im.getchannel('A').crop((0,y,im.width,y+1)).tobytes())>12];groups=[]
 for y in ys:
  if not groups or y>groups[-1][-1]+8:groups.append([y])
  else:groups[-1].append(y)
 assert len(groups)==4,('ROW_GROUPS',[(g[0],g[-1]) for g in groups])
 return [(g[0],g[-1]+1) for g in groups]
def largest(im):
 pixels=im.load();seen=set();best=[]
 for y in range(im.height):
  for x in range(im.width):
   if (x,y) in seen or pixels[x,y][3]==0:continue
   group=[];queue=[(x,y)];seen.add((x,y))
   while queue:
    a,b=queue.pop();group.append((a,b))
    for dy in [-1,0,1]:
     for dx in [-1,0,1]:
      c,d=a+dx,b+dy
      if 0<=c<im.width and 0<=d<im.height and (c,d) not in seen and pixels[c,d][3]:seen.add((c,d));queue.append((c,d))
   if len(group)>len(best):best=group
 out=Image.new('RGBA',im.size);target=out.load()
 for x,y in best:target[x,y]=pixels[x,y]
 return out
def main():
 out=WORK/('stage-'+str(time.time_ns()));out.mkdir();members={};parts=[];bodies=[];atlas=Image.new('RGBA',(768,520));reviews=[]
 common=json.loads((ROOT/'src/godot-game/content/packs/common.json').read_bytes())
 donor_ids=['common.s0.2361','common.s0.7052','common.s0.10365','common.s0.7060','common.s0.7246','common.s0.10669']
 with zipfile.ZipFile(ROOT/'production/phase4/common-selected.zip') as z:
  for id in donor_ids:
   d=next(x for x in common['resources'] if x['id']==id);members['references/'+id+'.json']=js(d);members['references/'+id+'.png']=z.read(d['member']);members['references/'+id+'.bin']=z.read(d['source']['rawMember'])
   reviews.append({'source':id,'sourceIdentity':d['source'],'suitability':'K14/K18 proportions and motion reference; baked clothes excluded from neutral body pixels; all newly authored neutral pixels identified as generated, never unchanged donor reuse'})
 for file in ['zombie-idle-original-size.png','zombie-walk-strip.png','zombie-attack-strip.png']:
  raw=(ROOT/'examples/zombie'/file).read_bytes();members['references/'+file]=raw;reviews.append({'source':'examples/zombie/'+file,'sha256':sha(raw),'suitability':'Head palette/profile and collapse/motion reference; baked shirt/trousers excluded; only idle uncovered head pixels adapted into CH-02 head component'})
 members['references/scale-pilot.json']=(ROOT/'src/godot-game/content/packs/scale-pilot.json').read_bytes()
 for file in ['rejected-covered-survivor.png','rejected-covered-expanded.txt','rejected-safety.json','runner-original-clipped.png','runner-expanded.txt','runner-repair-expanded.txt']:
  members['history/'+file]=(WORK/file).read_bytes()
 for bi,(id,name,file,prompt,height) in enumerate([('CH-01','Shared survivor','survivor-original.png','survivor-expanded.txt',30),('CH-02','Hunched shambler','shambler-original.png','shambler-expanded.txt',28),('CH-03','Lean runner','runner-selected.png','runner-repair-expanded.txt',30)]):
  raw=(WORK/file).read_bytes();master='masters/'+id+'.png';members[master]=raw;members['prompts/'+id+'.txt']=(WORK/prompt).read_bytes();source=Image.open(io.BytesIO(raw)).convert('RGBA');im=clean(source);bands=rows(im);pose_records=[]
  first=im.crop((0,bands[0][0],im.width//4,bands[0][1]));firstbox=first.getbbox();factor=height/(firstbox[3]-firstbox[1])
  for pi,pose in enumerate(POSES):
   col=pi%4;row=pi//4;box=[round(im.width*col/4),bands[row][0],round(im.width*(col+1)/4),bands[row][1]];cell=largest(im.crop(box));bbox=cell.getbbox();assert bbox,('EMPTY',id,pose)
   # One shared scale per body preserves the authored changes in height/length.
   crop=[box[0]+bbox[0],box[1]+bbox[1],box[0]+bbox[2],box[1]+bbox[3]];cut=largest(im.crop(crop));size=[max(1,round(cut.width*factor)),max(1,round(cut.height*factor))];assert size[0]<=44 and size[1]<=34,(id,pose,size)
   cut=cut.resize(size,Image.Resampling.NEAREST);frame=Image.new('RGBA',(48,40));at=[24-size[0]//2,38-size[1]];frame.alpha_composite(cut,at)
   # Source hand/hip landmarks are refined against the resulting native sheet before publication.
   hip=[at[0]+round(size[0]*.44),at[1]+round(size[1]*.60)];hy=frame.getbbox()[1]+2;xs=[x for x in range(48) if frame.getpixel((x,hy))[3]];head=[round(sum(xs)/len(xs)),hy]
   if pose=='corpse':hip=[at[0]+round(size[0]*.45),at[1]+round(size[1]*.5)];head=[at[0]+round(size[0]*.88),at[1]+round(size[1]*.40)]
   pivot=[24,38];keys={};split=max(at[1]+1,min(37,hip[1]));headbox=[max(0,head[0]-3),max(0,head[1]-3),min(48,head[0]+3),min(40,head[1]+3)]
   for label in ['full','head','upper','lower']:
    layer=frame.copy();bounds=[0,0,48,40];exclude=[]
    if label=='head':bounds=headbox
    elif label=='upper':bounds=[0,0,48,split];exclude=[headbox]
    elif label=='lower':bounds=[0,split,48,40]
    if label!='full':layer=Image.new('RGBA',(48,40));layer.paste(frame.crop(bounds),(bounds[0],bounds[1]))
    if label=='lower':exclude=[headbox]
    for cutbox in exclude:layer.paste((0,0,0,0),cutbox)
    key=id+'.'+pose+'.'+label;member='native/'+key+'.png';data=png(layer);members[member]=data;index=len(parts);x=(index%16)*48;y=(index//16)*40;atlas.alpha_composite(layer,(x,y));keys[label]=key
    parts.append({'key':key,'member':member,'origin':master,'sha256':sha(data),'rgbaSha256':sha(layer.tobytes()),'atlasRect':[x,y,48,40],'pivot':pivot,'density':1,'worldSize':[48,40],'operations':[{'op':'mask','alphaAtLeast':240,'removeRedMatte':[180,2,2]},{'op':'crop','box':crop},{'op':'largest-component','connectivity':8},{'op':'nearest','size':size},{'op':'place','canvas':[48,40],'at':at},{'op':'partition','bounds':bounds,'exclude':exclude}]})
   pose_records.append({'id':pose,'parts':keys,'pivot':pivot,'head':head,'hips':hip,'sourceCell':box,'sourceCrop':crop,'nativeSize':size,'nativePlacement':at,'duration':.12 if pose!='corpse' else 0,'persistent':pose=='corpse','authored':True,'bakedEquipment':[]})
  bodies.append({'id':id,'name':name,'master':master,'masterSha256':sha(raw),'prompt':'prompts/'+id+'.txt','promptSha256':sha(members['prompts/'+id+'.txt']),'tool':'built-in image_gen','sourceCanvas':list(source.size),'sourceAlphaRange':list(source.getchannel('A').getextrema()),'logicalStandingHeight':height,'sharedScale':factor,'silhouette':['upright-natural','hunched-rounded-shoulders','lean-forward-long-limbs'][bi],'poses':pose_records,'bakedEquipment':[]})
  reviews.extend({'source':master,'cell':pi,'pose':p['id'],'suitability':'Selected complete neutral authored pose; no selectable gear; strict matte cleanup and common body scale; appearance judgement pending04-32'} for pi,p in enumerate(pose_records))
 # An uncovered source head is retained as a separately reusable adaptation, never a clothed full-body import.
 original=Image.open(io.BytesIO(members['references/zombie-idle-original-size.png'])).convert('RGBA');box=[560,260,815,540];head=clean(original.crop(box)).resize((5,6),Image.Resampling.NEAREST);members['adapted/local-shambler-head.png']=png(head)
 frame=Image.new('RGBA',(48,40));frame.alpha_composite(head,(22,8));index=len(parts);x=(index%16)*48;y=(index//16)*40;atlas.alpha_composite(frame,(x,y));data=png(frame);members['native/CH-02.local-head.png']=data
 parts.append({'key':'CH-02.local-head','member':'native/CH-02.local-head.png','origin':'references/zombie-idle-original-size.png','sha256':sha(data),'rgbaSha256':sha(frame.tobytes()),'atlasRect':[x,y,48,40],'pivot':[24,38],'density':1,'worldSize':[48,40],'operations':[{'op':'mask','alphaAtLeast':240,'removeRedMatte':[180,2,2]},{'op':'crop','box':box},{'op':'nearest','size':[5,6]},{'op':'place','canvas':[48,40],'at':[22,8]},{'op':'partition','bounds':[0,0,48,40]}]})
 pack={'schemaVersion':1,'id':'bodies-a','version':1,'logicalPixelsPerWorldPixel':1,'scaleDecision':'D-13-pilot-1','stylePrecedence':'D-13 LOW-RESOLUTION OVERRIDES older richer sprite defaults','atlas':{'path':'res://assets/characters/bodies-a.png','size':list(atlas.size),'sha256':sha(png(atlas))},'commonBundleSha256':sha((ROOT/'production/phase4/common-selected.zip').read_bytes()),'pilotBundleSha256':sha((ROOT/'production/phase4/scale-pilot.zip').read_bytes()),'bodies':bodies,'parts':parts,'sourceSuitability':reviews,'headAdaptation':{'body':'CH-02','member':'adapted/local-shambler-head.png','source':'references/zombie-idle-original-size.png','operations':[{'op':'crop','box':box},{'op':'mask','alphaAtLeast':240},{'op':'nearest','size':[5,6]}],'sha256':sha(members['adapted/local-shambler-head.png']),'binding':'head component source; integrated with per-pose facing in04-06 fit renderer'},'acceptance':{'visual':'pending','humanApproval':None,'owner':'04-32/04-33','completedObligations':[]},'recipe':{'member':'recipes/build-bodies.py','sha256':sha(pathlib.Path(__file__).read_bytes()),'Python':'3.12.14','Pillow':'13.0.0'}}
 members['bodies-a.png']=png(atlas);members['bodies-a.json']=js(pack);members['recipes/build-bodies.py']=pathlib.Path(__file__).read_bytes();members['members.json']=js([{'path':k,'bytes':len(v),'sha256':sha(v)} for k,v in sorted(members.items())])
 with zipfile.ZipFile(out/'bodies-a.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,data in sorted(members.items()):z.writestr(name,data)
 for name in ['bodies-a.png','bodies-a.json']:(out/name).write_bytes(members[name])
 # Source-side integer enlargement only, no actual game/rendered acceptance.
 atlas.resize((atlas.width*4,atlas.height*4),Image.Resampling.NEAREST).save(out/'native-nearest4x.png')
 (WORK/'latest-stage.txt').write_text(str(out));print(json.dumps({'stage':str(out),'bodies':len(bodies),'poses':sum(len(x['poses']) for x in bodies),'parts':len(parts),'members':len(members)}))
if __name__=='__main__':main()
