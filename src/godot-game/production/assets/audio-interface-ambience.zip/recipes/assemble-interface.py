import array,base64,hashlib,html,io,json,math,pathlib,random,sys,wave,zipfile
root=pathlib.Path(sys.argv[1]).resolve();assert root.is_relative_to(pathlib.Path('D:/Work/Games/KingdomZombies/.phase4').resolve())
sha=lambda x:hashlib.sha256(x).hexdigest()
config=json.loads((root/'selection.json').read_text());members={};sources=[];samples=[];bank=array.array('h')
def wav(pcm):
    out=io.BytesIO()
    with wave.open(out,'wb') as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(44100);f.writeframes(pcm)
    return out.getvalue()
def add(identity,data,source,trim,gain,loop=None,transform='trim-gain'):
    pcm=data.tobytes();payload=wav(pcm);first=len(bank)//2;bank.extend(data);end=len(bank)//2;bank.extend([0]*4410)
    member='variants/'+identity+'.wav';members[member]=payload
    peak=max(abs(v) for v in data);rms=math.sqrt(sum(v*v for v in data)/len(data))
    samples.append({'id':identity,'version':1,'sourceId':source,'variantMember':member,'sha256':sha(payload),'pcmSha256':sha(pcm),
      'frames':len(data)//2,'channels':2,'rate':44100,'sampleWidth':2,'durationSeconds':len(data)/2/44100,'trimFrames':trim,
      'gainLinear':gain,'gainDb':20*math.log10(gain),'regionFrames':[first,end],'loop':loop,'transform':transform,
      'listening':{'status':'Not auditioned','listener':None,'verdict':None,'finalOwner':'04-32'},
      'technical':{'peak':peak,'rms':rms,'nonzeroSamples':sum(v!=0 for v in data),'fullScaleSamples':sum(abs(v)>=32767 for v in data)}})
for key,object_id,name in config['candidates']:
    identity=key+str(object_id);folder=root/('interface.'+identity);record=json.loads((folder/'sample.json').read_text())
    original=(folder/(name+'.wav')).read_bytes();prefix='sources/'+identity
    members[prefix+'/original.wav']=original;members[prefix+'/stream.fsb']=base64.b64decode(record['bundle']['originalPayloadBase64'])
    members[prefix+'/audioclip.bin']=base64.b64decode(record['bundle']['rawAudioClipBase64']);del record['bundle']
    members[prefix+'/provenance.json']=(json.dumps(record,indent=2)+'\n').encode()
    sources.append({**record,'id':identity,'sourceMember':prefix+'/original.wav'})
    with wave.open(io.BytesIO(original),'rb') as f:raw=f.readframes(f.getnframes())
    values=array.array('h');values.frombytes(raw)
    if record['output']['channels']==1:values=array.array('h',(v for x in values for v in (x,x)))
    gain=min(1.0,24575/max(abs(v) for v in values))
    if object_id in [3558,4441,125,138,152]:
        fade=512;count=min(len(values)//2,44100*8+fade);original_trim=values[:count*2]
        out=array.array('h')
        for i in range(count-fade):
            for channel in range(2):
                value=original_trim[i*2+channel]
                if i<fade:
                    t=i/(fade-1);value=value*t+original_trim[(count-fade+i)*2+channel]*(1-t)
                out.append(round(value*gain))
        loop={'mode':'forward','startFrame':0,'endFrame':len(out)//2,'crossfadeFrames':fade,'sourceTrimFrames':[0,count],
          'method':'tail-head-overlap-add','auditorySeamVerdict':'Not auditioned'}
        add('interface.'+identity+'.loop',out,identity,[0,count],gain,loop,'trim-overlap-add-gain')
    else:
        add('interface.'+identity+'.full',array.array('h',(round(v*gain) for v in values)),identity,[0,len(values)//2],gain)
    if key=='s0' and object_id==485:
        count=min(6615,len(values)//2);one=array.array('h',(round(v*gain*0.7) for v in values[:count*2]))
        add('interface.s0485.negative',one+array.array('h',[0]*4410)+one,identity,[0,count],gain*0.7,None,'two-pulses-with-2205-frame-gap')
    if key=='r' and object_id==3755:
        count=min(6615,len(values)//2)
        add('interface.handling.v1',array.array('h',(round(v*gain*0.5) for v in values[:count*2])),identity,[0,count],gain*0.5)
# AU19 is an explicit source-backed catalog gap, not an unheard donor rejection.
# Deterministic non-tonal contact/crunch texture; no music, speech model or downloaded recording.
rng=random.Random(190021);food=array.array('h');previous=0.0
for i in range(11025):
    t=i/44100;noise=rng.uniform(-1,1);high=noise-previous;previous=noise
    envelope=sum(math.exp(-max(0,t-onset)*55) if t>=onset else 0 for onset in [0.01,0.07,0.13,0.19])
    value=round(max(-1,min(1,high*envelope*0.15))*16384);food.extend([value,value])
add('interface.food-crunch.v1',food,'generated-food-crunch',[0,11025],1,None,'seed190021-four-noise-transients')
with zipfile.ZipFile(config['actionsZip']) as z:
    a=json.loads(z.read('production/manifest.json'));s=next(x for x in a['samples'] if x['id']=='action.2790.full')
    with wave.open(io.BytesIO(z.read(s['variantMember'])),'rb') as f:burst=array.array('h');burst.frombytes(f.readframes(min(f.getnframes(),13230)))
add('interface.bloater-burst.v1',array.array('h',(round(v*0.65) for v in burst)),'action.2790.full',[0,len(burst)//2],0.65,None,'shared-approved-source-new-trim-not-auditioned')
pack={'schemaVersion':1,'id':'audio-interface-ambience','version':1,'status':'production-resources-listening-pending',
 'scope':'AU16-30 actual source/variant resources; all new variants Not auditioned; native mix and loop hearing pending04-32',
 'bank':{'path':'assets/audio/interface-ambience.wav','sha256':sha(wav(bank.tobytes())),'frames':len(bank)//2,'channels':2,'rate':44100,'sampleWidth':2},
 'sources':sources,'samples':samples,'listening':{'status':'Not auditioned','listener':None,'verdicts':[],'acceptanceOwner':'04-32'},
 'donorGap':{'category':'AU-19','authority':'specs/0.1/assets-and-resources.md section10 AU-19',
 'evidence':'Food-use detail has no verified suitable human donor in the approved donor inventory; animal-eating recordings are not selected as human food sounds',
 'synthesis':'Deterministic non-tonal contact/crunch texture seed190021; needs real audition','unsupportedDonorUnsuitabilityClaims':[]},
 'sharedSources':[{'id':'action.2790.full','pack':'packs/audio-actions.json','wavSha256':s['sha256'],'use':'New cosmetic burst trim; creator approval not extended'}],
 'recipes':{'decoderMember':'recipes/decode-interface.py','decoderSha256':sha((root/'decode-interface.py').read_bytes()),
 'assemblerMember':'recipes/assemble-interface.py','assemblerSha256':sha(pathlib.Path(__file__).read_bytes())}}
members['recipes/decode-interface.py']=(root/'decode-interface.py').read_bytes();members['recipes/assemble-interface.py']=pathlib.Path(__file__).read_bytes()
members['recipes/selection.json']=(root/'selection.json').read_bytes()
rows=[]
for s in samples:
    rows.append('<h2>'+s['id']+' v1 — Not auditioned</h2><p>Frames '+str(s['regionFrames'])+'; trim '+str(s['trimFrames'])+'; SHA256 '+s['sha256']+'</p>'
    +'<audio controls preload="none" '+('loop ' if s['loop'] else '')+'src="../'+s['variantMember']+'"></audio>')
members['review/index.html']=('<!doctype html><html lang="en"><meta charset="utf-8"><title>AU16-30 source review</title><style>body{font:16px sans-serif;max-width:900px;margin:auto}p{overflow-wrap:anywhere}audio{width:100%}</style>'
 '<h1>AU16-30 — Not auditioned</h1><p>Deliberate playback only. Check full source and variant for suitability/music/speech/identity/distortion/onset/tail. '
 'Repeat ambience across boundaries; record seam/pump/drop observations. No final game mix approval is presumed.</p>'+''.join(rows)+'</html>').encode()
members['review/questions.txt']=b'For each exact version: suitable category and material? unwanted speech/music/source identity? silence/distortion? onset/tail/punch? For five loops hear several boundaries and quiet action-overlay balance in later native mix. Record actual listener/device/time and verdict; creator action approval does not cover these new versions.'
pack['bundleMembers']=[{'path':k,'bytes':len(v),'sha256':sha(v)} for k,v in sorted(members.items())]
members['production/manifest.json']=(json.dumps(pack,indent=2,allow_nan=False)+'\n').encode()
with zipfile.ZipFile(root/'audio-interface-ambience.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,payload in sorted(members.items()):
        info=zipfile.ZipInfo(name,(2026,11,18,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,payload,compresslevel=9)
pack['bundleSha256']=sha((root/'audio-interface-ambience.zip').read_bytes())
(root/'audio-interface-ambience.json').write_text(json.dumps(pack,indent=2,allow_nan=False)+'\n',encoding='utf-8',newline='\n')
(root/'interface-ambience.wav').write_bytes(wav(bank.tobytes()))
print(json.dumps({'sources':len(sources),'variants':len(samples),'zipBytes':(root/'audio-interface-ambience.zip').stat().st_size,'bankBytes':len(wav(bank.tobytes()))}))
