import sys,pathlib,json,zipfile,io,hashlib,math
sys.dont_write_bytecode=True
sys.path.insert(0,'D:/Work/Games/KindomCrown/.tools/resource-python')
from PIL import Image,ImageDraw
ROOT=pathlib.Path('D:/Work/Games/KingdomZombies');HERE=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def js(x):return (json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()
def png(im):
 b=io.BytesIO();im.save(b,format='PNG',compress_level=9);return b.getvalue()
def binary(im):
 im=im.convert('RGBA');im.putalpha(im.getchannel('A').point(lambda a:255 if a>=128 else 0));im.putdata([(r,g,b,a) if a else (0,0,0,0) for r,g,b,a in im.get_flattened_data()]);return im
def info(im):return {'size':list(im.size),'rgbaSha256':sha(im.tobytes()),'alphaBBox':list(im.getbbox()) if im.getbbox() else None,'alphaValues':sorted(set(im.getchannel('A').tobytes()))}
common=zipfile.ZipFile(ROOT/'production/phase4/common-selected.zip');cp=json.loads(common.read('common.json'));pilot=zipfile.ZipFile(ROOT/'production/phase4/scale-pilot.zip')
members={};parts=[];images={};selected={}
def retain(name,data):
 if name in members:assert members[name]==data
 members[name]=data
def source(key):
 x=next(x for x in cp['resources'] if x['id']==key);selected[key]=x
 for n in [x['member'],x['source']['rawMember'],'trees/'+x['source']['owner']+'/'+str(x['source']['objectId'])+'.json']:
  retain('common/'+n,common.read(n))
 return 'common/'+x['member']
def part(key,origin,ops):
 im=Image.open(io.BytesIO(members[origin])).convert('RGBA')
 for op in ops:
  if op['op']=='alpha-threshold':im=binary(im)
  elif op['op']=='crop':im=im.crop(op['box'])
  elif op['op']=='nearest':im=im.resize(op['size'],Image.Resampling.NEAREST)
  elif op['op']=='damage':
   for box in op['cuts']:im.paste((0,0,0,0),box)
   for box,at in op['bends']:
    patch=im.crop(box);im.paste((0,0,0,0),box);im.alpha_composite(patch,at)
  elif op['op']=='rubble':
   original=im;im=Image.new('RGBA',tuple(op['size']))
   for box,at in op['pieces']:im.alpha_composite(original.crop(box),at)
  else:raise ValueError(op)
 raw=png(im);retain('parts/'+key+'.png',raw);images[key]=im
 parts.append({'key':key,'member':'parts/'+key+'.png','origin':origin,'operations':ops,'sha256':sha(raw),'image':info(im),'density':1,'worldSize':list(im.size)})
 return key
for k in ['shelter']:
 for n in ['masters/'+k+'.png','prompts/'+k+'.txt','native/'+k+'.png']:
  retain('pilot/'+n,pilot.read(n))
for n in pilot.namelist():
 if n.startswith('references/') or n=='recipes/build-scale.py':retain('pilot/'+n,pilot.read(n))
for k in ['metal','boxes']:
 retain('masters/'+k+'.png',(HERE/(k+'-master.png')).read_bytes());retain('prompts/'+k+'.txt',(HERE/(k+'-prompt.txt')).read_bytes())
 retain('references/shelter-pilot.png',(HERE/'shelter-pilot.png').read_bytes())
 retain('references/donor-board.png',(HERE/'references.png').read_bytes())
 original=Image.open(io.BytesIO(members['masters/'+k+'.png'])).convert('RGBA');clean=binary(original);bbox=clean.getbbox();retain('cleaned/'+k+'.png',png(clean))
 part(k,'masters/'+k+'.png',[{'op':'alpha-threshold','value':128},{'op':'crop','box':list(bbox)},{'op':'nearest','size':[128,62] if k=='metal' else [28,20]}])
part('wood','pilot/native/shelter.png',[{'op':'alpha-threshold','value':128}])
ids={'fire':'common.r.7977','chest-open':'common.s0.8280','chest-closed':'common.s0.7551','scaffold':'common.r.9956','tower':'common.r.8711','ground':'common.r.10583','wood-fragment':'common.r.8053','bow':'common.s0.7008','arrow':'common.s0.6885'}
# Source tower is one independent platform, not a baked guard facade.
for key,id in ids.items():
 origin=source(id);part(key,origin,[{'op':'alpha-threshold','value':128}])
fire_records=sorted([x for x in cp['resources'] if x['name'].startswith('fire_small_burn_')],key=lambda x:x['name'])
for i,x in enumerate(fire_records):part('flame-'+str(i),source(x['id']),[{'op':'alpha-threshold','value':128}])
guard=next(x for x in cp['clips'] if x['id']=='common.clip.783');retain('common/clips/783.json',common.read('clips/783.json'));retain('common/'+guard['source']['rawMember'],common.read(guard['source']['rawMember']))
for i,key in enumerate(guard['mapping']):part('guard-shoot-'+str(i),source(key),[{'op':'alpha-threshold','value':128}])
for material in ['wood','metal','boxes']:
 origin='parts/'+material+'.png';w,h=images[material].size
 for severity in ['light','heavy']:
  cuts=[[w//4,h-8,w//4+1,h-3],[w//4+1,h-6,w//4+3,h-4]]
  if severity=='heavy':cuts += [[w*3//4,h-10,w*3//4+3,h-3],[w//4+2,h-5,w//4+5,h-3]]
  bends=[[[16,35,21,40],[18,33]]] if material=='metal' else []
  part(material+'-damage-'+severity,origin,[{'op':'damage','cuts':cuts,'bends':bends}])
 part(material+'-rubble',origin,[{'op':'rubble','size':[w,16],'pieces':[[[0,h-12,min(20,w),h],[0,4]],[[w//2,0,min(w,w//2+14),8],[max(0,w//3),8]],[[max(0,w-24),h-10,w,h],[max(0,w-24),6]]]}])
part('metal-fragment','parts/metal.png',[{'op':'crop','box':[16,35,36,47]}])
# Reusable camp composition; no guard/tower is included in any facade resource.
tiers=[]
for tier,material in [(1,'boxes'),(2,'wood'),(3,'metal')]:
 states={}
 for state in ['intact','damage-light','damage-heavy','defeated']:
  canvas=Image.new('RGBA',(160,88));key=material if state=='intact' else material+'-'+('rubble' if state=='defeated' else state)
  pos=(4,68) if tier==1 else (16,26 if state=='defeated' else 16)
  if state=='defeated':pos=(16,72)
  canvas.alpha_composite(images[key],pos)
  if state!='defeated':
   canvas.alpha_composite(images['fire'],(63,72));canvas.alpha_composite(images['chest-closed'],(130,68))
   if tier>1:canvas.alpha_composite(images['boxes'],(2,68))
  else:canvas.alpha_composite(images['wood-fragment'],(65,65))
  origin='compositions/tier-'+str(tier)+'-'+state+'.png';retain(origin,png(canvas))
  key='tier-'+str(tier)+'-'+state;part(key,origin,[{'op':'alpha-threshold','value':128}]);states[state]=key
 tiers.append({'id':'BL-%02d'%tier,'tier':tier,'material':['campfire/rough-boxes','wood','metal-reinforced-wood'][tier-1],'states':states,'repairOverlay':'scaffold','upgradeOverlay':'scaffold','fragments':['wood-fragment']+(['metal-fragment'] if tier==3 else []),'bakedGuardCount':0,'sourceComposition':{'facade':material,'position':[4,68] if tier==1 else [16,16],'fire':[63,72],'chest':[130,68],'boxes':[2,68] if tier>1 else None}})
atlas=Image.new('RGBA',(1024,512));x=y=1;row=0
for p in parts:
 im=images[p['key']]
 if x+im.width+1>atlas.width:x=1;y+=row+2;row=0
 assert y+im.height+1<=atlas.height
 atlas.alpha_composite(im,(x,y));p['atlasRect']=[x,y,im.width,im.height];x+=im.width+2;row=max(row,im.height)
raw=png(atlas);retain('main-tiers.png',raw)
retain('sources/selected-common.json',js(selected));retain('sources/common-preservation.json',js(cp['preservation']));retain('sources/guard-shoot.json',js(guard))
retain('recipes/build-main.py',pathlib.Path(__file__).read_bytes())
pack={'schemaVersion':1,'id':'main-buildings','version':1,'logicalPixelsPerWorldPixel':1,'stylePrecedence':'D-13 LOW-RESOLUTION OVERRIDES older richer sprite-skill examples','commonBundleSha256':sha((ROOT/'production/phase4/common-selected.zip').read_bytes()),'pilotBundleSha256':sha((ROOT/'production/phase4/scale-pilot.zip').read_bytes()),'atlas':{'path':'res://assets/buildings/main-tiers.png','sha256':sha(raw),**info(atlas)},'tiers':tiers,'parts':parts,'sources':{'selected':'sources/selected-common.json','guardClip':'sources/guard-shoot.json','generated':[{'key':k,'tool':'built-in image_gen','master':'masters/'+k+'.png','sha256':sha(members['masters/'+k+'.png']),'prompt':'prompts/'+k+'.txt','promptSha256':sha(members['prompts/'+k+'.txt']),'original':info(Image.open(io.BytesIO(members['masters/'+k+'.png'])).convert('RGBA'))} for k in ['metal','boxes']],'wood':'pilot/masters/shelter.png'},'recipe':{'member':'recipes/build-main.py','sha256':sha(members['recipes/build-main.py'])},'acceptance':{'visual':'pending','owner':'04-32/04-33','humanApproval':None,'completedObligations':[]}}
retain('main-buildings.json',js(pack));retain('members.json',js([{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())]))
out=HERE/'stage';out.mkdir(exist_ok=True)
(out/'main-tiers.png').write_bytes(raw);(out/'main-buildings.json').write_bytes(members['main-buildings.json'])
with zipfile.ZipFile(out/'main-buildings.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(members.items()):z.writestr(zipfile.ZipInfo(n,date_time=(2026,11,17,0,0,0)),b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
board=Image.new('RGBA',(640,440),(35,36,45,255));d=ImageDraw.Draw(board)
for ti,tier in enumerate(tiers):
 for si,(state,key) in enumerate(tier['states'].items()):
  im=images[key];board.alpha_composite(im,(si*160,ti*140+20));d.text((si*160,ti*140),'T'+str(ti+1)+' '+state,fill='white')
board.save(HERE/'main-source-board.png')
print(json.dumps({'parts':len(parts),'members':len(members),'bundleSha256':sha((out/'main-buildings.zip').read_bytes())}))
