import importlib.util, pathlib, sys, io, json, copy
sys.dont_write_bytecode=True
root=pathlib.Path(sys.argv[1]);spec=importlib.util.spec_from_file_location('media',root/'tools/phase4/extract-media.py')
media=importlib.util.module_from_spec(spec);spec.loader.exec_module(media);Image=media.image_module()
bundle=root/'production/phase4/scale-pilot.zip';members=media.read_archive(bundle)
pack=media.loads(members['scale-pilot.json'])
media.need((root/'src/godot-game/content/packs/scale-pilot.json').read_bytes()==members['scale-pilot.json'],'SCALE_PACK_IDENTITY')
media.need((root/'src/godot-game/assets/common/scale-pilot.png').read_bytes()==members['scale-pilot.png'],'SCALE_ATLAS_IDENTITY')
media.need((root/'src/godot-game/inspection/ScaleComparison.tscn').read_bytes()==members['ScaleComparison.tscn'],'SCALE_SCENE_IDENTITY')
inventory=media.loads(members['members.json'])
media.need(len(inventory)+1==len(members),'SCALE_MEMBER_COUNT')
for row in inventory:
 media.need(row['path'] in members and len(members[row['path']])==row['bytes'] and media.sha(members[row['path']])==row['sha256'],'SCALE_MEMBER_HASH')
media.need(pack['recipe']['verifierSha256']==media.sha(pathlib.Path(__file__).read_bytes()) and
           pack['recipe']['sha256']==media.sha(members['recipes/build-scale.py']),'SCALE_RECIPE_IDENTITY')

def verify(pack,members):
 media.need(pack['schemaVersion']==1 and pack['id']=='scale-pilot' and pack['version']==1,'SCALE_IDENTITY')
 media.need([x['name'] for x in pack['resources']]==['survivor','zombie','metal','shelter','wall-wood','wall-reinforced','tower','base-donor'],'SCALE_PART_IDS')
 media.need(pack['scaleDecision']['logicalPixelsPerWorldPixel']==1 and
            pack['scaleDecision']['status']=='selected-source-production-choice','SCALE_DENSITY')
 media.need('D-13' in pack['stylePrecedence'] and 'OVERRIDES' in pack['stylePrecedence'],'SCALE_STYLE')
 media.need(pack['acceptance']['visual']=='pending' and pack['acceptance']['humanApproval'] is None and
            pack['acceptance']['completedObligations']==[],'SCALE_FALSE_ACCEPTANCE')
 media.need(pack['commonBundleSha256']==media.digest(root/'production/phase4/common-selected.zip'),'SCALE_DONOR_BUNDLE')
 media.need(pack['assembly']['groundLine']==92 and all(x['anchor'][1]==92 for x in pack['assembly']['layers']),'SCALE_GROUND')
 scene=members['ScaleComparison.tscn'].decode('utf-8')
 media.need('texture_filter = 1' in scene and 'filter_clip = true' in scene and 'texture_filter = 2' not in scene,'SCALE_SCENE_FILTER')
 atlas=Image.open(io.BytesIO(members['scale-pilot.png'])).convert('RGBA')
 media.need(media.image_info(atlas)=={key:pack['atlas'][key] for key in media.image_info(atlas)},'SCALE_ATLAS_METADATA')
 for part in pack['resources']:
  native=Image.open(io.BytesIO(members[part['member']])).convert('RGBA')
  media.need(part['dimensions']['worldSize']==part['dimensions']['nativeExport']==list(native.size) and
             part['dimensions']['logicalPixelsPerWorldPixel']==1,'SCALE_DIMENSION')
  media.need(set(native.getchannel('A').tobytes())=={0,255} or set(native.getchannel('A').tobytes())=={255},'SCALE_ALPHA')
  if part['route']=='generate':
   media.need(all(a or (r==0 and g==0 and b==0) for r,g,b,a in native.get_flattened_data()),'SCALE_ALPHA_RGB')
  media.need(media.image_info(native)==part['image'] and media.sha(members[part['member']])==part['sha256'],'SCALE_NATIVE_IDENTITY')
  x,y,w,h=part['atlasRect']
  media.need([w,h]==list(native.size) and atlas.crop((x,y,x+w,y+h)).tobytes()==native.tobytes(),'SCALE_ATLAS_PIXELS')
  if part['route']=='generate':
   source=part['source'];media.need(source['tool']=='built-in image_gen' and source['transparentBackgroundRequested'],'SCALE_GENERATION')
   media.need(source['masterMember'] in members,'SCALE_MASTER_MISSING')
   media.need(source['promptMember'] in members,'SCALE_PROMPT_MISSING')
   raw=members[source['masterMember']];prompt=members[source['promptMember']]
   media.need(media.sha(raw)==source['masterSha256'] and media.sha(prompt)==source['promptSha256'],'SCALE_MASTER_PROMPT_HASH')
   media.need(b'D-13' in prompt and b'LOW-RESOLUTION' in prompt and b'transparen' in prompt,'SCALE_PROMPT_DIRECTION')
   transformation=part['transformation'];media.need(transformation['resampling']=='nearest' and transformation['maskThreshold']==128,'SCALE_SAMPLING')
   original=Image.open(io.BytesIO(raw)).convert('RGBA');alpha=original.getchannel('A')
   media.need(alpha.getextrema()==(0,255) and alpha.getpixel((0,0))<128 and alpha.getpixel((original.width-1,original.height-1))<128 and
              sum(a<128 for a in alpha.tobytes())/(original.width*original.height)>0.30,'SCALE_MASTER_ALPHA')
   media.need(media.image_info(original)==source['originalAlpha'],'SCALE_ORIGINAL_METADATA')
   clean=original.copy();clean.putalpha(alpha.point(lambda x:255 if x>=128 else 0))
   clean.putdata([(r,g,b,a) if a else (0,0,0,0) for r,g,b,a in clean.get_flattened_data()])
   transformation=part['transformation'];media.need(transformation['resampling']=='nearest' and transformation['maskThreshold']==128,'SCALE_SAMPLING')
   media.need(list(clean.getbbox())==transformation['crop'],'SCALE_CROP')
   media.need(media.png(clean)==members['cleaned/'+part['name']+'.png'],'SCALE_MASK_REPRODUCTION')
   expected=clean.crop(tuple(transformation['crop'])).resize(tuple(transformation['targetSize']),Image.Resampling.NEAREST)
   media.need(expected.tobytes()==native.tobytes(),'SCALE_NATIVE_REPRODUCTION')
  else:
   donor=media.loads(members[part['recordMember']])
   media.need(donor['id']==part['commonId'] and donor['source']==part['source'] and
              donor['pngSha256']==media.sha(members[part['member']]) and donor['image']==part['image'],'SCALE_DONOR_IDENTITY')
 for reference in pack['references']:
  media.need(reference['member'] in members and media.sha(members[reference['member']])==reference['sha256'],'SCALE_REFERENCE')
 media.need(pack['assembly']['groundLine']==92 and all(x['anchor'][1]==92 for x in pack['assembly']['layers']),'SCALE_GROUND')
 media.need(len(pack['assembly']['layers'])==9 and pack['assembly']['rows']==['Day','Night'] and
            pack['assembly']['nightTint']==[0.63,0.72,0.88] and pack['assembly']['viewZoom']==3,'SCALE_ASSEMBLY')
 scene=members['ScaleComparison.tscn'].decode('utf-8')
 media.need('texture_filter = 1' in scene and 'filter_clip = true' in scene and 'texture_filter = 2' not in scene,'SCALE_SCENE_FILTER')
 media.need(media.sha(members['ScaleComparison.tscn'])==pack['scene']['sha256'],'SCALE_SCENE_HASH')
 return {'parts':len(pack['resources']),'generatedMasters':4,'references':len(pack['references']),'members':len(members),
         'atlasSha256':media.sha(members['scale-pilot.png']),'scaleDecision':pack['scaleDecision'],'acceptance':pack['acceptance']}

result=verify(pack,members);outcomes=[]
for name,code in [('missing-master','SCALE_MASTER_MISSING'),('missing-prompt','SCALE_PROMPT_MISSING'),
                  ('smooth-sampling','SCALE_SAMPLING'),('wrong-ground','SCALE_GROUND'),
                  ('density-change','SCALE_DENSITY'),('missing-tower','SCALE_PART_IDS'),
                  ('missing-base','SCALE_PART_IDS'),('wrong-world-size','SCALE_DIMENSION'),
                  ('atlas-region','SCALE_ATLAS_PIXELS'),('erased-precedence','SCALE_STYLE'),
                  ('fake-generation','SCALE_GENERATION'),('scene-linear-filter','SCALE_SCENE_FILTER')]:
 subject=copy.deepcopy(pack);data=dict(members)
 if name=='missing-master':data.pop(subject['resources'][0]['source']['masterMember'])
 elif name=='missing-prompt':data.pop(subject['resources'][0]['source']['promptMember'])
 elif name=='smooth-sampling':subject['resources'][0]['transformation']['resampling']='bilinear'
 elif name=='wrong-ground':subject['assembly']['layers'][0]['anchor'][1]+=1
 elif name=='density-change':subject['scaleDecision']['logicalPixelsPerWorldPixel']=2
 elif name=='missing-tower':subject['resources'].pop(6)
 elif name=='missing-base':subject['resources'].pop(7)
 elif name=='wrong-world-size':subject['resources'][0]['dimensions']['worldSize'][1]+=1
 elif name=='atlas-region':subject['resources'][0]['atlasRect'][0]+=1
 elif name=='erased-precedence':subject['stylePrecedence']='Older richer art'
 elif name=='fake-generation':subject['resources'][0]['source']['tool']='programmatic stand-in'
 elif name=='scene-linear-filter':data['ScaleComparison.tscn']=data['ScaleComparison.tscn'].replace(b'texture_filter = 1',b'texture_filter = 2')
 failure=None
 try:verify(subject,data)
 except ValueError as error:failure=str(error)
 media.need(failure==code,'SCALE_CONTROL_NOT_REJECTED_'+name+'_'+str(failure))
 outcomes.append({'name':name,'diagnostic':failure,'expectedRejectionObserved':True})
result['controls']=outcomes;result['expectedRejected']=len(outcomes)
print(json.dumps(result))
