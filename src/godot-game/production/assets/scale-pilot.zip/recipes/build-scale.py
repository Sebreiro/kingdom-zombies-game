import importlib.util, pathlib, sys, io, json
sys.dont_write_bytecode=True
ROOT=pathlib.Path('D:/Work/Games/KingdomZombies')
spec=importlib.util.spec_from_file_location('media',ROOT/'tools/phase4/extract-media.py')
media=importlib.util.module_from_spec(spec);spec.loader.exec_module(media)
Image=media.image_module()
OUT=media.owned(sys.argv[1])
INPUT=ROOT/'.phase4/04-04/scale-input'
common=media.read_archive(ROOT/'production/phase4/common-selected.zip')
common_pack=media.loads(common['common.json'])
prompts=media.loads((ROOT/'.phase4/04-04/pilot-prompts.json').read_bytes())
members={};parts=[];images={}
origins={
 'survivor':'exec-2c6f9f79-f013-43c6-9eac-8efd070c05f8.png',
 'zombie':'exec-df0be24c-279b-46ff-ab9d-1e286f1c8268.png',
 'metal':'exec-8dbfa84e-d3ca-41a1-8682-81e7d7eae8ef.png',
 'shelter':'exec-b77b82fa-79b7-4886-a2d7-a4e3344ae432.png'}
for name in ['survivor','zombie','metal','shelter']:
 raw=(INPUT/f'masters/{name}.png').read_bytes()
 original=Image.open(io.BytesIO(raw)).convert('RGBA')
 alpha=original.getchannel('A');media.need(alpha.getextrema()==(0,255),'MASTER_ALPHA')
 # Authorized cleanup preserves retained RGB; originals remain byte-for-byte intact.
 clean=original.copy();clean.putalpha(alpha.point(lambda x:255 if x>=128 else 0))
 pixels=list(clean.get_flattened_data())
 clean.putdata([(r,g,b,a) if a else (0,0,0,0) for r,g,b,a in pixels])
 bounds=clean.getbbox();crop=clean.crop(bounds)
 if name=='survivor':size=(max(1,round(crop.width*30/crop.height)),30)
 elif name=='zombie':size=(max(1,round(crop.width*34/crop.height)),34)
 elif name=='metal':size=(32,43)
 else:size=(128,max(1,round(crop.height*128/crop.width)))
 native=crop.resize(size,Image.Resampling.NEAREST)
 members[f'masters/{name}.png']=raw
 members[f'prompts/{name}.txt']=(prompts[name]+'\n').encode('utf-8')
 members[f'cleaned/{name}.png']=media.png(clean)
 members[f'native/{name}.png']=media.png(native)
 info=media.image_info(native)
 record={'id':'scale.'+name,'name':name,'version':1,'route':'generate','member':f'native/{name}.png',
         'source':{'tool':'built-in image_gen','generationSession':'01a1e68a-0f44-7392-bfe8-70e3761f0132',
                   'originalFile':origins[name],'masterMember':f'masters/{name}.png','masterSha256':media.sha(raw),
                   'promptMember':f'prompts/{name}.txt','promptSha256':media.sha(members[f'prompts/{name}.txt']),
                   'transparentBackgroundRequested':True,'originalAlpha':media.image_info(original)},
         'transformation':{'maskThreshold':128,'clearTransparentRGB':True,'preserveRetainedRGB':True,
                           'crop':list(bounds),'resampling':'nearest','targetSize':list(size),
                           'cropAspectBefore':crop.width/crop.height,'targetAspect':size[0]/size[1],
                           'reason':'Fit to common low-resolution donor density; metal explicitly fits32x43 tier2 wall'},
         'dimensions':{'originalCanvas':list(original.size),'sourceCrop':list(crop.size),'nativeExport':list(size),
                       'worldSize':list(size),'logicalPixelsPerWorldPixel':1},'image':info,'sha256':media.sha(members[f'native/{name}.png'])}
 images[name]=native;parts.append(record)
for name,object_id in [('wall-wood',8144),('wall-reinforced',9758),('tower',8711),('base-donor',10583)]:
 donor=next(x for x in common_pack['resources'] if x['id']==f'common.r.{object_id}')
 raw=common[donor['member']];image=Image.open(io.BytesIO(raw)).convert('RGBA')
 members[f'donors/{name}.png']=raw;members[f'donors/{name}.json']=media.json_bytes(donor)
 images[name]=image
 parts.append({'id':'scale.'+name,'name':name,'version':1,'route':'reuse','source':donor['source'],
               'commonId':donor['id'],'member':f'donors/{name}.png','recordMember':f'donors/{name}.json',
               'image':media.image_info(image),'sha256':media.sha(raw),
               'dimensions':{'originalLogical':[donor['registration']['logicalRect']['width'],donor['registration']['logicalRect']['height']],
                             'nativeExport':list(image.size),'worldSize':list(image.size),'logicalPixelsPerWorldPixel':1},
               'registration':{'original':donor['registration'],'pilotBottomCenter':[-(image.width//2),-image.height],
                               'policy':'Preserve original exact registration in donor record; explicitly normalize visible bottom to pilot ground line only'}})
# Retain the inspected real visual references, never refer runtime to global files.
references=[
 ('donor-survivor','D:/Work/Games/KingdomZombies/.planning/phases/04-asset-production/research-evidence/sharedassets0.assets-2361.png'),
 ('donor-wall','D:/Work/Games/KingdomZombies/.planning/phases/04-asset-production/research-evidence/resources.assets-9758.png'),
 ('donor-tower','D:/Work/Games/KingdomZombies/.planning/phases/04-asset-production/research-evidence/resources.assets-8711.png'),
 ('older-zombie','C:/Users/User/.codex/skills/kingdom-zombies-sprites/references/images/zombie-preferred.png'),
 ('older-base','C:/Users/User/.codex/skills/kingdom-zombies-sprites/references/images/base-tier-3-approved.png'),
 ('donor-castle','C:/Users/User/.codex/skills/kingdom-zombies-sprites/references/images/originals/building_castle_facade.png'),
 ('donor-lighthouse','C:/Users/User/.codex/skills/kingdom-zombies-sprites/references/images/originals/building_lighthouse.png')]
reference_records=[]
for identity,file in references:
 payload=pathlib.Path(file).read_bytes();member=f'references/{identity}.png';members[member]=payload
 reference_records.append({'id':identity,'member':member,'sha256':media.sha(payload),'originalPath':file,
                           'role':'Inspected internal anatomy/material reference; currentD-13 simpler donor detail takes precedence over older rich examples'})
# Lossless atlas for real native resources, with separators; never a screenshot.
atlas=Image.new('RGBA',(512,128));x=1;y=1;row=0
for part in parts:
 image=images[part['name']]
 if x+image.width+1>atlas.width:x=1;y+=row+2;row=0
 media.need(y+image.height<atlas.height,'PILOT_ATLAS_SIZE')
 atlas.paste(image,(x,y));part['atlasRect']=[x,y,image.width,image.height]
 part['path']='assets/common/scale-pilot.png';part['atlasSha256']=None
 x+=image.width+2;row=max(row,image.height)
atlas_bytes=media.png(atlas)
for part in parts:part['atlasSha256']=media.sha(atlas_bytes)
members['scale-pilot.png']=atlas_bytes
positions={'survivor':[16,92],'zombie':[56,92],'wall-wood':[100,92],'wall-reinforced':[140,92],
           'metal':[180,92],'tower':[228,92],'shelter':[320,92],'base-donor':[320,92]}
layers=[{'name':name,'part':name,'anchor':positions[name],'layer':0} for name in positions]
layers.insert(4,{'name':'metal-backing','part':'wall-reinforced','anchor':[180,92],'layer':0})
next(x for x in layers if x['name']=='metal')['layer']=1
next(x for x in layers if x['name']=='base-donor')['layer']=1
# Same assembled actual parts, quiet day/night treatments and contact shadows.
from PIL import ImageDraw
proof=Image.new('RGBA',(400,224),(0,0,0,0))
for row,(background,tint) in enumerate([((139,157,128,255),(1,1,1)),((31,43,56,255),(0.63,0.72,0.88))]):
 stage=Image.new('RGBA',(400,112),background);draw=ImageDraw.Draw(stage)
 draw.line((0,92,400,92),fill=(77,79,57,255) if row==0 else (37,45,42,255))
 for cx,width in [(16,8),(56,21),(100,22),(140,22),(180,22),(228,28),(320,104)]:
  draw.ellipse((cx-width//2,91,cx+width//2,94),fill=(32,36,31,95))
 for layer in layers:
  image=images[layer['part']];cx,cy=layer['anchor']
  shown=image.copy()
  shown.putdata([(round(r*tint[0]),round(g*tint[1]),round(b*tint[2]),a) for r,g,b,a in image.get_flattened_data()])
  stage.alpha_composite(shown,(cx-image.width//2,cy-image.height))
 proof.paste(stage,(0,row*112))
members['proofs/day-night-native.png']=media.png(proof)
members['proofs/day-night-nearest-4x.png']=media.png(proof.resize((1600,896),Image.Resampling.NEAREST))
# Actual scriptless resource scene; proof probe constructs and observes these nodes.
scene=['[gd_scene load_steps=10 format=3]','',
 '[ext_resource type="Texture2D" path="res://assets/common/scale-pilot.png" id="1_pilot"]','']
for part in parts:
 name=part['name'].replace('-','_');x,y,w,h=part['atlasRect']
 scene += [f'[sub_resource type="AtlasTexture" id="Atlas_{name}"]','atlas = ExtResource("1_pilot")',
           f'region = Rect2({x}, {y}, {w}, {h})','filter_clip = true','']
scene += ['[node name="ScaleComparison" type="Node2D"]','texture_filter = 1',
          'metadata/logical_density = "one-art-pixel-per-world-pixel"',
          'metadata/acceptance = "Source production choice; actual04-32 review pending"','']
for row,(name,origin,tint,background) in enumerate([('Day',[40,40],[1,1,1],[0.545,0.616,0.502]),
                                                  ('Night',[40,390],[0.63,0.72,0.88],[0.122,0.169,0.220])]):
 scene += [f'[node name="{name}" type="Node2D" parent="."]',f'position = Vector2({origin[0]}, {origin[1]})',
           'scale = Vector2(3, 3)','',f'[node name="Background" type="Polygon2D" parent="{name}"]',
           'polygon = PackedVector2Array(0, 0, 400, 0, 400, 112, 0, 112)',
           f'color = Color({background[0]}, {background[1]}, {background[2]}, 1)','',
           f'[node name="Artwork" type="Node2D" parent="{name}"]',
           f'modulate = Color({tint[0]}, {tint[1]}, {tint[2]}, 1)','']
 for cx,width in [(16,8),(56,21),(100,22),(140,22),(180,22),(228,28),(320,104)]:
  scene += [f'[node name="Contact{cx}" type="Polygon2D" parent="{name}/Artwork"]',
            f'position = Vector2({cx}, 92)',f'polygon = PackedVector2Array({-width//2}, 0, {-width//2+2}, -1, {width//2-2}, -1, {width//2}, 0, {width//2-2}, 1, {-width//2+2}, 1)',
            'color = Color(0.09, 0.10, 0.085, 0.32)','']
 for layer in layers:
  image=images[layer['part']];node=layer['name'].replace('-','_');part=layer['part'].replace('-','_');cx,cy=layer['anchor']
  scene += [f'[node name="{node}" type="Sprite2D" parent="{name}/Artwork"]',
            f'position = Vector2({cx}, {cy})',f'z_index = {layer["layer"]}',
            f'texture = SubResource("Atlas_{part}")','centered = false',
            f'offset = Vector2({-(image.width//2)}, {-image.height})','']
scene_bytes=('\n'.join(scene)+'\n').encode('utf-8');members['ScaleComparison.tscn']=scene_bytes
recipe=pathlib.Path(__file__).read_bytes();members['recipes/build-scale.py']=recipe
verifier=(ROOT/'.phase4/04-04/verify-scale.py').read_bytes();members['recipes/verify-scale.py']=verifier
pack={'schemaVersion':1,'id':'scale-pilot','version':1,'status':'source-production-choice-actual-acceptance-pending',
      'resources':parts,'atlas':{'path':'assets/common/scale-pilot.png','sha256':media.sha(atlas_bytes),**media.image_info(atlas)},
      'scene':{'path':'inspection/ScaleComparison.tscn','sha256':media.sha(scene_bytes)},
      'assembly':{'layers':layers,'groundLine':92,'viewZoom':3,'rows':['Day','Night'],
                  'nightTint':[0.63,0.72,0.88],'contactShadows':'small quiet pixel polygons; no art stand-ins'},
      'scaleDecision':{'id':'D-13-pilot-1','logicalPixelsPerWorldPixel':1,'sourcePixelsPerUnit':32,
                       'survivorVisibleHeight':30,'zombieVisibleHeight':34,'wallWoodVisibleHeight':35,
                       'wallReinforcedVisibleHeight':43,'towerVisibleHeight':48,
                       'shelterVisibleWidth':128,'dayNightProof':'proofs/day-night-native.png',
                       'rationale':'Native donor wall/tower detail stays unchanged; 30px natural adult fits35px shelter doorway; broad34px zombie preserves distinct mass. Simple128px shelter matches rough donor timber clusters. One art pixel is one world pixel;3x is inspection zoom only.',
                       'status':'selected-source-production-choice','actualRenderedApproval':'pending-04-32'},
      'references':reference_records,'stylePrecedence':'CurrentD-13 simpler low-resolution donor detail OVERRIDES older richer-density sprite skill examples',
      'recipe':{'member':'recipes/build-scale.py','sha256':media.sha(recipe),'verifierMember':'recipes/verify-scale.py',
                'verifierSha256':media.sha(verifier),'transformations':[
          'Retain original generated RGBA masters, expanded prompts and inspected references',
          'Threshold alpha128; zeroRGB outside; preserveRGB inside; crop exactopaque bbox',
          'Nearest-neighbor normalization only; record original/logical/export/world dimensions separately',
          'Donor pixels unchanged; explicit normalized bottom-center anchor only in pilot',
          'Lossless separated atlas; actual donor/generated layered scene; quiet contact shapes/day-night tint']},
      'acceptance':{'owner':'04-32/04-33','visual':'pending','humanApproval':None,'completedObligations':[]},
      'commonBundleSha256':media.digest(ROOT/'production/phase4/common-selected.zip')}
members['scale-pilot.json']=media.json_bytes(pack)
members['members.json']=media.json_bytes([{'path':name,'bytes':len(value),'sha256':media.sha(value)} for name,value in sorted(members.items())])
media.archive(OUT/'scale-pilot.zip',members)
(OUT/'scale-pilot.png').write_bytes(atlas_bytes);(OUT/'scale-pilot.json').write_bytes(members['scale-pilot.json'])
(OUT/'ScaleComparison.tscn').write_bytes(scene_bytes)
(OUT/'day-night-4x.png').write_bytes(members['proofs/day-night-nearest-4x.png'])
print(json.dumps({'complete':True,'members':len(members),'parts':[(p['name'],p['dimensions']) for p in parts],
                  'bundleSha256':media.digest(OUT/'scale-pilot.zip')}))
