"""Reproducible item authoring: selected immutable donors and built-in masters only."""
import pathlib,sys,json,hashlib,io,zipfile,math,os
from PIL import Image,ImageDraw
ROOT=pathlib.Path('D:/Work/Games/KingdomZombies');WORK=ROOT/'.phase4/04-05'
def sha(b):return hashlib.sha256(b).hexdigest()
def js(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def png(im):
 b=io.BytesIO();im.save(b,format='PNG',compress_level=9);return b.getvalue()
def info(im):return {'width':im.width,'height':im.height,'rgbaSha256':sha(im.tobytes()),'visiblePixels':sum(a>0 for a in im.getchannel('A').tobytes()),'alphaBBox':list(im.getbbox()),'alphaValues':sorted(set(im.getchannel('A').tobytes()))}
def clean(im):
 im=im.convert('RGBA');im.putalpha(im.getchannel('A').point(lambda a:255 if a>=128 else 0));im.putdata([(r,g,b,a) if a else (0,0,0,0) for r,g,b,a in im.get_flattened_data()]);return im
NAMES=['Money','Arrows','Knife','Wooden club','Machete','Metal bat','Bow','Berries','Fruit','Meat']
FOOT=[[1,1],[1,2],[1,2],[1,3],[1,3],[1,4],[2,4],[1,1],[1,1],[1,2]]
NAMES+=['Basic shirt','Trousers','Coat','Cap','Face covering','Gloves','Boots','Protective helmet','Improvised body armor','Plated body armor','Belt with pouches','Small pouch','Small backpack','Field backpack']
FOOT+=[[2,2],[2,2],[2,3],[2,1],[1,1],[1,1],[1,2],[2,2],[2,3],[3,3],[2,1],[1,2],[2,3],[3,4]]
SIZES={'knife':[4,12],'club':[5,18],'machete':[5,20],'bat':[4,24],'fruit':[6,7],'meat':[7,5]}
SOURCES={1:'common.s0.7856',2:'common.s0.6885',7:'common.s0.7008',8:'common.r.11340'}
GEN={3:'knife',4:'club',5:'machete',6:'bat',9:'fruit',10:'meat'}
GEN.update(dict(enumerate(['shirt','trousers','coat','cap','face','gloves','boots','helmet','improvised','plated','belt','pouch','smallpack','fieldpack'],11)))
SIZES.update(dict(zip(['shirt','trousers','coat','cap','face','gloves','boots','helmet','improvised','plated','belt','pouch','smallpack','fieldpack'],[[14,11],[8,13],[16,18],[7,4],[5,3],[8,5],[10,6],[7,6],[8,11],[10,12],[10,4],[5,7],[8,11],[11,15]])))
STORAGE={11:[2,1],12:[2,2],13:[2,2],21:[4,2],22:[2,2],23:[4,4],24:[5,6]}
SLOTS={11:'torso-clothing',12:'legs',13:'torso-clothing',14:'headwear',15:'face',16:'gloves',17:'boots',18:'headwear',19:'body-armor',20:'body-armor',21:'belt',22:None,23:'backpack',24:'backpack'}
# Explicit source-space partitions are independently reusable inputs, not baked body fits.
CROPS={11:[('torso-front',[4,0,10,11],'torso.front'),('torso-rear',[4,0,10,11],'torso.rear'),('sleeve-left-front',[0,2,4,6],'arm.left.front'),('sleeve-left-rear',[0,2,4,6],'arm.left.rear'),('sleeve-right-front',[10,2,14,6],'arm.right.front'),('sleeve-right-rear',[10,2,14,6],'arm.right.rear')],
12:[('waist',[0,0,8,4],'hips'),('leg-left',[0,4,4,13],'leg.left'),('leg-right',[4,4,8,13],'leg.right')],
13:[('torso-front',[5,0,11,13],'torso.front'),('torso-rear',[5,0,11,13],'torso.rear'),('hem',[5,13,11,18],'hips'),('sleeve-left-front',[0,3,5,8],'arm.left.front'),('sleeve-left-rear',[0,3,5,8],'arm.left.rear'),('sleeve-right-front',[11,3,16,8],'arm.right.front'),('sleeve-right-rear',[11,3,16,8],'arm.right.rear')],
14:[('head',[0,0,7,4],'head')],15:[('face',[0,0,5,3],'head.face')],
16:[('hand-left-front',[0,0,4,5],'hand.left.front'),('hand-left-rear',[0,0,4,5],'hand.left.rear'),('hand-right-front',[4,0,8,5],'hand.right.front'),('hand-right-rear',[4,0,8,5],'hand.right.rear')],
17:[('foot-left',[0,0,5,6],'foot.left'),('foot-right',[5,0,10,6],'foot.right')],18:[('head',[0,0,7,6],'head')],
19:[('torso-front',[0,3,8,11],'armor.front'),('torso-rear',[0,3,8,11],'armor.rear'),('strap-left-front',[0,0,2,5],'shoulder.left.front'),('strap-left-rear',[0,0,2,5],'shoulder.left.rear'),('strap-right-front',[6,0,8,5],'shoulder.right.front'),('strap-right-rear',[6,0,8,5],'shoulder.right.rear')],
20:[('torso-front',[0,3,10,12],'armor.front'),('torso-rear',[0,3,10,12],'armor.rear'),('strap-left-front',[1,0,3,5],'shoulder.left.front'),('strap-left-rear',[1,0,3,5],'shoulder.left.rear'),('strap-right-front',[7,0,9,5],'shoulder.right.front'),('strap-right-rear',[7,0,9,5],'shoulder.right.rear')],
21:[('belt-front',[3,1,7,3],'waist.front'),('belt-rear',[3,1,7,3],'waist.rear'),('pouch-left',[0,0,3,4],'waist.left'),('pouch-right',[7,0,10,4],'waist.right')],
22:[('container-header',[0,0,5,7],'inventory.hidden')],
23:[('bag-body',[1,2,7,11],'backpack.body'),('strap-left-front',[0,0,2,7],'shoulder.left.front'),('strap-left-rear',[0,0,2,7],'shoulder.left.rear'),('strap-right-front',[6,0,8,7],'shoulder.right.front'),('strap-right-rear',[6,0,8,7],'shoulder.right.rear')],
24:[('bag-body',[1,3,10,15],'backpack.body'),('pocket-left',[0,8,3,14],'backpack.left'),('pocket-right',[8,8,11,14],'backpack.right'),('strap-left-front',[2,0,4,7],'shoulder.left.front'),('strap-left-rear',[2,0,4,7],'shoulder.left.rear'),('strap-right-front',[7,0,9,7],'shoulder.right.front'),('strap-right-rear',[7,0,9,7],'shoulder.right.rear')]}
def quoted(v):return json.dumps(v,ensure_ascii=False)
def track(index,target,value):
 return f'tracks/{index}/type = "value"\ntracks/{index}/path = NodePath({quoted(target)})\ntracks/{index}/interp = 0\ntracks/{index}/enabled = true\ntracks/{index}/keys = {{"times": PackedFloat32Array(0), "transitions": PackedFloat32Array(1), "update": 1, "values": [{value}]}}\n'
def scene(pack):
 parts=pack['parts'];items=pack['items'];s=['[gd_scene load_steps='+str(1+1+len(parts)+len(items)*2+4+4)+' format=3]','[ext_resource type="Texture2D" path="res://'+pack['atlas']['path']+'" id="1_items"]']
 for part in parts:
  x,y,w,h=part['atlasRect'];s.append(f'[sub_resource type="AtlasTexture" id="A_{part["key"]}"]\natlas = ExtResource("1_items")\nregion = Rect2({x}, {y}, {w}, {h})\nfilter_clip = true')
 for item in items:
  lines=[f'[sub_resource type="Animation" id="Select_{item["node"]}"]','length = 0.001']
  for j,other in enumerate(items):lines.append(track(j,'Groups/'+other['node']+':visible','true' if other==item else 'false'))
  # Selection always retires broken/ammo test states, without changing item identity.
  ti=len(items)
  for other in items:
   for mode in other['modes']:
    lines.append(track(ti,f'Groups/{other["node"]}/ArtScroll/Canvas/Art/{mode["node"]}:visible','false'));ti+=1
  s.append('\n'.join(lines))
  for mode in item['modes']:
   lines=[f'[sub_resource type="Animation" id="State_{item["node"]}_{mode["node"]}"]','length = 0.001'];ti=0
   for other in items:
    for candidate in other['modes']:
     lines.append(track(ti,f'Groups/{other["node"]}/ArtScroll/Canvas/Art/{candidate["node"]}:visible','true' if other==item and candidate==mode else 'false'));ti+=1
   s.append('\n'.join(lines))
 for z in [1,2,4,8]:
  lines=[f'[sub_resource type="Animation" id="Zoom_{z}"]','length = 0.001']
  for j,item in enumerate(items):
   rows=math.ceil(len(item['components'])/3);lines.append(track(j*2,'Groups/'+item['node']+'/ArtScroll/Canvas/Art:scale',f'Vector2({z}, {z})'));lines.append(track(j*2+1,'Groups/'+item['node']+'/ArtScroll/Canvas:custom_minimum_size',f'Vector2({120*z+8}, {(rows*40+25)*z+8})'))
  s.append('\n'.join(lines))
 def library(id,rows):return f'[sub_resource type="AnimationLibrary" id="{id}"]\n_data = {{\n'+',\n'.join('&'+quoted(k)+': SubResource('+quoted(v)+')' for k,v in rows)+'\n}'
 s.append(library('Selections',[(x['id'],'Select_'+x['node']) for x in items]));s.append(library('States',[(x['id']+'.'+m['node'],'State_'+x['node']+'_'+m['node']) for x in items for m in x['modes']]));s.append(library('Zooms',[(f'zoom{z}',f'Zoom_{z}') for z in [1,2,4,8]]))
 def node(name,type,parent=None,props=''):
  s.append('[node name='+quoted(name)+' type='+quoted(type)+((' parent='+quoted(parent)) if parent is not None else '')+']\n'+props)
 node(pack['preview']['root'],'Control',props='layout_mode = 3\nanchors_preset = 15\nanchor_right = 1.0\nanchor_bottom = 1.0\ngrow_horizontal = 2\ngrow_vertical = 2\ntexture_filter = 1')
 node('Title','Label','.', 'offset_left = 12.0\noffset_top = 8.0\ntext = "Items - reusable masters; resource inspection"')
 node('Browse','ScrollContainer','.', 'offset_left = 12.0\noffset_top = 44.0\noffset_right = 222.0\noffset_bottom = 470.0')
 node('List','VBoxContainer','Browse','layout_mode = 2')
 for item in items:node('Select_'+item['node'],'Button','Browse/List','layout_mode = 2\ntext = '+quoted(item['id']+' '+item['name']))
 node('Zoom','HBoxContainer','.', 'offset_left = 250.0\noffset_top = 55.0\noffset_right = 540.0\noffset_bottom = 87.0')
 for z in [1,2,4,8]:node('Zoom'+str(z),'Button','Zoom','layout_mode = 2\ntext = '+quoted(str(z)+'x'))
 node('Modes','HBoxContainer','.', 'offset_left = 250.0\noffset_top = 95.0\noffset_right = 770.0\noffset_bottom = 127.0')
 node('Groups','Control','.', 'offset_left = 250.0\noffset_top = 145.0')
 for item in items:
  group='Groups/'+item['node'];node(item['node'],'Control','Groups','visible = '+('true' if item==items[0] else 'false'))
  node('Identity','Label',group,'text = '+quoted(item['id']+' | '+item['name']+' | '+item['status']))
  node('Use','Label',group,'offset_top = 25.0\ntext = '+quoted(item['usageLabel']))
  rows=math.ceil(len(item['components'])/3)
  node('ArtScroll','ScrollContainer',group,'offset_top = 100.0\noffset_right = 680.0\noffset_bottom = 420.0\nclip_contents = true')
  node('Canvas','Control',group+'/ArtScroll',f'layout_mode = 2\ncustom_minimum_size = Vector2(488, {(rows*40+25)*4+8})\nsize_flags_horizontal = 0\nsize_flags_vertical = 0')
  node('Art','Node2D',group+'/ArtScroll/Canvas','scale = Vector2(4, 4)\ntexture_filter = 1')
  for j,comp in enumerate(item['components']):
   node(comp['node'],'Sprite2D',group+'/ArtScroll/Canvas/Art',f'position = Vector2({20+j%3*32}, {20+j//3*40})\ntexture = SubResource("A_{comp["part"]}")\ncentered = false\nrotation = {comp["rotation"]}\ntexture_filter = 1')
   node('Caption_'+str(j),'Label',group+'/ArtScroll/Canvas/Art',f'offset_left = {16+j%3*32}.0\noffset_top = {40+j//3*40}.0\ntext = '+quoted(str(j+1))+'\ntheme_override_font_sizes/font_size = 4')
  node('Components','Label',group,'offset_top = 425.0\noffset_right = 680.0\nautowrap_mode = 3\ntext = '+quoted('Components: '+'; '.join(str(j+1)+' '+c['name'] for j,c in enumerate(item['components']))))
  for mode in item['modes']:
   node(mode['node'],'Sprite2D',group+'/ArtScroll/Canvas/Art',f'visible = false\nposition = Vector2(52, 20)\ntexture = SubResource("A_{mode["part"]}")\ncentered = false\ntexture_filter = 1')
  for j,mode in enumerate(item['modes']):node('State_'+mode['node'],'Button',group,f'offset_left = {j*140}.0\noffset_top = 50.0\noffset_right = {(j+1)*140-8}.0\noffset_bottom = 80.0\ntext = '+quoted(mode['node']+' example'))
  if item.get('storage'):
   w,h=item['storage'];node('Storage','Label',group,'offset_left = 700.0\noffset_top = 100.0\ntext = '+quoted('Storage '+str(w)+'x'+str(h)+'\n'+('\n'.join(' '.join('[ ]' for _ in range(w)) for _ in range(h)))))
 for name,lib in [('Selection','Selections'),('State','States'),('ZoomPlayer','Zooms')]:node(name,'AnimationPlayer','.', 'libraries = {&"": SubResource("'+lib+'")}')
 for item in items:
  s.append('[connection signal="pressed" from="Browse/List/Select_'+item['node']+'" to="Selection" method="play" binds= [&'+quoted(item['id'])+']]')
  for mode in item['modes']:s.append('[connection signal="pressed" from="Groups/'+item['node']+'/State_'+mode['node']+'" to="State" method="play" binds= [&'+quoted(item['id']+'.'+mode['node'])+']]')
 for z in [1,2,4,8]:s.append('[connection signal="pressed" from="Zoom/Zoom'+str(z)+'" to="ZoomPlayer" method="play" binds= [&"zoom'+str(z)+'"]]')
 return ('\n\n'.join(s)+'\n').encode()
def build(which):
 assert which in ['items-01-10','items-11-24'];wearables=which=='items-11-24'
 out=WORK/(which+'-stage-'+str(__import__('time').time_ns()));assert not out.exists(),'FRESH_STAGE_REQUIRED';out.mkdir()
 members={};generated=json.loads((WORK/('wearables-generated.json' if wearables else 'generated.json')).read_text());common=json.loads((ROOT/'src/godot-game/content/packs/common.json').read_text());donors={x['id']:x for x in common['resources']}
 with zipfile.ZipFile(ROOT/'production/phase4/common-selected.zip') as archive:
  for id in (['common.s0.7848','common.s0.7052'] if wearables else list(SOURCES.values())+['common.r.8203','common.s0.7848']):
   row=donors[id];members['donors/'+id+'.json']=js(row);members['donors/'+id+'.png']=archive.read(row['member'])
 for name in ['references.png','survivor.png','donor-survivor.png','donor-wall.png']:members['references/'+name]=(WORK/name).read_bytes()
 parts=[];images={};items=[];atlas=Image.new('RGBA',(512,256));x=2;y=2;rowh=0
 def part(key,im,origin,ops):
  nonlocal x,y,rowh
  assert im.getbbox() and im.width<=128 and im.height<=128
  if x+im.width+2>512:x=2;y+=rowh+2;rowh=0
  assert y+im.height<256
  atlas.paste(im,(x,y));images[key]=im;member='parts/'+key+'.png';raw=png(im);members[member]=raw
  p={'key':key,'member':member,'sha256':sha(raw),'image':info(im),'atlasRect':[x,y,im.width,im.height],'origin':origin,'operations':ops,'worldSize':list(im.size),'density':1};parts.append(p);x+=im.width+2;rowh=max(rowh,im.height);return key
 for n in (range(11,25) if wearables else range(1,11)):
  id=f'IT-{n:02}';node=id.replace('-','_');route='adapt-donor';origin=None
  if n in GEN:
   name=GEN[n];g=generated[name];raw=pathlib.Path(g['path']).read_bytes();master=Image.open(io.BytesIO(raw)).convert('RGBA');cl=clean(master);bbox=cl.getbbox();size=SIZES[name];im=cl.crop(bbox).resize(size,Image.Resampling.NEAREST);origin='masters/'+name+'.png';members[origin]=raw;members['prompts/'+name+'.txt']=(g['prompt']+'\n').encode();members['cleaned/'+name+'.png']=png(cl)
   source={'tool':'built-in image_gen','outputIdentity':g['path'].split('/')[-1],'session':g['path'].split('/')[-2],'master':origin,'masterSha256':sha(raw),'prompt':'prompts/'+name+'.txt','promptSha256':sha(members['prompts/'+name+'.txt']),'original':info(master),'originalCanvas':list(master.size),'crop':list(bbox),'nativeExport':size,'maskThreshold':128,'resampling':'nearest','referenceMembers':['references/references.png','references/survivor.png','references/donor-wall.png']};route='generate' if n!=9 else 'generated-adaptation'
   ops=[{'op':'alpha-threshold','value':128},{'op':'crop','box':list(bbox)},{'op':'nearest','size':size}]
  else:
   d=SOURCES[n];origin='donors/'+d+'.png';master=Image.open(io.BytesIO(members[origin])).convert('RGBA');im=clean(master);source={'resource':d,'record':'donors/'+d+'.json','master':origin,'masterSha256':sha(members[origin]),'original':info(master),'nativeExport':list(im.size),'retainsOriginalRegistration':True};ops=[{'op':'alpha-threshold','value':128}]
   if n==8:
    # Exact purple berry clusters from K04; arrange into a compact bunch without repainting pixels.
    berry=im.crop((5,0,7,2));im=Image.new('RGBA',(6,5));
    for at in [(0,0),(3,0),(1,3)]:im.alpha_composite(berry,at)
    ops.append({'op':'crop-compose','box':[5,0,7,2],'size':[6,5],'placements':[[0,0],[3,0],[1,3]]})
  masterkey=part(node+'_master',im,origin,ops)
  canonical=masterkey
  if n==2:
   single=im;im=Image.new('RGBA',(10,7))
   for at in [(0,0),(1,2),(2,3)]:im.alpha_composite(single,at)
   canonical=part(node+'_bundle',im,origin,[{'op':'alpha-threshold','value':128},{'op':'crop-compose','box':[0,0,8,4],'size':[10,7],'placements':[[0,0],[1,2],[2,3]]}])
  sceneName='ItemsWearablesPreview.tscn' if wearables else 'ItemsWeaponsPreview.tscn'
  item={'id':id,'version':1,'node':node,'name':NAMES[n-1],'nameKey':'item.'+id+'.name','descriptionKey':'item.'+id+'.description','inventoryFootprint':FOOT[n-1],'canonicalIcon':canonical,'iconVariants':[canonical],'master':masterkey,'route':route,'source':source,'status':'Source produced; appearance review pending04-32','storage':None,'slot':None,'components':[],'modes':[],'bodyFitOwner':'04-06/04-07','balanceOwner':'DT-04','inspection':{'category':'Items','scene':'inspection/'+sceneName,'selection':'Selection','animation':id,'button':'Browse/List/Select_'+node,'group':'Groups/'+node,'zoom':'ZoomPlayer','zoomAnimations':['zoom1','zoom2','zoom4','zoom8']}}
  def component(name,key=masterkey,rotation=0,attachment=None,pivot=None):item['components'].append({'name':name,'node':name.replace('-','_'),'part':key,'rotation':rotation,'scale':[1,1],'pivot':pivot or [0,0],'attachment':attachment,'nativeSize':list(images[key].size)})
  component('icon',canonical)
  if wearables:
   item['storage']=STORAGE.get(n);item['slot']=SLOTS[n];item['secondaryMotion']='closely-attached-little-sway';item['independentlyRemovable']=True;item['bakedEquipment']=[];item['usageLabel']='Stored container only; no worn slot' if n==22 else 'Removable '+SLOTS[n]+'; front/rear inputs; exact body fits owned04-06/07'
   item['source']['donorIngredients']=['donors/common.s0.7848.json','donors/common.s0.7052.json'];item['source']['donorSuitability']='K14 clothing/brown-white palette inspected; source garments are baked into actor, not complete removable masters'
   for name,box,attachment in CROPS[n]:
    componentKey=part(node+'_'+name.replace('-','_'),images[masterkey].crop(box),origin,ops+[{'op':'crop','box':box}]);component(name,componentKey,attachment=attachment,pivot=[0,0])
   if n!=22:
    # Corpse composition reuses the same independent limb/torso/strap parts, transformed at their anchors.
    live=list(item['components'][1:])
    for c in live:component('corpse-'+c['name'],c['part'],rotation=math.pi/2,attachment='corpse.'+c['attachment'],pivot=c['pivot'])
   if n in [14,18]:item['crownAnchor']={'attachment':'head.crown','aboveHeadgear':True,'independent':True}
   if n==15:item['mouthReleaseAnchor']={'attachment':'head.mouth','maskDoesNotSuppressAttack':True,'owner':'04-07/04-09'}
   if n in [18,19,20]:
    w,h=images[masterkey].size;mask=Image.new('RGBA',(w,h));ImageDraw.Draw(mask).line([(max(0,w//2-1),h//2),(w//2,h//2+1),(max(0,w//2-1),min(h-1,h//2+2))],fill=(33,33,46,255));k=part(node+'_broken',mask,'procedural-condition-overlay',[{'op':'broken-crack','size':[w,h]}]);item['modes'].append({'node':'Broken','part':k,'visibleWhen':'condition==0','identity':id})
   if n==22:item['presentation']='stored-only';item['wornWhenNested']=False
   if n in [23,24]:item['presentation']='worn-only-in-backpack-slot';item['wornWhenNested']=False
  elif n in [2,3,4,5,6,7]:
   item['slot']='either-logical-hand';item['usageLabel']='Logical left/right hand attachments; natural scale1; body fits owned04-06/07'
   grip=[images[masterkey].width//2,max(0,images[masterkey].height-3)] if n not in [2,7] else ([2,2] if n==2 else [7,9])
   for hand in ['left','right']:
    component('held-'+hand,attachment='hand.'+hand,pivot=grip);component('corpse-'+hand,rotation=math.pi/2,attachment='corpse.hand.'+hand,pivot=grip)
   if n==2:
    component('nocked-arrow',attachment='bow.nock',pivot=[0,2]);component('flying-arrow',attachment='projectile.origin',pivot=[0,2]);item['ammoVisibleWhen']='opposite-hand stack count>0';item['recoverableProjectile']=False
   else:
    w,h=images[masterkey].size;mask=Image.new('RGBA',(w,h));draw=ImageDraw.Draw(mask);draw.line([(max(0,w//2-1),h//2),(w//2,h//2+1),(max(0,w//2-1),min(h-1,h//2+2))],fill=(33,33,46,255));k=part(node+'_broken',mask,'procedural-condition-overlay',[{'op':'broken-crack','size':[w,h]}]);item['modes'].append({'node':'Broken','part':k,'visibleWhen':'condition==0','identity':id})
   if n==7:
    # Reuse the exact bow master; string/limb transforms belong to the later bow action rig.
    for name in ['drawn-bow','released-bow']:component(name,attachment='bow.grip',pivot=grip)
    arrow=images['IT_02_master'];k=part(node+'_nocked',arrow,'donors/common.s0.6885.png',[{'op':'alpha-threshold','value':128}]);item['modes'].append({'node':'Nocked','part':k,'visibleWhen':'opposite-hand arrows>0 and bow usable','identity':'IT-02'});item['emptyArrowHand']='no nocked layer';item['actionRigOwner']='04-09'
  elif n in [8,9,10]:
   item['usageLabel']='Food-use component from the canonical master; no cooked/raw mechanic';component('food-use',attachment='hand.food');component('corpse-storage',rotation=math.pi/2,attachment='inventory.hidden')
  else:item['usageLabel']='Physical currency icon; count is a UI overlay, no global wallet';component('stored',attachment='inventory.hidden')
  items.append(item)
 pack={'schemaVersion':1,'id':which,'version':1,'stylePrecedence':'Current D-13 SIMPLE LOW-RESOLUTION OVERRIDES older rich sprite skill examples','commonBundleSha256':sha((ROOT/'production/phase4/common-selected.zip').read_bytes()),'scaleDecision':'D-13-pilot-1','logicalPixelsPerWorldPixel':1,'atlas':{'path':'assets/equipment/'+which+'.png',**info(atlas),'sha256':sha(png(atlas))},'items':items,'parts':parts,'preview':{'scene':'inspection/'+sceneName,'root':sceneName[:-5],'selectionPlayer':'Selection','statePlayer':'State','zoomPlayer':'ZoomPlayer','zooms':[1,2,4,8],'integrationOwner':'04-23','currentHubReachability':'pending-04-23'},'donorSuitability':[{'family':'K20','decision':'Reuse coin7856/bow7008/arrow6885 exact selected art; adaptations explicitly identified'},{'family':'K04','decision':'Compose three exact2x2 purple berry crops from11340; do not confuse with orchard apples'},{'family':'K05','decision':'8203 has13x3/13x4 flattened orchard fragments, not a legible complete apple; generated full apple retains source reference'},{'family':'K14','decision':'Humanoid clothing is baked into tiny bodies; retain exact reference source ingredients and generate missing removable garment masters'}],'acceptance':{'visual':'pending','humanApproval':None,'owner':'04-32/04-33','completedObligations':[]},'publication':{'kind':'validated-standalone','indexAdoptionOwner':'04-23','manifestPublishedLast':True},'recipe':{'member':'recipes/build-items.py','sha256':sha(pathlib.Path(__file__).read_bytes()),'toolPins':{'Python':'3.12.14','Pillow':'13.0.0'}}}
 if not wearables:pack['donorSuitability'][-1]['decision']='Humanoid clothing is baked into tiny bodies; later wearable generation/reuse retains source palette/ingredients'
 sceneBytes=scene(pack);pack['preview']['sha256']=sha(sceneBytes);pack['preview']['artNode']='ArtScroll/Canvas/Art';pack['preview']['viewport']=[680,320];pack['preview']['logicalWindow']=[1280,720]
 if not wearables:
  legacy=(WORK/'original-weapons.tscn').read_bytes();assert sha(legacy)=='e6657e1e02bb4977a8f9f23b8c5baab7a7cd9210f88db07e20ddf6b44a51a1ae';members['history/pre-scroll.tscn']=legacy;pack['preview']['originalOverflowSha256']=sha(legacy)
 members[sceneName]=sceneBytes;members[which+'.png']=png(atlas);members['recipes/build-items.py']=pathlib.Path(__file__).read_bytes();members[which+'.json']=js(pack)
 # Self-contained source proofs are artwork assemblies, not rendered game screenshots.
 board=Image.new('RGBA',(len(items)*48,100),(24,37,43,255))
 for i,item in enumerate(items):
  im=images[item['canonicalIcon']];board.alpha_composite(im.resize((im.width*3,im.height*3),Image.Resampling.NEAREST),(i*46+3,5))
 members['proofs/icons-nearest3x.png']=png(board)
 members['members.json']=js([{'path':k,'bytes':len(v),'sha256':sha(v)} for k,v in sorted(members.items())])
 with zipfile.ZipFile(out/(which+'.zip'),'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,raw in sorted(members.items()):z.writestr(name,raw)
 for name in [which+'.json',which+'.png',sceneName]:(out/name).write_bytes(members[name])
 print(json.dumps({'stage':str(out),'items':len(items),'parts':len(parts),'members':len(members),'atlas':info(atlas)}))
if __name__=='__main__':build(sys.argv[1])
